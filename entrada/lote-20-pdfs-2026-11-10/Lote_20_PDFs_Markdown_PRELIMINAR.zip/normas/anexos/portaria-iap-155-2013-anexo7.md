---
anexo: "ANEXO 7"
norma_mae: "[[portaria-iap-155-2013]]"
arquivo: portaria-iap-155-2013-anexo7
tipo_anexo: "termo-referencia"
estudo: "PCA"
atividades: ["triagem-residuo"]
modalidades: ["li", "regularizacao"]
tags: ["pca", "controle-ambiental", "residuo-solido-urbano"]
---

# Termo de referência para elaboração de PCA

## Texto do anexo

- **Anexo 7, linha 1** {#anexo7_lin1} 1. MEMORIAL TÉCNICO

- **Anexo 7, linha 2** {#anexo7_lin2} 1.1. Informações sobre os resíduos

- **Anexo 7, linha 3** {#anexo7_lin3} a) origem dos resíduos;

- **Anexo 7, linha 4** {#anexo7_lin4} b) composição dos resíduos, com indicação das frações de resíduos orgânicos e inorgânicos, recicláveis e de rejeitos;

- **Anexo 7, linha 5** {#anexo7_lin5} c) quantidade diária e mensal a ser recebida na área;

- **Anexo 7, linha 6** {#anexo7_lin6} d) freqüência e horário de recebimento.

- **Anexo 7, linha 7** {#anexo7_lin7} 1.2. Concepção e justificativa de projeto

- **Anexo 7, linha 8** {#anexo7_lin8} Devem ser apresentadas a concepção e a metodologia de operação, justificando face às suas finalidades.

- **Anexo 7, linha 9** {#anexo7_lin9} 1.3. Descrição e especificações do projeto

- **Anexo 7, linha 10** {#anexo7_lin10} Todos os elementos de projeto devem ser suficientemente descritos e especificados, com apresentação de desenhos, esquemas, detalhes, cálculos, etc.

- **Anexo 7, linha 11** {#anexo7_lin11} 1.3.1. Disposição dos resíduos Especificar o local e a forma como os resíduos serão armazenados e dispostos, antes e depois da triagem.

- **Anexo 7, linha 12** {#anexo7_lin12} 1.3.2. Acessos e isolamento da área Apresentar a forma de isolamento do empreendimento e os dispositivos de segurança para evitar a interferência de pessoas estranhas e animais, bem como para coibir possíveis efeitos na vizinhança.

- **Anexo 7, linha 13** {#anexo7_lin13} 1.3.3. Fluxograma e descrição detalhada do processo Apresentar uma descrição da atividade, bem como um fluxograma detalhado da operação, contendo todas as atividades realizadas no empreendimento. Obs.: Quando houver utilização de simbologia ou abreviatura, anexar ao fluxograma legenda explicativa.

- **Anexo 7, linha 14** {#anexo7_lin14} 1.3.4. Descrição do sistema de captação de água, limpeza do barracão , estruturas e drenagem Quando existirem áreas descobertas de estocagem de resíduos, contemplar sistema de prevenção para a não contaminação das águas pluviais. Detalhar sistemas de drenagem, impermeabilização e contenção.

- **Anexo 7, linha 15** {#anexo7_lin15} 1.3.5. Instalações de apoio Deverão ser descritas as instalações de apoio a serem instaladas na área. Detalhar o abastecimento de água e o esgotamento sanitário nas instalações.

- **Anexo 7, linha 16** {#anexo7_lin16} 1.3.6. Controle Ambiental Detalhar as medidas de controle ambiental a serem adotadas, bem como de controle de vetores. Especificar a possível geração de rejeitos e efluentes, e a destinação a ser dada.

- **Anexo 7, linha 17** {#anexo7_lin17} 1.4. Equipe de trabalho e equipamentos

- **Anexo 7, linha 18** {#anexo7_lin18} a) Quantificar a equipe de trabalho;

- **Anexo 7, linha 19** {#anexo7_lin19} b) Adoção de equipamentos de proteção individual - EPI

- **Anexo 7, linha 20** {#anexo7_lin20} c) Especificar e quantificar os equipamentos a serem utilizados na operação do empreendimento, tais como veículos, balanças de pesagem, mesas de triagem manual, esteira mecânicas, prensas elétricas, entre outros.

- **Anexo 7, linha 21** {#anexo7_lin21} 2. REPRESENTAÇÃO GRÁFICA

- **Anexo 7, linha 22** {#anexo7_lin22} Planta da concepção geral Devem ser apresentados em um único desenho georeferenciado os seguintes elementos:

- **Anexo 7, linha 23** {#anexo7_lin23} a) localização geográfica do barracão;

- **Anexo 7, linha 24** {#anexo7_lin24} b) acessos principais e instalações de apoio;

- **Anexo 7, linha 25** {#anexo7_lin25} c) cursos de água e poços existentes na região.

- **Anexo 7, linha 26** {#anexo7_lin26} Planta com indicação das áreas de deposição de resíduos sólidos

- **Anexo 7, linha 27** {#anexo7_lin27} a) indicação das áreas de deposição dos resíduos sólidos;

- **Anexo 7, linha 28** {#anexo7_lin28} b) limites da área total a ser utilizada;

- **Anexo 7, linha 29** {#anexo7_lin29} c) apresentação do perfil original do terreno, com as devidas cotas, e identificação do nível d’água subterrânea;

- **Anexo 7, linha 30** {#anexo7_lin30} d) cortes longitudinais e transversais, onde necessário, para melhor visualização dos elementos do sistema.

- **Anexo 7, linha 31** {#anexo7_lin31} Planta com representação da área e vegetação

- **Anexo 7, linha 32** {#anexo7_lin32} a) indicação do isolamento da área;

- **Anexo 7, linha 33** {#anexo7_lin33} c) indicação da área de Reserva Legal;

- **Anexo 7, linha 34** {#anexo7_lin34} d) indicação das áreas de Preservação Permanente;

- **Anexo 7, linha 35** {#anexo7_lin35} e) indicação de demais áreas com presença de vegetação, se aplicável.

- **Anexo 7, linha 36** {#anexo7_lin36} Apresentação das plantas As pranchas de desenho e demais peças deverão possuir identificação contendo:

- **Anexo 7, linha 37** {#anexo7_lin37} a) Denominação e local da obra;

- **Anexo 7, linha 38** {#anexo7_lin38} b) Nome da entidade executora;

- **Anexo 7, linha 39** {#anexo7_lin39} c) Tipo de projeto;

- **Anexo 7, linha 40** {#anexo7_lin40} d) Data;

- **Anexo 7, linha 41** {#anexo7_lin41} e) Nome do responsável técnico, número de registro no CREA e sua assinatura.

## Síntese do conversor (não é texto normativo)

O PCA do barracão caracteriza os resíduos, justifica a concepção do projeto e descreve a operação. Especifica armazenamento antes e depois da triagem, isolamento, acessos, fluxograma, água, limpeza, drenagem, impermeabilização e contenção; instalações de apoio, controles ambientais e de vetores, rejeitos, efluentes, equipe e equipamentos. As plantas apresentam a concepção geral, áreas de deposição, limites, terreno, nível de água subterrânea, cortes, isolamento e vegetação.

Fluxograma é a representação da sequência de operações; o próprio termo exige legenda para símbolos e abreviaturas. A representação gráfica deve identificar a obra, entidade executora, tipo de projeto, data e responsável técnico.

Fonte da síntese: o texto deste anexo, transcrito acima. As explicações não acrescentam exigências normativas.

## Notas de transcrição

- Fonte: portaria IAP 155 2013(1).pdf (portal Sistema de Informações Ambientais do Paraná). Foram retirados os marcadores de página da extração e reunidas as quebras de linha; mantidas as grafias do texto fornecido.
- A transcrição foi feita a partir do texto extraído disponível. A comparação palavra por palavra com a extração local do PDF e a conferência visual não foram concluídas nesta etapa.
