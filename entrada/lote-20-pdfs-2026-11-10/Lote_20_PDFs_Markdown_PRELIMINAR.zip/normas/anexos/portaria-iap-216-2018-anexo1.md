---
anexo: "ANEXO 1"
norma_mae: "[[portaria-iap-216-2018]]"
arquivo: portaria-iap-216-2018-anexo1
tipo_anexo: "termo-referencia"
estudo: "RAS"
atividades: ["empreendimento-imobiliario", "habitacao-interesse-social"]
modalidades: ["lp"]
tags: ["ras", "empreendimento-imobiliario", "interesse-social"]
---

# Termo de referência — Relatório Ambiental Simplificado - RAS

## Texto do anexo

- **Anexo 1, linha 1** {#anexo1_lin1} TERMO DE REFERÊNCIA

- **Anexo 1, linha 2** {#anexo1_lin2} RELATÓRIO AMBIENTAL SIMPLIFICADO - RAS

- **Anexo 1, linha 3** {#anexo1_lin3} 1-Identificação do empreendedor:

- **Anexo 1, linha 4** {#anexo1_lin4} -Nome;

- **Anexo 1, linha 5** {#anexo1_lin5} -Razão Social;

- **Anexo 1, linha 6** {#anexo1_lin6} -Endereço completo;

- **Anexo 1, linha 7** {#anexo1_lin7} -CNPJ e Inscrição Estadual;

- **Anexo 1, linha 8** {#anexo1_lin8} 2-Identificação da empresa ou profissional responsável pela elaboração do RAS

- **Anexo 1, linha 9** {#anexo1_lin9} -Razão social ou nome completo (caso profissional autônomo);

- **Anexo 1, linha 10** {#anexo1_lin10} -Endereço completo;

- **Anexo 1, linha 11** {#anexo1_lin11} -CNPJ e Inscrição Estadual (caso empresa), nome do responsável legal, nome da pessoa de contato, e-mail e número do telefone;

- **Anexo 1, linha 12** {#anexo1_lin12} 3-Identificação, modalidade e localização do empreendimento

- **Anexo 1, linha 13** {#anexo1_lin13} -Nome do empreendimento (pode ser alterado durante processo de licenciamento);

- **Anexo 1, linha 14** {#anexo1_lin14} -Modalidade quanto a:

- **Anexo 1, linha 15** {#anexo1_lin15} • Parcelamento do solo para loteamento ou desmembramento

- **Anexo 1, linha 16** {#anexo1_lin16} • Condomínios para fins habitacionais, industriais ou comerciais;

- **Anexo 1, linha 17** {#anexo1_lin17} • Conjuntos Habitacionais;

- **Anexo 1, linha 18** {#anexo1_lin18} • Conjuntos habitacionais de interesse social

- **Anexo 1, linha 19** {#anexo1_lin19} -Planta de localização do empreendimento em relação à área do município;

- **Anexo 1, linha 20** {#anexo1_lin20} -Imagem aérea fotogramétrica (ortofoto) ou imagem de satélite (Google Earth) ou similar, com traçado da poligonal do empreendimento;

- **Anexo 1, linha 21** {#anexo1_lin21} -Relatório fotográfico contendo no mínimo 10 fotografias da área do empreendimento, com vários ângulos do terreno e respectiva localização, em planta, do local onde foram tiradas;

- **Anexo 1, linha 22** {#anexo1_lin22} 4-Plantas, laudos, projetos e estudos específicos

- **Anexo 1, linha 23** {#anexo1_lin23} -Planta ilustrativa, em escala adequada à visualização, contendo a caracterização/delimitação da área quanto aos itens abaixo: vegetação, hidrografia, relevo, infra-estrutura existente, áreas de preservação permanente e entorno do imóvel com localização com vias de acesso informando o tipo de pavimento (asfalto, anti-pó ou saibro);

- **Anexo 1, linha 24** {#anexo1_lin24} -Planta planialtimétrica, com estatística da distribuição de áreas propostas para o empreendimento, apresentando as áreas destinadas ao domínio público (sistema viário, áreas verdes e institucionais) e áreas de propriedade particular (lotes, áreas remanescentes), em escala adequada à visualização, contendo os itens abaixo: coordenadas geográficas, demarcação dos lotes do parcelamento proposto, arruamento proposto, localização das áreas destinadas a equipamentos sociais (ruas, praças, áreas verdes, etc. conforme Lei Federal 6766/79), localização da reserva legal, (quando for o caso), hidrografia e demais áreas de preservação permanente, vegetação existente classificada por tipologia;

- **Anexo 1, linha 25** {#anexo1_lin25} -Projeto básico de terraplanagem contendo: movimentação do solo, cotas de implantação do empreendimento, demonstração de áreas de corte e aterro, cálculo dos volumes finais de corte e aterro, medidas de proteção do lote visando a estabilização de taludes evitando interferências em lotes lindeiros assim como indicação de áreas de bota-fora e/ou de corte para empréstimos de solo devidamente licenciados, quando necessário;

- **Anexo 1, linha 26** {#anexo1_lin26} -Estudos do meio socioeconômico: caracterização geral do município do ponto de vista das condições sociais e econômicas da população, principais atividades econômicas, saneamento básico, equipamentos urbanos, sistema viário e de transportes, uso e ocupação do solo no entorno.

- **Anexo 1, linha 27** {#anexo1_lin27} 5-Identificação e Análise dos Impactos Ambientais

- **Anexo 1, linha 28** {#anexo1_lin28} -Identificação e avaliação qualitativa e quantitativa dos impactos ambientais decorrentes das diferentes fases dos projetos (preparação do local, instalação e operação), considerando os seus impactos sobre os meios físico, biológico e antrópico descritos no diagnóstico ambiental.

- **Anexo 1, linha 29** {#anexo1_lin29} -No estudo da identificação e avaliação dos impactos ambientais do empreendimento, deverão ser apresentados os critérios para definição e interpretação da magnitude e importância dos impactos ambientais, explicitando a metodologia utilizada na sua elaboração. Para efeito de análise, os impactos devem ser caracterizados, no mínimo, quanto ao efeito (positivo, negativo), à natureza (diretos e indiretos), à periodicidade (temporários, permanentes ou cíclicos) e à reversibilidade (reversíveis e irreversíveis).

- **Anexo 1, linha 30** {#anexo1_lin30} -Dentre todos os impactos ambientais, o RAS deverá identificar e avaliar, no mínimo, os elencados abaixo:

- **Anexo 1, linha 31** {#anexo1_lin31} 5.1-Durante a fase de instalação do empreendimento

- **Anexo 1, linha 32** {#anexo1_lin32} -Interferências e transtornos à população, no que se refere às emissões atmosféricas, ruídos e tráfego de máquinas;

- **Anexo 1, linha 33** {#anexo1_lin33} -Impactos resultantes das obras de terraplanagem (erosão e instabilidade do solo)

- **Anexo 1, linha 34** {#anexo1_lin34} -Mitigação da retirada de cobertura vegetal (quando aplicável);

- **Anexo 1, linha 35** {#anexo1_lin35} -Destinação final adequada para efluentes sanitários e resíduos sólidos gerados no canteiro de obras e demais instalações de apoio administrativo.

- **Anexo 1, linha 36** {#anexo1_lin36} 5.2-Durante a fase de ocupação do empreendimento

- **Anexo 1, linha 37** {#anexo1_lin37} -Mitigação dos impactos referentes ao incremento de população, estimada de acordo com os parâmetros de uso e ocupação do solo, adotados pela legislação urbanística municipal, para a ocupação do empreendimento

- **Anexo 1, linha 38** {#anexo1_lin38} -Estimativa do aumento da demanda por serviços públicos de educação, saúde, segurança e transporte coletivo após a ocupação da população estimada;

- **Anexo 1, linha 39** {#anexo1_lin39} -Tratamento e disposição final de efluentes sanitários do empreendimento;

- **Anexo 1, linha 40** {#anexo1_lin40} -Coleta e destino final de resíduos sólidos urbanos;

- **Anexo 1, linha 41** {#anexo1_lin41} 6-Medidas Mitigadoras e Compensatórias Com base na avaliação dos impactos ambientais significativos, para aqueles de caráter negativo deverão ser recomendadas medidas que venham a minimizá-los ou eliminá-los, justificando inclusive os impactos que não podem ser evitados ou mitigados. Indicar, nesses casos, as medidas destinadas à sua compensação. As medidas mitigadoras deverão ser classificadas quanto:

- **Anexo 1, linha 42** {#anexo1_lin42} • Ao componente ambiental afetado;

- **Anexo 1, linha 43** {#anexo1_lin43} • À fase em que deverão ser implementadas;

- **Anexo 1, linha 44** {#anexo1_lin44} • Ao caráter preventivo ou corretivo e sua eficácia;

- **Anexo 1, linha 45** {#anexo1_lin45} • À responsabilidade pela sua implementação;

- **Anexo 1, linha 46** {#anexo1_lin46} 7- Conclusões Apresentar as conclusões do Relatório Ambiental Simplificado (RAS), com base nos resultados obtidos na avaliação dos impactos ambientais, devendo esclarecer, sob o aspecto ambiental, a viabilidade ou não do empreendimento.

- **Anexo 1, linha 47** {#anexo1_lin47} 8- Anotação de Responsabilidade Técnica Anotação        de     Responsabilidade        Técnica     dos   profissionais    elaboradores       dos estudos/projetos/laudos/relatórios apresentados e dos responsáveis pela execução do empreendimento, junto aos respectivos conselhos de classe.

- **Anexo 1, linha 48** {#anexo1_lin48} 9- Referências bibliográficas Citar as referências consultadas, incluindo as páginas eletrônicas com data e hora do acesso, segundo as normas de publicação de trabalhos científicos da Associação Brasileira de Normas Técnicas – ABNT.

- **Anexo 1, linha 49** {#anexo1_lin49} Obs: todos os estudos e plantas deverão ser apresentados em meio digital, em arquivos formato PDF.

## Síntese do conversor (não é texto normativo)

O RAS identifica o empreendedor, o responsável pelo estudo e o empreendimento; caracteriza a área e apresenta plantas, laudos e projetos. A exigência de apresentação decorre das situações do [[portaria-iap-216-2018#art4_cpt_inc13|art. 4º, inciso XIII]], e não de uma exigência indistinta para todo empreendimento habitacional.

- **Diagnóstico e implantação:** localização, imagens, fotografias, distribuição das áreas, vegetação e hidrografia; projeto básico de terraplanagem e caracterização socioeconômica.
- **Impactos:** efeitos da instalação e da ocupação, incluindo emissões, ruídos, tráfego, erosão, supressão de cobertura vegetal, efluentes, resíduos e demanda por serviços públicos.
- **Resposta aos impactos:** medidas mitigadoras e compensatórias, responsáveis e fases de implantação; conclusão sobre viabilidade ambiental, responsabilidade técnica e referências.

Levantamento planialtimétrico combina a posição dos elementos com as cotas do terreno. O glossário da base explica o termo e registra sua fonte técnica: [[glossario|Glossário — levantamento planialtimétrico]].

Fonte da síntese: o texto deste anexo, transcrito acima. As explicações não acrescentam exigências normativas.

## Notas de transcrição

- Fonte: portaria IAP 216 2018.pdf (portal Sistema de Informações Ambientais do Paraná). Foram retirados os marcadores de página da extração e reunidas as quebras de linha; mantidas as grafias do texto fornecido.
- A transcrição foi feita a partir do texto extraído disponível. A comparação palavra por palavra com a extração local do PDF e a conferência visual não foram concluídas nesta etapa.
