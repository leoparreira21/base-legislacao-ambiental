---
anexo: "ANEXO 5"
norma_mae: "[[portaria-iap-155-2013]]"
arquivo: portaria-iap-155-2013-anexo5
tipo_anexo: "diretriz-estudo"
estudo: "Relatório anual"
atividades: ["triagem-residuo"]
modalidades: ["las", "lo", "regularizacao"]
tags: ["relatorio", "residuo-solido-urbano", "renovacao"]
---

# Relatório Anual de recebimento, movimentação, processamento e destinação final dos resíduos

## Texto do anexo

- **Anexo 5, linha 1** {#anexo5_lin1} Relatório Anual de recebimento, movimentação, processamento e destinação final dos resíduos, descrevendo o gerador, classificação, quantidades e tratamento/destinação final adotados.

- **Anexo 5, linha 2** {#anexo5_lin2} Este relatório deverá ser entregue na ocasião da renovação de licença ambiental simplificada, na renovação da licença de operação e na ocasião da regularização do licenciamento, e deverá ser referente a cada ano de operação. Os arquivos deverão ser mantidos na administração do empreendimento.

- **Anexo 5, linha 3** {#anexo5_lin3} O relatório deve conter as seguintes informações:

- **Anexo 5, linha 4** {#anexo5_lin4} - Período de referência do documento;

- **Anexo 5, linha 5** {#anexo5_lin5} - Informações sobre a perspectiva de reformas e ampliações no empreendimento;

- **Anexo 5, linha 6** {#anexo5_lin6} - Medidas adotadas para controle de vetores;

- **Anexo 5, linha 7** {#anexo5_lin7} - Medidas adotadas para controle ambiental;

- **Anexo 5, linha 8** {#anexo5_lin8} - Identificar os resíduos recolhidos pelo empreendimento, suas quantidades, características, geradores e pontos de coleta;

- **Anexo 5, linha 9** {#anexo5_lin9} - Descrever o processo de manuseio e triagem dos resíduos, especificando o local de armazenamento temporário e equipamentos utilizados;

- **Anexo 5, linha 10** {#anexo5_lin10} - Preencher a seguinte tabela, com os dados referentes aos resíduos já separados e possíveis rejeitos do processo:

## Síntese do conversor (não é texto normativo)

O relatório documenta cada ano de operação e acompanha a renovação da LAS, a renovação da LO ou a regularização. Deve registrar período de referência, perspectiva de reformas, controles ambientais e de vetores e a movimentação dos resíduos. Inclui a identificação dos resíduos e geradores, pontos de coleta, manuseio, triagem, armazenamento e destino dos materiais e rejeitos.

As colunas do formulário em branco são um modelo de apresentação; sua diagramação não foi reconstruída. Controle de vetores reúne medidas para prevenir a presença de animais que transmitem ou veiculam doenças; o conceito e suas fontes já constam no [[glossario|Glossário — controle de vetores e pragas urbanas]].

Fonte da síntese: o texto deste anexo, transcrito acima. As explicações não acrescentam exigências normativas.

## Notas de transcrição

- Fonte: portaria IAP 155 2013(1).pdf (portal Sistema de Informações Ambientais do Paraná). Foram retirados os marcadores de página da extração e reunidas as quebras de linha; mantidas as grafias do texto fornecido.
- A transcrição foi feita a partir do texto extraído disponível. A comparação palavra por palavra com a extração local do PDF e a conferência visual não foram concluídas nesta etapa.
- Anexo misto: transcritas as diretrizes textuais do relatório; a tabela vazia para preenchimento foi tratada como modelo, conforme a regra de anexos tipo 1. As instruções sobre preenchimento permanecem no texto.
