---
anexo: "ANEXO 4"
norma_mae: "[[portaria-iap-187-2013]]"
arquivo: portaria-iap-187-2013-anexo4
tipo_anexo: "diretriz-estudo"
estudo: "Relatório anual"
atividades: ["transbordo-residuo"]
modalidades: ["las", "lo", "regularizacao"]
tags: ["relatorio", "residuo-solido-urbano", "renovacao"]
---

# Relatório anual de recebimento, movimentação e destinação final dos resíduos

## Texto do anexo

- **Anexo 4, linha 1** {#anexo4_lin1} Relatório anual de recebimento, movimentação e destinação final dos resíduos, descrevendo o gerador, quantidades e tratamento/destinação final adotados

- **Anexo 4, linha 2** {#anexo4_lin2} Este relatório deverá ser entregue na ocasião da renovação de licença ambiental simplificada, na renovação da licença de operação e na ocasião da regularização do licenciamento, e deverá ser referente a cada ano de operação. Os certificados de destinação final, do efluente e dos resíduos, deverão ser mantidos na administração do empreendimento e entregue ao IAP junto com este Relatório.

- **Anexo 4, linha 3** {#anexo4_lin3} O Relatório deve conter as seguintes informações:

- **Anexo 4, linha 4** {#anexo4_lin4} - Período de referência do documento;

- **Anexo 4, linha 5** {#anexo4_lin5} - Informações sobre a perspectiva de reformas e ampliações no empreendimento;

- **Anexo 4, linha 6** {#anexo4_lin6} - Medidas adotadas para controle de vetores;

- **Anexo 4, linha 7** {#anexo4_lin7} - Medidas adotadas para controle ambiental;

- **Anexo 4, linha 8** {#anexo4_lin8} - Descrever o processo de transbordo dos resíduos, especificando o local e forma de transferência dos resíduos e equipamentos utilizados;

- **Anexo 4, linha 9** {#anexo4_lin9} - Preencher a tabela abaixo com as informações referentes aos resíduos (quantidades, geradores e destinação final) e quanto ao efluente (quantidade, forma de armazenamento e destino final);

## Síntese do conversor (não é texto normativo)

O relatório documenta cada ano de operação e acompanha a renovação da LAS, a renovação da LO ou a regularização. Deve registrar período de referência, perspectiva de reformas, controles ambientais e de vetores e a movimentação dos resíduos. Inclui o processo de transbordo e as informações sobre efluentes, transporte e destino, com os certificados de destinação.

As colunas do formulário em branco são um modelo de apresentação; sua diagramação não foi reconstruída. Controle de vetores reúne medidas para prevenir a presença de animais que transmitem ou veiculam doenças; o conceito e suas fontes já constam no [[glossario|Glossário — controle de vetores e pragas urbanas]].

Fonte da síntese: o texto deste anexo, transcrito acima. As explicações não acrescentam exigências normativas.

## Notas de transcrição

- Fonte: portaria IAP 187 2013(1).pdf (portal Sistema de Informações Ambientais do Paraná). Foram retirados os marcadores de página da extração e reunidas as quebras de linha; mantidas as grafias do texto fornecido.
- A transcrição foi feita a partir do texto extraído disponível. A comparação palavra por palavra com a extração local do PDF e a conferência visual não foram concluídas nesta etapa.
- Anexo misto: transcritas as diretrizes textuais do relatório; a tabela vazia para preenchimento foi tratada como modelo, conforme a regra de anexos tipo 1. As instruções sobre preenchimento permanecem no texto.
