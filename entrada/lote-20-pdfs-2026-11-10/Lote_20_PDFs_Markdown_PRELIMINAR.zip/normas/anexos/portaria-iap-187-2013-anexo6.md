---
anexo: "ANEXO 6"
norma_mae: "[[portaria-iap-187-2013]]"
arquivo: portaria-iap-187-2013-anexo6
tipo_anexo: "termo-referencia"
estudo: "PCA"
atividades: ["transbordo-residuo"]
modalidades: ["li", "regularizacao"]
tags: ["pca", "controle-ambiental", "residuo-solido-urbano"]
---

# Termo de referência para elaboração de PCA

## Texto do anexo

- **Anexo 6, linha 1** {#anexo6_lin1} 1. MEMORIAL TÉCNICO

- **Anexo 6, linha 2** {#anexo6_lin2} 1.1. Informações sobre a área

- **Anexo 6, linha 3** {#anexo6_lin3} a) Localização;

- **Anexo 6, linha 4** {#anexo6_lin4} b) Área total e área construída

- **Anexo 6, linha 5** {#anexo6_lin5} c) Distância com relação a núcleos populacionais, residências isoladas, corpos d’água e demais distanciamentos pertinentes;

- **Anexo 6, linha 6** {#anexo6_lin6} d) Acesso à área.

- **Anexo 6, linha 7** {#anexo6_lin7} 1.2. Informações sobre os resíduos

- **Anexo 6, linha 8** {#anexo6_lin8} a) Origem dos resíduos;

- **Anexo 6, linha 9** {#anexo6_lin9} b) Composição dos resíduos, com indicação das frações de resíduos orgânicos e inorgânicos, recicláveis e de rejeitos;

- **Anexo 6, linha 10** {#anexo6_lin10} c) Quantidade diária e mensal a ser recebida na área;

- **Anexo 6, linha 11** {#anexo6_lin11} d) Freqüência e horário de recebimento.

- **Anexo 6, linha 12** {#anexo6_lin12} 1.2. Concepção e justificativa de projeto Devem ser apresentadas a concepção e a metodologia de operação, justificando face às suas finalidades.

- **Anexo 6, linha 13** {#anexo6_lin13} 1.3. Descrição e especificações do projeto Todos os elementos de projeto devem ser suficientemente descritos e especificados, com apresentação de desenhos, esquemas, detalhes, cálculos, etc.

- **Anexo 6, linha 14** {#anexo6_lin14} 1.3.1. Transferência dos resíduos Especificar o local aonde ocorrerá a transferência e armazenamento e a forma como os resíduos serão transferidos, acondicionados e armazenados. Especificar o tempo total que os resíduos permaneceram na área, desde sua chegada até encaminhamento ao destino final.

- **Anexo 6, linha 15** {#anexo6_lin15} 1.3.2. Acessos e isolamento da área Apresentar a forma de isolamento do empreendimento e os dispositivos de segurança para evitar a interferência de pessoas estranhas e animais, bem como para coibir possíveis efeitos na vizinhança.

- **Anexo 6, linha 16** {#anexo6_lin16} 1.3.3. Fluxograma e descrição detalhada do processo

- **Anexo 6, linha 17** {#anexo6_lin17} Apresentar uma descrição da atividade, bem como um fluxograma detalhado da operação, contendo todas as atividades realizadas no empreendimento. Obs.: Quando houver utilização de simbologia ou abreviatura, anexar ao fluxograma legenda explicativa.

- **Anexo 6, linha 18** {#anexo6_lin18} 1.3.4. Descrição do sistema de captação de água, limpeza da área , estruturas e drenagem Detalhar sistemas de captação de água, drenagem, impermeabilização, contenção, acúmulo de efluente.

- **Anexo 6, linha 19** {#anexo6_lin19} 1.3.5. Instalações de apoio Deverão ser descritas as instalações de apoio a serem instaladas na área. Detalhar o abastecimento de água e o esgotamento sanitário nas instalações.

- **Anexo 6, linha 20** {#anexo6_lin20} 1.3.6. Controle Ambiental Detalhar as medidas de controle ambiental a serem adotadas, bem como de controle de vetores. Especificar a destinação a ser dada aos resíduos e ao efluente.

- **Anexo 6, linha 21** {#anexo6_lin21} 1.4. Equipe de trabalho e equipamentos

- **Anexo 6, linha 22** {#anexo6_lin22} a) Quantificar a equipe de trabalho;

- **Anexo 6, linha 23** {#anexo6_lin23} b) Adoção de equipamentos de proteção individual - EPI

- **Anexo 6, linha 24** {#anexo6_lin24} c) Especificar e quantificar os equipamentos/estruturas a serem utilizados na operação do empreendimento, tais como veículos, balanças de pesagem, rampa de acesso, entre outros.

- **Anexo 6, linha 25** {#anexo6_lin25} 2. REPRESENTAÇÃO GRÁFICA

- **Anexo 6, linha 26** {#anexo6_lin26} Planta da concepção geral Devem ser apresentados em desenho georeferenciado os seguintes elementos:

- **Anexo 6, linha 27** {#anexo6_lin27} a) localização geográfica da Unidade;

- **Anexo 6, linha 28** {#anexo6_lin28} b) acessos principais e instalações de apoio;

- **Anexo 6, linha 29** {#anexo6_lin29} c) corpos da água e indicação da distância com relação a Unidade.

- **Anexo 6, linha 30** {#anexo6_lin30} d) distância com relação à núcleos populacionais e residências isoladas.

- **Anexo 6, linha 31** {#anexo6_lin31} e) indicação do isolamento da área;

- **Anexo 6, linha 32** {#anexo6_lin32} f) indicação da área de Reserva Legal;

- **Anexo 6, linha 33** {#anexo6_lin33} g) indicação das áreas de Preservação Permanente;

- **Anexo 6, linha 34** {#anexo6_lin34} j) indicação de demais áreas com presença de vegetação, se aplicável.

- **Anexo 6, linha 35** {#anexo6_lin35} Planta com detalhes da Unidade de Transbordo

- **Anexo 6, linha 36** {#anexo6_lin36} a) limites da área total a ser utilizada;

- **Anexo 6, linha 37** {#anexo6_lin37} b) área de transferência dos resíduos

- **Anexo 6, linha 38** {#anexo6_lin38} c) rampa de acesso

- **Anexo 6, linha 39** {#anexo6_lin39} d) sistema de cobertura

- **Anexo 6, linha 40** {#anexo6_lin40} e) estrutura

- **Anexo 6, linha 41** {#anexo6_lin41} f) sistema de drenagem, caixa de acúmulo de efluente

- **Anexo 6, linha 42** {#anexo6_lin42} g) cortes longitudinais e transversais, onde necessário, para melhor visualização dos elementos do sistema.

- **Anexo 6, linha 43** {#anexo6_lin43} Apresentação das plantas As pranchas de desenho e demais peças deverão possuir identificação contendo:

- **Anexo 6, linha 44** {#anexo6_lin44} a) Denominação e local da obra;

- **Anexo 6, linha 45** {#anexo6_lin45} b) Nome da entidade executora;

- **Anexo 6, linha 46** {#anexo6_lin46} c) Tipo de projeto;

- **Anexo 6, linha 47** {#anexo6_lin47} d) Data;

- **Anexo 6, linha 48** {#anexo6_lin48} e) Nome do responsável técnico, número de registro no CREA e sua assinatura.

## Síntese do conversor (não é texto normativo)

O PCA da unidade de transbordo descreve a área, os resíduos, a concepção e a operação, inclusive o local e a forma de transferência, acondicionamento, armazenamento e tempo de permanência. Deve detalhar isolamento, acessos, sistemas de água, drenagem, impermeabilização, contenção, acúmulo e destinação de efluentes; controles ambientais e de vetores, equipe e equipamentos. As plantas apresentam localização, corpos hídricos e distâncias, áreas protegidas, isolamento e detalhes da unidade.

Fluxograma é a representação da sequência de operações; o próprio termo exige legenda para símbolos e abreviaturas. A representação gráfica deve identificar a obra, entidade executora, tipo de projeto, data e responsável técnico.

Fonte da síntese: o texto deste anexo, transcrito acima. As explicações não acrescentam exigências normativas.

## Notas de transcrição

- Fonte: portaria IAP 187 2013(1).pdf (portal Sistema de Informações Ambientais do Paraná). Foram retirados os marcadores de página da extração e reunidas as quebras de linha; mantidas as grafias do texto fornecido.
- A transcrição foi feita a partir do texto extraído disponível. A comparação palavra por palavra com a extração local do PDF e a conferência visual não foram concluídas nesta etapa.
- A numeração e as letras do original foram preservadas, inclusive as sequências repetidas ou descontínuas.
