---
norma: "Resolução SEDEST nº 51/2019"
arquivo: resolucao-sedest-51-2019
tipo: resolucao
esfera: estadual
uf: PR
numero: 51
ano: 2019
data_assinatura: 2019-11-19
ementa: "Estabelece normas e critérios para o licenciamento ambiental de Armazenadoras de Produtos Agrotóxicos, seus componentes e afins, tais como Armazéns Gerais ou Centros de Distribuição, Armazenamento Comercial em distribuidores ou cooperativas e depósitos para uso final."
situacao: revogada
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: ["[[resolucao-sedest-26-2020]]"]
revoga: ["[[resolucao-sema-28-2016]]"]
revogado_por: ["[[decreto-estadual-9541-2025]]"]
cita: ["[[decreto-estadual-1440-2019]]", "[[decreto-estadual-6674-2002]]", "[[decreto-federal-4074-2002]]", "[[lei-estadual-10066-1992]]", "[[lei-estadual-10233-1992]]", "[[lei-estadual-12493-1999]]", "[[lei-federal-19848-2019]]", "[[lei-federal-6938-1981]]", "[[lei-federal-7802-1989]]", "[[lei-federal-9605-1998]]", "[[portaria-iap-159-2015]]", "[[resolucao-cema-65-2008]]", "[[resolucao-cema-70-2009]]", "[[resolucao-conama-6-1986]]", "[[resolucao-sema-28-2016]]"]
tags: ["agrotoxico", "agua-subterranea", "app", "armazenamento-agrotoxico", "definicao", "documentacao", "efluente", "eia-rima", "enquadramento", "li", "licenciamento-ambiental", "lo", "lp", "monitoramento", "prazo", "redacao-alterada", "renovacao", "residuo-solido", "responsavel-tecnico"]
fonte: "PDF fornecido: sedest 51 2019(1).pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
texto: "compilado segundo as alterações explícitas no PDF fornecido; conferência visual pendente"
---

# Resolução SEDEST nº 51/2019

> Estabelece normas e critérios para o licenciamento ambiental de Armazenadoras de Produtos Agrotóxicos, seus componentes e afins, tais como Armazéns Gerais ou Centros de Distribuição, Armazenamento Comercial em distribuidores ou cooperativas e depósitos para uso final.

## Preâmbulo

Resolução 051 - 19 de Novembro de 2019 Publicado no Diário Oficial nº. 10567 de 20 de Novembro de 2019 Súmula: Estabelece normas e critérios para o licenciamento ambiental de Armazenadoras de Produtos Agrotóxicos, seus componentes e afins, tais como Armazéns Gerais ou Centros de Distribuição, Armazenamento Comercial em distribuidores ou cooperativas e depósitos para uso final. O SECRETÁRIO DE ESTADO DO DESENVOLVIMENTO SUSTENTÁVEL E DO TURISMO, designado pelo [[decreto-estadual-1440-2019|Decreto Estadual nº 1440, de 23 de maio de 2019]], no uso das atribuições que lhe são conferidas pela Lei Estadual nº [[lei-federal-19848-2019|Lei nº 19.848, de 03 de maio de 2019]] e [[lei-estadual-10066-1992|Lei n° 10.066, de 27 de julho de 1992]] e, Considerando que a proteção do meio ambiente é um dever do Poder Público, conforme dispõe o Art. 225, § 1º, da Constituição Federal; Considerando que cabe ao Poder Público controlar a produção, a comercialização e o emprego de técnicas, métodos e substâncias que comportem risco para a vida, a qualidade de vida e o meio ambiente nos termos do Art. 225 §1º, V, da Constituição Federal; Considerando que cabe ao Poder Público Estadual regulamentar e controlar a produção, a comercialização, as técnicas e os métodos de manejo e utilização das substâncias que comportem risco para a vida e para o meio ambiente, em especial agrotóxicos, biocidas, anabolizantes, produtos nocivos em geral e resíduos nucleares, nos termos do Art. 207, § 1º, VIII, da Constituição Estadual do Paraná; Considerando que compete aos Estados e ao Distrito Federal, nos termos do Art. 23, incisos VI, VII e VIII e Art. 24, da Constituição Federal, legislar sobre o uso, a produção, o consumo, o comércio e o armazenamento dos agrotóxicos, seus componentes e afins; Considerando a necessidade de dar efetividade ao princípio da prevenção, consagrado na Política Nacional de Meio Ambiente - [[lei-federal-6938-1981|Lei nº 6.938, de 31 de agosto de 1981]], em seu Art. 2º, incisos I, IV e IX, bem como no princípio nº 15, da Declaração do Rio de Janeiro de 1992; e Considerando que o licenciamento ambiental é requisito para o registro do estabelecimento, de acordo com a [[lei-federal-7802-1989|Lei Federal nº 7802/89]], Art. 10; e [[decreto-federal-4074-2002|Decreto Federal nº 4074/02]] em seu Art. 62 e no Anexo V, item 9.1, RESOLVE:

###### Art. 1º {#art1}
Tags: #agrotoxico #armazenamento-agrotoxico #licenciamento-ambiental

**Art. 1º, caput** {#art1_cpt} #licenciamento-ambiental Estabelecer requisitos e condições técnicas para o Licenciamento ambiental de Armazenadoras de Produtos Agrotóxicos, seus componentes e afins, tais como Armazéns Gerais ou Centros de Distribuição, Armazenamento Comercial em distribuidores ou cooperativas e depósitos para uso final.

###### Art. 2º {#art2}
Tags: #agrotoxico #armazenamento-agrotoxico #eia-rima #enquadramento #licenciamento-ambiental #monitoramento #prazo #residuo-solido

**Art. 2º, caput** {#art2_cpt} Para efeito desta Resolução consideram-se:
- **Art. 2º, caput, inciso I** {#art2_cpt_inc1} Armazém: espaço físico para guardar, estocar e manter Produtos Agrotóxicos, seus componentes e afins, contratado para prestação de serviços de armazenamento e expedição, em condições que garantam a saúde e segurança do trabalhador, segurança ambiental e a integridade e segurança dos produtos;
- **Art. 2º, caput, inciso II** {#art2_cpt_inc2} Armazém Geral: espaço físico para guardar, estocar e manter Produtos Agrotóxicos, seus componentes e afins, contratado para prestação de serviços de armazenamento e expedição, mediante remuneração pela indústria e/ou outro contratante, em condições que garantam a saúde e segurança do trabalhador, segurança ambiental e a integridade e segurança dos produtos;
- **Art. 2º, caput, inciso III** {#art2_cpt_inc3} Armazenadoras de Produtos Agrotóxicos, seus componentes e afins: todas as pessoas jurídicas ou físicas que armazenem Produtos Agrotóxicos, seus componentes e afins, com ou sem finalidade comercial, para prestação de serviços fitossanitários, para uso final ou para armazenagem logística;
- **Art. 2º, caput, inciso IV** {#art2_cpt_inc4} #enquadramento Armazenagem logística: atividade desenvolvida por pessoa física ou jurídica que consiste em guarda, armazenagem, transbordo e transporte para terceiros;
- **Art. 2º, caput, inciso V** {#art2_cpt_inc5} #prazo Autorização Ambiental ou florestal: ato administrativo discricionário pelo qual o Órgão Ambiental Competente estabelece condições, restrições e medidas de controle ambiental ou florestal de empreendimentos ou atividades específicas, com prazo de validade estabelecido de acordo com a natureza do empreendimento ou atividade, passível de prorrogação, a critério do Órgão Ambiental Competente;
- **Art. 2º, caput, inciso VI** {#art2_cpt_inc6} Centros de Distribuição: espaço físico para guardar, estocar e manter Produtos Agrotóxicos, seus componentes e afins, contratado para prestação de serviços de armazenamento e expedição, mediante remuneração pela indústria e/ou outro contratante, em condições que garantam a saúde e segurança do trabalhador, segurança ambiental e a integridade e segurança dos produtos, onde o contratante abre uma filial fiscal;
- **Art. 2º, caput, inciso VII** {#art2_cpt_inc7} Depósito sem fins comerciais: espaço físico sem fins comerciais, utilizado para guardar, estocar, conter e manter Produtos Agrotóxicos, seus componentes e afins, em condições que garantam a saúde e segurança do trabalhador, segurança ambiental e a integridade e segurança dos produtos, destinados para uso próprio. Pode estar localizado em propriedades rurais ou área urbana;
- **Art. 2º, caput, inciso VIII** {#art2_cpt_inc8} Estabelecimento para comércio de produtos Agrotóxicos, seus componentes e afins - sem armazenagem: Empresa que comercializa agrotóxico e não armazena os produtos em suas dependências, apenas realiza a operação de compra e venda, ou seja, compra do fabricante ou de um revendedor e encaminha o agrotóxico direto ao usuário final, sem necessidade de armazenagem;
- **Art. 2º, caput, inciso IX** {#art2_cpt_inc9} #eia-rima #residuo-solido Estudos Ambientais: todos e quaisquer estudos relativos aos aspectos ambientais relacionados à localização, instalação, operação e ampliação de um empreendimento, atividade ou obra, apresentado como subsídio para a análise da licença ou autorização requerida, tais como: estudo de impacto ambiental/relatório de impacto ambiental - EIA/RIMA, relatório ambiental preliminar- RAP, projeto básico ambiental- PBA, plano de controle ambiental - PCA, plano de recuperação de área degradada - PRAD, plano de gerenciamento de resíduos sólidos - PGRS, análise de risco -AR, projeto de controle de poluição ambiental - PCPA, avaliação ambiental integrada ou estratégica – AAI ou AAE e outros;
- **Art. 2º, caput, inciso X** {#art2_cpt_inc10} Licença Ambiental: ato administrativo pelo qual o órgão ambiental competente estabelece as condições, restrições e medidas de controle ambiental que deverão ser obedecidas pelo empreendedor, pessoa física ou jurídica, para localizar, instalar, ampliar e operar empreendimentos ou atividades utilizadoras dos recursos ambientais consideradas efetiva ou potencialmente poluidoras ou aquelas que, sob qualquer forma, possam causar degradação e/ou modificação ambiental;
- **Art. 2º, caput, inciso XI** {#art2_cpt_inc11} #licenciamento-ambiental Licenciamento Ambiental: procedimento administrativo pelo qual o órgão ambiental competente, verificando a satisfação das condições legais e técnicas, licencia a localização, instalação, ampliação e a operação de empreendimentos e atividades utilizadoras de recursos ambientais consideradas efetivas ou potencialmente poluidoras ou daquelas que, sob qualquer forma, possam vir a causar degradação e/ou modificação ambiental, considerando as disposições legais e regulamentares e as normas técnicas aplicáveis ao caso;
- **Art. 2º, caput, inciso XII** {#art2_cpt_inc12} Local de reunião de público - o espaço destinado ao agrupamento de pessoas, em imóvel de uso coletivo, público ou não, sendo eles: escolas, creches, postos de saúde, hospitais, locais de cultos religiosos, casas de repouso;
- **Art. 2º, caput, inciso XIII** {#art2_cpt_inc13} #enquadramento #licenciamento-ambiental #monitoramento Sistema de Gestão Ambiental – SGA: Módulo Licenciamento, sistema informatizado para emissão de licenças ambientais, permitindo aos usuários a requisição de licenças pela internet, além de disponibilizar consultas e outras informações. É integrada com uma base de dados georreferenciados que serve de apoio à tomada de decisão na emissão de pareceres e laudos técnicos, bem como na decisão administrativa, além de dar suporte aos módulos de monitoramento e fiscalização;
- **Art. 2º, caput, inciso XIV** {#art2_cpt_inc14} Termo de Ajustamento de Conduta: instrumento que tem por finalidade estabelecer obrigações do compromissário, em decorrência de sua responsabilidade civil, de forma a ajustar a sua conduta às exigências legais, mediante cominações, que terá eficácia de título executivo extrajudicial;
- **Art. 2º, caput, inciso XV** {#art2_cpt_inc15} Termo de Compromisso: instrumento pelo qual o causador de infração administrativa ambiental compromete-se a adotar medidas específicas determinadas pelo órgão ambiental de forma a reparar e fazer cessar os danos causados ao meio ambiente; e
- **Art. 2º, caput, inciso XVI** {#art2_cpt_inc16} Usuário final: Pessoa Física ou Jurídica que faz uso de agrotóxicos, seus componentes e afins.

###### Art. 3º {#art3}
Tags: #agrotoxico #armazenamento-agrotoxico #documentacao #li #licenciamento-ambiental #lo #lp #prazo

**Art. 3º, caput** {#art3_cpt} O Órgão Ambiental no exercício de sua competência de controle ambiental expedirá os seguintes atos administrativos:
- **Art. 3º, caput, inciso I** {#art3_cpt_inc1} #documentacao #prazo Autorização Ambiental Florestal – AAF: documento expedido pelo Órgão Ambiental Competente que permite ao proprietário de um imóvel a condição de efetuar o corte de vegetação florestal nativa, árvores isoladas em ambiente florestal ou agropecuário e aproveitamento material lenhoso seco, sendo os prazos estabelecidos no anexo IV da [[resolucao-cema-65-2008|Resolução CEMA 065/2008]], ou outra a que vier substituí-la;
- **Art. 3º, caput, inciso II** {#art3_cpt_inc2} #licenciamento-ambiental Declaração de Dispensa de Licenciamento Ambiental Estadual – DLAE - concedida para os empreendimentos cujo licenciamento ambiental não compete ao órgão ambiental estadual, conforme os critérios estabelecidos em resoluções específicas;
- **Art. 3º, caput, inciso III** {#art3_cpt_inc3} #lp Licença Prévia - LP - Concedida na fase preliminar do planejamento do empreendimento ou atividade, aprovando sua localização e concepção, atestando a viabilidade ambiental e estabelecendo os requisitos básicos e condicionantes a serem atendidos nas próximas fases de sua implementação;
- **Art. 3º, caput, inciso IV** {#art3_cpt_inc4} #li Licença de Instalação - LI - Autoriza a instalação do empreendimento ou atividade de acordo com as especificações constantes dos planos, programas e projetos aprovados, incluindo as medidas de controle ambiental e demais condicionantes; e
- **Art. 3º, caput, inciso V** {#art3_cpt_inc5} #lo Licença de Operação - LO - Autoriza o funcionamento da atividade ou empreendimento, após a verificação do efetivo cumprimento do que consta das licenças anteriores, com as medidas de controle ambientais e condicionantes determinados para a operação.

###### Art. 4º {#art4}
Tags: #agrotoxico #armazenamento-agrotoxico #licenciamento-ambiental

**Art. 4º, caput** {#art4_cpt} #licenciamento-ambiental As unidades Armazenadoras de Produtos Agrotóxicos, seus componentes e afins deverão ser submetidos ao processo de licenciamento ambiental, nos termos desta Resolução e dos demais dispositivos legais cabíveis.

###### Art. 5º {#art5}
Tags: #agrotoxico #armazenamento-agrotoxico #efluente #enquadramento #licenciamento-ambiental #residuo-solido

**Art. 5º, caput** {#art5_cpt} #licenciamento-ambiental Ficam dispensados do Licenciamento Ambiental Estadual:
- **Art. 5º, caput, inciso I** {#art5_cpt_inc1} os depósitos sem fins comerciais, de produtos Agrotóxicos, seus componentes e afins, inclusive os localizados em propriedades rurais, obedecidos os critérios desta Resolução; e
- **Art. 5º, caput, inciso II** {#art5_cpt_inc2} os estabelecimentos para comércio de produtos Agrotóxicos, seus componentes e afins, sem armazenagem.

**Art. 5º, § 1º** {#art5_par1} #enquadramento #licenciamento-ambiental Os empreendimentos enquadrados no caput deste artigo não são obrigados a requerer a Declaração de Dispensa de Licenciamento Ambiental Estadual (DLAE).

**Art. 5º, § 2º** {#art5_par2} #licenciamento-ambiental A DLAE poderá ser requerida, nos casos em que seja necessária a comprovação de dispensa de licenciamento ambiental estadual, no SGA, mediante a prestação das informações necessárias.

**Art. 5º, § 3º** {#art5_par3} Qualquer alteração em um dos critérios estabelecidos no caput deste artigo, o interessado deverá solicitar a Licença Ambiental.

**Art. 5º, § 4º** {#art5_par4} #efluente #residuo-solido A DLAE não exime o dispensado das exigências legais ambientais, com a correta destinação de efluentes e resíduos.

###### Art. 6º {#art6}
Tags: #agrotoxico #armazenamento-agrotoxico #licenciamento-ambiental

**Art. 6º, caput** {#art6_cpt} #licenciamento-ambiental São passíveis de licenciamento ambiental os empreendimentos com as características constantes no quadro abaixo.

> **Pendência de transcrição — Art. 6, quadro/tabela** {#art6_tab1}. Conteúdo preservado na extração textual que acompanha o lote; falta conferência visual das colunas. Não é texto normativo transcrito.


###### Art. 7º {#art7}
Tags: #agrotoxico #app #armazenamento-agrotoxico #documentacao #li #licenciamento-ambiental #lo #lp #prazo #renovacao #residuo-solido #responsavel-tecnico

**Art. 7º, caput** {#art7_cpt} #documentacao #licenciamento-ambiental Os requerimentos de Licenciamento Ambiental de Armazenadoras de Produtos Agrotóxicos, seus componentes e afins deverão ser protocolados através do Sistema de Gestão Ambiental - SGA, disponível no site do órgão ambiental, instruídos na forma prevista abaixo, respeitando-se a modalidade solicitada:

**Art. 7º, § 1º** {#art7_par1} #documentacao #lp São documentos necessários para o requerimento de Licença Prévia - LP:
- **Art. 7º, § 1º, alínea "a"** {#art7_par1_alia} #documentacao #prazo matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente com data de no máximo 90 (noventa) dias, e em caso de imóvel locado, nome do locador junto com o contrato de locação, ou documento de propriedade, ou justa posse rural ou conforme exigências constantes no Capítulo VI, Seção VI da [[resolucao-cema-65-2008|Resolução CEMA 065 de 01 de julho de 2008]], ou outra que vier a substituí-la;
- **Art. 7º, § 1º, alínea "b"** {#art7_par1_alib} #documentacao documentação complementar do imóvel, se a situação imobiliária estiver irregular ou comprometida, conforme exigências para casos imobiliários excepcionais, constantes do Capítulo VI, Seção VI da [[resolucao-cema-65-2008|Resolução CEMA 065 de 01 de julho de 2008]], ou outra que vier a substituí-la;
- **Art. 7º, § 1º, alínea "c"** {#art7_par1_alic} #documentacao Certidão do Município ou documento equivalente, declarando expressamente que o local e o tipo de empreendimento estão em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano, com a legislação municipal do meio ambiente, inclusive com relação ao entorno de unidades de conservação municipais, e que atende as demais exigências legais e administrativas perante o município (Anexo I);
- **Art. 7º, § 1º, alínea "d"** {#art7_par1_alid} croqui de localização do empreendimento com imagem aérea atualizada e contendo no mínimo:
  - **Art. 7º, § 1º, alínea "d", item 1** {#art7_par1_alid_ite1} quanto ao disposto nos Arts. 9º e 10 desta Resolução distância dos corpos hídricos;
  - **Art. 7º, § 1º, alínea "d", item 2** {#art7_par1_alid_ite2} #app indicando as áreas de preservação permanente;
  - **Art. 7º, § 1º, alínea "d", item 3** {#art7_par1_alid_ite3} cobertura florestal;
  - **Art. 7º, § 1º, alínea "d", item 4** {#art7_par1_alid_ite4} vias de acesso principais; e
  - **Art. 7º, § 1º, alínea "d", item 5** {#art7_par1_alid_ite5} pontos de referências.
- **Art. 7º, § 1º, alínea "e"** {#art7_par1_alie} requerer supressão de cobertura florestal – Autorização Ambiental Florestal – AAF, quando for o caso, devendo ser avaliada nesta fase;
- **Art. 7º, § 1º, alínea "f"** {#art7_par1_alif} #lp publicação de súmula do pedido de Licença Prévia em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]]; e
- **Art. 7º, § 1º, alínea "g"** {#art7_par1_alig} recolhimento da taxa ambiental e demais valores cabíveis referentes às publicações, em caso de optar pela publicação no site do órgão ambiental competente.

**Art. 7º, § 2º** {#art7_par2} #documentacao #li São documentos necessários para o requerimento de Licença de Instalação - LI:
- **Art. 7º, § 2º, alínea "a"** {#art7_par2_alia} Cópia do Ato Constitutivo ou do Contrato Social;
- **Art. 7º, § 2º, alínea "b"** {#art7_par2_alib} #responsavel-tecnico b) Plano de Controle Ambiental – PCA, acompanhado de ART - Anotação ou Registro de Responsabilidade Técnica, conforme anexo I;
- **Art. 7º, § 2º, alínea "c"** {#art7_par2_alic} #responsavel-tecnico c) Programa de Gerenciamento de Riscos – PGR, nos empreendimentos que se enquadram nos critérios do Art. 2º da [[portaria-iap-159-2015|Portaria IAP n.º 159/2015]], com a respectiva ART, para conhecimento do Órgão Ambiental Competente;
- **Art. 7º, § 2º, alínea "d"** {#art7_par2_alid} d) Apresentar AAF em caso de necessidade de supressão florestal, antes do início das obras de instalação;
- **Art. 7º, § 2º, alínea "e"** {#art7_par2_alie} e) Plano de Segurança Contra Incêndio e Pânico aprovado (PSCIP) pelo Corpo de Bombeiros, para conhecimento do Órgão Ambiental Competente;
- **Art. 7º, § 2º, alínea "f"** {#art7_par2_alif} #lp f) Publicação de súmula da concessão da Licença Prévia em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 7º, § 2º, alínea "g"** {#art7_par2_alig} #li g) Publicação de súmula do pedido de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]]; e
- **Art. 7º, § 2º, alínea "h"** {#art7_par2_alih} h) Recolhimento da taxa ambiental e demais valores cabíveis referentes às publicações, em caso de optar pela publicação no site do órgão ambiental competente.

**Art. 7º, § 3º** {#art7_par3} #documentacao #lo #renovacao São documentos necessários para o requerimento de Licença de Operação e sua respectiva renovação:
- **Art. 7º, § 3º, alínea "a"** {#art7_par3_alia} #lo #renovacao #residuo-solido Plano de Gerenciamento de Resíduos Sólidos, de acordo com o estabelecido na [[lei-estadual-12493-1999|Lei Estadual nº 12.493/99]] e no [[decreto-estadual-6674-2002|Decreto Estadual nº 6.674/02]], elaborado por técnico habilitado e apresentado de acordo com as diretrizes do Orgão Ambiental Competente do anexo 5 da [[resolucao-cema-70-2009|Resolução CEMA 070/09]], com a devida atualização quando da Renovação da Licença de Operação;
- **Art. 7º, § 3º, alínea "b"** {#art7_par3_alib} Alvará de Funcionamento expedido pela Prefeitura Municipal;
- **Art. 7º, § 3º, alínea "c"** {#art7_par3_alic} recolhimento da Taxa Ambiental de acordo com a [[lei-estadual-10233-1992|Lei Estadual n° 10.233/92]];
- **Art. 7º, § 3º, alínea "d"** {#art7_par3_alid} #responsavel-tecnico Laudo de Conclusão de Obra, com ART;
- **Art. 7º, § 3º, alínea "e"** {#art7_par3_alie} #li publicação de súmula de concessão de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 7º, § 3º, alínea "f"** {#art7_par3_alif} #lo publicação de súmula do pedido de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]]; e
- **Art. 7º, § 3º, alínea "g"** {#art7_par3_alig} recolhimento da taxa ambiental e demais valores cabíveis referentes às publicações, em caso de optar pela publicação no site do órgão ambiental competente.

###### Art. 8º {#art8}
Tags: #agrotoxico #armazenamento-agrotoxico #li #lo #lp #prazo #renovacao

**Art. 8º, caput** {#art8_cpt} #prazo #renovacao Os prazos de validade e renovação das licenças concedidas pelo órgão ambiental competente será de:
- **Art. 8º, caput, inciso I** {#art8_cpt_inc1} #lp #prazo O prazo de validade da Licença Prévia - LP será de até 02 (dois) anos passível de prorrogação por dois anos;
- **Art. 8º, caput, inciso II** {#art8_cpt_inc2} #li #prazo #renovacao O prazo de validade da Licença de Instalação - LI será de até 06 (seis) anos não sendo passível de renovação; e
- **Art. 8º, caput, inciso III** {#art8_cpt_inc3} #lo #prazo #renovacao O prazo de validade da Licença de Operação - LO será de até 06 (seis) anos e poderá ser renovada. único A critério do órgão ambiental licenciador e mediante justificativa técnica os prazos previstos no caput deste artigo podem ser reduzidos.

###### Art. 9º {#art9}
Tags: #agrotoxico #agua-subterranea #app #armazenamento-agrotoxico #licenciamento-ambiental

**Art. 9º, caput** {#art9_cpt} #licenciamento-ambiental Consideram-se como não passíveis de licenciamento ambiental as armazenadoras de produtos agrotóxicos seus componentes e afins, quando estiverem localizadas:
- **Art. 9º, caput, inciso I** {#art9_cpt_inc1} em zonas estritamente residenciais, atendendo Plano Diretor do município;
- **Art. 9º, caput, inciso II** {#art9_cpt_inc2} #app em áreas de preservação permanente;
- **Art. 9º, caput, inciso III** {#art9_cpt_inc3} #agua-subterranea em áreas com lençol freático aflorante ou com solos alagadiços;
- **Art. 9º, caput, inciso IV** {#art9_cpt_inc4} em Unidades de Conservação, de acordo com o plano de manejo, se existente;
- **Art. 9º, caput, inciso V** {#art9_cpt_inc5} em áreas onde as condições geológicas não oferecem condições para a construção de obras civis;
- **Art. 9º, caput, inciso VI** {#art9_cpt_inc6} #redacao-alterada Em áreas de manancial de abastecimento público, numa distância inferior a 100 (cem) metros adjacentes de mananciais de captação de água. *(Redação dada pela Resolução 26 de 26/03/2020)*
- **Art. 9º, caput, inciso VII** {#art9_cpt_inc7} em edificações conjugadas/contíguas com residências.

###### Art. 10 {#art10}
Tags: #agrotoxico #armazenamento-agrotoxico #definicao #enquadramento

**Art. 10, caput** {#art10_cpt} #definicao #enquadramento As distâncias de afastamento das armazenadoras de produtos agrotóxicos seus componentes e afins devem atender aos critérios abaixo definidos em função de seu porte: Distâncias para Locais de reunião de Porte público (m)* Pequeno                 15 Médio                   40 Grande                  75 Excepcional             100 * Distância medida entre as paredes mais próximas dos locais de reunião de público e a edificação das armazenadoras de produtos agrotóxicos seus componentes e afins.

###### Art. 11 {#art11}
Tags: #agrotoxico #armazenamento-agrotoxico #lo #prazo #renovacao

**Art. 11, caput** {#art11_cpt} #lo #prazo #renovacao No caso de empreendimentos já licenciados que não atendam aos requisitos estabelecidos na presente Resolução, quando da renovação da Licença de Operação, deverá ser firmado Termo de Compromisso para Ajustamento de Conduta Ambiental, contendo as exigências necessárias para a adequação ambiental do empreendimento e os respectivos prazos para seu cumprimento.

###### Art. 12 {#art12}
Tags: #agrotoxico #armazenamento-agrotoxico

**Art. 12, caput** {#art12_cpt} O armazenamento de agrotóxicos, seus componentes e afins obedecerá à legislação vigente e as instruções fornecidas pelo fabricante, em especial, às especificações a serem adotadas no caso de acidentes, derramamento ou vazamento de produtos, incêndio, e ainda, as normas municipais aplicáveis, inclusive quanto à edificação e a localização.

###### Art. 13 {#art13}
Tags: #agrotoxico #armazenamento-agrotoxico #definicao

**Art. 13, caput** {#art13_cpt} Cabe ao órgão ambiental competente a avaliação de critérios e procedimentos técnicos em acidentes que incidam em contaminação ambiental, em especial derramamentos.

**Art. 13, § 1º** {#art13_par1} #definicao As Armazenadoras de Produtos Agrotóxicos, seus componentes e afins deverão seguir os critérios definidos nas Normas Técnicas aplicáveis em especial aos aspectos construtivos das edificações, sistemas de drenagem, instalações elétricas, ventilação, iluminação, medidas de segurança contra incêndio, saídas de emergência, situações de emergência e sinalização geral.

**Art. 13, § 2º** {#art13_par2} #definicao As Armazenadoras de Produtos Agrotóxicos, seus componentes e afins, sem fins comerciais para usuário final deverão seguir os critérios definidos nas Normas Técnicas aplicáveis em especial aos requisitos para construção do depósito e de segurança.

###### Art. 14 {#art14}
Tags: #agrotoxico #armazenamento-agrotoxico #responsavel-tecnico

**Art. 14, caput** {#art14_cpt} #responsavel-tecnico O descumprimento das disposições desta Resolução, dos termos das Licenças Ambientais e de eventual Termo de Ajustamento de Conduta sujeitará o infrator às penalidades previstas na [[lei-federal-9605-1998|Lei nº 9.605, de 12 de fevereiro de 1998]] e seus decretos reguladores e em outros dispositivos normativos pertinentes, sem prejuízo do dever de recuperar os danos ambientais causados, na forma do art. 225, § 3º, da Constituição Federal, e art. 207, § 3º da Constituição do Estado do Paraná.

###### Art. 15 {#art15}
Tags: #agrotoxico #armazenamento-agrotoxico #responsavel-tecnico

**Art. 15, caput** {#art15_cpt} #responsavel-tecnico Esta Resolução entra em vigor na data de sua publicação, tornando sem efeito a publicação no DIOE nº 10499, de 14/08/2019, por motivo de correção no Art. 5º, inciso I, desta Resolução, ficando também revogada a [[resolucao-sema-28-2016|Resolução SEMA nº 28/2016]]. Curitiba, 15 de julho de 2019. Márcio Nunes Secretário de Estado do Turismo Este texto não substitui o publicado no Diário Oficial do Estado ANEXOS: Arquivo                                                        Observações anexo229441_53047.pdf

### Anexo I citado como certidão municipal e como diretriz para PCA {#anexo1}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|
| [[resolucao-sedest-26-2020]] | Ver anotações no corpo | Alteração indicada no PDF; conferência pendente. |
| [[decreto-estadual-9541-2025]] | Norma inteira | Revogação expressa registrada no acervo. |

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (sedest 51 2019(1).pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- Divergência no próprio documento: cabeçalho de 19/11/2019 e fecho em Curitiba, 15 de julho de 2019. Mantida a data do cabeçalho nos metadados; revisão humana necessária.
- Anexo próprio citado ou vinculado em arquivo separado, sem o respectivo conteúdo no PDF do lote. Não foi importado material externo ou presumida sua redação.
- O corpo usa Anexo I para a certidão e para o PCA. A correspondência exige revisão no documento de anexo separado; não foi corrigida.
- Revisão de numeração: sequência de inciso: art9_cpt_inc6 após art9_cpt_inc6. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Situação revogada conforme relação expressa já cadastrada no acervo: [[decreto-estadual-9541-2025]]. Regras de transição e processos antigos devem ser avaliados separadamente.
