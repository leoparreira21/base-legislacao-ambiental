---
norma: "Resolução Conjunta SEDEST/SEAB/IAT/IAPAR-EMATER-IDR nº 18/2020"
arquivo: resolucao-conjunta-sedest-seab-iat-iapar-18-2020
tipo: resolucao
esfera: estadual
uf: PR
numero: 18
ano: 2020
data_assinatura: 2020-08-14
ementa: "Estabelece condições e critérios e dá outras providências, para empreendimentos de Irrigação no Estado do Paraná."
situacao: revogada
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: ["[[resolucao-conjunta-sedest-seab-iat-iapar-20-2020]]"]
revoga: ["[[resolucao-conjunta-seab-sema-iap-1-2007]]", "[[resolucao-conjunta-sedest-1-2007]]"]
revogado_por: ["[[decreto-estadual-9541-2025]]"]
cita: ["[[decreto-estadual-1440-2019]]", "[[decreto-estadual-3820-2020]]", "[[decreto-federal-10-2019]]", "[[decreto-federal-85-2019]]", "[[lei-estadual-19848-2019]]", "[[lei-federal-12787-2013]]", "[[lei-federal-19848-2019]]", "[[lei-federal-20070-2019]]", "[[lei-federal-20121-2019]]", "[[resolucao-cema-105-2019]]", "[[resolucao-conama-1-1986]]", "[[resolucao-conama-237-1997]]", "[[resolucao-conama-284-2001]]", "[[resolucao-conama-357-2005]]", "[[resolucao-conama-6-1986]]", "[[resolucao-conjunta-sedest-1-2007]]"]
tags: ["app", "autorizacao-florestal", "definicao", "documentacao", "enquadramento", "irrigacao", "las", "li", "licenciamento-ambiental", "lo", "lp", "monitoramento", "outorga", "prazo", "redacao-alterada", "renovacao", "responsavel-tecnico"]
fonte: "PDF fornecido: Resolução Conjunta SEDEST SEAB IAT IAPAR-EMATER-IDR 18 2020(1).pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
texto: "compilado segundo as alterações explícitas no PDF fornecido; conferência visual pendente"
---

# Resolução Conjunta SEDEST/SEAB/IAT/IAPAR-EMATER-IDR nº 18/2020

> Estabelece condições e critérios e dá outras providências, para empreendimentos de Irrigação no Estado do Paraná.

## Preâmbulo

Resolução Conjunta SEDEST/SEAB/IAT/IAPAR-EMATER-IDR 18 - 14 de Agosto de 2020 Publicado no Diário Oficial nº. 10752 de 18 de Agosto de 2020 Súmula: Estabelece condições e critérios e dá outras providências, para empreendimentos de Irrigação no Estado do Paraná. O Secretário de Estado do Desenvolvimento Sustentável e do Turismo - SEDEST, designado pelo [[decreto-estadual-1440-2019|Decreto nº 1.440, de 23 de maio de 2019]], no uso das atribuições que lhes são conferidas pela [[lei-federal-19848-2019|Lei nº 19.848, de 3 de maio de 2019]] e alterações posteriores; O Secretário de Estado da Agricultura e do Abastecimento – SEAB, designado pelo Decreto, nomeador pelo [[decreto-federal-10-2019|Decreto nº 10, de 1º de janeiro de 2019]]; uso de suas atribuições que lhes são conferidas da [[lei-estadual-19848-2019|Lei Estadual nº 19.848, de 3 de maio de 2019]]; O Diretor Presidente do Instituto Água e Terra, designado pelo [[decreto-estadual-3820-2020|Decreto nº 3.820, de 09 de janeiro de 2020]], no uso das atribuições que lhes são conferidas pela [[lei-federal-20070-2019|Lei nº 20.070, de 18 de dezembro de 2019]] e; O Diretor-Presidente do Instituto de Desenvolvimento Rural do Paraná-Iapar/Emater-IDR, designado pelo [[decreto-federal-85-2019|Decreto nº 85, de 1 de janeiro de 2019]]; no uso de suas atribuições que lhes são conferidas pela [[lei-federal-20121-2019|Lei 20121, de 31 de dezembro de 2019]]; e, Considerando o que estabelece a Política Nacional de Irrigação [[lei-federal-12787-2013|Lei Nº 12.787, de 11 de janeiro de 2013]]; Considerando o que estabelece a [[resolucao-conama-284-2001|Resolução CONAMA 284, de 30 de agosto de 2001]]; Considerando o que estabelece a [[resolucao-conama-1-1986|Resolução CONAMA 001, de 23 de janeiro de 1986]]; Considerando o que estabelece a [[resolucao-conama-237-1997|Resolução CONAMA 237, de 19 de dezembro de 1997]]; Considerando o que estabelece a [[resolucao-conama-357-2005|Resolução CONAMA 357, de 17 de março de 2005]]; Considerando a necessidade de adotar critérios diferenciados e procedimentos alternativos para o licenciamento ambiental; Considerando a necessidade de compatibilização do processo de licenciamento com as necessidades do Programa Estadual de Irrigação; RESOLVE:

###### Art. 1º {#art1}
Tags: #irrigacao #licenciamento-ambiental #outorga

**Art. 1º, caput** {#art1_cpt} #licenciamento-ambiental #outorga Estabelecer condições e critérios de Licenciamento Ambiental e Outorga de Recursos Hídricos para empreendimentos de Irrigação no Estado do Paraná.

### Capítulo I – DEFINIÇÕES

###### Art. 2º {#art2}
Tags: #definicao #irrigacao #outorga

**Art. 2º, caput** {#art2_cpt} #definicao Para os efeitos desta Resolução, considera-se:
- **Art. 2º, caput, inciso I** {#art2_cpt_inc1} Empreendimento de irrigação: conjunto de obras e atividades que o compõem, tais como: reservatório (exceto barragens) e captação, adução e distribuição de água, drenagem, caminhos internos e a lavoura propriamente dita, bem como qualquer outra ação indispensável à obtenção do produto final do sistema de irrigação e que sejam realizadas em áreas de uso consolidado.
- **Art. 2º, caput, inciso II** {#art2_cpt_inc2} Métodos de irrigação: é a forma pela qual a água pode ser aplicada às culturas. Basicamente, são três os métodos de irrigação: A) Aspersão: pivô central, auto propelido, convencional e outros; B) Localizada: gotejamento, microaspersão, xique-xique e outros; e C) Superfície: sulco, inundação, faixa e outros.
- **Art. 2º, caput, inciso III** {#art2_cpt_inc3} Medidor de vazão: é um instrumento usado para medir a taxa de vazão, linear ou não linear, da massa ou do volume de um líquido ou um gás.

### Capítulo II – LICENCIAMENTO AMBIENTAL

#### Seção I – Atos administrativos

###### Art. 3º {#art3}
Tags: #documentacao #enquadramento #irrigacao #las #li #licenciamento-ambiental #lo #lp #outorga

**Art. 3º, caput** {#art3_cpt} O Órgão Ambiental Competente, no exercício de sua competência de controle ambiental, expedirá os seguintes atos administrativos:
- **Art. 3º, caput, inciso I** {#art3_cpt_inc1} #licenciamento-ambiental Declaração de Dispensa de Licenciamento Ambiental Estadual - DLAE: concedida para os empreendimentos cujo licenciamento ambiental não compete ao órgão ambiental estadual, conforme os critérios estabelecidos em resoluções específicas;
- **Art. 3º, caput, inciso II** {#art3_cpt_inc2} #documentacao #enquadramento #las Licença Ambiental Simplificada - LAS: Aprova a localização e a concepção doempreendimento, atividade ou obra de pequeno porte e/ou que possua baixo potencial poluidor/degradador, atestando a viabilidade ambiental e estabelecendo os requisitosbásicos e condicionantes a serem atendidos, bem como autoriza sua instalação e operação de acordo com as especificações constantes dos requerimentos, planos, programas e/ou projetos aprovados, incluindo as medidas de controle ambiental e demais condicionantes determinadas pelo Órgão Ambiental Competente.
- **Art. 3º, caput, inciso III** {#art3_cpt_inc3} #lp Licença Prévia - LP: Concedida na fase preliminar do planejamento do empreendimento ou atividade, aprovando sua localização e concepção, atestando a viabilidade ambiental e estabelecendo os requisitos básicos e condicionantes a serem atendidos nas próximas fases de sua implementação.
- **Art. 3º, caput, inciso IV** {#art3_cpt_inc4} #li Licença de Instalação - LI: Autoriza a instalação do empreendimento ou atividade de acordo com as especificações constantes dos planos, programas e projetos aprovados, incluindo as medidas de controle ambiental e demais condicionantes.
- **Art. 3º, caput, inciso V** {#art3_cpt_inc5} #lo Licença de Operação - LO: Autoriza o funcionamento da atividade ou empreendimento, após a verificação do efetivo cumprimento do que consta das licenças anteriores, com as medidas de controle ambientais e condicionantes determinados para a operação.
- **Art. 3º, caput, inciso II** {#art3_cpt_inc2-dup2} #licenciamento-ambiental Procedimentos de Licenciamento Ambiental

###### Art. 4º {#art4}
Tags: #definicao #enquadramento #irrigacao #licenciamento-ambiental #outorga

**Art. 4º, caput** {#art4_cpt} #definicao #enquadramento #licenciamento-ambiental O porte dos empreendimentos de irrigação é definido de acordo com a dimensão efetiva da área irrigada por propriedade individual e o procedimento de licenciamento ambiental considera esse porte e o método de irrigação empregado, conforme tabela a seguir:

> **Pendência de transcrição — Art. 4, quadro/tabela** {#art4_tab1}. Conteúdo preservado na extração textual que acompanha o lote; falta conferência visual das colunas. Não é texto normativo transcrito.


#### Seção III – Documentação para o Licenciamento Ambiental

###### Art. 5º {#art5}
Tags: #app #autorizacao-florestal #documentacao #enquadramento #irrigacao #licenciamento-ambiental #monitoramento #outorga

**Art. 5º, caput** {#art5_cpt} #documentacao #licenciamento-ambiental Os requerimentos para a Declaração de Dispensa de Licenciamento Ambiental DLAE deverão ser protocolados através do sistema automatizado do Instituto Água e Terra, instruídos na forma prevista abaixo:
- **Art. 5º, caput, inciso I** {#art5_cpt_inc1} #licenciamento-ambiental Formulário para Licenciamento Ambiental de Empreendimentos de Irrigação (Anexo I), para o caso de procedimentos protocolados pelo eProtocolo;
- **Art. 5º, caput, inciso II** {#art5_cpt_inc2} #app Croqui de localização do empreendimento com imagem aérea e contendo no mínimo: -distância dos corpos hídricos; -áreas de preservação permanente; -cobertura florestal; -vias de acesso principais; e -pontos de referências.
- **Art. 5º, caput, inciso III** {#art5_cpt_inc3} #documentacao Documento de propriedade ou justa posse rural, conforme o artigo 52 da [[resolucao-cema-105-2019|Resolução CEMA nº 105 /2019]], ou outra que vier a substituí-la;
- **Art. 5º, caput, inciso IV** {#art5_cpt_inc4} #outorga Outorga/Uso insignificante de Outorga de Uso de Água, a ser solicitada de acordo com a legislação vigente;
- **Art. 5º, caput, inciso V** {#art5_cpt_inc5} #monitoramento Projeto Técnico de Irrigação contendo o descritivo do sistema a ser implantado e medidas de conservação de solo e monitoramento de uso de água;
- **Art. 5º, caput, inciso VI** {#art5_cpt_inc6} Número de Registro do CAR;

**Art. 5º, § 1º** {#art5_par1} #enquadramento Para os empreendimentos enquadrados no caput deste artigo o interessado deverá ser cadastrado no SGA como Usuário Ambiental, para o caso de procedimentos protocolados pelo SGA.

**Art. 5º, § 2º** {#art5_par2} #documentacao #licenciamento-ambiental A Declaração de Dispensa de Licenciamento Ambiental - DLAE será emitida de forma automática, desde que sejam anexados os documentos exigidos no caput deste parágrafo.

**Art. 5º, § 3º** {#art5_par3} #enquadramento Qualquer alteração nas características do porte nos empreendimentos de irrigação deverá ser solicitada à respectiva Licença Ambiental.

**Art. 5º, § 4º** {#art5_par4} #licenciamento-ambiental A Dispensa do Licenciamento Ambiental Estadual - DLAE não exime o dispensado das exigências legais quanto à preservação do meio ambiente.

**Art. 5º, § 5º** {#art5_par5} #autorizacao-florestal #licenciamento-ambiental A Dispensa do Licenciamento Ambiental Estadual - DLAE não se aplica em caso de necessidade de supressão florestal, devendo ser requerida a LAS e a Autorização Florestal, de forma concomitante.

###### Art. 6º {#art6}
Tags: #autorizacao-florestal #documentacao #irrigacao #las #licenciamento-ambiental #monitoramento #outorga #responsavel-tecnico

**Art. 6º, caput** {#art6_cpt} #documentacao #las Os requerimentos para LICENÇA AMBIENTAL SIMPLIFICADA – LAS deverão ser protocolados através do sistema automatizado do Instituto Água e Terra, instruídos na forma prevista abaixo:
- **Art. 6º, caput, inciso I** {#art6_cpt_inc1} #licenciamento-ambiental Formulário para Licenciamento Ambiental de Empreendimentos de Irrigação (Anexo I), para o caso de procedimentos protocolados pelo eProtocolo;
- **Art. 6º, caput, inciso II** {#art6_cpt_inc2} #outorga Outorga/Uso insignificante de Outorga de Uso de Água, a ser solicitada de acordo com a legislação vigente;
- **Art. 6º, caput, inciso III** {#art6_cpt_inc3} Projeto Técnico de Irrigação contendo o descritivo do sistema e memória de cálculo do dimensionamento;
- **Art. 6º, caput, inciso IV** {#art6_cpt_inc4} Número de Registro do CAR;
- **Art. 6º, caput, inciso V** {#art6_cpt_inc5} #monitoramento Plano de Controle Ambiental contendo as medidas de conservação de solos e água e monitoramento de uso e água;
- **Art. 6º, caput, inciso VI** {#art6_cpt_inc6} #documentacao Certidão do município ou documento equivalente, declarando expressamente que o local e o tipo de empreendimento estão em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano, com a legislação municipal do meio ambiente, inclusive com relação ao entorno de unidades de conservação municipais, e que atende as demais exigências legais e administrativas perante o município;
- **Art. 6º, caput, inciso VII** {#art6_cpt_inc7} #documentacao #responsavel-tecnico Documento de propriedade ou justa posse rural, conforme Art. 52 da [[resolucao-cema-105-2019|Resolução CEMA nº105/19]] ou outra que vier a substituí-la;
- **Art. 6º, caput, inciso VIII** {#art6_cpt_inc8} #autorizacao-florestal Requerer a Autorização Florestal em caso de supressão florestal, antes do início das obras de instalação.
- **Art. 6º, caput, inciso IX** {#art6_cpt_inc9} #las Publicação de súmula do pedido de Licença Ambiental Simplificada - LAS em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/1986]].
- **Art. 6º, caput, inciso X** {#art6_cpt_inc10} Recolhimento da taxa ambiental e demais valores cabíveis referentes às publicações, em caso de optar pela publicação no site do órgão ambiental competente.

**Art. 6º, § 1º** {#art6_par1} #autorizacao-florestal #las Quando necessário o corte ou supressão de vegetação nativa, a LICENÇA AMBIENTAL SIMPLIFICADA – LAS somente poderá ser emitida acompanhada da respectiva Autorização Florestal.

**Art. 6º, § 2º** {#art6_par2} #responsavel-tecnico Antes de início de operação do empreendimento deverá ser apresentado ao órgão ambiental competente o Laudo de Conclusão da instalação dos sistemas, acompanhado da respectiva ART.

###### Art. 7º {#art7}
Tags: #documentacao #irrigacao #las #licenciamento-ambiental #monitoramento #outorga #renovacao #responsavel-tecnico

**Art. 7º, caput** {#art7_cpt} #documentacao #las #renovacao Os requerimentos para RENOVAÇÃO DA LICENÇA AMBIENTAL SIMPLIFICADA - RLAS deverão ser protocolados através do sistema automatizado do Instituto Água e Terra, instruídos na forma prevista abaixo:
- **Art. 7º, caput, inciso I** {#art7_cpt_inc1} #licenciamento-ambiental Formulário para Licenciamento Ambiental de Empreendimentos de Irrigação (Anexo I), para o caso de procedimentos protocolados pelo eprotocolo;
- **Art. 7º, caput, inciso II** {#art7_cpt_inc2} #monitoramento #responsavel-tecnico Relatório de Monitoramento da aplicação do sistema (solo e água), acompanhado da respectiva ART;
- **Art. 7º, caput, inciso III** {#art7_cpt_inc3} Relatório de atendimento das condicionantes da Licença anterior;
- **Art. 7º, caput, inciso IV** {#art7_cpt_inc4} #las Publicação de súmula de concessão de Licença Ambiental Simplificada em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/1986]];
- **Art. 7º, caput, inciso V** {#art7_cpt_inc5} #las #renovacao Publicação de súmula do pedido de Renovação de Licença Ambiental Simplificada em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/1986]];
- **Art. 7º, caput, inciso VI** {#art7_cpt_inc6} Recolhimento da taxa ambiental e demais valores cabíveis referentes às publicações, em caso de optar pela publicação no site do órgão ambiental competente;

###### Art. 8º {#art8}
Tags: #enquadramento #irrigacao #outorga

**Art. 8º, caput** {#art8_cpt} #enquadramento Os empreendimentos de irrigação classificados como de porte grande e excepcional, deverão requerer sucessivamente as Licenças Prévia, de Instalação e de Operação.

###### Art. 9º {#art9}
Tags: #app #autorizacao-florestal #documentacao #irrigacao #li #licenciamento-ambiental #lp #outorga #prazo

**Art. 9º, caput** {#art9_cpt} #documentacao #lp Os requerimentos para LICENÇA PRÉVIA – LP, deverão ser protocolados através do sistema automatizado do Instituto Água e Terra, instruídos na forma prevista abaixo:
- **Art. 9º, caput, inciso I** {#art9_cpt_inc1} #licenciamento-ambiental Formulário para Licenciamento Ambiental de Empreendimentos de Irrigação (Anexo I), para o caso de procedimentos protocolados pelo e-Protocolo;
- **Art. 9º, caput, inciso II** {#art9_cpt_inc2} #documentacao Certidão do município ou documento equivalente, declarando expressamente que o local e o tipo de empreendimento estão em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano, com a legislação municipal do meio ambiente, inclusive com relação ao entorno de unidades de conservação municipais, e que atende as demais exigências legais e administrativas perante o município;
- **Art. 9º, caput, inciso III** {#art9_cpt_inc3} #documentacao #prazo Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente ou em nome do locador, junto com o contrato de locação, em caso de imóvel locado, atualizada em até 90 (noventa) dias contados da data de sua emissão e, em caso da matricula estar constando a área como rural, deve ser apresentado o CAR;
- **Art. 9º, caput, inciso IV** {#art9_cpt_inc4} #documentacao Documentação complementar do imóvel se a situação imobiliária estiver irregular conforme Capitulo II, Seção V da [[resolucao-cema-105-2019|Resolução CEMA nº 105 de 17 de dezembro de 2019]];
- **Art. 9º, caput, inciso V** {#art9_cpt_inc5} #documentacao #li Nos casos devidamente justificados em que não seja possível a apresentação dos documentos especificados nos itens II e III, os mesmos deverão ser apresentados quando da solicitação da Licença de Instalação.
- **Art. 9º, caput, inciso VI** {#art9_cpt_inc6} #outorga Outorga/Uso insignificante de Outorga de Uso de Água, a ser solicitada de acordo com a legislação vigente;
- **Art. 9º, caput, inciso VII** {#art9_cpt_inc7} #app Croqui de localização do empreendimento com imagem aérea atualizada e contendo no mínimo: -Estruturas físicas; -Distância dos corpos hídricos; -Áreas de preservação permanente; -Cobertura florestal; -Vias de acesso principais; e -Pontos de referências.
- **Art. 9º, caput, inciso VIII** {#art9_cpt_inc8} #autorizacao-florestal Requerer a Autorização Florestal em caso de necessidade de supressão florestal, antes do início das obras de instalação;
- **Art. 9º, caput, inciso IX** {#art9_cpt_inc9} #lp Publicação de súmula do pedido de Licença Prévia em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/1986]].
- **Art. 9º, caput, inciso X** {#art9_cpt_inc10} Recolhimento da taxa ambiental e demais valores cabíveis referentes às publicações, em caso de optar pela publicação no site do órgão ambiental competente.

**Art. 9º, parágrafo único** {#art9_par1u} #autorizacao-florestal Em caso de necessidade de supressão florestal requerer a Autorização Florestal.

###### Art. 10 {#art10}
Tags: #autorizacao-florestal #documentacao #irrigacao #li #licenciamento-ambiental #lp #monitoramento #outorga

**Art. 10, caput** {#art10_cpt} #documentacao #li Os requerimentos para LICENÇA DE INSTALAÇÃO – LI deverão ser protocolados através do sistema automatizado do Instituto Água e Terra, instruídos na forma prevista abaixo:
- **Art. 10, caput, inciso I** {#art10_cpt_inc1} #licenciamento-ambiental Formulário para Licenciamento Ambiental de Empreendimentos de Irrigação (Anexo I), para o caso de procedimentos protocolados pelo eProtocolo;
- **Art. 10, caput, inciso II** {#art10_cpt_inc2} #lp Cópia da Licença Prévia;
- **Art. 10, caput, inciso III** {#art10_cpt_inc3} Relatório de atendimento das condicionantes da licença anterior;
- **Art. 10, caput, inciso IV** {#art10_cpt_inc4} Projeto Técnico de Irrigação contendo o descritivo do sistema e memória de cálculo do dimensionamento;
- **Art. 10, caput, inciso V** {#art10_cpt_inc5} Número de Registro do CAR;
- **Art. 10, caput, inciso VI** {#art10_cpt_inc6} #monitoramento Plano de Controle Ambiental contendo Programa de controle e proteção de solo e água e Programa de monitoramento de solo e água;
- **Art. 10, caput, inciso VII** {#art10_cpt_inc7} #lp Publicação de súmula de concessão da Licença Prévia em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 10, caput, inciso VIII** {#art10_cpt_inc8} #li Publicação de súmula do pedido de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 10, caput, inciso IX** {#art10_cpt_inc9} Recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

**Art. 10, parágrafo único** {#art10_par1u} #autorizacao-florestal #li Quando necessário o corte ou supressão de vegetação nativa, a Licença de Instalação– LI somente poderá ser emitida acompanhada da respectiva Autorização Florestal.

###### Art. 11 {#art11}
Tags: #documentacao #irrigacao #li #licenciamento-ambiental #lo #outorga

**Art. 11, caput** {#art11_cpt} #documentacao #lo Os requerimentos para LICENÇA DE OPERAÇÃO - LO deverão ser protocolados através do sistema automatizado do Instituto Água e Terra, instruídos na forma prevista abaixo:
- **Art. 11, caput, inciso I** {#art11_cpt_inc1} #licenciamento-ambiental Formulário para Licenciamento Ambiental de Empreendimentos de Irrigação (Anexo I), para o caso de procedimentos protocolados pelo eProtocolo;
- **Art. 11, caput, inciso II** {#art11_cpt_inc2} #li Cópia da Licença de instalação;
- **Art. 11, caput, inciso III** {#art11_cpt_inc3} #outorga Outorga/Uso insignificante de Outorga de Uso de Água, a ser solicitada de acordo com a legislação vigente
- **Art. 11, caput, inciso IV** {#art11_cpt_inc4} Relatório fotográfico de conclusão da obra;
- **Art. 11, caput, inciso V** {#art11_cpt_inc5} Relatório de atendimento das condicionantes da licença anterior;
- **Art. 11, caput, inciso VI** {#art11_cpt_inc6} #li Publicação de súmula de concessão de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 11, caput, inciso VII** {#art11_cpt_inc7} #lo Publicação de súmula do pedido de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]]; g
- **Art. 11, caput, inciso VIII** {#art11_cpt_inc8} Recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

###### Art. 12 {#art12}
Tags: #app #documentacao #irrigacao #licenciamento-ambiental #lo #monitoramento #outorga #renovacao #responsavel-tecnico

**Art. 12, caput** {#art12_cpt} #documentacao #lo #renovacao Os requerimentos para RENOVAÇÃO DE LICENÇA DE OPERAÇÃO - RLO deverão ser protocolados através do sistema automatizado do Instituto Água e Terra, instruído na forma prevista abaixo:
- **Art. 12, caput, inciso I** {#art12_cpt_inc1} #licenciamento-ambiental Formulário para Licenciamento Ambiental de Empreendimentos de Irrigação (Anexo I), para o caso de procedimentos protocolados pelo eProtocolo; - Cópia da Licença anterior;
- **Art. 12, caput, inciso II** {#art12_cpt_inc2} Cópia da Licença anterior;
- **Art. 12, caput, inciso III** {#art12_cpt_inc3} #responsavel-tecnico Relatório de atendimento das condicionantes da licença anterior, elaborado por profissional com a devida anotação de responsabilidade técnica – ART;
- **Art. 12, caput, inciso IV** {#art12_cpt_inc4} #monitoramento #responsavel-tecnico Relatório de Monitoramento da aplicação dos sistemas (solo e água), acompanhado da respectiva ART;
- **Art. 12, caput, inciso V** {#art12_cpt_inc5} #app Croqui de localização do empreendimento com imagem aérea atualizada e contendo no mínimo: -Estruturas físicas; -Distância dos corpos hídricos; -Indicando as áreas de preservação permanente; -Cobertura florestal; -Vias de acesso principais e; -Pontos de referências.
- **Art. 12, caput, inciso VI** {#art12_cpt_inc6} #lo Publicação de súmula de concessão de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/1986]].
- **Art. 12, caput, inciso VII** {#art12_cpt_inc7} #lo #renovacao Publicação de súmula do pedido de Renovação de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/1986]].
- **Art. 12, caput, inciso VIII** {#art12_cpt_inc8} Recolhimento da taxa ambiental e demais valores cabíveis referentes às publicações, em caso de optar pela publicação no site do órgão ambiental competente.

###### Art. 13 {#art13}
Tags: #definicao #irrigacao #licenciamento-ambiental #outorga

**Art. 13, caput** {#art13_cpt} #definicao #licenciamento-ambiental Poderá ser admitido um único processo de licenciamento ambiental para empreendimentos e atividades similares e vizinhos, ou para aqueles integrantes de planos de desenvolvimento/Programas de Governo aprovados previamente pelo IAT, desde que definida a responsabilidade legal pelo conjunto de empreendimentos ou atividades.

#### Seção IV – Prazos de Validade das Licenças Ambientais

###### Art. 14 {#art14}
Tags: #documentacao #irrigacao #las #li #lo #lp #outorga #prazo #renovacao

**Art. 14, caput** {#art14_cpt} #documentacao #prazo O órgão ambiental competente estabelecerá os prazos de validade para cada tipo de licença e autorização ambiental, especificando-os no respectivo documento, levando em consideração os seguintes aspectos:
- **Art. 14, caput, inciso I** {#art14_cpt_inc1} #las #prazo #renovacao O prazo de validade da Licença Ambiental Simplificada - LAS será de até 10 (dez) anos, podendo ser renovada a critério técnico do órgão ambiental competente;
- **Art. 14, caput, inciso II** {#art14_cpt_inc2} #lp #prazo O prazo de validade da Licença Prévia - LP será de 05 (cinco) anos, não prorrogável se concedido o prazo máximo;
- **Art. 14, caput, inciso III** {#art14_cpt_inc3} #li #prazo O prazo de validade da Licença de Instalação - LI será de até 06 (seis) anos, não prorrogável se concedido o prazo máximo;
- **Art. 14, caput, inciso IV** {#art14_cpt_inc4} #lo #prazo O prazo de validade da Licença de Operação - LO será de no mínimo 4 anos e no máximo 10 (dez) anos, renovável a critério do Órgão Licenciador.

**Art. 14, parágrafo único** {#art14_par1u} #lo #prazo #renovacao Na Renovação da Licença de Operação - RLO de empreendimento, atividade ou obra, o órgão ambiental competente poderá, mediante decisão motivada, aumentar ou diminuir o seu prazo de validade, após a avaliação do desempenho ambiental da atividade ou empreendimento no período de vigência anterior.

### Capítulo III – OUTORGA DE USO RECURSOS HÍDRICOS

###### Art. 15 {#art15}
Tags: #irrigacao #outorga

**Art. 15, caput** {#art15_cpt} #outorga Os atos administrativos correspondentes à emissão de Outorga Prévia de Uso de Recursos Hídricos, Outorga de Direito de Uso de Recursos Hídricos e Uso Insignificante de Recursos Hídricos devem seguir os procedimentos em conformidade com a legislação vigente.

###### Art. 16 {#art16}
Tags: #irrigacao #outorga

**Art. 16, caput** {#art16_cpt} #outorga Os atos administrativos correspondentes à emissão de Outorga Prévia de Uso de Recursos Hídricos, Outorga de Direito de Uso de Recursos Hídricos e Uso Insignificante de Recursos Hídricos devem seguir os procedimentos em conformidade com a legislação vigente.

### Capítulo IV – ASPECTOS TÉCNICOS

###### Art. 17 {#art17}
Tags: #irrigacao #licenciamento-ambiental #monitoramento #outorga #renovacao

**Art. 17, caput** {#art17_cpt} #licenciamento-ambiental #monitoramento #outorga #renovacao É obrigatória a instalação de sistema de controle de vazão de captação/recalque de água em empreendimentos para fins de concessão/renovação de Licenciamentos ou Dispensa de Licenciamentos Ambientais, que permita ao Órgão Ambiental proceder o monitoramento do volume de água consumido e outorgado.

###### Art. 18 {#art18}
Tags: #enquadramento #irrigacao #outorga

**Art. 18, caput** {#art18_cpt} A água a ser utilizada para a irrigação deverá atender aos seguintes critérios, de acordo com a [[resolucao-conama-357-2005|Resolução CONAMA 357/2005]]:
- **Art. 18, caput, inciso I** {#art18_cpt_inc1} Irrigação de hortaliças que são consumidas cruas e de frutas que se desenvolvam rentes ao solo e que sejam ingeridas cruas sem remoção de película, qualidade de água compatível com Classe I;
- **Art. 18, caput, inciso II** {#art18_cpt_inc2} #enquadramento Irrigação de hortaliças, plantas frutíferas e de parques, jardins, campos de esporte e lazer, com os quais o público possa vir a ter contato direto, qualidade de água compatível com Classe II;
- **Art. 18, caput, inciso III** {#art18_cpt_inc3} Irrigação de culturas arbóreas, cerealíferas e forrageiras, qualidade de água compatível com Classe III.

### Capitulo V – DISPOSIÇÕES GERAIS

###### Art. 19 {#art19}
Tags: #documentacao #irrigacao #outorga #responsavel-tecnico

**Art. 19, caput** {#art19_cpt} #documentacao #responsavel-tecnico As solicitações vinculadas a Programas de Estado ou Planos de Desenvolvimento serão dispensadas de pagamentos de emolumentos referentes a serviços ambientais para obtenção da Licença Ambiental, desde que comprovadas conforme relação de documentos do Art. 21.

###### Art. 20 {#art20}
Tags: #irrigacao #licenciamento-ambiental #outorga

**Art. 20, caput** {#art20_cpt} #licenciamento-ambiental #outorga O IAT poderá firmar Termos de Cooperação com outras entidades públicas, desde que com reconhecida capacidade técnica, para a realização de atividades de vistoria e análise técnica de empreendimentos de irrigação nas fases de Outorga de Uso de Água e Licenciamento Ambiental, com a finalidade de agilizar e qualificar estes procedimentos.

###### Art. 21 {#art21}
Tags: #documentacao #irrigacao #licenciamento-ambiental #outorga

**Art. 21, caput** {#art21_cpt} #documentacao #licenciamento-ambiental Para fins de isenção da Taxa Ambiental no requerimento de licenciamento ambiental, deverá ser apresentada declaração emitida pela IDR Paraná, Sindicatos Rurais ou ainda o DAP - Declaração de Aptidão do PRONAF.

###### Art. 22 {#art22}
Tags: #irrigacao #outorga #prazo

**Art. 22, caput** {#art22_cpt} #prazo Esta Resolução deverá ser reavaliada a cada 06 (seis) anos ou a qualquer tempo, quando o órgão ambiental considerar necessário.

###### Art. 23 {#art23}
Tags: #irrigacao #outorga

**Art. 23, caput** {#art23_cpt} O não cumprimento do disposto nesta Resolução sujeitará os infratores às sanções previstas nas Leis Federais nº 6.938 de 31 de agosto de 1981, nº 9.605 de 12 de fevereiro de 1998 e seus decretos regulamentadores.

###### Art. 24 {#art24}
Tags: #irrigacao #outorga

**Art. 24, caput** {#art24_cpt} #redacao-alterada Esta Resolução entra em vigor após sua publicação, ficando revogada a [[resolucao-conjunta-sedest-1-2007|RESOLUÇÃO CONJUNTA Nº 001/2007]] - SEAB/SEMA/IAP, de 27 de junho de 2007. *(Redação dada pela Resolução 20 de 27/08/2020)*

## Fecho

Curitiba, 12 de agosto de 2020. Márcio Nunes Secretário de Estado do Turismo Norberto Anacleto Ortigara Secretário de Estado da Agricultura e do Abastecimento

EVERTON LUIZ DA COSTA SOUZA Diretor-Presidente do Instituto Água e Terra Natalino Avance de Souza Diretor-Presidente Interino do Instituto Agronômico do Paraná Este texto não substitui o publicado no Diário Oficial do Estado

ANEXOS: Arquivo                                                       Observações anexo237948_55030.08

### Formulário para Licenciamento Ambiental de Empreendimentos de Irrigação {#anexo1}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|
| [[resolucao-conjunta-sedest-seab-iat-iapar-20-2020]] | Ver anotações no corpo | Alteração indicada no PDF; conferência pendente. |
| [[decreto-estadual-9541-2025]] | Norma inteira | Revogação expressa registrada no acervo. |

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (Resolução Conjunta SEDEST SEAB IAT IAPAR-EMATER-IDR 18 2020(1).pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- Divergência no próprio documento: cabeçalho de 14/08/2020 e fecho em Curitiba, 12 de agosto de 2020. Denominação de arquivo harmonizada com o acervo existente (iapar); denominação longa mantida no título.
- Redações anteriores de artigos repetidos foram excluídas desta versão compilada, conforme o padrão do acervo; estão preservadas na extração da fonte que acompanha o lote.
- Anexo próprio citado ou vinculado em arquivo separado, sem o respectivo conteúdo no PDF do lote. Não foi importado material externo ou presumida sua redação.
- Revisão de numeração: ID duplicado: art3_cpt_inc2. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Revisão de numeração: sequência de inciso: art3_cpt_inc2-dup2 após art3_cpt_inc5. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Quadros no corpo devem ser conferidos visualmente; números, colunas e células mescladas ainda não estão certificados. Não utilizar este rascunho para enquadramento antes da revisão.
- Situação revogada conforme relação expressa já cadastrada no acervo: [[decreto-estadual-9541-2025]]. Regras de transição e processos antigos devem ser avaliados separadamente.
