---
norma: "Resolução Conjunta SEDEST/IAT nº 22/2021"
arquivo: resolucao-conjunta-sedest-iat-22-2021
tipo: resolucao
esfera: estadual
uf: PR
numero: 22
ano: 2021
data_assinatura: 2021-07-28
ementa: "Define as diretrizes para implementação e operacionalização da responsabilidade pós-consumo no Estado do Paraná e estabelece o procedimento para incorporação da logística reversa no âmbito do licenciamento ambiental no Estado, e dá outras providências."
situacao: vigente
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: []
revoga: []
revogado_por: []
cita: ["[[decreto-estadual-1440-2019]]", "[[decreto-estadual-3813-2020]]", "[[decreto-estadual-3820-2020]]", "[[decreto-estadual-9213-2012]]", "[[decreto-estadual-9213-2013]]", "[[decreto-federal-10388-2020]]", "[[decreto-federal-4074-2002]]", "[[decreto-federal-7404-2010]]", "[[decreto-federal-9177-2017]]", "[[lei-estadual-12493-1999]]", "[[lei-estadual-17211-2012]]", "[[lei-estadual-19848-2019]]", "[[lei-estadual-20070-2019]]", "[[lei-estadual-20607-2021]]", "[[lei-federal-12305-2010]]", "[[lei-federal-17211-2012]]", "[[lei-federal-9605-1998]]", "[[resolucao-conjunta-sedest-iat-20-2021]]"]
tags: ["definicao", "documentacao", "enquadramento", "las", "licenciamento-ambiental", "lo", "logistica-reversa", "prazo", "proibicao", "renovacao", "residuo-solido", "responsavel-tecnico"]
fonte: "PDF fornecido: resolução conjunta SEDEST IAT 22 2021(1).pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
---

# Resolução Conjunta SEDEST/IAT nº 22/2021

> Define as diretrizes para implementação e operacionalização da responsabilidade pós-consumo no Estado do Paraná e estabelece o procedimento para incorporação da logística reversa no âmbito do licenciamento ambiental no Estado, e dá outras providências.

## Preâmbulo

Resolução Conjunta SEDEST/IAT 22 - 28 de Julho de 2021 Publicado no Diário Oficial nº. 10988 de 30 de Julho de 2021 Súmula: Define as diretrizes para implementação e operacionalização da responsabilidade pós-consumo no Estado do Paraná e estabelece o procedimento para incorporação da logística reversa no âmbito do licenciamento ambiental no Estado, e dá outras providências. O Secretário de Estado do Desenvolvimento Sustentável e do Turismo – SEDEST, nomeado pelo [[decreto-estadual-1440-2019|Decreto Estadual nº 1.440, de 23 de maio de 2019]], no uso das atribuições que lhe são conferidas pela [[lei-estadual-19848-2019|Lei Estadual nº 19.848, de 03 de maio de 2019]]; e alterações posteriores, e O Diretor Presidente do Instituto Água e Terra – IAT, nomeado pelo [[decreto-estadual-3820-2020|Decreto Estadual n° 3.820, de 10 de janeiro de 2020]], no uso de suas atribuições que lhe são conferidas pela [[lei-estadual-20070-2019|Lei Estadual n° 20.070, de 18 de dezembro de 2019]], [[decreto-estadual-3813-2020|Decreto Estadual n° 3.813, de 09 de janeiro de 2020]] e, Considerando a [[lei-estadual-12493-1999|Lei Estadual n° 12.493, de 22 de janeiro de 1999]], que estabelece princípios, procedimentos, normas e critérios referentes a geração, acondicionamento, armazenamento, coleta, transporte, tratamento e destinação final dos resíduos sólidos no Estado do Paraná, visando controle da poluição, da contaminação e a minimização de seus impactos ambientais e adota outras providências; Considerando a [[lei-federal-12305-2010|Lei Federal nº 12.305, de 02 de agosto de 2010]], que dispõe sobre a Política Nacional de Resíduos Sólidos – PNRS, e sua regulamentação por meio do [[decreto-federal-7404-2010|Decreto Federal nº 7.404, de 23 de dezembro de 2010]]; Considerando a [[lei-estadual-17211-2012|Lei Estadual n° 17.211, de 3 de julho de 2012]], que dispõe sobre a responsabilidade da destinação dos medicamentos de uso humano e/ou veterinário em desuso no Estado do Paraná, bem como os seus procedimentos; Considerando o [[decreto-estadual-9213-2013|Decreto Estadual n° 9.213, de 23 de outubro de 2013]], que regulamenta a [[lei-federal-17211-2012|Lei nº 17.211, de 3 de julho de 2012]] e dispõe sobre a responsabilidade da destinação dos medicamentos de uso humano e/ou veterinário em desuso no Estado do Paraná, seus procedimentos e dá outras providências; Considerando o [[decreto-federal-9177-2017|Decreto Federal n° 9.177, de 23 de outubro de 2017]], que regulamenta o art. 33 da [[lei-federal-12305-2010|Lei nº 12.305, de 2 de agosto de 2010]] e complementa os art. 16 e art. 17 do [[decreto-federal-7404-2010|Decreto nº 7.404, de 23 de dezembro de 2010]]; Considerando o [[decreto-federal-10388-2020|Decreto Federal n° 10.388, de 5 de junho de 2020]], que regulamenta o § 1º do caput do art. 33 da [[lei-federal-12305-2010|Lei nº 12.305, de 2 de agosto de 2010]], e institui o sistema de logística reversa de medicamentos domiciliares vencidos ou em desuso, de uso humano, industrializados e manipulados, e de suas embalagens após o descarte pelos consumidores; Considerando a [[lei-estadual-20607-2021|Lei Estadual n° 20.607, de 10 de junho de 2021]], que dispõe sobre o Plano Estadual de Resíduos Sólidos do Estado do Paraná – PERS/PR e dá outras providências; Considerando a [[resolucao-conjunta-sedest-iat-20-2021|Resolução Conjunta SEDEST/IAT nº 020/2021]], que dispõe sobre a Plataforma digital CONTABILIZANDO RESÍDUOS, estabelece critérios e procedimentos a serem adotados para sua implementação; Considerando a formulação, coordenação, execução e desenvolvimento das políticas públicas da Secretaria de Estado do Desenvolvimento Sustentável e do Turismo, estabelecidos na [[lei-estadual-19848-2019|Lei Estadual n°19.848, de 3 de maio de 2019]]; Considerando os objetivos institucionais do Instituto Água e Terra, estabelecidos na [[lei-estadual-20070-2019|Lei Estadual n° 20.070, de 18 de dezembro de 2019]]. RESOLVE:

###### Art. 1º {#art1}
Tags: #definicao #licenciamento-ambiental #logistica-reversa

**Art. 1º, caput** {#art1_cpt} #definicao #licenciamento-ambiental Definir diretrizes para implementação e operacionalização da responsabilidade pós?consumo no Estado do Paraná e estabelecer o procedimento para incorporação da logística reversa no âmbito do licenciamento ambiental no Estado.

### CAPÍTULO I – DAS DELIBERAÇÕES

###### Art. 2º {#art2}
Tags: #definicao #documentacao #enquadramento #licenciamento-ambiental #logistica-reversa #residuo-solido

**Art. 2º, caput** {#art2_cpt} #definicao Para efeitos desta Resolução, consideram-se as seguintes definições:
- **Art. 2º, caput, inciso I** {#art2_cpt_inc1} Acordo Setorial: ato de natureza contratual firmado entre o poder público e fabricantes, importadores, distribuidores e/ou comerciantes, tendo em vista a implantação da responsabilidade compartilhada pelo ciclo de vida do produto;
- **Art. 2º, caput, inciso II** {#art2_cpt_inc2} Aderentes: pessoa jurídica, que pode ser fabricante, importador, distribuidor, ou comerciante, que adere ao sistema de logística reversa estabelecido no Termo de Compromisso, Acordo Setorial e/ou outro instrumento regulatório;
- **Art. 2º, caput, inciso III** {#art2_cpt_inc3} Comerciante: pessoa jurídica que oferte produtos ao consumidor, distinta do fabricante, do importador e do distribuidor;
- **Art. 2º, caput, inciso IV** {#art2_cpt_inc4} Consumidor: toda pessoa física ou jurídica que adquire ou utiliza produto ou serviço como destinatário final;
- **Art. 2º, caput, inciso V** {#art2_cpt_inc5} #residuo-solido Destinação final ambientalmente adequada: destinação de resíduos que inclui a reutilização, a reciclagem, tratamentos por vias mecânicas, biológicas ou térmicas, e outras destinações admitidas pelos órgãos competentes, entre elas a disposição final, observando os tipos de materiais dispostos e normas operacionais específicas de modo a evitar danos ou riscos à saúde pública e à segurança e a minimizar os impactos ambientais adversos;
- **Art. 2º, caput, inciso VI** {#art2_cpt_inc6} Distribuidor: pessoa jurídica que oferte produtos a comerciante, distinta do fabricante e do importador;
- **Art. 2º, caput, inciso VII** {#art2_cpt_inc7} Embalagens: invólucro, recipiente ou qualquer forma de acondicionamento, removível ou não, destinado a cobrir, empacotar, envasar, proteger ou manter, especificamente ou não, produtos;
- **Art. 2º, caput, inciso VIII** {#art2_cpt_inc8} Fabricante: pessoa jurídica de direito público ou privado que fabrique ou mande fabricar produtos em seu nome ou sob sua marca, ou seja, detentores das marcas dos respectivos produtos e/ou aqueles que, em nome destes, realizam o envase, a montagem ou a manufatura dos produtos;
- **Art. 2º, caput, inciso IX** {#art2_cpt_inc9} Importador: pessoa jurídica que realiza ou se responsabiliza pela importação de produtos, devidamente autorizada para o exercício da atividade;
- **Art. 2º, caput, inciso X** {#art2_cpt_inc10} #licenciamento-ambiental Licenciamento ambiental: procedimento administrativo pelo qual o órgão ambiental competente, verificando a satisfação das condições legais e técnicas, delibera quanto à localização, instalação, ampliação, operação e encerramento de empreendimentos e atividades utilizadoras de recursos ambientais consideradas efetivas ou potencialmente poluidoras ou daquelas que, sob qualquer forma, possam vir a causar degradação e/ou modificação ambiental, considerando as disposições legais e regulamentares e as normas técnicas aplicáveis ao caso;
- **Art. 2º, caput, inciso XI** {#art2_cpt_inc11} #residuo-solido Logística reversa: instrumento de desenvolvimento econômico e social caracterizado por um conjunto de ações, procedimentos e meios destinados a viabilizar a coleta e a restituição dos resíduos sólidos ao setor empresarial, para reaproveitamento, em seu ciclo ou em outros ciclos produtivos, ou outra destinação final ambientalmente adequada;
- **Art. 2º, caput, inciso XII** {#art2_cpt_inc12} #enquadramento #residuo-solido Operadores de logística: pessoa física ou jurídica que presta serviços logísticos, podendo incluir coleta, triagem, armazenamento, beneficiamento e transporte de resíduos, devidamente autorizada pelos órgãos competentes;
- **Art. 2º, caput, inciso XIII** {#art2_cpt_inc13} #documentacao Plano de Logística Reversa: documento descritivo contendo conjunto de metas, ações e procedimentos destinados a viabilizar a logística reversa;
- **Art. 2º, caput, inciso XIV** {#art2_cpt_inc14} Relatórios Comprobatórios do Plano de Logística Reversa: relatórios contendo os resultados das ações realizadas em função das metas estabelecidas nos Planos de Logística Reversa;
- **Art. 2º, caput, inciso XV** {#art2_cpt_inc15} Representatividade coletiva: entidades gestoras, associações, sindicatos, empresas e outros, que realizem a gestão do Sistema de Logística Reversa, representando fabricantes, importadores, distribuidores ou comerciantes;
- **Art. 2º, caput, inciso XVI** {#art2_cpt_inc16} Representatividade individual: pessoa jurídica, que pode ser fabricante, importador, distribuidor, comerciante e outros, que realize a gestão do Sistema de Logística Reversa de forma individual;
- **Art. 2º, caput, inciso XVII** {#art2_cpt_inc17} #enquadramento #residuo-solido Resíduos pós-consumo: resíduos sólidos gerados após o uso pelo consumidor final, incluindo os classificados como perigosos pela legislação e normas técnicas brasileiras
- **Art. 2º, caput, inciso XVIII** {#art2_cpt_inc18} Signatários: entidade que representa fabricantes, importadores, distribuidores ou comerciantes junto aos sistemas de logística reversa e que assina o Termo de Compromisso ou Acordo Setorial;
- **Art. 2º, caput, inciso XIX** {#art2_cpt_inc19} Termo de compromisso: ato de natureza contratual firmado entre o poder público e fabricantes, importadores, distribuidores e comerciantes, tendo em vista a implantação de sistema de logística reversa.

### CAPÍTULO II – DAS DISPOSIÇÕES GERAIS QUANTO À IMPLEMENTAÇÃO E OPERACIONALIZAÇÃO DA LOGÍSTICA REVERSA

###### Art. 3º {#art3}
Tags: #definicao #licenciamento-ambiental #logistica-reversa #residuo-solido

**Art. 3º, caput** {#art3_cpt} #definicao Ficam definidas as diretrizes para o aprimoramento, implementação e operacionalização da responsabilidade pós-consumo no Estado do Paraná, conforme dispõe a [[lei-federal-12305-2010|Lei Federal nº 12.305/2010]] e a [[lei-estadual-20607-2021|Lei Estadual n° 20.607/2021]]

**Art. 3º, § 1º** {#art3_par1} #definicao #residuo-solido A logística reversa, conforme definido no inciso III, do artigo [[#art8|8º]] é um instrumento da Política Nacional de Resíduos Sólidos ([[lei-federal-12305-2010|Lei Federal 12.305/2010]]).

**Art. 3º, § 2º** {#art3_par2} #residuo-solido A logística reversa, conforme inciso XII, do artigo [[#art3|3º]], da Política Nacional de Resíduos Sólidos ([[lei-federal-12305-2010|Lei Federal 12.305/2010]]), integra e operacionaliza a responsabilidade pós-consumo para fins desta Resolução.

###### Art. 4º {#art4}
Tags: #licenciamento-ambiental #logistica-reversa

**Art. 4º, caput** {#art4_cpt} Esta resolução aplica-se aos fabricantes, importadores, distribuidores e comerciantes de produtos e embalagens pós-consumo sujeitos à logística reversa no Estado do Paraná

###### Art. 5º {#art5}
Tags: #licenciamento-ambiental #logistica-reversa #prazo #proibicao #residuo-solido #responsavel-tecnico

**Art. 5º, caput** {#art5_cpt} #residuo-solido São obrigados a estruturar e implementar sistemas de logística reversa, mediante retorno dos produtos após o uso pelo consumidor, de forma independente do serviço público de limpeza urbana e de manejo dos resíduos sólidos, os fabricantes, importadores, distribuidores e comerciantes de:
- **Art. 5º, caput, inciso I** {#art5_cpt_inc1} #prazo #proibicao #residuo-solido #responsavel-tecnico Agrotóxicos, seus resíduos e embalagens, assim como, outros produtos cuja embalagem após o uso, constitua resíduo perigoso, observadas as regras de gerenciamento de resíduos perigosos previstas em lei ou regulamento, em normas estabelecidas pelos órgãos do Sisnama, do SNVS e do Suasa e/ou em normas técnicas. Estende-se a obrigatoriedade aos agrotóxicos vencidos, em desuso, fora de fabricação e/ou proibidos recentemente pela legislação, dentro do prazo de devolução previsto no Art. 53 do [[decreto-federal-4074-2002|Decreto Federal nº 4074/02]];
- **Art. 5º, caput, inciso II** {#art5_cpt_inc2} Pilhas e baterias;
- **Art. 5º, caput, inciso III** {#art5_cpt_inc3} Pneus;
- **Art. 5º, caput, inciso VI** {#art5_cpt_inc6} Produtos eletroeletrônicos, seus acessórios e componentes;
- **Art. 5º, caput, inciso VII** {#art5_cpt_inc7} Medicamentos domiciliares vencidos ou não utilizados, de uso humano e veterinário, industrializados e manipulados e de suas bulas e embalagens, conforme [[decreto-federal-10388-2020|Decreto Federal n° 10.388/2020]], [[lei-estadual-17211-2012|Lei Estadual nº 17.211/2012]] e [[decreto-estadual-9213-2012|Decreto Estadual nº 9.213/2012]]. Estende-se a obrigatoriedade aos perfurocortantes, agulhas descartáveis, seringas, ampolas, canetas injetoras, dentre outros dispositivos utilizados na aplicação de medicamentos injetáveis
- **Art. 5º, caput, inciso VIII** {#art5_cpt_inc8} #residuo-solido Produtos saneantes desinfestantes domissanitários vencidos ou não utilizados, seus resíduos e embalagens, assim como outros produtos cuja embalagem, após o uso, constitua resíduo perigoso, observadas as regras de gerenciamento de resíduos perigosos previstas em lei ou regulamento, em normas estabelecidas pelos órgãos do Sisnama, do SNVS e do Suasa e/ou em normas técnicas;
- **Art. 5º, caput, inciso IX** {#art5_cpt_inc9} Produtos comercializados em embalagens (a) papel, papelão e embalagem cartonada longa vida, (b) plástico, (c) metal, (d) vidro.

**Art. 5º, parágrafo único** {#art5_par1u} #residuo-solido Fica estendida a obrigatoriedade de logística reversa aos demais produtos e embalagens, considerando, o grau e a extensão do impacto à saúde pública e ao meio ambiente dos resíduos gerados, conforme § 1º do artigo 33 da [[lei-federal-12305-2010|Lei Federal n° 12.305/2010]] e artigo 4º da [[lei-estadual-20607-2021|Lei Estadual 20.607/2021]].

###### Art. 6º {#art6}
Tags: #definicao #licenciamento-ambiental #logistica-reversa #renovacao

**Art. 6º, caput** {#art6_cpt} O Poder Público poderá celebrar Termos de Compromisso com os fabricantes, importadores, distribuidores e comerciantes referidos no artigo [[#art5|5º]] desta Resolução, visando o estabelecimento de sistema de logística reversa, em qualquer tempo e priorizando:
- **Art. 6º, caput, inciso I** {#art6_cpt_inc1} Situações em que não houver, em uma mesma área de abrangência, Acordo Setorial e/ou regulamentação específica, consoante com o estabelecido nesta Resolução;
- **Art. 6º, caput, inciso II** {#art6_cpt_inc2} Fixação de compromissos e metas mais exigentes que o previsto em Acordo Setorial e/ou regulamentação específica e compatíveis com as particularidades dos municípios do Estado do Paraná;
- **Art. 6º, caput, inciso III** {#art6_cpt_inc3} Dar mais especificidade e detalhes a Planos de Logística Reversa
- **Art. 6º, caput, inciso IV** {#art6_cpt_inc4} Estabelecimento de metas geográficas, de recolhimento e destinação ambientalmente adequadas, bem como metas estruturantes, estas quando couber, que visem a ampliação do sistema de logística reversa a ser implementado ou em operação;
- **Art. 6º, caput, inciso V** {#art6_cpt_inc5} Destinação ambientalmente adequada que empregue tecnologias de transformação por vias mecânicas, biológicas ou térmicas, priorizando as mais sustentáveis do ponto de vista ambiental, econômico e social.

**Art. 6º, § 1º** {#art6_par1} #renovacao Os Termos de Compromisso em vigência poderão ser renovados, em qualquer tempo, a critério da Secretaria de Estado do Desenvolvimento Sustentável e do Turismo (SEDEST) e/ou a pedido da(s) entidade(s) representativa(s) do setor que assinou o respectivo Termo, objetivando o atendimento ao disposto no artigo [[#art6|6º]].

**Art. 6º, § 2º** {#art6_par2} #definicao Os Termos de Compromisso deverão atender, minimamente, os itens dispostos no Apêndice I da presente Resolução e demais definições celebradas entre as partes compromissárias e compromitentes.

###### Art. 7º {#art7}
Tags: #licenciamento-ambiental #logistica-reversa #residuo-solido

**Art. 7º, caput** {#art7_cpt} #residuo-solido A prestação das informações do sistema de logística reversa à SEDEST passa a ser compulsório no Sistema Estadual de Informações sobre Resíduos Sólidos - plataforma digital CONTABILIZANDO RESÍDUOS.

**Art. 7º, § 1º** {#art7_par1} #residuo-solido O preenchimento do módulo de Logística Reversa (LR) na plataforma digital CONTABILIZANDO RESÍDUOS passa a ser obrigatório a todos os fabricantes, importadores, distribuidores e comerciantes, de forma individual ou coletiva, dos produtos e embalagens pós?consumo, conforme descritos no artigo [[#art5|5º]] da presente Resolução.

**Art. 7º, § 2º** {#art7_par2} #residuo-solido O encaminhamento das informações do sistema de logística reversa na plataforma digital CONTABILIZANDO RESÍDUOS ocorrerá por meio da apresentação dos Planos de Logística Reversa (PLRs) e dos Relatórios Comprobatórios do Plano de Logística Reversa (RCPLRs), de acordo com as diretrizes estabelecidas nos Apêndices I e II da presente Resolução.

###### Art. 8º {#art8}
Tags: #definicao #documentacao #licenciamento-ambiental #lo #logistica-reversa #renovacao

**Art. 8º, caput** {#art8_cpt} #documentacao Os Planos de Logística Reversa (PLRs) serão avaliados pela SEDEST para posterior aprovação e, emissão de documento que ateste sua aprovação.

**Art. 8º, § 1º** {#art8_par1} #definicao Os Planos de Logística Reversa (PLRs) que não atendam, minimamente, aos itens dispostos no Apêndice I da presente Resolução e demais definições celebradas entre as partes, serão objetos de esclarecimentos e complementações, e no caso de não cumprimento ou atendimento parcial ao proposto, os Planos de Logística Reversa (PLRs) que poderão ser indeferidos.

**Art. 8º, § 2º** {#art8_par2} #licenciamento-ambiental #lo #renovacao Os Planos de Logística Reversa (PLRs) para os procedimentos de licenciamento ambiental, na fase da licença de operação e em suas renovações, passam a ter eficácia a partir da aprovação da SEDEST.

###### Art. 9º {#art9}
Tags: #definicao #documentacao #licenciamento-ambiental #logistica-reversa #prazo #renovacao

**Art. 9º, caput** {#art9_cpt} #documentacao #prazo Após a aprovação do Plano de Logística Reversa (PLR) pela SEDEST, os fabricantes, importadores, distribuidores e comerciantes dos produtos e embalagens pós-consumo, conforme descritos no artigo [[#art5|5º]] da presente Resolução, deverão apresentar até 31 de março dos anos subsequentes, os Relatórios Comprobatórios do Plano de Logística Reversa (RCPLRs), de forma individual ou coletiva, contendo informações e resultados tendo como base, o ano anterior (janeiro a dezembro) para avaliação da SEDEST para, posterior aprovação e, emissão de documento que ateste sua aprovação.

**Art. 9º, § 1º** {#art9_par1} #documentacao Os Relatórios Comprobatórios do Plano de Logística Reversa (RCPLRs) são considerados documentos que comprovam a execução da logística reversa no Estado do Paraná sendo que, sua análise e aprovação pela SEDEST, passam a ser obrigatórias.

**Art. 9º, § 2º** {#art9_par2} #definicao Os Relatórios Comprobatórios do Plano de Logística Reversa (RCPLRs) que não atendam, minimamente, aos itens dispostos no Apêndice II da presente Resolução e demais definições celebradas entre as partes, serão objetos de esclarecimentos e complementações, e no caso de não cumprimento ou atendimento parcial ao proposto, os RCPLRs poderão ser indeferidos.

**Art. 9º, § 3º** {#art9_par3} #licenciamento-ambiental #renovacao Os Relatórios Comprobatórios do Plano de Logística Reversa (RCPLRs) para os procedimentos de licenciamento ambiental, na fase de suas renovações, passam a ter eficácia a partir da aprovação da SEDEST.

###### Art. 10 {#art10}
Tags: #licenciamento-ambiental #logistica-reversa #residuo-solido

**Art. 10, caput** {#art10_cpt} #residuo-solido Os fabricantes, importadores, distribuidores e comerciantes dos produtos e embalagens pós-consumo, conforme descritos no artigo [[#art5|5º]] da presente Resolução, de forma individual ou coletiva, deverão manter cópia dos demonstrativos/certificados da quantidade e tipologia de resíduos recolhidos e encaminhados ao tratamento e destinação final como forma de comprovação de atingimento de metas celebradas nos Planos de Logística Reversa (PLRs) e nos Termo de Compromisso firmados, no contexto do Relatório Comprobatório do Plano de Logística Reversa (RCPLR) e/ou em qualquer tempo, quando solicitados pela SEDEST.

###### Art. 11 {#art11}
Tags: #licenciamento-ambiental #logistica-reversa

**Art. 11, caput** {#art11_cpt} Os setores que demandam logística reversa por obrigatoriedade legal, deverão ser, prioritariamente, representados por meio de entidade(s) e/ou por pessoa(s) jurídica(s) que agreguem em volume, fabricantes, importadores, distribuidores e comerciantes, com o objetivo de gerenciar o mesmo sistema.

###### Art. 12 {#art12}
Tags: #licenciamento-ambiental #logistica-reversa #residuo-solido

**Art. 12, caput** {#art12_cpt} #residuo-solido Os fabricantes, importadores, distribuidores e comerciantes de produtos e embalagens pós-consumo sujeitos à realização da logística reversa, conforme artigo [[#art5|5º]] desta Resolução, independente da adesão a Termo de Compromisso, Acordo Setorial e/ou outro instrumento legal equivalente junto ao Poder Público, ficam obrigados a prestar informações do sistema de logística reversa à SEDEST, por meio do Sistema Estadual de Informações sobre Resíduos Sólidos – plataforma digital CONTABILIZANDO RESÍDUOS, com a apresentação dos Planos de Logística Reversa (PLRs) e dos Relatórios Comprobatórios do Plano de Logística Reversa (RCPLRs).

### CAPÍTULO III – PROCEDIMENTOS PARA INCORPORAÇÃO DA LOGÍSTICA REVERSA NO ÂMBITO DO LICENCIAMENTO AMBIENTAL NO ESTADO DO PARANÁ

###### Art. 13 {#art13}
Tags: #licenciamento-ambiental #logistica-reversa

**Art. 13, caput** {#art13_cpt} #licenciamento-ambiental Os fabricantes, importadores, distribuidores e comerciantes de produtos e embalagens pós-consumo, previstos nos incisos I ao VIII do artigo [[#art5|5°]] da presente Resolução, deverão apresentar o comprovante de aprovação emitido pela SEDEST do Plano de Logística Reversa (PLR) no Estado do Paraná, para fins de licenciamento ambiental, a partir de 1º de janeiro de 2022.

###### Art. 14 {#art14}
Tags: #licenciamento-ambiental #logistica-reversa #residuo-solido

**Art. 14, caput** {#art14_cpt} Os fabricantes, importadores, distribuidores e comerciantes de produtos e embalagens pós-consumo, previstos no
- **Art. 14, caput, inciso IX** {#art14_cpt_inc9} #licenciamento-ambiental #residuo-solido do artigo [[#art5|5°]] da presente Resolução, que compreende os produtos comercializados em embalagens (a) papel, papelão e embalagem cartonada longa vida, (b) plástico, (c) metal, (d) vidro e demais produtos e embalagens, considerando prioritariamente o grau e a extensão do impacto à saúde pública e ao meio ambiente dos resíduos gerados, deverão apresentar o comprovante de aprovação emitido pela SEDEST do Plano de Logística Reversa (PLR) no Estado do Paraná, para fins de licenciamento ambiental, nos seguintes termos:
- **Art. 14, caput, inciso I** {#art14_cpt_inc1} A partir de 1º de julho de 2022 aqueles empreendimentos e atividades com área construída igual ou superior a 5 (cinco) mil metros quadrados;
- **Art. 14, caput, inciso II** {#art14_cpt_inc2} A partir de 1º de janeiro de 2023 a obrigação se estende a todos os empreendimentos e atividades.

###### Art. 15 {#art15}
Tags: #las #licenciamento-ambiental #lo #logistica-reversa #prazo #renovacao

**Art. 15, caput** {#art15_cpt} #licenciamento-ambiental #lo #renovacao Os fabricantes, importadores, distribuidores e comerciantes de produtos e embalagens pós-consumo, previstos no artigo [[#art5|5°]] desta Resolução e subordinados ao licenciamento ambiental, deverão obrigatoriamente apresentar os comprovantes de aprovação pela SEDEST, dos Planos de Logística Reversa (PLRs) ou dos Relatórios Comprobatórios do Plano de Logística Reversa (RCPLRs), nas fases da licença de operação ou em suas renovações.

**Art. 15, § 1º** {#art15_par1} #lo #renovacao O comprovante de aprovação dos Planos de Logística Reversa (PLRs) passa a ser requisito obrigatório para emissão da licença de operação e, quando for o caso, na renovação da Licença de Operação (LO).

**Art. 15, § 2º** {#art15_par2} #lo #renovacao O comprovante de aprovação dos Relatórios Comprobatórios do Plano de Logística Reversa (RCPLRs) passa a ser requisito obrigatório para emissão da renovação da Licença de Operação (LO).
- **Art. 15, § 2º, inciso I** {#art15_par2_inc1} O Relatório Comprobatório do Plano de Logística Reversa somente será solicitado para os empreendimentos e atividades que já apresentaram o Plano de Logística Reversa aprovado pela SEDEST.

**Art. 15, § 3º** {#art15_par3} #las O caput deste artigo, é extensivo a Licença Ambiental Simplificada (LAS) e a Licença Ambiental por Adesão e Compromisso (LAC), e se dará da seguinte forma:
- **Art. 15, § 3º, inciso I** {#art15_par3_inc1} #las #prazo O comprovante de aprovação dos Planos de Logística Reversa (PLRs) passa a ser condicionante na Licença Ambiental Simplificada (LAS) ou na Licença Ambiental por Adesão e Compromisso (LAC), devendo ser apresentado ao órgão ambiental competente no prazo de 180 (cento e oitenta) dias, após a emissão da licença ambiental;
- **Art. 15, § 3º, inciso II** {#art15_par3_inc2} #renovacao Nas próximas renovações ficam obrigados a apresentarem o comprovante de aprovação do Plano de Logística Reversa (PLR) ou Relatório Comprobatório do Plano de Logística Reversa (RCPLR), quando couber.

###### Art. 16 {#art16}
Tags: #definicao #licenciamento-ambiental #logistica-reversa #residuo-solido

**Art. 16, caput** {#art16_cpt} #definicao #licenciamento-ambiental #residuo-solido Os fabricantes, importadores, distribuidores e comerciantes de produtos e embalagens pós-consumo previstos no artigo [[#art5|5°]] da presente Resolução, que não se enquadram no processo de licenciamento ambiental definido pelo Instituto Água e Terra (IAT), e portanto, não condicionados ao artigo anterior, ficam obrigados da mesma forma a operacionalizarem a logística reversa, em consonância com a [[lei-federal-12305-2010|Lei Federal n° 12.305/2010]] e regulamentações afins, e ainda, ao encaminhamento compulsório de seus Planos de Logística Reversa (PLRs) e posteriormente, seus Relatórios Comprobatórios do Plano de Logística Reversa (RCPLRs) à apreciação e aprovação pela SEDEST, por meio do Sistema Estadual de Informações sobre Resíduos Sólidos - plataforma digital CONTABILIZANDO RESÍDUOS, conforme referido nos artigos [[#art7|7º]], [[#art8|8º]] e [[#art9|9º]] da presente Resolução.

**Art. 16, parágrafo único** {#art16_par1u} Os casos de abstenção serão notificados a qualquer momento e a critério do órgão competente, para apresentação do Plano de Logística Reversa (PLR) e Relatórios Comprobatórios do Plano de Logística Reversa (RCPLRs), ficando estes, sujeitos as sanções cabíveis ao não cumprimento da lei.

### CAPÍTULO IV – DAS DISPOSIÇÕES FINAIS

###### Art. 17 {#art17}
Tags: #licenciamento-ambiental #logistica-reversa

**Art. 17, caput** {#art17_cpt} A operacionalização da logística reversa deve obrigatoriamente ser realizada em consonância com a [[lei-federal-12305-2010|Lei Federal n° 12.305/2010]] e todas as demais regulamentações pertinentes, sendo pretérita e não vinculada exclusivamente à Acordos Setoriais, Termos de Compromisso, Decretos, Planos de Logística Reversa (PLRs), bem como quaisquer outros instrumentos aplicáveis.

**Art. 17, parágrafo único** {#art17_par1u} A obrigatoriedade da logística reversa de produtos pós-consumo que causam impacto à saúde pública e ao meio ambiente é requerida desde o estabelecimento das Políticas Públicas Ambientais.

### CAPÍTULO V – DAS PENALIDADES

###### Art. 18 {#art18}
Tags: #licenciamento-ambiental #logistica-reversa

**Art. 18, caput** {#art18_cpt} A observância ao disposto nesta Resolução é considerada obrigação de relevante interesse ambiental para os efeitos da [[lei-federal-9605-1998|Lei Federal n° 9.605, de 12 de fevereiro de 1998]].

###### Art. 19 {#art19}
Tags: #licenciamento-ambiental #logistica-reversa

**Art. 19, caput** {#art19_cpt} O não cumprimento às condições desta Resolução ensejará a aplicação das penalidades previstas na legislação ambiental e de responsabilização administrativa, civil e criminal.

###### Art. 20 {#art20}
Tags: #licenciamento-ambiental #logistica-reversa

**Art. 20, caput** {#art20_cpt} Esta Resolução entra em vigor na data da sua publicação, tendo seus efeitos a partir de 01 de janeiro de 2022.


## Fecho

Curitiba, 27 de julho de 2021. Márcio Nunes Secretário de Estado do Turismo

EVERTON LUIZ DA COSTA SOUZA Diretor-Presidente do Instituto Água e Terra Este texto não substitui o publicado no Diário Oficial do Estado

ANEXOS: Arquivo                                                     Observações anexo251285_59363.pdf anexo251285_59364.pdf


## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (resolução conjunta SEDEST IAT 22 2021(1).pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- Anexo próprio citado ou vinculado em arquivo separado, sem o respectivo conteúdo no PDF do lote. Não foi importado material externo ou presumida sua redação.
- Revisão de numeração: sequência de inciso: art5_cpt_inc6 após art5_cpt_inc3. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Revisão de numeração: inciso inicial IX: art14_cpt_inc9. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Revisão de numeração: sequência de inciso: art14_cpt_inc1 após art14_cpt_inc9. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
