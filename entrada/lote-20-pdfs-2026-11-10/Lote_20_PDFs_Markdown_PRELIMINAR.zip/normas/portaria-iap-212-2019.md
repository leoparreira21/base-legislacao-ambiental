---
norma: "Portaria IAP nº 212/2019"
arquivo: portaria-iap-212-2019
tipo: portaria
esfera: estadual
uf: PR
numero: 212
ano: 2019
data_assinatura: 2019-09-12
ementa: "Estabelece os critérios para emissão de Autorizações Ambientais para o Gerenciamento de Resíduos Sólidos."
situacao: revogada
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: []
revoga: ["[[portaria-iap-202-2016]]"]
revogado_por: ["[[portaria-iat-33-2022]]"]
cita: ["[[decreto-estadual-472-2019]]", "[[lei-estadual-10066-1992]]", "[[portaria-iap-202-2016]]", "[[resolucao-cema-100-2017]]", "[[resolucao-cema-50-2005]]", "[[resolucao-cema-76-2009]]", "[[resolucao-sema-42-2008]]"]
tags: ["autorizacao-ambiental", "definicao", "documentacao", "efluente", "eia-rima", "enquadramento", "licenciamento-ambiental", "lo", "prazo", "proibicao", "renovacao", "residuo-solido", "responsavel-tecnico"]
fonte: "PDF fornecido: portaria IAP 212 2019.pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
---

# Portaria IAP nº 212/2019

> Estabelece os critérios para emissão de Autorizações Ambientais para o Gerenciamento de Resíduos Sólidos.

## Preâmbulo

PORTARIA IAP Nº 212, DE 12 DE SETEMBRO DE 2019 Estabelece os critérios para emissão de Autorizações Ambientais para o Gerenciamento de Resíduos Sólidos. O Diretor Presidente do Instituto Ambiental do Paraná-IAP, nomeado pelo [[decreto-estadual-472-2019|Decreto nº 472, de 12 de fevereiro de 2019]], no uso das atribuições que lhe são conferidas pela [[lei-estadual-10066-1992|Lei Estadual n° 10.066, de 27 de julho de 1992]] e alterações posteriores; RESOLVE:

###### Art. 1º {#art1}
Tags: #autorizacao-ambiental #residuo-solido

**Art. 1º, caput** {#art1_cpt} #residuo-solido Estabelecer procedimentos e critérios para exigência e emissão de Autorizações Ambientais para as Atividades de Gerenciamento de Resíduos Sólidos.

###### Art. 2º {#art2}
Tags: #autorizacao-ambiental #definicao #documentacao #efluente #eia-rima #enquadramento #lo #residuo-solido

**Art. 2º, caput** {#art2_cpt} #definicao Para fins desta Portaria aplicam-se as seguintes definições:
- **Art. 2º, caput, inciso I** {#art2_cpt_inc1} #enquadramento #residuo-solido Atividade de gerenciamento de resíduos sólidos: atividade associada ao controle da geração, armazenamento, coleta, transporte, transbordo, tratamento, destinação final dos resíduos sólidos e disposição final ambientalmente adequada dos rejeitos de acordo com os melhores princípios de saúde pública e de preservação ambiental;
- **Art. 2º, caput, inciso II** {#art2_cpt_inc2} #documentacao Autorização Ambiental: ato administrativo que aprova e autoriza a execução da atividade de caráter temporário, que possa acarretar alterações ao meio ambiente de acordo com as especificações constantes dos requerimentos, cadastros, planos, programas e/ou projetos aprovados, incluindo as medidas de controle ambiental e demais condicionantes determinadas pelo órgão licenciador;
- **Art. 2º, caput, inciso III** {#art2_cpt_inc3} #residuo-solido Coleta: ato de coletar e remover resíduos sólidos para destinação;
- **Art. 2º, caput, inciso IV** {#art2_cpt_inc4} #eia-rima #residuo-solido Coprocessamento de resíduos em fornos de produção de clínquer: Técnica de utilização de resíduos sólidos a partir do processamento desses como substituto parcial de matéria-prima e / ou de combustível no sistema forno de produção de clínquer, na fabricação de cimento;
- **Art. 2º, caput, inciso V** {#art2_cpt_inc5} #residuo-solido Destinação final ambientalmente adequada: destinação de resíduos que inclui a reutilização, a reciclagem, a compostagem, a recuperação e o aproveitamento energético ou outras destinações admitidas pelos órgão competentes, observando normas operacionais específicas de modo a evitar danos ou riscos à saúde pública e à segurança e a minimizar os impactos ambientais adversos;
- **Art. 2º, caput, inciso VI** {#art2_cpt_inc6} Disposição final ambientalmente adequada: distribuição ordenada de rejeitos em aterros, observando normas operacionais específicas de modo a evitar danos ou riscos à saúde pública e à segurança e a minimizar os impactos ambientais adversos;
- **Art. 2º, caput, inciso VII** {#art2_cpt_inc7} #residuo-solido Geração: todo ato ou efeito de produzir resíduos sólidos;
- **Art. 2º, caput, inciso VIII** {#art2_cpt_inc8} #enquadramento #residuo-solido Gerenciamento de resíduos sólidos: conjunto de ações exercidas, direta ou indiretamente, nas etapas de coleta, transporte, transbordo, tratamento e destinação final ambientalmente adequada dos resíduos sólidos e disposição final ambientalmente adequada dos rejeitos;
- **Art. 2º, caput, inciso IX** {#art2_cpt_inc9} #residuo-solido Grandes geradores: estabelecimentos cuja geração diária de resíduos sólidos urbanos é superior ao limite estabelecido pelo município para atendimento de coleta pública;
- **Art. 2º, caput, inciso X** {#art2_cpt_inc10} #lo Licença de Operação (LO): ato administrativo que autoriza a operação da atividade ou empreendimento, após a verificação do efetivo cumprimento do que consta das licenças anteriores, com as medidas de controle ambiental e condicionantes determinados para a operação;
- **Art. 2º, caput, inciso XI** {#art2_cpt_inc11} #efluente Lodo de esgoto higienizado: lodo de esgoto ou produto derivado submetido a processo de tratamento de redução de patógenos de acordo com os níveis estabelecidos na legislação vigente;
- **Art. 2º, caput, inciso XII** {#art2_cpt_inc12} #residuo-solido Reciclagem: processo de transformação dos resíduos sólidos que envolve a alteração de suas propriedades físicas, físico-químicas ou biológicas, com vistas à transformação em insumos ou novos produtos;
- **Art. 2º, caput, inciso XIII** {#art2_cpt_inc13} #residuo-solido Rejeito: resíduos para os quais ainda não há tecnologia ou viabilidade econômica que permita seu tratamento, reaproveitamento ou reciclagem;
- **Art. 2º, caput, inciso XIV** {#art2_cpt_inc14} #residuo-solido Resíduos agrossilvopastoris: os gerados nas atividades agropecuárias e silviculturais, incluídos os relacionados a insumos utilizados nessas atividades;
- **Art. 2º, caput, inciso XV** {#art2_cpt_inc15} #residuo-solido Resíduos da construção civil: gerados em obras de construção civil, reformas, reparos e demolições, incluindo os resultantes da preparação e escavação de terrenos para obras civis;
- **Art. 2º, caput, inciso XVI** {#art2_cpt_inc16} #residuo-solido Resíduos de limpeza urbana: os originários da varrição, limpeza de logradouros e vias públicas e outros serviços de limpeza urbana;
- **Art. 2º, caput, inciso XVII** {#art2_cpt_inc17} #residuo-solido Resíduos domiciliares: os originários de atividades domésticas em residências;
- **Art. 2º, caput, inciso XVIII** {#art2_cpt_inc18} #residuo-solido Resíduo domiciliar bruto: resíduos domiciliares que não passaram por sistemas de triagem, classificação ou tratamento;
- **Art. 2º, caput, inciso XIX** {#art2_cpt_inc19} #definicao #efluente #residuo-solido Resíduos sólidos: qualquer forma de matéria ou substância, nos estados sólido e semi-sólido, que resulte de atividades de origem industrial, doméstica, hospitalar, comercial, agrícola, de serviços e de varrição, bem como de outras atividades da comunidade, capazes de causar a poluição ou a contaminação do meio ambiente. Ficam incluídos nesta definição os lodos provenientes de sistemas de tratamento de água, aqueles gerados em equipamentos e instalações de controle de poluição, bem como determinados líquidos cujas particularidades tornem inviável o seu lançamento na rede pública de esgotos ou corpos de água, ou exijam para isso soluções técnica e economicamente inviáveis em face a melhor tecnologia disponível;
- **Art. 2º, caput, inciso XX** {#art2_cpt_inc20} #residuo-solido Resíduos sólidos industriais: aqueles provenientes de processos produtivos produção de bens, bem como os provenientes de atividades de mineração e aqueles gerados em áreas de utilidades e manutenção das instalações industriais;
- **Art. 2º, caput, inciso XXI** {#art2_cpt_inc21} #residuo-solido Resíduos de serviços de saúde: os provenientes de qualquer unidade que execute atividade de natureza médico-assistencial às populações humana e animal, centros de pesquisa, desenvolvimento ou experimentação na área de farmacologia e saúde, bem como os medicamentos vencidos ou deteriorados oriundos dessas atividades;
- **Art. 2º, caput, inciso XXII** {#art2_cpt_inc22} #residuo-solido Resíduos sólidos urbanos: aqueles provenientes de residências ou de qualquer outra atividade que gere resíduos com características e equiparados aos domiciliares, bem como os resíduos de limpeza pública urbana;
- **Art. 2º, caput, inciso XXIII** {#art2_cpt_inc23} #residuo-solido Resíduo sólidos urbanos bruto: resíduos urbanos que não passaram por sistemas de triagem, classificação ou tratamento;
- **Art. 2º, caput, inciso XXIV** {#art2_cpt_inc24} #enquadramento #residuo-solido Transbordo: ponto intermediário entre o local de geração e o local de tratamento e destinação final do resíduo, com o objetivo de otimizar o transporte dos resíduos, reduzindo o tempo e o custo de operação;
- **Art. 2º, caput, inciso XXV** {#art2_cpt_inc25} #enquadramento #residuo-solido Transporte: movimentação física de resíduos entre pontos diferentes;
- **Art. 2º, caput, inciso XXVI** {#art2_cpt_inc26} #enquadramento Transportadora: empresas que executam o transporte;
- **Art. 2º, caput, inciso XXVII** {#art2_cpt_inc27} #residuo-solido Tratamento: o processo de transformação de natureza física, química ou biológica a que um resíduo sólido é submetido para minimização do risco à saúde pública e à qualidade do meio ambiente;
- **Art. 2º, caput, inciso XXVIII** {#art2_cpt_inc28} #residuo-solido Unidade de Preparo de Resíduos Sólidos (UPR): planta de mistura e pré- condicionamento de resíduos sólidos, através de operações específicas (processamento, trituração, tratamento, segregação, homogeneização entre outras) que tem por finalidade o preparo de lotes de resíduos com determinadas características para o aproveitamento energético de forma sustentável;
- **Art. 2º, caput, inciso XXIX** {#art2_cpt_inc29} #eia-rima #residuo-solido Uso de resíduos para fins agrícolas: utilização de resíduos sólidos em áreas destinadas à produção agrícola e silvicultura como fertilizantes/corretivos ou como matéria prima de fertilizantes/corretivos, de modo a proporcionar efeitos comprovadamente benéficos para o solo e espécies neles cultivadas.

###### Art. 3º {#art3}
Tags: #autorizacao-ambiental #enquadramento #lo #residuo-solido

**Art. 3º, caput** {#art3_cpt} #enquadramento #lo #residuo-solido Os empreendimentos que realizam coleta, transporte (transportadora), transbordo, armazenamento, tratamento e destinação final de resíduos deverão estar devidamente licenciados pelo órgão ambiental competente, com a Licença de Operação vigente.

###### Art. 4º {#art4}
Tags: #autorizacao-ambiental #enquadramento #residuo-solido #responsavel-tecnico

**Art. 4º, caput** {#art4_cpt} #enquadramento #residuo-solido #responsavel-tecnico Estão sujeitos à AUTORIZAÇÃO AMBIENTAL, com exceção dos resíduos relacionados no Art. 5º da presente Portaria, os procedimentos de transbordo, transporte, armazenamento, tratamento e destinação final dos resíduos sólidos:

> **Pendência de transcrição — Art. 4, quadro/tabela** {#art4_tab1}. Conteúdo preservado na extração textual que acompanha o lote; falta conferência visual das colunas. Não é texto normativo transcrito.


###### Art. 5º {#art5}
Tags: #autorizacao-ambiental #residuo-solido

**Art. 5º, caput** {#art5_cpt} #residuo-solido Estão dispensados de Autorização Ambiental os seguintes resíduos:

> **Pendência de transcrição — Art. 5, quadro/tabela** {#art5_tab1}. Conteúdo preservado na extração textual que acompanha o lote; falta conferência visual das colunas. Não é texto normativo transcrito.


###### Art. 6º {#art6}
Tags: #autorizacao-ambiental #efluente #proibicao #residuo-solido

**Art. 6º, caput** {#art6_cpt} #proibicao É proibido o uso para fins agrícolas de:
- **Art. 6º, caput, inciso I** {#art6_cpt_inc1} #efluente #residuo-solido Resíduos e efluentes gerados no tratamento de efluente sanitário, com exceção do lodo de esgoto gerado em empreendimentos específicos de saneamento, conforme legislação pertinente em vigor.
- **Art. 6º, caput, inciso II** {#art6_cpt_inc2} #efluente #residuo-solido Resíduos e efluentes que contenham substâncias consideradas contaminantes para o solo e/ou não apresentem potencial agronômico e efeitos benéficos que justifique sua utilização na agricultura.

**Art. 6º, parágrafo único** {#art6_par1u} #efluente #residuo-solido Para o uso agrícola de resíduos gerados em tratamento de efluentes industriais ou em sistemas que misturem com efluente sanitário, será analisado caso a caso, considerando a proporção da vazão do efluente sanitário tratado em relação a vazão total do sistema.

###### Art. 7º {#art7}
Tags: #autorizacao-ambiental #residuo-solido

**Art. 7º, caput** {#art7_cpt} #residuo-solido O uso de resíduos na alimentação animal só será autorizado mediante aprovação prévia dos órgãos responsáveis competentes, com exceção do artigo [[#art5|5º]].

###### Art. 8º {#art8}
Tags: #autorizacao-ambiental #efluente #eia-rima #residuo-solido

**Art. 8º, caput** {#art8_cpt} #residuo-solido Não serão autorizados, para destinação no Estado do Paraná, os seguintes resíduos gerados em outros Estados:
- **Art. 8º, caput, inciso I** {#art8_cpt_inc1} #efluente Efluentes líquidos;
- **Art. 8º, caput, inciso II** {#art8_cpt_inc2} #eia-rima #residuo-solido Utilização agrícola de resíduos, com exceção de resíduos que serão utilizados como matéria prima em industrias de fertilizantes/corretivos, exceto compostagem, desde que o estabelecimento, matéria prima e produto final estejam seja devidamente regularizados no MAPA - Ministério da Agricultura, Pecuária e Abastecimento.
- **Art. 8º, caput, inciso III** {#art8_cpt_inc3} Disposição em aterros;
- **Art. 8º, caput, inciso IV** {#art8_cpt_inc4} #residuo-solido Resíduos relacionados na [[resolucao-cema-50-2005|Resolução CEMA N° 050/2005]] ou outra que venha a substituí-la;
- **Art. 8º, caput, inciso V** {#art8_cpt_inc5} #residuo-solido Resíduos sólidos urbanos ou domiciliares brutos;

###### Art. 9º {#art9}
Tags: #autorizacao-ambiental #prazo #proibicao #residuo-solido

**Art. 9º, caput** {#art9_cpt} #proibicao #residuo-solido Fica proibida a disposição final em aterros industriais, localizados no Estado do Paraná, dos resíduos abaixo relacionados:
- **Art. 9º, caput, inciso I** {#art9_cpt_inc1} Borras Oleosas;
- **Art. 9º, caput, inciso II** {#art9_cpt_inc2} Borras de processos petroquímicos;
- **Art. 9º, caput, inciso III** {#art9_cpt_inc3} Borras de fundo de tanques de combustíveis e de produtos inflamáveis;
- **Art. 9º, caput, inciso IV** {#art9_cpt_inc4} Elementos filtrantes de filtros de combustíveis e lubrificantes;
- **Art. 9º, caput, inciso V** {#art9_cpt_inc5} Solventes e borras de solventes;
- **Art. 9º, caput, inciso VI** {#art9_cpt_inc6} Borras de tintas a base de solventes;
- **Art. 9º, caput, inciso VII** {#art9_cpt_inc7} Ceras contendo solventes;
- **Art. 9º, caput, inciso VIII** {#art9_cpt_inc8} Panos, estopas, serragem, EPIs, elementos filtrantes e absorventes contaminados com óleos lubrificantes, solventes ou combustíveis (álcool, gasolina, óleo diesel, etc);
- **Art. 9º, caput, inciso IX** {#art9_cpt_inc9} Lodo de caixa separadora de óleo com mais de 5% de hidrocarbonetos derivados de petróleo ou mais 70% de umidade;
- **Art. 9º, caput, inciso X** {#art9_cpt_inc10} Solo contaminado com combustíveis ou com qualquer um dos componentes acima identificados.

**Art. 9º, § 1º** {#art9_par1} #residuo-solido Cabe aos geradores e gerenciadores dos resíduos relacionados neste artigo o cumprimento do mesmo.

**Art. 9º, § 2º** {#art9_par2} #prazo Fica estabelecido o prazo de 12 (doze) meses, a partir da publicação desta Portaria, para o cumprimento deste artigo.

###### Art. 10 {#art10}
Tags: #autorizacao-ambiental #residuo-solido

**Art. 10, caput** {#art10_cpt} #residuo-solido Para a queima de resíduos em caldeira, deverá ser solicitada Autorização Ambiental para teste de queima, atendendo os critérios estabelecidos na [[resolucao-sema-42-2008|RESOLUÇÃO SEMA Nº 042/08]] ou outra que venha a substituí-la.

###### Art. 11 {#art11}
Tags: #autorizacao-ambiental #residuo-solido #responsavel-tecnico

**Art. 11, caput** {#art11_cpt} #residuo-solido #responsavel-tecnico Não será autorizado o coprocessamento dos resíduos listados no Art. 3º da [[resolucao-cema-76-2009|Resolução CEMA N° 76/2009]] ou outra que venha a substituí-la.

###### Art. 12 {#art12}
Tags: #autorizacao-ambiental #eia-rima #residuo-solido

**Art. 12, caput** {#art12_cpt} #residuo-solido Os resíduos gerados em UPRS instaladas em outros Estados, somente poderão ser destinados para coprocessamento em cimenteiras localizadas no Paraná, desde que atendidos os seguintes critérios:
- **Art. 12, caput, inciso I** {#art12_cpt_inc1} O empreendimento deve estar devidamente licenciado pelo órgão ambiental competente;
- **Art. 12, caput, inciso II** {#art12_cpt_inc2} #residuo-solido A planta deve operar exclusivamente com a atividade de mistura e pré-condicionamento de resíduos para coprocessamento em fornos de clinquer;
- **Art. 12, caput, inciso III** {#art12_cpt_inc3} #eia-rima #residuo-solido A utilização do resíduo obtido nas de mistura e pré-condicionamento deverá ser única e exclusivamente para substitutos de combustível, desde que haja comprovação da ocorrência de ganho de energia, e resíduos substitutos da matéria prima de fabricação de cimento;
- **Art. 12, caput, inciso IV** {#art12_cpt_inc4} #residuo-solido O interessado deverá requerer a Autorização Ambiental por categoria de resíduos, de acordo com a IN 01/2013-IBAMA.

###### Art. 13 {#art13}
Tags: #autorizacao-ambiental #documentacao #enquadramento #licenciamento-ambiental #residuo-solido

**Art. 13, caput** {#art13_cpt} #enquadramento #residuo-solido A Autorização Ambiental, para as atividades de transbordo, transporte, armazenamento, tratamento e destinação final do(s) resíduo(s) sólidos, deverão ser requeridas pelo gerador do(s) resíduo(s), através do SGA-Sistema de Gestão Ambiental.

**Art. 13, parágrafo único** {#art13_par1u} #documentacao #residuo-solido Em se tratando de resíduos gerados nos empreendimentos abaixo relacionados, a Autorização Ambiental poderá ser requerida pelo gerenciador dos resíduos em questão, devendo informar no requerimento a relação dos geradores dos resíduos:
- **Art. 13, parágrafo único, inciso I** {#art13_par1u_inc1} Estabelecimentos de serviço de saúde;
- **Art. 13, parágrafo único, inciso II** {#art13_par1u_inc2} Serviços de manutenção e reparação de veículos automotores (exceto postos de combustíveis);
- **Art. 13, parágrafo único, inciso III** {#art13_par1u_inc3} #licenciamento-ambiental Empreendimentos Dispensados de Licenciamento Ambiental Estadual;
- **Art. 13, parágrafo único, inciso IV** {#art13_par1u_inc4} #residuo-solido Plantas de mistura e pré-condicionamento de resíduos, instaladas em outros Estados;
- **Art. 13, parágrafo único, inciso V** {#art13_par1u_inc5} Estabelecimentos previstos em programas de logística reversa.

###### Art. 14 {#art14}
Tags: #autorizacao-ambiental #documentacao #residuo-solido #responsavel-tecnico

**Art. 14, caput** {#art14_cpt} #residuo-solido A Autorização Ambiental para resíduos gerados no Paraná serão emitidas automaticamente através do Sistema de Gestão Ambiental-SGA, com exceção da destinação final para uso agrícola e para alimentação animal.

**Art. 14, § 1º** {#art14_par1} #responsavel-tecnico As informações prestadas ao Sistema de Gestão Ambiental-SGA, para a emissão automática da Autorização Ambiental, são de inteira responsabilidade do Responsável Legal e do Responsável Técnico da atividade e/ou empreendimento.

**Art. 14, § 2º** {#art14_par2} #documentacao #residuo-solido #responsavel-tecnico O Responsável Técnico informado no requerimento de Autorização Ambiental automática deverá ser devidamente habilitado pelo respectivo Conselho Profissional para atuar com gestão de resíduos sólidos.

**Art. 14, § 3º** {#art14_par3} #documentacao #responsavel-tecnico A omissão e falsidade das informações prestadas no requerimento estão sujeitas as sanções penais previstas no Art. 299 do Código Penal.

###### Art. 15 {#art15}
Tags: #autorizacao-ambiental #definicao #documentacao #efluente #lo #residuo-solido

**Art. 15, caput** {#art15_cpt} #documentacao #residuo-solido Os requerimentos de Autorização Ambiental para a destinação no Estado do Paraná, de resíduos gerados no Paraná e em outros Estados, deverão ser protocolados através do Sistema de Gestão Ambiental -SGA, disponível no site do IAP, instruídos na forma prevista abaixo.
- **Art. 15, caput, inciso I** {#art15_cpt_inc1} #residuo-solido Disposição de resíduos em aterros:
  - **Art. 15, caput, inciso I, alínea "a"** {#art15_cpt_inc1_alia} #lo Cópia da Licença de Operação do empreendimento gerador;
  - **Art. 15, caput, inciso I, alínea "b"** {#art15_cpt_inc1_alib} #lo Cópia da Licença de Operação do responsável pelo tratamento, quando houver;
  - **Art. 15, caput, inciso I, alínea "c"** {#art15_cpt_inc1_alic} #lo #residuo-solido Cópia da Licença de Operação do receptor do resíduo;
  - **Art. 15, caput, inciso I, alínea "d"** {#art15_cpt_inc1_alid} #residuo-solido Anuência do receptor do(s) resíduo(s);
  - **Art. 15, caput, inciso I, alínea "e"** {#art15_cpt_inc1_alie} #residuo-solido Memorial descritivo e fluxograma do processo gerador do resíduo;
  - **Art. 15, caput, inciso I, alínea "f"** {#art15_cpt_inc1_alif} #definicao #residuo-solido Laudo de Classificação de acordo com a NBR 10.004/04 - Resíduos Sólidos – Classificação, acompanhado dos respectivos relatórios de ensaios analíticos, exceto para aqueles que apresentam periculosidade, conforme definido em 3.2, ou uma das características descritas em a 4.2.1.5, ou constem nos anexos A, B ou H, conforme NBR 10.004/04;
  - **Art. 15, caput, inciso I, alínea "g"** {#art15_cpt_inc1_alig} Recolhimento da taxa ambiental;
  - **Art. 15, caput, inciso I, alínea "h"** {#art15_cpt_inc1_alih} #documentacao Outros documentos a critério do IAP.
- **Art. 15, caput, inciso II** {#art15_cpt_inc2} #residuo-solido Utilização agrícola de resíduos:
  - **Art. 15, caput, inciso II, alínea "a"** {#art15_cpt_inc2_alia} #lo Cópia da Licença de Operação do empreendimento gerador;
  - **Art. 15, caput, inciso II, alínea "b"** {#art15_cpt_inc2_alib} #lo Cópia da Licença de Operação do responsável pelo tratamento, quando houver;
  - **Art. 15, caput, inciso II, alínea "c"** {#art15_cpt_inc2_alic} #lo #residuo-solido Cópia da Licença de Operação do receptor do resíduo, se for o caso;
  - **Art. 15, caput, inciso II, alínea "d"** {#art15_cpt_inc2_alid} #residuo-solido Anuência do proprietário/receptor, no caso de disposição do resíduo em áreas em que o interessado não é o proprietário;
  - **Art. 15, caput, inciso II, alínea "e"** {#art15_cpt_inc2_alie} #residuo-solido Memorial descritivo e fluxograma do processo gerador do resíduo;
  - **Art. 15, caput, inciso II, alínea "f"** {#art15_cpt_inc2_alif} Apresentar caracterização química da massa bruta (anexo G da NBR 10.004/04, com exceção dos elementos não pertinentes, isto é, os ingredientes ativos componentes de agrotóxicos);
  - **Art. 15, caput, inciso II, alínea "g"** {#art15_cpt_inc2_alig} #definicao #residuo-solido Laudo de Classificação de acordo com a NBR 10.004/04 - Resíduos Sólidos – Classificação, acompanhado dos respectivos relatórioss de ensaios analíticos, exceto para aqueles que apresentam periculosidade, conforme definido em 3.2, ou uma das características descritas em a 4.2.1.5, ou constem nos anexos A, B ou H, conforme NBR 10.004/04, no caso da disposição de resíduos classe II.
  - **Art. 15, caput, inciso II, alínea "h"** {#art15_cpt_inc2_alih} #residuo-solido Caracterização agronômica do resíduo, comprovando o potencial agronômico do mesmo;
  - **Art. 15, caput, inciso II, alínea "i"** {#art15_cpt_inc2_alii} #residuo-solido Projeto para utilização agrícola de resíduos, elaborado por técnico habilitado e apresentado de acordo com as diretrizes específicas deste IAP (ANEXO 1).
  - **Art. 15, caput, inciso II, alínea "j"** {#art15_cpt_inc2_alij} Recolhimento da taxa ambiental;
  - **Art. 15, caput, inciso II, alínea "k"** {#art15_cpt_inc2_alik} #documentacao Outros documentos a critério do IAP.
- **Art. 15, caput, inciso III** {#art15_cpt_inc3} #residuo-solido Destinação para plantas de mistura e pré-condicionamento de resíduos (UPRs) para coprocessamento em fornos de clinquer instaladas no Estado do Paraná:
  - **Art. 15, caput, inciso III, alínea "a"** {#art15_cpt_inc3_alia} #lo Cópia da Licença de Operação do empreendimento gerador;
  - **Art. 15, caput, inciso III, alínea "b"** {#art15_cpt_inc3_alib} #lo Cópia da Licença de Operação da UPR;
  - **Art. 15, caput, inciso III, alínea "c"** {#art15_cpt_inc3_alic} #lo Cópia da Licença de Operação da(s) cimenteira(s);
  - **Art. 15, caput, inciso III, alínea "d"** {#art15_cpt_inc3_alid} #residuo-solido Anuência do receptor do(s) resíduo(s);
  - **Art. 15, caput, inciso III, alínea "e"** {#art15_cpt_inc3_alie} #residuo-solido Memorial descritivo e fluxograma do processo gerador do resíduo;
  - **Art. 15, caput, inciso III, alínea "f"** {#art15_cpt_inc3_alif} #residuo-solido Laudo de determinação de PCS (Poder Calorífico Superior) da massa bruta do resíduo, desde que o mesmo seja caracterizado como substituto de combustível, acompanhado dos respectivos relatórios de ensaios analíticos;
  - **Art. 15, caput, inciso III, alínea "g"** {#art15_cpt_inc3_alig} #residuo-solido Laudo analítico da composição elementar da massa bruta do resíduo que compõem a mistura considerando os componentes: S, Cl, F, Al, Fe, Si, Ca, K, Zn, Ba, P, Cd, Hg, Tl, As, Co, Ni, Se, Te, Sb, Cr, Sn, Pb, V e Umidade, com resultados expressos em mg/kg e em percentual;
  - **Art. 15, caput, inciso III, alínea "h"** {#art15_cpt_inc3_alih} Recolhimento da taxa ambiental;
  - **Art. 15, caput, inciso III, alínea "i"** {#art15_cpt_inc3_alii} #documentacao Outros documentos a critério do IAP.
- **Art. 15, caput, inciso IV** {#art15_cpt_inc4} #residuo-solido Destinação de resíduos diretamente para coprocessamento:
  - **Art. 15, caput, inciso IV, alínea "a"** {#art15_cpt_inc4_alia} #lo Cópia da Licença de Operação do empreendimento gerador;
  - **Art. 15, caput, inciso IV, alínea "b"** {#art15_cpt_inc4_alib} #lo #residuo-solido Cópia da Licença de Operação do receptor do resíduo;
  - **Art. 15, caput, inciso IV, alínea "c"** {#art15_cpt_inc4_alic} Anuência da cimenteira;
  - **Art. 15, caput, inciso IV, alínea "d"** {#art15_cpt_inc4_alid} #residuo-solido Memorial descritivo e fluxograma do processo gerador do resíduo;
  - **Art. 15, caput, inciso IV, alínea "e"** {#art15_cpt_inc4_alie} #residuo-solido Laudo de determinação de PCS (Poder Calorífico Superior) da massa bruta do resíduo, desde que o mesmo seja caracterizado como substituto de combustível, acompanhado dos respectivos relatórios de ensaios analíticos;
  - **Art. 15, caput, inciso IV, alínea "f"** {#art15_cpt_inc4_alif} #residuo-solido Laudo analítico da composição elementar da massa bruta do resíduo que compõem a mistura considerando os componentes: S, Cl, F, Al, Fe, Si, Ca, K, Zn, Ba, P, Cd, Hg, Tl, As, Co, Ni, Se, Te, Sb, Cr, Sn, Pb, V e Umidade, com resultados expressos em mg/kg e em percentual;
  - **Art. 15, caput, inciso IV, alínea "g"** {#art15_cpt_inc4_alig} Recolhimento da taxa ambiental;
  - **Art. 15, caput, inciso IV, alínea "h"** {#art15_cpt_inc4_alih} #documentacao Outros documentos a critério do IAP.
- **Art. 15, caput, inciso V** {#art15_cpt_inc5} #residuo-solido Destinação para coprocessamento em cimenteiras localizadas no Paraná de resíduos gerados em plantas de mistura e pré-condicionamento instaladas em outros Estados, conforme artigo [[#art13|13]] da presente Portaria:
  - **Art. 15, caput, inciso V, alínea "a"** {#art15_cpt_inc5_alia} #lo Cópia da Licença de Operação da planta de mistura e pré-condicionamento;
  - **Art. 15, caput, inciso V, alínea "b"** {#art15_cpt_inc5_alib} #lo Cópia da Licença de Operação da cimenteira;
  - **Art. 15, caput, inciso V, alínea "c"** {#art15_cpt_inc5_alic} Anuência da cimenteira;
  - **Art. 15, caput, inciso V, alínea "d"** {#art15_cpt_inc5_alid} #residuo-solido Relatórios contendo: Tabela relacionando código e descrição dos resíduos que irão compor o lote de resíduos, conforme IN/2013-IBAMA, bem como a quantidade estimada (T/ano) por código de resíduos; Tabela com a nome/razão social das empresas geradoras por código da categoria do resíduo, CNPJ e atividade; Laudo de determinação de PCS (Poder Calorífico Superior) da massa bruta, por categoria do resíduo, acompanhado dos respectivos relatórios de ensaios analíticos; Laudo analítico da composição elementar da massa bruta da massa bruta, por categoria do resíduo considerando os componentes: S, Cl, F, Al, Fe, Si, Ca, K, Zn, Ba, P, Cd, Hg, Tl, As, Co, Ni, Se, Te, Sb, Cr, Sn, Pb, V e Umidade, com resultados expressos em mg/kg e em percentual, acompanhado dos respectivos relatórios de ensaios analíticos;
  - **Art. 15, caput, inciso V, alínea "e"** {#art15_cpt_inc5_alie} #residuo-solido Laudo de determinação de PCS (Poder Calorífico Superior) do lote de resíduos composto pelos resíduos relacionados no item d), acompanhado dos respectivos relatórios de ensaios analíticos;
  - **Art. 15, caput, inciso V, alínea "f"** {#art15_cpt_inc5_alif} #residuo-solido Laudo analítico da composição elementar do lote de resíduos composto pelos resíduos relacionados no item d), considerando os componentes: S, Cl, F, Al, Fe, Si, Ca, K, Zn, Ba, P, Cd, Hg, Tl, As, Co, Ni, Se, Te, Sb, Cr, Sn, Pb, V e Umidade, com resultados expressos em mg/kg e em percentual;
  - **Art. 15, caput, inciso V, alínea "g"** {#art15_cpt_inc5_alig} Comprovante de recolhimento da taxa ambiental;
  - **Art. 15, caput, inciso V, alínea "h"** {#art15_cpt_inc5_alih} #documentacao Outros documentos a critério do IAP.
- **Art. 15, caput, inciso VI** {#art15_cpt_inc6} #efluente Destinação de efluentes líquidos gerados em empreendimentos localizados no Estado do Paraná para tratamento e destinação final em plantas de tratamento de efluentes:
  - **Art. 15, caput, inciso VI, alínea "a"** {#art15_cpt_inc6_alia} #lo Cópia da Licença de Operação do empreendimento gerador;
  - **Art. 15, caput, inciso VI, alínea "b"** {#art15_cpt_inc6_alib} #lo Cópia da Licença de Operação do responsável pelo tratamento, quando houver;
  - **Art. 15, caput, inciso VI, alínea "c"** {#art15_cpt_inc6_alic} #lo #residuo-solido Cópia da Licença de Operação do receptor do resíduo;
  - **Art. 15, caput, inciso VI, alínea "d"** {#art15_cpt_inc6_alid} #residuo-solido Anuência do receptor do(s) resíduo(s);
  - **Art. 15, caput, inciso VI, alínea "e"** {#art15_cpt_inc6_alie} #residuo-solido Memorial descritivo e fluxograma do processo gerador do resíduo;
  - **Art. 15, caput, inciso VI, alínea "f"** {#art15_cpt_inc6_alif} #efluente Laudo analítico da composição do efluente bruto, considerando os parâmetros: pH, Materiais Sedimentáveis, Sólidos suspensos totais, Materiais flutuantes, DBO, DQO, Óleos Minerais, Óleos vegetais e gorduras animais, toxicidade e outros critério do órgão ambiental, considerando a atividade geradora do efluente.
  - **Art. 15, caput, inciso VI, alínea "g"** {#art15_cpt_inc6_alig} Comprovante de recolhimento da taxa ambiental.
  - **Art. 15, caput, inciso VI, alínea "h"** {#art15_cpt_inc6_alih} #documentacao Outros documentos a critério do IAP.
- **Art. 15, caput, inciso VII** {#art15_cpt_inc7} #residuo-solido Destinação de resíduos gerados no Estado do Paraná para outros Estados da Federação:
  - **Art. 15, caput, inciso VII, alínea "a"** {#art15_cpt_inc7_alia} #lo Cópia da Licença de Operação do empreendimento gerador;
  - **Art. 15, caput, inciso VII, alínea "b"** {#art15_cpt_inc7_alib} #lo Cópia da Licença de Operação do responsável pelo tratamento, quando houver;
  - **Art. 15, caput, inciso VII, alínea "c"** {#art15_cpt_inc7_alic} #lo #residuo-solido Cópia da Licença de Operação do receptor do resíduo;
  - **Art. 15, caput, inciso VII, alínea "d"** {#art15_cpt_inc7_alid} #documentacao Autorização, declaração ou documento equivalente emitido pela autoridade ambiental competente dos Estados receptores;
  - **Art. 15, caput, inciso VII, alínea "e"** {#art15_cpt_inc7_alie} Recolhimento da taxa ambiental;
  - **Art. 15, caput, inciso VII, alínea "f"** {#art15_cpt_inc7_alif} #documentacao Outros documentos a critério do IAP.
- **Art. 15, caput, inciso VIII** {#art15_cpt_inc8} #residuo-solido Outras formas de destinação de resíduos no Estado do Paraná não especificadas anteriormente:
  - **Art. 15, caput, inciso VIII, alínea "a"** {#art15_cpt_inc8_alia} #lo Cópia da Licença de Operação do empreendimento gerador;
  - **Art. 15, caput, inciso VIII, alínea "b"** {#art15_cpt_inc8_alib} #lo Cópia da Licença de Operação do responsável pelo tratamento, quando houver;
  - **Art. 15, caput, inciso VIII, alínea "c"** {#art15_cpt_inc8_alic} #lo #residuo-solido Cópia da Licença de Operação do receptor do resíduo;
  - **Art. 15, caput, inciso VIII, alínea "d"** {#art15_cpt_inc8_alid} #residuo-solido Memorial descritivo e fluxograma do processo gerador do resíduo;
  - **Art. 15, caput, inciso VIII, alínea "e"** {#art15_cpt_inc8_alie} Recolhimento da taxa ambiental;
  - **Art. 15, caput, inciso VIII, alínea "f"** {#art15_cpt_inc8_alif} #documentacao Outros documentos a critério do IAP.

**Art. 15, § 1º** {#art15_par1} Além do laudo de análises físico-químicas exigidas, o laboratório executante do da análise deverá manter, pelo período mínimo de um ano, amostra testemunha coletada de acordo com a NBR 10007/04, para eventual realização de novo laudo.

**Art. 15, § 2º** {#art15_par2} Os relatórios de ensaios deverão ser emitidos por laboratórios que possuam o Certificado de Cadastramento de Laboratórios de Ensaios Ambientais-CCL, emitido pelo IAP, conforme [[resolucao-cema-100-2017|Resolução CEMA 100/2017]].

**Art. 15, § 3º** {#art15_par3} #documentacao A validade dos relatórios de ensaios deve ser inferior a 12 meses da data do protocolo de solicitação de requerimento de Autorização Ambiental.

###### Art. 16 {#art16}
Tags: #autorizacao-ambiental #lo #renovacao #residuo-solido

**Art. 16, caput** {#art16_cpt} #lo #renovacao #residuo-solido A movimentação, expedição e recebimento, dos resíduos autorizados deverá obrigatoriamente ser registrada através do sistema de movimentação (sga-mr.pr.gov.br) até a emissão do Certificado de Aprovação de Destinação Final-CADEF e não havendo a manifestação dos mesmos, comprometerá a Renovação da Licença de Operação do Gerador e do Receptor do resíduo, a emissão de nova Autorização Ambiental, bem como sujeitará os responsáveis a aplicação das sanções legais.

**Art. 16, parágrafo único** {#art16_par1u} #residuo-solido O Certificado de Aprovação de Destinação Final-CADEF, quando da sua emissão, deverá ser assinado pelo responsável pela destinação final do resíduo e entregue ao Gerador.

###### Art. 17 {#art17}
Tags: #autorizacao-ambiental #documentacao #enquadramento #residuo-solido

**Art. 17, caput** {#art17_cpt} #documentacao #enquadramento #residuo-solido O lote de resíduos, gerados em UPR´s, só poderá ser destinado para coprocessamento quando da formulação do lote através do sistema de movimentação (sga-mr.pr.gov.br) do IAP, devendo ser informado o número da Nota Fiscal-NF, o número do Manifesto de Transporte de Resíduos-MTR, anexar o Laudo Analítico do lote de resíduos e o documento original de anuência da cimenteira com aceitação de coprocessamento do resíduo e justificativa técnica de sua utilização, elaborada por técnico habilitado.

###### Art. 18 {#art18}
Tags: #autorizacao-ambiental #prazo #residuo-solido

**Art. 18, caput** {#art18_cpt} #prazo A Autorização Ambiental será concedida por prazo não superior ao estabelecido em Resoluções do Conselho Estadual de Meio Ambiente-CEMA.

###### Art. 19 {#art19}
Tags: #autorizacao-ambiental #residuo-solido

**Art. 19, caput** {#art19_cpt} #residuo-solido A análise dos processos de Autorização Ambiental de resíduos para uso agrícola, alimentação animal, resíduos gerados em outros Estados, bem como outros resíduos, a critério do órgão ambiental estadual, é de competência da Câmara Técnica de Resíduos-CTR, nomeada em Portaria específica.

###### Art. 20 {#art20}
Tags: #autorizacao-ambiental #enquadramento #residuo-solido

**Art. 20, caput** {#art20_cpt} #enquadramento #residuo-solido Os geradores de resíduos sólidos, de qualquer natureza, são responsáveis pelo seu acondicionamento, armazenamento, coleta, transporte, tratamento, disposição final, pelo passivo ambiental oriundo da desativação de sua fonte geradora, bem como pela recuperação de áreas degradadas.

###### Art. 21 {#art21}
Tags: #autorizacao-ambiental #residuo-solido

**Art. 21, caput** {#art21_cpt} #residuo-solido As atividades geradoras de resíduos sólidos instaladas no território paranaense ficam obrigadas a efetuar anualmente o seu cadastramento junto ao órgão ambiental estadual através do www.sga-ir.pr.gov.br, para fins de controle e inventário dos resíduos sólidos gerados, informando inclusive qual a destinação final atualmente dispensada aos mesmos, sob pena das sanções previstas em lei.

**Art. 21, parágrafo único** {#art21_par1u} #residuo-solido O gerador obrigatoriamente deverá informar através do inventário de resíduos sólidos o Número do Certificado de Aprovação de Destinação Final-CADEF.

###### Art. 22 {#art22}
Tags: #autorizacao-ambiental #definicao #residuo-solido

**Art. 22, caput** {#art22_cpt} #definicao Casos não contemplados na presente Portaria serão definidos pelo IAP.

###### Art. 23 {#art23}
Tags: #autorizacao-ambiental #residuo-solido

**Art. 23, caput** {#art23_cpt} Esta Portaria entrará em vigor na data de sua publicação, ficando revogadas as disposições em contrário e a [[portaria-iap-202-2016|Portaria IAP nº 202/2016]].

## Fecho

EVERTON LUIZ DA COSTA SOUZA Diretor Presidente do Instituto Ambiental do Paraná

### Diretrizes específicas para Projeto de Utilização Agrícola {#anexo1}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|
| [[portaria-iat-33-2022]] | Norma inteira | Revogação expressa registrada no acervo. |

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (portaria IAP 212 2019.pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- Anexo próprio citado ou vinculado em arquivo separado, sem o respectivo conteúdo no PDF do lote. Não foi importado material externo ou presumida sua redação.
- Cláusula genérica de revogação: não foram atribuídas revogações tácitas por inferência; exige decisão humana.
- Situação revogada conforme relação expressa já cadastrada no acervo: [[portaria-iat-33-2022]]. Regras de transição e processos antigos devem ser avaliados separadamente.
