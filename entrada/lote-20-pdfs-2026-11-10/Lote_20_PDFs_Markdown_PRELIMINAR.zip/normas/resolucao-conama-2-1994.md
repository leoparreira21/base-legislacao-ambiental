---
norma: "Resolução CONAMA nº 2/1994"
arquivo: resolucao-conama-2-1994
tipo: resolucao
esfera: federal
uf: BR
numero: 2
ano: 1994
data_assinatura: 1994-03-18
ementa: "Define formações vegetais primárias e estágios sucessionais de vegetação secundária, com finalidade de orientar os procedimentos de licenciamento de exploração da vegetação nativa no Estado do Paraná."
situacao: vigente
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: []
revoga: []
revogado_por: []
cita: ["[[decreto-federal-750-1993]]", "[[decreto-federal-99274-1990]]", "[[lei-federal-11428-2006]]", "[[resolucao-conama-10-1993]]", "[[resolucao-conama-388-2007]]"]
tags: ["definicao", "enquadramento", "mata-atlantica", "vegetacao"]
fonte: "PDF fornecido: conama 002 1994.pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
---

# Resolução CONAMA nº 2/1994

> Define formações vegetais primárias e estágios sucessionais de vegetação secundária, com finalidade de orientar os procedimentos de licenciamento de exploração da vegetação nativa no Estado do Paraná.

## Preâmbulo

RESOLUÇÃO CONAMA nº 2, de 18 de março de 1994 Publicada no DOU no 59, de 28 de março de 1994, Seção 1, páginas 4513-4514 Correlações: · Em atendimento ao art. 6o do [[decreto-federal-750-1993|Decreto no 750/93]] e art. 1o, § 1o da [[resolucao-conama-10-1993|Resolução CONAMA no 10/93]] · Convalidada pela [[resolucao-conama-388-2007|Resolução CONAMA nº 388/07]] para fins do disposto na [[lei-federal-11428-2006|Lei 11.428, de 22 de dezembro de 2006]] Define formações vegetais primárias e estágios sucessio-nais de vegetação secundária, com finalidade de orientar os procedimentos de licenciamento de exploração da vegetação nativa no Estado do Paraná.

O PRESIDENTE DO CONSELHO NACIONAL DO MEIO AMBIENTE - CONAMA, AD REFERENDUM do Plenário, no uso de suas atribuições e tendo em vista o disposto no artigo 9o, do [[decreto-federal-99274-1990|Decreto no 99.274, de 6 de junho de 1990]]; Considerando ação conjunta entre o Secretário de Meio Ambiente do Estado do Paraná e o Superintendente do IBAMA no Estado do Paraná; Considerando a necessidade de se definir as formações vegetais primárias, bem como os estágios sucessionais de vegetação secundária, com finalidade de orientar os procedimen-tos de licenciamento de exploração da vegetação nativa no Estado do Paraná, resolve:

###### Art. 1º {#art1}
Tags: #definicao #mata-atlantica #vegetacao

**Art. 1º, caput** {#art1_cpt} #definicao Considera-se como vegetação primária, toda comunidade vegetal, de máxima expressão local, com grande diversidade biológica, sendo os efeitos antrópicos mínimos, a ponto de não afetar significativamente suas características originais de estrutura e de espécie.

###### Art. 2º {#art2}
Tags: #enquadramento #mata-atlantica #vegetacao

**Art. 2º, caput** {#art2_cpt} As formações florestais abrangidas pela Floresta Ombrófila Densa (terras baixas, submontana e montana), Floresta Ombrófila Mista (montana) e a Floresta Estacional Semidecidual (submontana), em seus diferentes estágios de sucessão de vegetação se-cundária, apresentam os seguintes parâmetros, no Estado do Paraná, tendo como critério a amostragem dos indivíduos arbóreos com DAP igual ou maior que 20 cm.

**Art. 2º, § 1º** {#art2_par1} Estágio inicial:
- **Art. 2º, § 1º, alínea "a"** {#art2_par1_alia} fisionomia herbáceo/arbustiva, formando um estrato, variando de fechado a aberto, com a presença de espécies predominantemente heliófitas;
- **Art. 2º, § 1º, alínea "b"** {#art2_par1_alib} espécies lenhosas ocorrentes variam entre um a dez espécies, apresentam amplitude diamétrica pequena e amplitude de altura pequena, podendo a altura das espécies lenho-sas do dossel chegar até 10 m, com área basal (m2/ha) variando entre 8 a 20 m2/ha; com distribuição diamétrica variando entre 5 a 15 cm, e média da amplitude do DAP 10 cm;
- **Art. 2º, § 1º, alínea "c"** {#art2_par1_alic} o crescimento das árvores do dossel é rápido e a vida média das árvores do dossel é curta;
- **Art. 2º, § 1º, alínea "d"** {#art2_par1_alid} as epífitas são raras, as lianas herbáceas abundantes, e as lianas lenhosas apresen-tam-se ausentes. As espécies gramíneas são abundantes. A serapilheira quando presente pode ser contínua ou não, formando uma camada fina pouco decomposta;
- **Art. 2º, § 1º, alínea "e"** {#art2_par1_alie} a regeneração das árvores do dossel é ausente;
- **Art. 2º, § 1º, alínea "f"** {#art2_par1_alif} as espécies mais comuns, indicadoras do estágio inicial de regeneração, entre outras podem ser consideradas: bracatinga (Mimosa scabrella), vassourão (Vernonia discolor), aroeira (Schinus terebenthi folius), jacatirão (Tibouchina selowiana e Miconia circrescens), embaúba (Cecropia adenopus), maricá (Mimosa bimucronata), taquara e taquaruçu (Bam-busaa spp).

**Art. 2º, § 2º** {#art2_par2} Estágio médio:
- **Art. 2º, § 2º, alínea "a"** {#art2_par2_alia} fisionomia arbustiva e/ou arbórea, formando de 1 a 2 estratos, com a presença de espécies predominantemente facultativas;
- **Art. 2º, § 2º, alínea "b"** {#art2_par2_alib} as espécies lenhosas ocorrentes variam entre 5 e 30 espécies, apresentam amplitude diamétrica média e amplitude de altura média. A altura das espécies lenhosas do dossel varia entre 8 e 17 m, com área basal (m2/ha) variando entre 15 e 35 m2/ha; com distribui-ção diamétrica variando entre 10 a 40 cm, e média da amplitude do DAP 25 cm;
- **Art. 2º, § 2º, alínea "c"** {#art2_par2_alic} o crescimento das árvores do dossel é moderado e a vida média das árvores do dossel é média;
- **Art. 2º, § 2º, alínea "d"** {#art2_par2_alid} as epífitas são poucas, as lianas herbáceas poucas e as lianas lenhosas raras. As espécies gramíneas são poucas. A serapilheira pode apresentar variações de espessura de acordo com a estação do ano e de um lugar a outro;
- **Art. 2º, § 2º, alínea "e"** {#art2_par2_alie} a regeneração das árvores do dossel é pouca; f ) as espécies mais comuns, indicadoras do estágio médio de regeneração, entre ou-tras, podem ser consideradas: congonha (Ilex theezans), vassourão-branco (Piptocarpha angustifolia), canela guaica (Ocotea puberula), palmito (Euterpe edulis), guapuruvu (Schi-zolobium parayba), guaricica (Vochsia bifalcata), cedro (Cedrela fissilis), caxeta (Tabebuia cassinoides), etc.

**Art. 2º, § 3º** {#art2_par3} Estágio avançado: Biomas
- **Art. 2º, § 3º, alínea "a"** {#art2_par3_alia} #enquadramento fisionomia arbórea dominante sobre as demais, formando dossel fechado e uni-forme do porte, com a presença de mais de 2 estratos e espécies predominantemente umbrófilas;
- **Art. 2º, § 3º, alínea "b"** {#art2_par3_alib} as espécies lenhosas ocorrentes apresentam número superior a 30 espécies, ampli-tude diamétrica grande e amplitude de altura grande. A altura das espécies lenhosas do dossel é superior a 15 m, com área basal (m2/ha) superior a 30 m2/ha; com distribuição diamétrica variando entre 20 a 60 cm, e média da amplitude do DAP 40 cm;
- **Art. 2º, § 3º, alínea "c"** {#art2_par3_alic} o crescimento das árvores do dossel é lento e a vida média da árvore do dossel é longa;
- **Art. 2º, § 3º, alínea "d"** {#art2_par3_alid} as epífitas são abundantes, as lianas herbáceas raras e as lianas lenhosas encontram-se presentes. As gramíneas são raras. A serapilheira está presente, variando em função do tempo e da localização, apresentando intensa decomposição;
- **Art. 2º, § 3º, alínea "e"** {#art2_par3_alie} a regeneração das árvores do dossel é intensa; f ) as espécies mais comuns, indicadoras do estágio avançado de regeneração, entre outras podem ser consideradas: pinheiro (Araucaria angustifolia), imbuia (Ocotea porosa), canafístula (Peltophorum dubgium), ipê (Tabebuia alba), angico (Parapiptadenia rigida), figueira (Ficus sp.).

###### Art. 3º {#art3}
Tags: #enquadramento #mata-atlantica #vegetacao

**Art. 3º, caput** {#art3_cpt} #enquadramento Difere deste contexto, a vegetação da Floresta Ombrófila Densa altomontana, por ser constituída por um número menor de espécies arbóreas, ser de porte baixo e com pequena amplitude diamétrica e de altura.

###### Art. 4º {#art4}
Tags: #definicao #mata-atlantica #vegetacao

**Art. 4º, caput** {#art4_cpt} #definicao Os parâmetros definidos para tipificar os diferentes estágios de sucessão da vegetação secundária, podem variar de uma região geográfica para outra, dependendo das condições topográficas e edafo-climáticas, localização geográfica, bem como do uso anterior da área em que se encontra uma determinada formação florestal.

###### Art. 5º {#art5}
Tags: #definicao #mata-atlantica #vegetacao

**Art. 5º, caput** {#art5_cpt} #definicao De acordo com o artigo 3o do [[decreto-federal-750-1993|Decreto no 750, de 10 de fevereiro de 1993]], e para os efeitos desta Resolução, considera-se Mata Atlântica, no Estado do Paraná, as formações florestais e ecossistemas associados inseridos no domínio Mata Atlântica, com as respectivas delimitações estabelecidas pelo Mapa de Vegetação do Brasil, IBGE 1988: Floresta Ombrófila Densa Atlântica, Floresta Ombrófila Mista, Floresta Estacional Semidecidual, Manguezais e restingas.

###### Art. 6º {#art6}
Tags: #mata-atlantica #vegetacao

**Art. 6º, caput** {#art6_cpt} Esta Resolução entra em vigor na data de sua publicação, revogadas as dispo-sições em contrário. RUBENS RICUPERO - Presidente do Conselho ANEXO41 PARÂMETROS DE CLASSIFICAÇÃO DOS ESTÁGIOS SUCESSIONAIS DA VEGETAÇÃO SECUNDÁRIA PARÂMETROS                          INICIAL                                AVANÇADA INTERMEDIÁRIA N de estratos o 1                 1a2                 ≥2 No de espécies lenhosas                            1 a 10              5 a 30               ≥ 30 Área basal (m2/ha)                                 8 a 20             15 a 35               ≥ 30 Altura das espécies lenhosas Até 10            8 a 17                 ≥ 30 do dossel (m) Média de amplitude dos diâmetros - DAP 10               25                     40 (cm) Distribuição diamétrica (cm)                       5 a 15           10 a 40                20 a 60 Crescimento das árvores do dossel                 Rápido           Moderado                Lento Vida média das árvores                             Curta            Média                  Longa Amplitude diamétrica                             Pequena            Média                 Grande Amplitude da altura                              Pequena            Média                 Grande Epífitas                                           Raras            Poucas               Abundante Lianas herbáceas                                Abundantes          Poucas                  Raras Lianas lenhosas                                  Ausente             Rara                 Presente Gramíneas                                       Abundantes          Poucas                  Raras Regeneração das árvores do dossel                Ausente            Pouca                 Intensa Este texto não substitui o publicado no DOU, de 28 de março de 1994. 41 Retificado no DOU nº 73, de 19 de abril de 1994, pág. 5759.


### Parâmetros de classificação dos estágios sucessionais da vegetação {#anexo1}

Conteúdo normativo do anexo pendente de transcrição e conferência visual. A extração textual recebida está preservada nos arquivos de fonte deste lote.

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (conama 002 1994.pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- Conferência visual não concluída: a leitura por páginas não disponibilizou imagem utilizável nesta sessão. O texto extraído foi preservado no manifesto para revisão; não foi promovido a tabela normativa validada.
- ANEXO41 contém chamada de nota de rodapé 41, não é Anexo 41. A nota informa retificação no DOU nº 73, de 19 de abril de 1994, pág. 5759. O valor de altura do estágio avançado (≥ 30 na extração do quadro) diverge do corpo (> 15 m); não corrigido por inferência.
