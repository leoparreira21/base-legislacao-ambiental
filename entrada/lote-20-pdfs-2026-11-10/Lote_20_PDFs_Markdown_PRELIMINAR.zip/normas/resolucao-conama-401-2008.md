---
norma: "Resolução CONAMA nº 401/2008"
arquivo: resolucao-conama-401-2008
tipo: resolucao
esfera: federal
uf: BR
numero: 401
ano: 2008
data_assinatura: 2008-11-04
ementa: "Estabelece os limites máximos de chumbo, cádmio e mercúrio para pilhas e baterias comercializadas no território nacional e os critérios e padrões para o seu gerenciamento ambientalmente adequado, e dá outras providências."
situacao: vigente
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: ["[[resolucao-conama-424-2010]]"]
revoga: ["[[resolucao-conama-257-1999]]"]
revogado_por: []
cita: ["[[decreto-federal-99274-1990]]", "[[lei-federal-6938-1981]]", "[[resolucao-conama-257-1999]]", "[[resolucao-conama-424-2010]]"]
tags: ["definicao", "efluente", "eia-rima", "enquadramento", "logistica-reversa", "pilha-bateria", "prazo", "proibicao", "residuo-solido", "responsavel-tecnico", "revogado"]
fonte: "PDF fornecido: conama 401 2008.pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
texto: "compilado segundo as alterações explícitas no PDF fornecido; conferência visual pendente"
---

# Resolução CONAMA nº 401/2008

> Estabelece os limites máximos de chumbo, cádmio e mercúrio para pilhas e baterias comercializadas no território nacional e os critérios e padrões para o seu gerenciamento ambientalmente adequado, e dá outras providências.

## Preâmbulo

RESOLUÇÃO CONAMA n° 401, de 4 de novembro de 2008 Publicada no DOU nº 215, de 5 de novembro de 2008, Seção 1, página 108-109 Correlação: • Alterada pela Resolução nº 424, de 2010. • Revoga a [[resolucao-conama-257-1999|Resolução CONAMA nº 257/99]]. Estabelece os limites máximos de chumbo, cádmio e mercúrio para pilhas e baterias comercializadas no território nacional e os critérios e padrões para o seu gerenciamento ambientalmente adequado, e dá outras providências. O CONSELHO NACIONAL DO MEIO AMBIENTE-CONAMA, no uso das atribuições e competências que lhe são conferidas pelo art. 8o, inciso VII, da [[lei-federal-6938-1981|Lei no 6.938, de 31 de agosto de 1981]], e pelo art. 7o, incisos VI e VIII e § 3o, do [[decreto-federal-99274-1990|Decreto no 99.274, de 6 de junho de 1990]], e conforme o disposto em seu Regimento Interno, e o que consta do Processo nº 02000.005624/1998- 07, e Considerando a necessidade de minimizar os impactos negativos causados ao meio ambiente pelo descarte inadequado de pilhas e baterias; Considerando a necessidade de se disciplinar o gerenciamento ambiental de pilhas e baterias, em especial as que contenham em suas composições chumbo, cádmio, mercúrio e seus compostos, no que tange à coleta, reutilização, reciclagem, tratamento ou disposição final; Considerando a necessidade de reduzir, tanto quanto possível, a geração de resíduos, como parte de um sistema integrado de Produção Mais Limpa, estimulando o desenvolvimento de técnicas e processos limpos na produção de pilhas e baterias produzidas no Brasil ou importadas; Considerando a ampla disseminação do uso de pilhas e baterias no território brasileiro e a conseqüente necessidade de conscientizar o consumidor desses produtos sobre os riscos à saúde e ao meio ambiente do descarte inadequado; Considerando que há a necessidade de conduzir estudos para substituir as substâncias tóxicas potencialmente perigosas ou reduzir o seu teor até os valores mais baixos viáveis tecnologicamente; e Considerando a necessidade de atualizar, em razão da maior conscientização pública e evolução das técnicas e processos mais limpos, o disposto na [[resolucao-conama-257-1999|Resolução CONAMA nº 257/99]], resolve:

CAPÍTULO I

DAS DISPOSIÇÕES GERAIS

###### Art. 1º {#art1}
Tags: #logistica-reversa #pilha-bateria

**Art. 1º, caput** {#art1_cpt} Esta Resolução estabelece os limites máximos de chumbo, cádmio e mercúrio e os critérios e padrões para o gerenciamento ambientalmente adequado das pilhas e baterias portáteis, das baterias chumbo-ácido, automotivas e industriais e das pilhas e baterias dos sistemas eletroquímicos níquel-cádmio e óxido de mercúrio, relacionadas nos capítulos 85.06 e 85.07 da Nomenclatura Comum do Mercosul-NCM, comercializadas no território nacional.

###### Art. 2º {#art2}
Tags: #definicao #enquadramento #logistica-reversa #pilha-bateria

**Art. 2º, caput** {#art2_cpt} #definicao Para os fins do disposto nesta Resolução, considera-se:
- **Art. 2º, caput, inciso I** {#art2_cpt_inc1} bateria: acumuladores recarregáveis ou conjuntos de pilhas, interligados em série ou em paralelo;
- **Art. 2º, caput, inciso II** {#art2_cpt_inc2} pilha ou acumulador: gerador eletroquímico de energia elétrica, mediante conversão de energia química, podendo ser do tipo primária (não recarregável) ou secundária (recarregável);
- **Art. 2º, caput, inciso III** {#art2_cpt_inc3} pilha ou acumulador portátil: pilha, bateria ou acumulador que seja selado, que não seja pilha ou acumulador industrial ou automotivo e que tenham como sistema eletroquímico os que se aplicam a esta Resolução.
- **Art. 2º, caput, inciso IV** {#art2_cpt_inc4} bateria ou acumulador chumbo-ácido: dispositivo no qual o material ativo das placas positivas é constituído por compostos de chumbo e o das placas negativas essencialmente por chumbo, sendo o eletrólito uma solução de ácido sulfúrico;
- **Art. 2º, caput, inciso V** {#art2_cpt_inc5} pilha-botão: pilha que possui diâmetro maior que a altura;
- **Art. 2º, caput, inciso VI** {#art2_cpt_inc6} bateria de pilha botão: bateria em que cada elemento possui diâmetro maior que a altura;
- **Art. 2º, caput, inciso VII** {#art2_cpt_inc7} #definicao pilha miniatura: pilha com diâmetro ou altura menor que a do tipo AAA – LR03/ R03, definida pelas normas técnicas vigentes;
- **Art. 2º, caput, inciso VIII** {#art2_cpt_inc8} #enquadramento plano de gerenciamento de pilhas e baterias usadas: conjunto de procedimentos ambientalmente adequados para o descarte, segregação, coleta, transporte, recebimento, armazenamento, manuseio, reciclagem, reutilização, tratamento ou disposição final;
- **Art. 2º, caput, inciso IX** {#art2_cpt_inc9} destinação ambientalmente adequada: destinação que minimiza os riscos ao meio ambiente e adota procedimentos técnicos de coleta, recebimento, reutilização, reciclagem, tratamento ou disposição final de acordo com a legislação ambiental vigente;
- **Art. 2º, caput, inciso X** {#art2_cpt_inc10} reciclador: pessoa jurídica devidamente licenciada para a atividade pelo órgão ambiental competente que se dedique à recuperação de componentes de pilhas e baterias.
- **Art. 2º, caput, inciso XI** {#art2_cpt_inc11} importador: pessoa jurídica que importa para o mercado interno pilhas, baterias ou acumuladores ou produtos que os contenham, fabricados fora do país.

###### Art. 3º {#art3}
Tags: #logistica-reversa #pilha-bateria #prazo #responsavel-tecnico

**Art. 3º, caput** {#art3_cpt} #responsavel-tecnico Os fabricantes nacionais e os importadores de pilhas e baterias referidas no art. [[#art1|1º]] e dos produtos que as contenham deverão:
- **Art. 3º, caput, inciso I** {#art3_cpt_inc1} #responsavel-tecnico estar inscritos no Cadastro Técnico Federal de Atividades Potencialmente Poluidoras ou Utilizadoras dos Recursos Ambientais-CTF, de acordo com art. 17, inciso II, da [[lei-federal-6938-1981|Lei nº 6.938, de 31 de agosto de 1981]];
- **Art. 3º, caput, inciso II** {#art3_cpt_inc2} apresentar, anualmente, ao Instituto Brasileiro do Meio Ambiente e dos Recursos Naturais Renováveis-IBAMA laudo físico-químico de composição, emitido por laboratório acreditado junto ao Instituto Nacional de Metrologia e de Normatização-INMETRO;
- **Art. 3º, caput, inciso III** {#art3_cpt_inc3} apresentar ao órgão ambiental competente plano de gerenciamento de pilhas e baterias, que contemple a destinação ambientalmente adequada, de acordo com esta Resolução.

**Art. 3º, § 1º** {#art3_par1} Caso comprovado pelo laudo físico-químico de que trata o inciso II que os teores estejam acima do permitido, o fabricante e o importador estarão sujeitos às penalidades previstas na legislação.

**Art. 3º, § 2º** {#art3_par2} Os importadores de pilhas e baterias deverão apresentar ao IBAMA plano de gerenciamento referido no inciso III para a obtenção de licença de importação.

**Art. 3º, § 3º** {#art3_par3} O plano de gerenciamento apresentado ao órgão ambiental competente deve considerar que as pilhas e baterias a serem recebidas ou coletadas sejam acondicionadas adequadamente e armazenadas de forma segregada, até a destinação ambientalmente adequada, obedecidas as normas ambientais e de saúde pública pertinentes, contemplando a sistemática de recolhimento regional e local.

**Art. 3º, § 4º** {#art3_par4} #prazo O IBAMA publicará em 30 dias, a contar da vigência desta resolução, o termo de referência para a elaboração do plano de gerenciamento.

###### Art. 4º {#art4}
Tags: #logistica-reversa #pilha-bateria #responsavel-tecnico

**Art. 4º, caput** {#art4_cpt} #responsavel-tecnico Os estabelecimentos que comercializam os produtos mencionados no art. [[#art1|1º]], bem como a rede de assistência técnica autorizada pelos fabricantes e importadores desses produtos, deverão receber dos usuários as pilhas e baterias usadas, respeitando o mesmo princípio ativo, sendo facultativa a recepção de outras marcas, para repasse aos respectivos fabricantes ou importadores.

###### Art. 5º {#art5}
Tags: #logistica-reversa #pilha-bateria

**Art. 5º, caput** {#art5_cpt} Para as pilhas e baterias não contempladas nesta Resolução, deverão ser implementados, de forma compartilhada, programas de coleta seletiva pelos respectivos fabricantes, importadores, distribuidores, comerciantes e pelo poder público.

###### Art. 6º {#art6}
Tags: #logistica-reversa #pilha-bateria #responsavel-tecnico

**Art. 6º, caput** {#art6_cpt} #responsavel-tecnico As pilhas e baterias mencionadas no art. [[#art1|1o]], nacionais e importadas, usadas ou inservíveis, recebidas pelos estabelecimentos comerciais ou em rede de assistência técnica autorizada, deverão ser, em sua totalidade, encaminhadas para destinação ambientalmente adequada, de responsabilidade do fabricante ou importador.

**Art. 6º, parágrafo único** {#art6_par1u} O IBAMA estabelecerá por meio de Instrução Normativa a forma de controle do recebimento e da destinação final.

### CAPÍTULO II – DAS PILHAS E BATERIAS DE PILHAS ELÉTRICAS ZINCO-MANGANÊS E ALCALINO-MANGANÊS

###### Art. 7º {#art7}
Tags: #logistica-reversa #pilha-bateria #responsavel-tecnico

**Art. 7º, caput** {#art7_cpt} A partir de 1o de julho de 2009, as pilhas e baterias do tipo portátil, botão e miniatura que sejam comercializadas, fabricadas no território nacional ou importadas, deverão atender aos seguintes teores máximos dos metais de interesse:
- **Art. 7º, caput, inciso I** {#art7_cpt_inc1} #responsavel-tecnico conter até 0,0005% em peso de mercúrio quando for do tipo listado no inciso III do art. [[#art2|2º]] desta resolução;
- **Art. 7º, caput, inciso II** {#art7_cpt_inc2} #responsavel-tecnico conter até 0,002% em peso de cádmio quando for do tipo listado no inciso III do art. [[#art2|2º]] desta resolução;
- **Art. 7º, caput, inciso III** {#art7_cpt_inc3} #responsavel-tecnico conter até 2,0% em peso de mercúrio quando for do tipo listado nos incisos V, VI e VII do art. [[#art2|2º]] desta resolução.
- **Art. 7º, caput, inciso IV** {#art7_cpt_inc4} conter traços de até 0,1% em peso de chumbo.

### CAPÍTULO III – DAS BATERIAS CHUMBO-ÁCIDO

###### Art. 8º {#art8}
Tags: #logistica-reversa #pilha-bateria

**Art. 8º, caput** {#art8_cpt} As baterias, com sistema eletroquímico chumbo-ácido, não poderão possuir teores de metais acima dos seguintes limites:
- **Art. 8º, caput, inciso I** {#art8_cpt_inc1} mercúrio - 0,005% em peso; e II - cádmio - 0,010% em peso.

###### Art. 9º {#art9}
Tags: #logistica-reversa #pilha-bateria #responsavel-tecnico

**Art. 9º, caput** {#art9_cpt} #responsavel-tecnico O repasse das baterias chumbo-ácido previsto no art. [[#art4|4o]] poderá ser efetuado de forma direta aos recicladores, desde que licenciados para este fim.

###### Art. 10 {#art10}
Tags: #logistica-reversa #pilha-bateria

**Art. 10, caput** {#art10_cpt} Não é permitida a disposição final de baterias chumbo-ácido em qualquer tipo de aterro sanitário, bem como a sua incineração.

###### Art. 11 {#art11}
Tags: #enquadramento #logistica-reversa #pilha-bateria

**Art. 11, caput** {#art11_cpt} #enquadramento O transporte das baterias chumbo-ácido exauridas, sem o seu respectivo eletrólito, só será admitido quando comprovada a destinação ambientalmente adequada do eletrólito.

### CAPÍTULO IV – DAS BATERIAS NÍQUEL-CÁDMIO E ÓXIDO DE MERCÚRIO

###### Art. 12 {#art12}
Tags: #logistica-reversa #pilha-bateria #responsavel-tecnico

**Art. 12, caput** {#art12_cpt} #responsavel-tecnico O repasse das baterias níquel-cádmio e óxido de mercúrio previsto no art. [[#art4|4º]] poderá ser efetuado de forma direta aos recicladores, desde que licenciados para este fim.

###### Art. 13 {#art13}
Tags: #logistica-reversa #pilha-bateria

**Art. 13, caput** {#art13_cpt} Não é permitida a incineração e a disposição final dessas baterias em qualquer tipo de aterro sanitário, devendo ser destinadas de forma ambientalmente adequada.

### CAPÍTULO V – DA INFORMAÇÃO, EDUCAÇÃO E COMUNICAÇÃO AMBIENTAL

###### Art. 14 {#art14}
Tags: #logistica-reversa #pilha-bateria

**Art. 14, caput** {#art14_cpt} Nos materiais publicitários e nas embalagens de pilhas e baterias, fabricadas no País ou importadas, deverão constar de forma clara, visível e em língua portuguesa, a simbologia indicativa da destinação adequada, as advertências sobre os riscos à saúde humana e ao meio ambiente, bem como a necessidade de, após seu uso, serem encaminhadas aos revendedores ou à rede de assistência técnica autorizada, conforme Anexo I.

###### Art. 15 {#art15}
Tags: #logistica-reversa #pilha-bateria

**Art. 15, caput** {#art15_cpt} Os fabricantes e importadores de produtos que incorporem pilhas e baterias deverão informar aos consumidores sobre como proceder quanto à remoção destas pilhas e baterias após a sua utilização, possibilitando sua destinação separadamente dos aparelhos.

**Art. 15, parágrafo único** {#art15_par1u} Nos casos em que a remoção das pilhas ou baterias não for possível, oferecer risco ao consumidor ou, quando forem parte integrante e não removíveis do produto, o fabricante ou importador deverá obedecer aos critérios desta Resolução quanto à coleta e sua destinação ambientalmente adequada, sem prejuízo da obrigação de informar devidamente o consumidor sobre esses riscos.

###### Art. 16 {#art16}
Tags: #logistica-reversa #pilha-bateria
Alterações: [[resolucao-conama-424-2010|resolucao-conama-424-2010]] (revogado: parágrafo único)

**Art. 16, caput** {#art16_cpt} No corpo do produto das baterias chumbo-ácido, níquel-cádmio e óxido de mercúrio deverá constar:
- **Art. 16, caput, inciso I** {#art16_cpt_inc1} nos produtos nacionais, a identificação do fabricante e, nos produtos importados, a identificação do importador e do fabricante, de forma clara e objetiva, em língua portuguesa, mediante a utilização de etiquetas indeléveis, legíveis e com resistência mecânica suficiente para suportar o manuseio e intempéries, visando assim preservar as informações nelas contidas durante toda a vida útil da bateria;
- **Art. 16, caput, inciso II** {#art16_cpt_inc2} a advertência sobre os riscos à saúde humana e ao meio ambiente; e
- **Art. 16, caput, inciso III** {#art16_cpt_inc3} a necessidade de, após seu uso, serem devolvidos aos revendedores ou à rede de assistência técnica autorizada para repasse aos fabricantes ou importadores.

**Art. 16, parágrafo único** {#art16_par1u} #revogado *(Revogado pela [[resolucao-conama-424-2010|Resolução nº 424/2010]])*

###### Art. 17 {#art17}
Tags: #logistica-reversa #pilha-bateria

**Art. 17, caput** {#art17_cpt} Os fabricantes, importadores, distribuidores, comerciantes destas pilhas e baterias, ou de produtos que as contenham para seu funcionamento, serão incentivados, em parceria com o poder público e sociedade civil, a promover campanhas de educação ambiental, bem como pela veiculação de informações sobre a responsabilidade pós-consumo e por incentivos à participação do consumidor neste processo.

###### Art. 18 {#art18}
Tags: #eia-rima #logistica-reversa #pilha-bateria #residuo-solido

**Art. 18, caput** {#art18_cpt} #eia-rima #residuo-solido Os fabricantes e importadores dos produtos abrangidos por esta Resolução deverão periodicamente promover a formação e capacitação dos recursos humanos envolvidos na cadeia desta atividade, inclusive aos catadores de resíduos, sobre os processos de logística reversa com a destinação ambientalmente adequada de seus produtos.

### CAPÍTULO VI – DAS DISPOSIÇÕES FINAIS

###### Art. 19 {#art19}
Tags: #logistica-reversa #pilha-bateria #responsavel-tecnico

**Art. 19, caput** {#art19_cpt} #responsavel-tecnico Os estabelecimentos de venda de pilhas e baterias referidas no art. [[#art1|1o]] devem obrigatoriamente conter pontos de recolhimento adequados.

###### Art. 20 {#art20}
Tags: #logistica-reversa #pilha-bateria #prazo #responsavel-tecnico

**Art. 20, caput** {#art20_cpt} #prazo #responsavel-tecnico Os fabricantes e importadores dos produtos abrangidos por esta Resolução, que estejam em operação na data de sua publicação, terão prazo de até 12 meses para cumprir o disposto no Inciso III do art. [[#art3|3º]].

###### Art. 21 {#art21}
Tags: #logistica-reversa #pilha-bateria #prazo #responsavel-tecnico

**Art. 21, caput** {#art21_cpt} #prazo #responsavel-tecnico Para cumprimento do disposto nos arts. [[#art4|4º]], art. [[#art5|5º]] e caput do art. [[#art6|6º]], será dado um prazo de até 24 meses, a contar da publicação desta resolução.

###### Art. 22 {#art22}
Tags: #efluente #logistica-reversa #pilha-bateria #proibicao

**Art. 22, caput** {#art22_cpt} #proibicao Não serão permitidas formas inadequadas de disposição ou destinação final de pilhas e baterias usadas, de quaisquer tipos ou características, tais como:
- **Art. 22, caput, inciso I** {#art22_cpt_inc1} lançamento a céu aberto, tanto em áreas urbanas como rurais, ou em aterro não licenciado;
- **Art. 22, caput, inciso II** {#art22_cpt_inc2} queima a céu aberto ou incineração em instalações e equipamentos não licenciados;
- **Art. 22, caput, inciso III** {#art22_cpt_inc3} #efluente lançamento em corpos d’água, praias, manguezais, pântanos, terrenos baldios, poços ou cacimbas, cavidades subterrâneas, redes de drenagem de águas pluviais, esgotos, ou redes de eletricidade ou telefone, mesmo que abandonadas, ou em áreas sujeitas à inundação.

###### Art. 23 {#art23}
Tags: #logistica-reversa #pilha-bateria

**Art. 23, caput** {#art23_cpt} O IBAMA, baseado em fatos fundamentados e comprovados, poderá requisitar, a seu critério, amostra de lotes de pilhas e baterias, de quaisquer tipos, produzidos ou importados para comercialização no país, para fins de comprovação do atendimento às exigências desta Resolução, mediante a realização da medição dos teores de metais pesados, em laboratórios acreditados por órgãos competentes para este fim, signatários dos acordos do “International Laboratory Accreditation Cooperation” - ILAC.

**Art. 23, § 1º** {#art23_par1} Os custos dos ensaios de comprovação de conformidade, realizados no país ou no exterior, assim como os decorrentes de eventuais ações de reparo e armazenamento, correrão por conta do fabricante ou importador das pilhas e baterias.

**Art. 23, § 2º** {#art23_par2} A verificação do não cumprimento das exigências previstas nesta resolução resultará na obrigação para o fabricante ou importador de recolhimento de todos os lotes em desacordo com esta norma.

###### Art. 24 {#art24}
Tags: #logistica-reversa #pilha-bateria

**Art. 24, caput** {#art24_cpt} O órgão ambiental competente, poderá adotar procedimentos complementares relativos ao controle, fiscalização, laudos e análises físico-químicas, necessários à verificação do cumprimento do disposto nesta Resolução.

###### Art. 25 {#art25}
Tags: #logistica-reversa #pilha-bateria

**Art. 25, caput** {#art25_cpt} Compete aos órgãos e entidades do Sistema Nacional do Meio Ambiente- SISNAMA, sem prejuízo da competência de outros órgãos e entidades da Administração Pública, a fiscalização relativa ao cumprimento das disposições desta Resolução.

###### Art. 26 {#art26}
Tags: #logistica-reversa #pilha-bateria

**Art. 26, caput** {#art26_cpt} Os fabricantes e importadores dos produtos abrangidos por esta Resolução deverão conduzir estudos para substituir as substâncias potencialmente perigosas neles contidas ou reduzir o seu teor até os valores mais baixos viáveis tecnologicamente.

**Art. 26, parágrafo único** {#art26_par1u} Os estudos e resultados mencionados no caput devem ser entregues ao IBAMA, que os avaliará tecnicamente e encaminhará relatório ao CONAMA, respeitados o sigilo industrial e as patentes.

###### Art. 27 {#art27}
Tags: #logistica-reversa #pilha-bateria

**Art. 27, caput** {#art27_cpt} O não-cumprimento das obrigações previstas nesta Resolução sujeitará os infratores às penalidades previstas na legislação em vigor.

###### Art. 28 {#art28}
Tags: #logistica-reversa #pilha-bateria

**Art. 28, caput** {#art28_cpt} Esta Resolução entra em vigor na data de sua publicação, revogando-se a [[resolucao-conama-257-1999|Resolução nº 257, de 30 de junho 1999]].


## Fecho

CARLOS MINC Presidente do Conselho

### Simbologias adotadas para pilhas e baterias {#anexo1}

- **Anexo I, linha 1** {#anexo1_lin1} a) Chumbo ácido: Utilizar qualquer das 3 alternativas abaixo:

- **Anexo I, linha 2** {#anexo1_lin2} Se o fabricante ou o importador adotar um sistema de reciclagem poderá utilizar complementarmente a simbologia abaixo.

- **Anexo I, linha 3** {#anexo1_lin3} b) Níquel-cádmio: Utilizar qualquer das 3 alternativas abaixo

- **Anexo I, linha 4** {#anexo1_lin4} Se o fabricante ou o importador adotar um sistema de reciclagem poderá utilizar complementarmente a simbologia abaixo.

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|
| [[resolucao-conama-424-2010]] | Ver anotações no corpo | Alteração indicada no PDF; conferência pendente. |

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (conama 401 2008.pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- Conferência visual não concluída: a leitura por páginas não disponibilizou imagem utilizável nesta sessão. O texto extraído foi preservado no manifesto para revisão; não foi promovido a tabela normativa validada.
- O anexo contém símbolos gráficos para chumbo ácido e níquel-cádmio, ausentes na extração textual. Não foram inventadas descrições desses símbolos.
