---
norma: "Resolução CONAMA nº 428/2010"
arquivo: resolucao-conama-428-2010
tipo: resolucao
esfera: federal
uf: BR
numero: 428
ano: 2010
data_assinatura: 2010-12-17
ementa: "Dispõe, no âmbito do licenciamento ambiental sobre a autorização do órgão responsável pela administração da Unidade de Conservação e sua ciência no licenciamento de empreendimentos não sujeitos a EIA-RIMA."
situacao: vigente
regulamenta: []
regulamentado_por: []
altera: ["[[resolucao-conama-347-2004]]", "[[resolucao-conama-378-2006]]"]
alterado_por: ["[[resolucao-conama-473-2015]]", "[[resolucao-conama-508-2025]]"]
revoga: ["[[resolucao-conama-10-1988]]", "[[resolucao-conama-11-1987]]", "[[resolucao-conama-12-1988]]", "[[resolucao-conama-13-1990]]", "[[resolucao-conama-347-2004]]", "[[resolucao-conama-378-2006]]"]
revogado_por: []
cita: ["[[decreto-federal-99274-1990]]", "[[lei-federal-6938-1981]]", "[[lei-federal-9985-2000]]", "[[portaria-mma-168-2005]]", "[[resolucao-conama-347-2004]]", "[[resolucao-conama-378-2006]]", "[[resolucao-conama-473-2015]]", "[[resolucao-conama-508-2025]]"]
tags: ["definicao", "documentacao", "efluente", "eia-rima", "licenciamento-ambiental", "prazo", "proibicao", "redacao-alterada", "responsavel-tecnico", "unidade-conservacao", "zona-amortecimento"]
fonte: "PDF fornecido: conama 428 2010(1).pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
texto: "compilado segundo as alterações explícitas no PDF fornecido; conferência visual pendente"
---

# Resolução CONAMA nº 428/2010

> Dispõe, no âmbito do licenciamento ambiental sobre a autorização do órgão responsável pela administração da Unidade de Conservação e sua ciência no licenciamento de empreendimentos não sujeitos a EIA-RIMA.

## Preâmbulo

MINISTÉRIO DO MEIO AMBIENTE

CONSELHO NACIONAL DO MEIO AMBIENTE-CONAMA RESOLUÇÃO N° 428, DE 17 DE DEZEMBRO DE 2010 Correlações: • Alterada pela [[resolucao-conama-473-2015|Resolução nº 473/2015]] (altera o §2º do art. 1º e o inciso III do art. 5º) • Altera as Resoluções nº 347/2004, e nº 378/2006 • Revoga as Resoluções n° 10/1988, nº 11/1987, nº 12/1988, nº 13/1990 • Alterada pela [[resolucao-conama-508-2025|Resolução no 508/2025]] Dispõe, no âmbito do licenciamento ambiental sobre a autorização do órgão responsável pela administração da Unidade de Conservação (UC), de que trata o § 3º do artigo 36 da [[lei-federal-9985-2000|Lei nº 9.985 de 18 de julho de 2000]], bem como sobre a ciência do órgão responsável pela administração da UC no caso de licenciamento ambiental de empreendimentos não sujeitos a EIA-RIMA e dá outras providências. O CONSELHO NACIONAL DO MEIO AMBIENTE-CONAMA, no uso das atribuições e competências que lhe são conferidas pelo art. 8º da [[lei-federal-6938-1981|Lei nº 6.938, de 31 de agosto de 1981]], regulamentado pelo [[decreto-federal-99274-1990|Decreto nº 99.274, de 06 de julho de 1990]] e tendo em vista o disposto em seu Regimento Interno, Anexo à [[portaria-mma-168-2005|Portaria MMA nº 168, de 13 de junho de 2005]], e: Considerando a necessidade de regulamentar os procedimentos de licenciamento ambiental de empreendimentos de significativo impacto ambiental que afetem as Unidades de Conservação específicas ou suas zonas de amortecimento, resolve:

###### Art. 1º {#art1}
Tags: #definicao #eia-rima #licenciamento-ambiental #prazo #responsavel-tecnico #unidade-conservacao #zona-amortecimento
Alterações: [[resolucao-conama-473-2015|resolucao-conama-473-2015]] (nova redação: § 2º)

**Art. 1º, caput** {#art1_cpt} #eia-rima #licenciamento-ambiental O licenciamento de empreendimentos de significativo impacto ambiental que possam afetar Unidade de Conservação (UC) específica ou sua Zona de Amortecimento (ZA), assim considerados pelo órgão ambiental licenciador, com fundamento em Estudo de Impacto Ambiental e respectivo Relatório de Impacto Ambiental (EIA/RIMA), só poderá ser concedido após autorização do órgão responsável pela administração da UC ou, no caso das Reservas Particulares de Patrimônio Natural (RPPN), pelo órgão responsável pela sua criação.

**Art. 1º, § 1º** {#art1_par1} #definicao #responsavel-tecnico Para efeitos desta Resolução, entende-se por órgão responsável pela administração da UC, os órgãos executores do Sistema Nacional de Unidade de Conservação (SNUC), conforme definido no inciso III, art. 6º da [[lei-federal-9985-2000|Lei nº 9.985 de 18 de julho de 2000]].

**Art. 1º, § 2º** {#art1_par2} #redacao-alterada #eia-rima #licenciamento-ambiental #prazo Durante o prazo de 5 anos, contados a partir da publicação da [[resolucao-conama-473-2015|Resolução nº 473, de 11 de dezembro de 2015]], o licenciamento de empreendimento de significativo impacto ambiental, localizados numa faixa de 3 mil metros a partir do limite da UC, cuja ZA não esteja estabelecida, sujeitar-se-á ao procedimento previsto no caput, com exceção de RPPNs, Áreas de Proteção Ambiental (APAs) e Áreas Urbanas Consolidadas. *(redação dada pela [[resolucao-conama-473-2015|Resolução nº 473/2015]])*

###### Art. 2º {#art2}
Tags: #eia-rima #licenciamento-ambiental #prazo #unidade-conservacao #zona-amortecimento

**Art. 2º, caput** {#art2_cpt} #licenciamento-ambiental #prazo A autorização de que trata esta Resolução deverá ser solicitada pelo órgão ambiental licenciador, antes da emissão da primeira licença prevista, ao órgão responsável pela administração da UC que se manifestará conclusivamente após avaliação dos estudos ambientais exigidos dentro do procedimento de licenciamento ambiental, no prazo de até 60 dias, a partir do recebimento da solicitação.

**Art. 2º, § 1º** {#art2_par1} #eia-rima #prazo A autorização deverá ser solicitada pelo órgão ambiental licenciador, no prazo máximo de 15 dias, contados a partir do aceite do EIA/RIMA.

**Art. 2º, § 2º** {#art2_par2} #eia-rima #prazo O órgão ambiental licenciador deverá, antes de emitir os termos de referência do EIA/RIMA, consultar formalmente o órgão responsável pela administração da UC quanto à necessidade e ao conteúdo exigido de estudos específicos relativos a impactos do empreendimento na UC e na respectiva ZA, o qual se manifestará no prazo máximo de 15 dias úteis, contados do recebimento da consulta.

**Art. 2º, § 3º** {#art2_par3} Os estudos específicos a serem solicitados deverão ser restritos à avaliação dos impactos do empreendimento na UC ou sua ZA e aos objetivos de sua criação.

**Art. 2º, § 4º** {#art2_par4} O órgão responsável pela administração da UC facilitará o acesso às informações pelo interessado.

**Art. 2º, § 5º** {#art2_par5} Na existência de Plano de Manejo da UC, devidamente publicado, este deverá ser observado para orientar a avaliação dos impactos na UC específica ou sua ZA.

**Art. 2º, § 6º** {#art2_par6} #prazo Na hipótese de inobservância do prazo previsto no caput, o órgão responsável pela administração da UC deverá encaminhar, ao órgão licenciador e ao órgão central do SNUC, a justificativa para o descumprimento.

###### Art. 3º {#art3}
Tags: #definicao #licenciamento-ambiental #prazo #proibicao #unidade-conservacao #zona-amortecimento

**Art. 3º, caput** {#art3_cpt} O órgão responsável pela administração da UC decidirá, de forma motivada:
- **Art. 3º, caput, inciso I** {#art3_cpt_inc1} pela emissão da autorização;
- **Art. 3º, caput, inciso II** {#art3_cpt_inc2} pela exigência de estudos complementares, desde que previstos no termo de referência;
- **Art. 3º, caput, inciso III** {#art3_cpt_inc3} pela incompatibilidade da alternativa apresentada para o empreendimento com a UC;
- **Art. 3º, caput, inciso IV** {#art3_cpt_inc4} pelo indeferimento da solicitação.

**Art. 3º, § 1º** {#art3_par1} #licenciamento-ambiental A autorização integra o processo de licenciamento ambiental e especificará, caso necessário, as condições técnicas que deverão ser consideradas nas licenças.

**Art. 3º, § 2º** {#art3_par2} #definicao #proibicao Os estudos complementares deverão ter todo seu escopo definido uma única vez, sendo vedada, após essa oportunidade, a solicitação de novas demandas, salvo quando decorrerem das complementações solicitadas.

**Art. 3º, § 3º** {#art3_par3} #prazo A não apresentação dos estudos complementares específicos, no prazo acordado com o empreendedor para resposta, desde que não justificada, ensejará o arquivamento da solicitação de autorização.

**Art. 3º, § 4º** {#art3_par4} #prazo A contagem do prazo para manifestação do órgão responsável pela administração da UC será interrompida durante a elaboração dos estudos complementares específicos ou preparação de esclarecimentos, sendo retomada, acrescido de mais 30 dias, em relação ao prazo original, se necessário.

**Art. 3º, § 5º** {#art3_par5} Em caso de indeferimento da autorização, o empreendedor será comunicado pelo órgão ambiental licenciador e poderá requerer a revisão da decisão.

**Art. 3º, § 6º** {#art3_par6} Na hipótese do inciso III poderão ser apresentadas, pelo empreendedor, alternativas ao projeto em análise que busquem compatibilizar o empreendimento com a UC e sua ZA.

###### Art. 4º {#art4}
Tags: #eia-rima #unidade-conservacao #zona-amortecimento

**Art. 4º, caput** {#art4_cpt} #eia-rima Caso o empreendimento de significativo impacto ambiental afete duas ou mais UCs de domínios distintos, caberá ao órgão licenciador consolidar as manifestações dos órgãos responsáveis pela administração das respectivas UCs.

###### Art. 5º {#art5}
Tags: #documentacao #efluente #eia-rima #licenciamento-ambiental #prazo #responsavel-tecnico #unidade-conservacao #zona-amortecimento
Alterações: [[resolucao-conama-508-2025|resolucao-conama-508-2025]] (nova redação: caput, inciso III, § 1º, § 2º, § 3º, § 4º, § 4º, inciso I, § 4º, inciso II, § 4º, inciso III, § 4º, inciso IV, § 5º, § 6º, § 7º, § 8º, § 9º, § 10); [[resolucao-conama-473-2015|resolucao-conama-473-2015]] (nova redação: )

**Art. 5º, caput** {#art5_cpt} #redacao-alterada #eia-rima #licenciamento-ambiental #prazo Nos processos de licenciamento ambiental de empreendimentos não sujeitos a EIA/RIMA, o órgão ambiental licenciador, antes da emissão da primeira licença ambiental prevista e no prazo de até quinze dias da data de recebimento dos estudos ambientais, deverá dar ciência ao órgão responsável pela administração da unidade de conservação, quando o empreendimento: *(redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*
- **Art. 5º, caput, inciso I** {#art5_cpt_inc1} puder causar impacto direto em UC;
- **Art. 5º, caput, inciso II** {#art5_cpt_inc2} estiver localizado na sua ZA;
- **Art. 5º, caput, inciso III** {#art5_cpt_inc3} #redacao-alterada estiver localizado no entorno da UC até o limite de dois mil metros da UC, cuja ZA não tenha sido estabelecida. *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*
- **Art. 5º, caput, inciso III** {#art5_cpt_inc3-dup2} #prazo estiver localizado no limite de até 2 mil metros da UC, cuja ZA não tenha sido estabelecida no prazo de até 5 anos a partir da data da publicação da Resolução nº 473, de 11 de dezembro de 2015. *(redação dada pela [[resolucao-conama-473-2015|Resolução nº 473/2015]])*

**Art. 5º, § 1º** {#art5_par1} #redacao-alterada Nos casos das Áreas Urbanas Consolidadas, das APAs e RPPNs, não se aplicará o disposto no inciso III. *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*

**Art. 5º, § 2º** {#art5_par2} #redacao-alterada Nos casos de RPPN, o órgão licenciador deverá dar ciência ao órgão responsável pela sua criação e ao proprietário. *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*

**Art. 5º, § 3º** {#art5_par3} #redacao-alterada #documentacao #licenciamento-ambiental O documento de comunicação deverá indicar as instruções de acesso às informações do licenciamento ambiental na rede mundial de computadores ou enviá-las em anexo. *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*

**Art. 5º, § 4º** {#art5_par4} #redacao-alterada O órgão licenciador deverá disponibilizar as seguintes informações: *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*
- **Art. 5º, § 4º, inciso I** {#art5_par4_inc1} #redacao-alterada estudos ambientais existentes; *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*
- **Art. 5º, § 4º, inciso II** {#art5_par4_inc2} #redacao-alterada tipo de licença ambiental; *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*
- **Art. 5º, § 4º, inciso III** {#art5_par4_inc3} #redacao-alterada arquivo georreferenciado da atividade ou empreendimento em formato shapefile ou KML, no Datum SIRGAS 2000; e *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*
- **Art. 5º, § 4º, inciso IV** {#art5_par4_inc4} #redacao-alterada #documentacao outros estudos ou documentos que o órgão licenciador reputar necessários à ciência do órgão gestor de Unidade de Conservação. *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*

**Art. 5º, § 5º** {#art5_par5} #redacao-alterada #documentacao #licenciamento-ambiental Devem ser observadas as restrições do ato de criação da unidade de conservação e de seu plano de manejo, quando existente, na elaboração de estudos ou documentos que subsidiem o licenciamento ambiental da atividade ou empreendimento. *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*

**Art. 5º, § 6º** {#art5_par6} #redacao-alterada #licenciamento-ambiental #prazo As eventuais contribuições técnicas apresentadas pelo órgão responsável pela administração da unidade de conservação para o licenciamento ambiental do empreendimento deverão guardar relação direta com os impactos identificados com a UC e serem prestadas no prazo de até trinta dias. *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*

**Art. 5º, § 7º** {#art5_par7} #redacao-alterada #prazo Mediante justificativa, o órgão responsável pela administração da unidade de conservação pode informar ao órgão licenciador a necessidade de prazo adicional de análise, o qual está limitado ao máximo de trinta dias, salvo dos casos de obras e atividades de baixo impacto. *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*

**Art. 5º, § 8º** {#art5_par8} #redacao-alterada As contribuições apresentadas pelo órgão responsável pela administração da unidade de conservação não terão caráter vinculante e serão objeto de análise e manifestação pelo órgão licenciador quanto à relação das medidas mitigadoras propostas com os impactos ambientais que afetem diretamente a UC, bem como sua inclusão na licença ambiental. *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*

**Art. 5º, § 9º** {#art5_par9} #redacao-alterada #licenciamento-ambiental A ausência ou a intempestividade da manifestação do órgão responsável pela administração da UC não obstam o andamento do licenciamento, devendo o órgão licenciador, nesses casos, proceder ao respectivo controle ambiental relativo à unidade de conservação. *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*

**Art. 5º, § 10** {#art5_par10} #redacao-alterada #efluente #responsavel-tecnico No caso de instalação de redes de abastecimento de água, esgoto, energia e infraestrutura urbana em geral em unidades de conservação onde estes equipamentos são admitidos, o empreendedor deverá obter aprovação do órgão gestor da unidade de conservação previamente à instalação da atividade ou empreendimento, conforme disposto no art. 46 da [[lei-federal-9985-2000|Lei nº 9.985, de 18 de julho de 2000]]. *(Redação dada pela [[resolucao-conama-508-2025|Resolução no 508/2025]])*

###### Art. 6º {#art6}
Tags: #unidade-conservacao #zona-amortecimento

**Art. 6º, caput** {#art6_cpt} Os órgãos ambientais licenciadores estaduais e municipais poderão adotar normas complementares, observadas as regras gerais desta Resolução.

###### Art. 7º {#art7}
Tags: #documentacao #unidade-conservacao #zona-amortecimento

**Art. 7º, caput** {#art7_cpt} #documentacao Esta Resolução se aplica às UCs criadas até a data de requerimento da licença ambiental.

###### Art. 8º {#art8}
Tags: #responsavel-tecnico #unidade-conservacao #zona-amortecimento

**Art. 8º, caput** {#art8_cpt} #responsavel-tecnico Ficam revogadas as Resoluções Conama n° 10, de 14 de dezembro de 1988, Conama nº 11, de 3 de dezembro de 1987, Conama nº 12, de 14 de dezembro de 1988, Conama nº 13, de 6 de dezembro de 1990; bem como o inciso II, do art. 2º e §1º do art. 4º da [[resolucao-conama-347-2004|Resolução Conama nº 347, de 10 de setembro de 2004]], e o parágrafo único do art. 3º da [[resolucao-conama-378-2006|Resolução Conama nº 378, de 19 de outubro de 2006]].

###### Art. 9º {#art9}
Tags: #unidade-conservacao #zona-amortecimento

**Art. 9º, caput** {#art9_cpt} Esta Resolução entra em vigor na data de sua publicação. IZABELLA TEIXEIRA Presidente do Conselho ESSE TEXTO NÃO SUBSTITUI O PUBLICADO NO DOU nº 242, EM 20/12/2010, pág. 805.



## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|
| [[resolucao-conama-473-2015]] | Ver anotações no corpo | Alteração indicada no PDF; conferência pendente. |
| [[resolucao-conama-508-2025]] | Ver anotações no corpo | Alteração indicada no PDF; conferência pendente. |

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (conama 428 2010(1).pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- Redações anteriores de artigos repetidos foram excluídas desta versão compilada, conforme o padrão do acervo; estão preservadas na extração da fonte que acompanha o lote.
- Revisão de numeração: ID duplicado: art5_cpt_inc3. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Revisão de numeração: sequência de inciso: art5_cpt_inc3-dup2 após art5_cpt_inc3. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Revisão de numeração: sequência de inciso: art5_cpt_inc3 após art5_cpt_inc3-dup2. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
