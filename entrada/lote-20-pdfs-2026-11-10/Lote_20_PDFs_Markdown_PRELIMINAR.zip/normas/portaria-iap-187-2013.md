---
norma: "Portaria IAP nº 187/2013"
arquivo: portaria-iap-187-2013
tipo: portaria
esfera: estadual
uf: PR
numero: 187
ano: 2013
data_assinatura: 2013-06-27
ementa: "Estabelece condições e critérios e dá outras providências, para o licenciamento ambiental de Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos."
situacao: revogada
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: []
revoga: []
revogado_por: ["[[instrucao-normativa-iat-30-2025]]"]
cita: ["[[decreto-estadual-114-2011]]", "[[decreto-estadual-1502-1992]]", "[[lei-estadual-10066-1992]]", "[[lei-estadual-7109-1979]]", "[[lei-federal-9605-1998]]", "[[portaria-iap-187-2013-anexo4]]", "[[portaria-iap-187-2013-anexo6]]", "[[resolucao-cema-65-2008]]", "[[resolucao-conama-237-1997]]", "[[resolucao-conama-6-1986]]"]
tags: ["agua-subterranea", "app", "definicao", "documentacao", "efluente", "enquadramento", "las", "li", "licenciamento-ambiental", "lo", "lp", "prazo", "proibicao", "renovacao", "residuo-solido", "residuo-solido-urbano", "responsavel-tecnico", "transbordo"]
fonte: "PDF fornecido: portaria IAP 187 2013(1).pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
---

# Portaria IAP nº 187/2013

> Estabelece condições e critérios e dá outras providências, para o licenciamento ambiental de Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos.

## Preâmbulo

PORTARIA IAP Nº 187 DE 27 DE JUNHO DE 2013 Estabelece condições e critérios e dá outras providências, para o licenciamento ambiental de Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos. O Diretor Presidente do Instituto Ambiental do Paraná – IAP, nomeado pelo [[decreto-estadual-114-2011|Decreto n° 114 de 06 de janeiro de 2011]], no uso das atribuições que lhe são conferidas pela [[lei-estadual-10066-1992|Lei Estadual N.°10.066, de 27 de julho de 1992]], com as alterações trazidas pelas Leis n° 11.352, de 13 de fevereiro de 1996 e n° 13.425, de 07 de janeiro de 2002 e de acordo com o seu Regulamento, aprovado pelo [[decreto-estadual-1502-1992|Decreto n° 1.502, de 04 de agosto de 1992]], com alterações posteriores e considerando o disposto na [[resolucao-conama-237-1997|Resolução CONAMA Nº 237/97]], RESOLVE:

###### Art. 1º {#art1}
Tags: #licenciamento-ambiental #residuo-solido #residuo-solido-urbano #transbordo

**Art. 1º, caput** {#art1_cpt} #licenciamento-ambiental #residuo-solido Estabelecer critérios premissas para o Licenciamento Ambiental de Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos

**Art. 1º, parágrafo único** {#art1_par1u} #residuo-solido Esta Portaria aplica-se apenas e tão somente ao transbordo de resíduos sólidos urbanos não perigosos.

###### Art. 2º {#art2}
Tags: #definicao #licenciamento-ambiental #residuo-solido #residuo-solido-urbano #transbordo

**Art. 2º, caput** {#art2_cpt} #definicao Para efeito desta Portaria, considera-se:
- **Art. 2º, caput, inciso I** {#art2_cpt_inc1} Fonte de Poluição: qualquer atividade, sistema, processo, operação, maquinaria, equipamentos ou dispositivos, móvel ou imóvel previstos no regulamento da [[lei-estadual-7109-1979|Lei Estadual nº 7109/79]], que alterem ou possam vir a alterar o Meio Ambiente.
- **Art. 2º, caput, inciso II** {#art2_cpt_inc2} #licenciamento-ambiental Licenciamento Ambiental: procedimento administrativo pelo qual o IAP, verificando a satisfação das condições legais e técnicas, licenciam a localização, instalação, ampliação e a operação de empreendimentos e atividades utilizadoras de recursos ambientais consideradas efetiva ou potencialmente poluidoras ou daquelas que, sob qualquer forma, possam causar degradação e/ou modificação ambiental, considerando as disposições legais e regulamentares e as normas técnicas aplicáveis ao caso.
- **Art. 2º, caput, inciso III** {#art2_cpt_inc3} Licença Ambiental: ato administrativo pelo qual o IAP, estabelece as condições, restrições e medidas de controle ambiental que deverão ser obedecidas pelo empreendedor, pessoa física ou jurídica, para localizar, instalar, ampliar e operar empreendimentos ou atividades utilizadoras dos recursos ambientais consideradas efetiva ou potencialmente poluidoras ou aquelas que, sob qualquer forma, possam causar degradação e/ou modificação ambiental.
- **Art. 2º, caput, inciso IV** {#art2_cpt_inc4} #residuo-solido Unidade de Transbordo de Resíduos Sólidos Urbanos Não Perigosos: área de transferência de resíduos sólidos urbanos não perigosos de um veículo com menor capacidade de carga para outro veículo com maior capacidade de carga, para posterior encaminhamento para destinação final.

###### Art. 3º {#art3}
Tags: #documentacao #enquadramento #las #li #lo #lp #residuo-solido-urbano #transbordo

**Art. 3º, caput** {#art3_cpt} #documentacao #enquadramento #las #li #lo #lp O IAP, no exercício de sua competência, expedirá os seguintes atos administrativos: Licença ambiental simplificada (LAS): aprova a localização, concepção e viabilidade ambiental do empreendimento, atividade ou obra de pequeno porte, autorizando sua instalação e operação de acordo com as especificações constantes dos requerimentos, planos, programas e/ou projetos aprovados, incluindo as medidas de controle ambientais e demais condicionantes determinadas pelo IAP; Licença Prévia (LP) - concedida na fase preliminar do planejamento do empreendimento ou atividade de médio ou grande porte aprovando sua localização e concepção, atestando a viabilidade ambiental e estabelecendo os requisitos básicos e condicionantes a serem atendidos nas próximas fases de sua implementação. Licença de Instalação (LI) - autoriza a instalação do empreendimento ou atividade de médio e grande porte de acordo com as especificações constantes dos planos, programas e projetos aprovados, incluindo as medidas de controle ambiental e demais condicionantes da qual constituem motivo determinante. Licença de Operação (LO) - autoriza a operação da atividade ou empreendimento de médio e grande porte, após a verificação do efetivo cumprimento do que consta das licenças anteriores, com as medidas de controle ambiental e condicionantes determinados para a operação.

###### Art. 4º {#art4}
Tags: #enquadramento #residuo-solido #residuo-solido-urbano #transbordo

**Art. 4º, caput** {#art4_cpt} #enquadramento #residuo-solido Para efeito desta Portaria, as Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos, são classificados de acordo com o porte. Porte do empreendimento: quantidade de RSU recebida (tonelada/dia) Pequeno: até 120 t/dia Médio: 120 a 300 t/dia Grande: acima de 300 t/dia

###### Art. 5º {#art5}
Tags: #app #documentacao #las #li #licenciamento-ambiental #lo #lp #prazo #renovacao #residuo-solido #residuo-solido-urbano #responsavel-tecnico #transbordo

**Art. 5º, caput** {#art5_cpt} #documentacao #licenciamento-ambiental Os requerimentos de licenciamento, serão protocolados, desde que instruídos na forma prevista abaixo.
- **Art. 5º, caput, inciso I** {#art5_cpt_inc1} #documentacao #las #licenciamento-ambiental LICENÇA AMBIENTAL SIMPLIFICADA – LAS Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 5º, caput, inciso I, alínea "a"** {#art5_cpt_inc1_alia} #app #residuo-solido Cadastro de Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 5º, caput, inciso I, alínea "b"** {#art5_cpt_inc1_alib} #documentacao Certidão do Município, quanto ao uso e ocupação do solo, conforme modelo apresentado no (ANEXO 3);
  - **Art. 5º, caput, inciso I, alínea "c"** {#art5_cpt_inc1_alic} #documentacao #prazo #responsavel-tecnico Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente, e em caso de imóvel locado no nome do locador junto com o contrato de locação, no máximo de 90 (noventa) dias, para imóveis rurais exige-se a averbação da Reserva Legal junto à matrícula do imóvel, ou Documento de propriedade ou justa posse rural ou conforme exigências constantes da Seção VI, art.46 a 57 da [[resolucao-cema-65-2008|Resolução CEMA 065 de 01 de julho de 2008]];
  - **Art. 5º, caput, inciso I, alínea "d"** {#art5_cpt_inc1_alid} Cópia do Ato Constitutivo ou do Contrato Social (com última alteração);
  - **Art. 5º, caput, inciso I, alínea "e"** {#art5_cpt_inc1_alie} #las Publicação de súmula do pedido de Licença Ambiental Simplificada em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 5);
  - **Art. 5º, caput, inciso I, alínea "f"** {#art5_cpt_inc1_alif} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária)
  - **Art. 5º, caput, inciso I, alínea "g"** {#art5_cpt_inc1_alig} #residuo-solido Projeto de Controle Ambiental da Unidade de Transbordo de Resíduos Sólidos Urbanos Não Perigosos (ANEXO 6).
  - **Art. 5º, caput, inciso I, alínea "h"** {#art5_cpt_inc1_alih} Anotação de Responsabilidade Técnica referente ao PCA e à implantação da Unidade. Até o início da operação da Unidade deverá ser apresentada a Anotação de Responsabilidade Técnica referente à operação da Unidade.
- **Art. 5º, caput, inciso II** {#art5_cpt_inc2} #las #renovacao RENOVAÇÃO DA LICENÇA AMBIENTAL SIMPLIFICADA – LAS
  - **Art. 5º, caput, inciso II, alínea "a"** {#art5_cpt_inc2_alia} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 5º, caput, inciso II, alínea "b"** {#art5_cpt_inc2_alib} #app #residuo-solido Cadastro de Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 5º, caput, inciso II, alínea "c"** {#art5_cpt_inc2_alic} #las Publicação de súmula de recebimento de Licença Ambiental Simplificada em jornal de circulação regional e no Diário Oficial do Estado, (ANEXO 5);
  - **Art. 5º, caput, inciso II, alínea "d"** {#art5_cpt_inc2_alid} #las #renovacao Súmula do pedido de Renovação de Licença Ambiental Simplificada, publicada por ocasião da sua expedição conforme [[resolucao-conama-6-1986|Resolução CONAMA no 006/86]];
  - **Art. 5º, caput, inciso II, alínea "e"** {#art5_cpt_inc2_alie} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária).
  - **Art. 5º, caput, inciso II, alínea "f"** {#art5_cpt_inc2_alif} #residuo-solido Relatório anual de recebimento, movimentação e destinação final dos resíduos, descrevendo o gerador, quantidades e tratamento/destinação final adotados (ANEXO 4).
  - **Art. 5º, caput, inciso II, alínea "g"** {#art5_cpt_inc2_alig} Anotação de Responsabilidade Técnica referente à operação da Unidade.
- **Art. 5º, caput, inciso III** {#art5_cpt_inc3} #lp LICENÇA PRÉVIA
  - **Art. 5º, caput, inciso III, alínea "a"** {#art5_cpt_inc3_alia} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 5º, caput, inciso III, alínea "b"** {#art5_cpt_inc3_alib} #app #residuo-solido Cadastro de Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 5º, caput, inciso III, alínea "c"** {#art5_cpt_inc3_alic} #documentacao Certidão do Município, quanto ao uso e ocupação do solo, conforme modelo apresentado no (ANEXO 3);
  - **Art. 5º, caput, inciso III, alínea "d"** {#art5_cpt_inc3_alid} #lp Publicação de súmula do pedido de Licença Prévia em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 5);
  - **Art. 5º, caput, inciso III, alínea "e"** {#art5_cpt_inc3_alie} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária)
  - **Art. 5º, caput, inciso III, alínea "f"** {#art5_cpt_inc3_alif} #documentacao #prazo #responsavel-tecnico Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente, e em caso de imóvel locado no nome do locador junto com o contrato de locação, no máximo de 90 (noventa) dias, para imóveis rurais exige-se a averbação da Reserva Legal junto à matrícula do imóvel, ou Documento de propriedade ou justa posse rural ou conforme exigências constantes da Seção VI, art.46 a 57 da [[resolucao-cema-65-2008|Resolução CEMA 065 de 01 de julho de 2008]].
  - **Art. 5º, caput, inciso III, alínea "g"** {#art5_cpt_inc3_alig} #documentacao Nos casos devidamente justificados em que não seja possível a apresentação dos documentos especificados no item f, os mesmos deverão ser apresentados antes do inicio da operação da atividade ou empreendimento sob pena de cancelamento da licença Ambiental.
  - **Art. 5º, caput, inciso III, alínea "h"** {#art5_cpt_inc3_alih} #residuo-solido Apresentação de projeto preliminar, elaborado por profissionais habilitado, acompanhado das respectivas ARTs, com Memorial descritivo contendo: - informações sobre os resíduos da atividade de transbordo, incluindo origem, quantidade e destinação final a ser dada, concepção e justificativa do projeto, descritivo das medidas de controle ambiental a serem adotadas na área. - Indicação da distancia da Unidade em relação a corpos dá água, núcleos populacionais e residências isoladas.
  - **Art. 5º, caput, inciso III, alínea "i"** {#art5_cpt_inc3_alii} Cópia do Ato Constitutivo ou do Contrato Social (com última alteração)
- **Art. 5º, caput, inciso IV** {#art5_cpt_inc4} #li LICENÇA DE INSTALAÇÃO
  - **Art. 5º, caput, inciso IV, alínea "a"** {#art5_cpt_inc4_alia} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 5º, caput, inciso IV, alínea "b"** {#art5_cpt_inc4_alib} #app #residuo-solido Cadastro de Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 5º, caput, inciso IV, alínea "c"** {#art5_cpt_inc4_alic} #residuo-solido Projeto de Controle Ambiental da Unidade de Transbordo de Resíduos Sólidos Urbanos Não Perigosos (ANEXO 6).
  - **Art. 5º, caput, inciso IV, alínea "d"** {#art5_cpt_inc4_alid} Anotação de Responsabilidade Técnica referente ao PCA e à implantação da Unidade.
  - **Art. 5º, caput, inciso IV, alínea "e"** {#art5_cpt_inc4_alie} #lp Publicação de súmula de recebimento de Licença Prévia em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 5);
  - **Art. 5º, caput, inciso IV, alínea "f"** {#art5_cpt_inc4_alif} #li Publicação de súmula de pedido de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 5);
  - **Art. 5º, caput, inciso IV, alínea "g"** {#art5_cpt_inc4_alig} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária)
  - **Art. 5º, caput, inciso IV, alínea "h"** {#art5_cpt_inc4_alih} #lp Cópia da Licença Prévia.
- **Art. 5º, caput, inciso V** {#art5_cpt_inc5} #li #renovacao RENOVAÇÃO DE LICENÇA DE INSTALAÇÃO
  - **Art. 5º, caput, inciso V, alínea "a"** {#art5_cpt_inc5_alia} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 5º, caput, inciso V, alínea "b"** {#art5_cpt_inc5_alib} #app #residuo-solido Cadastro de Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 5º, caput, inciso V, alínea "c"** {#art5_cpt_inc5_alic} #li Publicação de súmula de recebimento de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 5);
  - **Art. 5º, caput, inciso V, alínea "d"** {#art5_cpt_inc5_alid} #li #renovacao Publicação de súmula do pedido de Renovação de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 5);
  - **Art. 5º, caput, inciso V, alínea "e"** {#art5_cpt_inc5_alie} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária);
  - **Art. 5º, caput, inciso V, alínea "f"** {#art5_cpt_inc5_alif} #documentacao #li Documento que declare se houveram mudanças no escopo e características do projeto apresentado quando da obtenção da Licença de Instalação. Caso existam modificações, detalhá-las.
  - **Art. 5º, caput, inciso V, alínea "g"** {#art5_cpt_inc5_alig} #li Cópia da Licença de Instalação.
- **Art. 5º, caput, inciso VI** {#art5_cpt_inc6} #lo LICENÇA DE OPERAÇÃO
  - **Art. 5º, caput, inciso VI, alínea "a"** {#art5_cpt_inc6_alia} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 5º, caput, inciso VI, alínea "b"** {#art5_cpt_inc6_alib} #app #residuo-solido Cadastro de Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 5º, caput, inciso VI, alínea "c"** {#art5_cpt_inc6_alic} #li Publicação de súmula de recebimento de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 5);
  - **Art. 5º, caput, inciso VI, alínea "d"** {#art5_cpt_inc6_alid} #lo Publicação de súmula do pedido de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 5);
  - **Art. 5º, caput, inciso VI, alínea "e"** {#art5_cpt_inc6_alie} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária)
  - **Art. 5º, caput, inciso VI, alínea "f"** {#art5_cpt_inc6_alif} #li Cópia da Licença de Instalação.
  - **Art. 5º, caput, inciso VI, alínea "g"** {#art5_cpt_inc6_alig} Anotação de Responsabilidade Técnica referente à operação da Unidade.
- **Art. 5º, caput, inciso VII** {#art5_cpt_inc7} #lo #renovacao RENOVAÇÃO DE LICENÇA DE OPERAÇÃO
  - **Art. 5º, caput, inciso VII, alínea "a"** {#art5_cpt_inc7_alia} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 5º, caput, inciso VII, alínea "b"** {#art5_cpt_inc7_alib} #app #residuo-solido Cadastro de Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 5º, caput, inciso VII, alínea "c"** {#art5_cpt_inc7_alic} #lo Cópia da Licença de Operação;
  - **Art. 5º, caput, inciso VII, alínea "d"** {#art5_cpt_inc7_alid} #lo Publicação de recebimento de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 5);
  - **Art. 5º, caput, inciso VII, alínea "e"** {#art5_cpt_inc7_alie} #lo #renovacao Publicação de pedido de Renovação de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 5);
  - **Art. 5º, caput, inciso VII, alínea "f"** {#art5_cpt_inc7_alif} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária)
  - **Art. 5º, caput, inciso VII, alínea "g"** {#art5_cpt_inc7_alig} #residuo-solido Relatório anual de recebimento, movimentação e destinação final dos resíduos, descrevendo o gerador, quantidades e tratamento/destinação final adotados (ANEXO 4).
  - **Art. 5º, caput, inciso VII, alínea "h"** {#art5_cpt_inc7_alih} Anotação de Responsabilidade Técnica referente à operação da Unidade.

###### Art. 6º {#art6}
Tags: #app #documentacao #enquadramento #las #licenciamento-ambiental #lo #prazo #residuo-solido #residuo-solido-urbano #responsavel-tecnico #transbordo

**Art. 6º, caput** {#art6_cpt} #documentacao #enquadramento #las #licenciamento-ambiental #lo Os empreendimentos que possuem Autorização Ambiental vigente deverão protocolar o pedido de Regularização do Licenciamento Ambiental. Para essas situações, conforme o porte do empreendimento, poderá ser solicitada diretamente a Licença de Operação - LO ou a Licença Ambiental Simplificada – LAS, através de requerimento dirigido ao Diretor Presidente do IAP, desde que instruídos na forma prevista abaixo.
- **Art. 6º, caput, inciso VIII** {#art6_cpt_inc8} #licenciamento-ambiental REGULARIZAÇÃO DO LICENCIAMENTO
  - **Art. 6º, caput, inciso VIII, alínea "a"** {#art6_cpt_inc8_alia} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 6º, caput, inciso VIII, alínea "b"** {#art6_cpt_inc8_alib} #app #residuo-solido Cadastro de Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 6º, caput, inciso VIII, alínea "c"** {#art6_cpt_inc8_alic} #documentacao #prazo Matrícula ou Transcrição do Cartório de Registro de Imóveis, atualizada, no máximo, 90 (noventa) dias;
  - **Art. 6º, caput, inciso VIII, alínea "d"** {#art6_cpt_inc8_alid} #residuo-solido Projeto de Controle Ambiental da Unidade de Transbordo de Resíduos Sólidos Urbanos Não Perigosos (ANEXO 6).
  - **Art. 6º, caput, inciso VIII, alínea "e"** {#art6_cpt_inc8_alie} #licenciamento-ambiental Publicação de pedido de Regularização do Licenciamento Ambiental em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 5);
  - **Art. 6º, caput, inciso VIII, alínea "f"** {#art6_cpt_inc8_alif} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária)
  - **Art. 6º, caput, inciso VIII, alínea "g"** {#art6_cpt_inc8_alig} #residuo-solido Relatório anual de recebimento, movimentação e destinação final dos resíduos, descrevendo o gerador, quantidades e tratamento/destinação final adotados (ANEXO 4).
  - **Art. 6º, caput, inciso VIII, alínea "h"** {#art6_cpt_inc8_alih} #documentacao #prazo #responsavel-tecnico Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente, e em caso de imóvel locado no nome do locador junto com o contrato de locação, no máximo de 90 (noventa) dias, para imóveis rurais exige-se a averbação da Reserva Legal junto à matrícula do imóvel, ou Documento de propriedade ou justa posse rural ou conforme exigências constantes da Seção VI, art.46 a 57 da [[resolucao-cema-65-2008|Resolução CEMA 065 de 01 de julho de 2008]];
  - **Art. 6º, caput, inciso VIII, alínea "i"** {#art6_cpt_inc8_alii} Cópia do Ato Constitutivo ou do Contrato Social (com última alteração).

###### Art. 7º {#art7}
Tags: #documentacao #las #li #lo #lp #prazo #renovacao #residuo-solido-urbano #transbordo

**Art. 7º, caput** {#art7_cpt} #documentacao #prazo O IAP estabelecerá os prazos de validade de cada tipo de licença ambiental, especificando-os no respectivo documento, levando em consideração os seguintes aspectos:
- **Art. 7º, caput, inciso I** {#art7_cpt_inc1} #lp #prazo #renovacao O prazo de validade da Licença Prévia (LP) será de 2 (dois) anos. A Licença Prévia - LP não é passível de renovação.
- **Art. 7º, caput, inciso II** {#art7_cpt_inc2} #li #prazo #renovacao O prazo de validade da Licença de Instalação (LI) será de 2 (dois) anos. A Licença de Instalação - LI poderá ser renovada. A renovação deve ser requerida no mínimo 120 (cento e vinte) dias antes da data de sua expiração.
- **Art. 7º, caput, inciso III** {#art7_cpt_inc3} #lo #prazo #renovacao O prazo de validade da Licença de Operação (LO) será de 04 (quatro) anos. A Licença de Operação (LO) poderá ser renovada. A renovação deve ser requerida no mínimo 120 (cento e vinte) dias antes da data de sua expiração.
- **Art. 7º, caput, inciso IV** {#art7_cpt_inc4} #las #prazo #renovacao O prazo de validade da Licença Ambiental Simplificada (LAS) será de 06 (seis) anos. A Licença Ambiental Simplificada (LAS) poderá ser renovada. A renovação deve ser requerida no mínimo 120 (cento e vinte) dias antes da data de sua expiração.

**Art. 7º, parágrafo único** {#art7_par1u} #prazo Em casos excepcionais, justificados por motivos técnicos e/ou legais, o IAP poderá reduzir o prazo de validade das Licenças.

###### Art. 8º {#art8}
Tags: #enquadramento #residuo-solido #residuo-solido-urbano #transbordo

**Art. 8º, caput** {#art8_cpt} #enquadramento #residuo-solido Nas situações aplicáveis deverá ser solicitada a Autorização Ambiental para transporte ou destinação final de resíduos, de acordo com o previsto nas Portarias específicas do IAP.

###### Art. 9º {#art9}
Tags: #agua-subterranea #residuo-solido #residuo-solido-urbano #transbordo

**Art. 9º, caput** {#art9_cpt} #agua-subterranea #residuo-solido A Unidade de Transbordo de Resíduos Sólidos Urbanos Não Perigosos deverá contemplar todas as medidas técnicas necessárias para evitar a proliferação de vetores, contaminação do solo, subsolo, lençol freático, bem como controle de emissões atmosféricas.

###### Art. 10 {#art10}
Tags: #efluente #residuo-solido-urbano #transbordo

**Art. 10, caput** {#art10_cpt} #efluente O efluente não poderá ser lançado em corpo hídrico ou infiltrado no solo, independente do pré-tratamento   realizado.   Deverá    ser   encaminhado     para   empresa     devidamente   licenciada   para tratamento/disposição final.

###### Art. 11 {#art11}
Tags: #efluente #residuo-solido #residuo-solido-urbano #transbordo

**Art. 11, caput** {#art11_cpt} #efluente #residuo-solido O tempo de permanência dos resíduos sólidos urbanos na área de transbordo deverá ser o mínimo possível, de forma a garantir a não geração de odores, de efluentes líquidos, atração de vetores e incômodos à população.

###### Art. 12 {#art12}
Tags: #efluente #proibicao #residuo-solido #residuo-solido-urbano #transbordo

**Art. 12, caput** {#art12_cpt} #residuo-solido A Unidade de Transbordo de Resíduos Sólidos Urbanos Não Perigosos deverá:
- **Art. 12, caput, inciso I** {#art12_cpt_inc1} #proibicao ser devidamente isolada e sinalizada, sendo proibido o acesso de pessoas não autorizadas e animais;
- **Art. 12, caput, inciso II** {#art12_cpt_inc2} possuir sistema de drenagem de águas pluviais;
- **Art. 12, caput, inciso III** {#art12_cpt_inc3} #efluente possuir sistema de drenagem, contenção e caixa/tanque de acúmulo dos efluentes eventualmente gerados;
- **Art. 12, caput, inciso IV** {#art12_cpt_inc4} #residuo-solido possuir impermeabilização de base, com geomembrana, piso de concreto ou sistemas similares no local onde ocorrerá a transferência dos resíduos;
- **Art. 12, caput, inciso V** {#art12_cpt_inc5} possuir vias de acesso que permitam a circulação de veículos pesados, mesmo em situações climáticas adversas.
- **Art. 12, caput, inciso VI** {#art12_cpt_inc6} #residuo-solido manter a área específica, onde ocorre de transferência dos resíduos sólidos urbanos não perigosos, a no mínimo 200 metros de residências isoladas e vias de domínio público e a no mínimo 400 metros de núcleos populacionais;

**Art. 12, parágrafo único** {#art12_par1u} Em casos de Unidades já implantadas, o IAP avaliará a adoção de distâncias diferentes, mediante as devidas justificativas técnicas e/ou legais.

**Art. 12, § 2º** {#art12_par2} ”: Em situações justificadas, considerando o tipo da unidade, as medidas mitigadoras previstas, o IAP poderá reduzir as distâncias contidas no item VI. DAS DISPOSIÇÕES TRANSITÓRIAS E FINAIS DAS DISPOSIÇÕES TRANSITÓRIAS E FINAIS

###### Art. 13 {#art13}
Tags: #documentacao #licenciamento-ambiental #residuo-solido-urbano #transbordo

**Art. 13, caput** {#art13_cpt} #documentacao #licenciamento-ambiental Caso haja necessidade, o IAP solicitará, a qualquer momento, outros documentos e informações complementares do requerente ou de outras instituições envolvidas no licenciamento ambiental em questão.

###### Art. 14 {#art14}
Tags: #residuo-solido-urbano #responsavel-tecnico #transbordo

**Art. 14, caput** {#art14_cpt} #responsavel-tecnico O descumprimento das disposições desta Portaria, dos termos das Licenças Ambientais sujeitará o infrator às penalidades previstas na [[lei-federal-9605-1998|Lei nº 9.605, de 12 de fevereiro de 1998]], e em outros dispositivos normativos pertinentes, sem prejuízo do dever de recuperar os danos ambientais causados, na forma do art. 225, Parágrafo 4º, da Constituição Federal do Brasil, e do art. 14, Parágrafo 1o, da Lei n. 6.938, de 1981.

###### Art. 15 {#art15}
Tags: #residuo-solido-urbano #transbordo

**Art. 15, caput** {#art15_cpt} O Instituto Ambiental do Paraná poderá reformular e/ou complementar os critérios estabelecidos na presente Portaria de acordo com o desenvolvimento científico e tecnológico e a necessidade de preservação ambiental.

###### Art. 16 {#art16}
Tags: #residuo-solido-urbano #transbordo

**Art. 16, caput** {#art16_cpt} Casos não contemplados nesta Portaria serão analisados caso a caso pelo IAP.

###### Art. 17 {#art17}
Tags: #residuo-solido-urbano #transbordo

**Art. 17, caput** {#art17_cpt} Os referidos anexos citados na Portaria encontram-se disponíveis no site do IAP na página: www.iap.pr.gov.br

###### Art. 18 {#art18}
Tags: #residuo-solido-urbano #transbordo

**Art. 18, caput** {#art18_cpt} Esta Portaria entra em vigor na data de sua publicação.


## Fecho

LUIZ TARCÍSIO MOSSATO PINTO Diretor Presidente do Instituto Ambiental do Paraná

REQUERIMENTO DE LICENCIAMENTO AMBIENTALDOCUMENTO DESTINADO À FORMALIZAÇÃO DO

REQUERIMENTO         PARA TODAS         AS    MODALIDADES       DE   LICENCIAMENTO       DE   ATIVIDADES POLUIDORAS, DEGRADANTES E/OU MODIFICADORAS DO MEIO AMBIENTE Secretaria de Estado do Meio Ambiente e Recursos HídricoS Diretoria de Controle de Recursos Ambientais 01 – USO DO IAP01 protocolo sid 02 – IDENTIFICAÇÃO DO REQUERENTE 02 RAZÃO SOCIAL (PESSOA JURÍDICA) OU NOME (PESSOA FÍSICA) 03 CNPJ OU CPF/MF 04 INSCRIÇÃO ESTADUAL PESSOA JURÍDICA OU RG PESSOA FÍSICA 05 ENDEREÇO COMPLETO 06 BAIRRO 07 MUNICÍPIO/UF 08 CEP 09 TELEFONE PARA CONTATO 03 – IDENTIFICAÇÃO DO OBJETO DA SOLICITAÇÃO 10 SOLICITAÇÃO DE LICENCIAMENTO AMBIENTAL PARA (TIPO DE EMPREENDIMENTO) 04 – REQUERIMENTO

AO SENHORDIRETOR PRESIDENTE DO INSTITUTO AMBIENTAL DO PARANÁCURITIBA - PARANÁO

REQUERENTE SUPRA CITADO, VEM MUI RESPEITOSAMENTE À PRESENÇA DE V.S., REQUERER EXPEDIÇÃO DE(A): 12 MODALIDADE DE LICENCIAMENTO AMBIENTAL

LICENÇA AMBIENTAL SIMPLIFICADA - LAS LICENÇA DE OPERAÇÃO - LO

LICENÇA PRÉVIA - LP AUTORIZAÇÃO AMBIENTAL - AA

LICENÇA DE INSTALAÇÃO - LI RENOVAÇÃO DE: DLAE LAS LI LO REGULARIZAÇÃO DO LICENCIAMENTO

CONFORME ELEMENTOS CONSTANTES DAS INFORMAÇÕES CADASTRADAS E DOCUMENTOS EM

ANEXO.DECLARA, OUTROSSIM, QUE CONHECE A LEGISLAÇÃO AMBIENTAL E DEMAIS NORMAS

PERTINENTES AO LICENCIAMENTO REQUERIDO, COMPROMETENDO-SE A RESPEITÁ-LA.NESTES

TERMOSPEDE DEFERIMENTO 13 LOCAL E DATA 14 ASSINATURA DO REQUERENTE 05 – IDENTIFICAÇÃO DO RESPONSÁVEL TÉCNICO (SE HOUVER) 15 NOME DO TÉCNICO RESPONSÁVEL 16 QUALIFICAÇÃO PROFISSIONAL 17 NO REGISTRO NO CREA 18 REGIÃO 19 POSSUI PENDÊNCIAS TÉCNICAS OU LEGAIS?

SIM NÃO TIPO 06 – RECEPÇÃO DE DOCUMENTOS 20 POSSUI DÉBITOS AMBIENTAIS? SIM NÃO 21 FORMA DE ENTREGA DA LICENÇA 22 ESCRITÓRIO REGIONAL DO IAP DE : 23 DOCUMENTOS E TAXA AMBIENTAL CONFERIDOS POR: (NOME, CARIMBO E ASSINATURA) 24 DATA

CADASTRO PARA UNIDADES DE TRANSBORDO DE RESÍDUOS SÓLIDOS URBANOS NÃO

PERIGOSOS CTU

SECRETARIA DE ESTADO DO MEIO AMBIENTE E RECURSOS HÍDRICOS DIRETORIA DE CONTROLE DE RECURSOS AMBIENTAIS - DIRAM 01 USO DO IAP01 PROTOCOLO SID 02 IDENTIFICAÇÃO DO REQUERENTE 02 RAZÃO SOCIAL 03 CGC 04 INSCRIÇÃO ESTADUAL 05 TELEFONE (DDD - NÚMERO) 06 FAX (DDD - NÚMERO) 07 ENDEREÇO PARA CONTATO 08 BAIRRO /DISTRITO 09 MUNICÍPIO/UF 10 CEP 11 NOME PARA CONTATO 12 CARGO 13 FONE PARA CONTATO 03 CARACTERIZAÇÃO DA ATIVIDADE GERADORA DO RESÍDUO 14 ATIVIDADE 15 CÓDIGO 16 ENDEREÇO DA ATIVIDADE 17 BAIRRO /DISTRITO 18 MUNICÍPIO/UF 19 CEP

RESÍDUOS RECEBIDOS DESTINOS SELECIONADOS 20 TIPO 21 QUANTIDADE/MÊS 22 TIPO 23 QUANTIDADE/MÊS 24 RESPONSÁVEL PELAS INFORMAÇÕES 25 NOME COMPLETO 26 CPF - CADASTRO DE PESSOA FÍSICA 27 LOCAL E DATA ASSUMO SOB AS PENAS DA LEI, QUE AS INFORMAÇÕES PRESTADAS SÃO VERDADEIRAS 28

ASSINATURA

ANEXO 3 Modelo de certidão do município, quanto ao uso e ocupação do solo Em papel timbrado do Município. CERTIDÃO MUNICÍPIO DE - (NOME DO MUNICÍPIO) Declaramos ao INSTITUTO AMBIENTAL DO PARANÁ - IAP/SEMA que o Empreendimento abaixo descrito, está localizado neste Município e que o Local, o Tipo de Empreendimento e Atividade estão em conformidade com a legislação municipal aplicável ao uso e ocupação do solo (nº do diploma legal pertinente) bem como atendem as demais exigências legais e administrativas perante o nosso Município.

EMPREENDEDOR CPF/CNPJ

NOME DO EMPREENDIMENTO

ATIVIDADE ENDEREÇO BAIRRO CEP TELEFONE Local e Data Nome, assinatura e carimbo do Prefeito Municipal e/ou Secretário Municipal

ANEXO 4 Relatório anual de recebimento, movimentação e destinação final dos resíduos, descrevendo o gerador, quantidades e tratamento/destinação final adotados Este relatório deverá ser entregue na ocasião da renovação de licença ambiental simplificada, na renovação da licença de operação e na ocasião da regularização do licenciamento, e deverá ser referente a cada ano de operação. Os certificados de destinação final, do efluente e dos resíduos, deverão ser mantidos na administração do empreendimento e entregue ao IAP junto com este Relatório. O Relatório deve conter as seguintes informações: - Período de referência do documento; - Informações sobre a perspectiva de reformas e ampliações no empreendimento; - Medidas adotadas para controle de vetores; - Medidas adotadas para controle ambiental; - Descrever o processo de transbordo dos resíduos, especificando o local e forma de transferência dos resíduos e equipamentos utilizados; - Preencher a tabela abaixo com as informações referentes aos resíduos (quantidades, geradores e destinação final) e quanto ao efluente (quantidade, forma de armazenamento e destino final); Quantidade(ton/mês) Forma de Acondicionamento Razão social da empresa responsável pelo transporte Forma de destinação final Razão social da empresa responsável pela destinação final Nº da Licença Ambiental da empresa responsável pela destinação final Resíduo QuantidadeAcumulada Forma de Acondicionamento Razão social da empresa responsável pelo transporte Forma de destinação final Razão social da empresa responsável pelo tratamento/ destinação final Nº da Licença Ambiental da empresa responsável pelo tratamento/destinação final Efluente

ANEXO 5 FUNDAMENTO LEGAL: RESOLUÇÃO CONAMA 06/1986 Modelo para publicação de REQUERIMENTO de licença em Jornal Local e Diário Oficial (Nome da empresa ou Município) torna público que (requereu ou recebeu) do IAP, a (LAS, LP, LI, LO, RLI ou RLO) com validade de até (data de validade apenas para licença recebida) para (atividade e local).

ANEXO 6 – Termo de referência para elaboração de PCA

1. MEMORIAL TÉCNICO 1.1. Informações sobre a área

a) Localização;

b) Área total e área construída

c) Distância com relação a núcleos populacionais, residências isoladas, corpos d’água e demais distanciamentos pertinentes;

d) Acesso à área. 1.2. Informações sobre os resíduos

a) Origem dos resíduos;

b) Composição dos resíduos, com indicação das frações de resíduos orgânicos e inorgânicos, recicláveis e de rejeitos;

c) Quantidade diária e mensal a ser recebida na área;

d) Freqüência e horário de recebimento. 1.2. Concepção e justificativa de projeto Devem ser apresentadas a concepção e a metodologia de operação, justificando face às suas finalidades. 1.3. Descrição e especificações do projeto Todos os elementos de projeto devem ser suficientemente descritos e especificados, com apresentação de desenhos, esquemas, detalhes, cálculos, etc. 1.3.1. Transferência dos resíduos Especificar o local aonde ocorrerá a transferência e armazenamento e a forma como os resíduos serão transferidos, acondicionados e armazenados. Especificar o tempo total que os resíduos permaneceram na área, desde sua chegada até encaminhamento ao destino final. 1.3.2. Acessos e isolamento da área Apresentar a forma de isolamento do empreendimento e os dispositivos de segurança para evitar a interferência de pessoas estranhas e animais, bem como para coibir possíveis efeitos na vizinhança. 1.3.3. Fluxograma e descrição detalhada do processo Apresentar uma descrição da atividade, bem como um fluxograma detalhado da operação, contendo todas as atividades realizadas no empreendimento. Obs.: Quando houver utilização de simbologia ou abreviatura, anexar ao fluxograma legenda explicativa. 1.3.4. Descrição do sistema de captação de água, limpeza da área , estruturas e drenagem Detalhar sistemas de captação de água, drenagem, impermeabilização, contenção, acúmulo de efluente. 1.3.5. Instalações de apoio Deverão ser descritas as instalações de apoio a serem instaladas na área. Detalhar o abastecimento de água e o esgotamento sanitário nas instalações. 1.3.6. Controle Ambiental Detalhar as medidas de controle ambiental a serem adotadas, bem como de controle de vetores. Especificar a destinação a ser dada aos resíduos e ao efluente. 1.4. Equipe de trabalho e equipamentos

a) Quantificar a equipe de trabalho;

b) Adoção de equipamentos de proteção individual - EPI

c) Especificar e quantificar os equipamentos/estruturas a serem utilizados na operação do empreendimento, tais como veículos, balanças de pesagem, rampa de acesso, entre outros.

2. REPRESENTAÇÃO GRÁFICA Planta da concepção geral Devem ser apresentados em desenho georeferenciado os seguintes elementos:

a) localização geográfica da Unidade;

b) acessos principais e instalações de apoio;

c) corpos da água e indicação da distância com relação a Unidade.

d) distância com relação à núcleos populacionais e residências isoladas.

e) indicação do isolamento da área;

f) indicação da área de Reserva Legal;

g) indicação das áreas de Preservação Permanente;

j) indicação de demais áreas com presença de vegetação, se aplicável. Planta com detalhes da Unidade de Transbordo

a) limites da área total a ser utilizada;

b) área de transferência dos resíduos

c) rampa de acesso

d) sistema de cobertura

e) estrutura

f) sistema de drenagem, caixa de acúmulo de efluente

g) cortes longitudinais e transversais, onde necessário, para melhor visualização dos elementos do sistema. Apresentação das plantas As pranchas de desenho e demais peças deverão possuir identificação contendo:

a) Denominação e local da obra;

b) Nome da entidade executora;

c) Tipo de projeto;

d) Data;

e) Nome do responsável técnico, número de registro no CREA e sua assinatura.

### Requerimento de Licenciamento Ambiental {#anexo1}

Modelo de requerimento de Licenciamento Ambiental.

### Cadastro de Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos {#anexo2}

Modelo de cadastro de Unidades de Transbordo de Resíduos Sólidos Urbanos Não Perigosos.

### Certidão do município, quanto ao uso e ocupação do solo {#anexo3}

Modelo de certidão do município, quanto ao uso e ocupação do solo.

### Relatório anual de recebimento, movimentação e destinação final dos resíduos {#anexo4}

[[portaria-iap-187-2013-anexo4|Relatório anual de recebimento, movimentação e destinação final dos resíduos]]

### Publicação de REQUERIMENTO de licença em Jornal Local e Diário Oficial {#anexo5}

Modelo de publicação de REQUERIMENTO de licença em Jornal Local e Diário Oficial.

### Termo de referência para elaboração de PCA {#anexo6}

[[portaria-iap-187-2013-anexo6|Termo de referência para elaboração de PCA]]

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|
| [[instrucao-normativa-iat-30-2025]] | Norma inteira | Revogação expressa registrada no acervo. |

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (portaria IAP 187 2013(1).pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- Fonte: portaria IAP 187 2013(1).pdf (portal Sistema de Informações Ambientais do Paraná). Foram retirados os marcadores de página da extração e reunidas as quebras de linha; mantidas as grafias do texto fornecido.
- A transcrição foi feita a partir do texto extraído disponível. A comparação palavra por palavra com a extração local do PDF e a conferência visual não foram concluídas nesta etapa.
- Anexo misto: transcritas as diretrizes textuais do relatório; a tabela vazia para preenchimento foi tratada como modelo, conforme a regra de anexos tipo 1. As instruções sobre preenchimento permanecem no texto.
- A numeração e as letras do original foram preservadas, inclusive as sequências repetidas ou descontínuas.
- Revisão de numeração: inciso inicial VIII: art6_cpt_inc8. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Situação revogada conforme relação expressa já cadastrada no acervo: [[instrucao-normativa-iat-30-2025]]. Regras de transição e processos antigos devem ser avaliados separadamente.
