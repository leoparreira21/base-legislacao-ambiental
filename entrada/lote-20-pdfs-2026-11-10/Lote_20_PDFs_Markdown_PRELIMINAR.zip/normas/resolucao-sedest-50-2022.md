---
norma: "Resolução SEDEST nº 50/2022"
arquivo: resolucao-sedest-50-2022
tipo: resolucao
esfera: estadual
uf: PR
numero: 50
ano: 2022
data_assinatura: 2022-08-24
ementa: "Estabelece definições, critérios, diretrizes e procedimentos para o licenciamento ambiental de empreendimentos imobiliários urbanos no território paranaense."
situacao: vigente
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: ["[[resolucao-sedest-9-2024]]"]
revoga: ["[[resolucao-sedest-30-2022]]", "[[resolucao-sedest-68-2019]]"]
revogado_por: []
cita: ["[[decreto-estadual-10613-2022]]", "[[lei-estadual-10066-1992]]", "[[lei-estadual-20448-2020]]", "[[lei-federal-10257-2001]]", "[[lei-federal-11428-2006]]", "[[lei-federal-11445-2007]]", "[[lei-federal-12651-2012]]", "[[lei-federal-13089-2015]]", "[[lei-federal-19848-2019]]", "[[lei-federal-4591-1964]]", "[[lei-federal-6496-1977]]", "[[lei-federal-6766-1979]]", "[[lei-federal-9605-1998]]", "[[portaria-iap-216-2018]]", "[[resolucao-cema-107-2020]]", "[[resolucao-cema-107-2022]]", "[[resolucao-conama-1-1986]]", "[[resolucao-conama-2-1994]]", "[[resolucao-conama-307-2002]]", "[[resolucao-conama-412-2009]]", "[[resolucao-conama-428-2010]]", "[[resolucao-sedest-30-2022]]", "[[resolucao-sedest-68-2019]]", "[[resolucao-sema-51-2009]]"]
tags: ["agua-subterranea", "app", "autorizacao-florestal", "definicao", "documentacao", "efluente", "eia-rima", "empreendimento-imobiliario", "enquadramento", "las", "li", "licenciamento-ambiental", "lo", "lp", "monitoramento", "outorga", "parcelamento-solo", "prazo", "proibicao", "redacao-alterada", "renovacao", "residuo-solido", "responsavel-tecnico"]
fonte: "PDF fornecido: sedest 50 2022(1).pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
texto: "compilado segundo as alterações explícitas no PDF fornecido; conferência visual pendente"
---

# Resolução SEDEST nº 50/2022

> Estabelece definições, critérios, diretrizes e procedimentos para o licenciamento ambiental de empreendimentos imobiliários urbanos no território paranaense.

## Preâmbulo

Resolução SEDEST 50 - 24 de Agosto de 2022 Publicado no Diário Oficial nº. 11248 de 26 de Agosto de 2022 Súmula: Estabelece definições, critérios, diretrizes e procedimentos para o licenciamento ambiental de empreendimentos imobiliários urbanos no território paranaense. O Secretário de Estado do Desenvolvimento Sustentável e do Turismo-SEDEST, designado pelo [[decreto-estadual-10613-2022|Decreto Estadual nº 10613, de 30 de março de 2022]] no uso das atribuições que lhes são conferidas pela [[lei-federal-19848-2019|Lei nº 19.848, de 3 de maio de 2019]]; Considerando o disposto na [[lei-federal-6496-1977|Lei Federal nº 6.496, de 07 de dezembro de 1977]], que dispõe sobre a "Anotação de Responsabilidade Técnica" na prestação de serviços de engenharia, de arquitetura e agronomia; Considerando a [[lei-federal-6766-1979|Lei Federal nº 6.766, de 19 de dezembro de 1979]], e alterações posteriores, que dispõe sobre o Parcelamento do Solo Urbano e dá outras providências; Considerando a [[lei-federal-11428-2006|Lei Federal nº 11.428, de 22 de dezembro de 2006]], que dispõe sobre a utilização e proteção da vegetação nativa do Bioma Atlântica, e dá outras providências; Considerando a [[lei-federal-11445-2007|Lei Federal nº 11.445, de 05 de janeiro de 2007]], que estabelece diretrizes nacionais para o Saneamento Básico; Considerando a [[lei-federal-10257-2001|Lei Federal nº 10.257, de 10 de julho de 2001]], que instituiu o Estatuto das Cidades; Considerando a [[lei-federal-12651-2012|Lei Federal nº 12.651, de 25 de maio de 2012]], que dispõe sobre a proteção da vegetação nativa e suas alterações posteriores; Considerando a [[lei-federal-13089-2015|Lei Federal nº 13.089, de 12 de janeiro de 2015]], que instituiu o Estatuto da Metrópole; Considerando os objetivos institucionais do Instituto Ambiental do Paraná - IAP estabelecidos na [[lei-estadual-10066-1992|Lei Estadual nº 10.066, de 27 de julho de 1992]] e alterações posteriores; Considerando o disposto na Resolução do Conselho Nacional de Meio Ambiente- CONAMA nº 237, de 19 de dezembro de 1997; Considerando as Resoluções do Conselho Nacional de Meio Ambiente - CONAMA nº 357, de 17 de março de 2005 e 430, de 13 de maio de 2011, que dispõe sobre condições e padrões de lançamento de efluentes; Considerando o disposto na Resolução do Conselho Estadual do Meio Ambiente - CEMA n° 107 de 09 de setembro de 2020, ou outra que vier a substituíla, que dispõe sobre o licenciamento ambiental, estabelece critérios e procedimentos a serem adotados para as atividades poluidoras, degradadoras e/ou modificadoras do meio ambiente; Considerando o disposto na [[resolucao-sema-51-2009|Resolução SEMA nº 051, de 23 de outubro de 2009]], que trata da Dispensa de Licenciamento e/ou Autorização Ambiental Estadual de empreendimentos e atividades de pequeno porte e baixo impacto ambiental; Considerando a [[lei-estadual-20448-2020|Lei Estadual nº 20448 de 17 de dezembro de 2020]], que dispõe sobre o uso responsável de água no Estado do Paraná e dá outras providências. Considerando a necessidade de revisão da [[resolucao-sedest-68-2019|Resolução SEDEST 068/2019]]. RESOLVE:

###### Art. 1º {#art1}
Tags: #definicao #empreendimento-imobiliario #licenciamento-ambiental #parcelamento-solo

**Art. 1º, caput** {#art1_cpt} #definicao #licenciamento-ambiental Estabelecer definições, critérios, diretrizes e procedimentos para o licenciamento ambiental de empreendimentos imobiliários, localizados em área urbana.

### CAPÍTULO I – DAS DEFINIÇÕES

###### Art. 2º {#art2}
Tags: #empreendimento-imobiliario #parcelamento-solo

**Art. 2º, caput** {#art2_cpt} Para fins desta Resolução consideram-se empreendimentos imobiliários:
- **Art. 2º, caput, inciso I** {#art2_cpt_inc1} Parcelamento do solo urbano, que poderá ser feito mediante loteamento, condomínio de lotes ou desmembramento para fins habitacionais, industriais ou comerciais;
- **Art. 2º, caput, inciso II** {#art2_cpt_inc2} Condomínios para fins habitacionais, industriais ou comerciais;
- **Art. 2º, caput, inciso III** {#art2_cpt_inc3} Conjuntos Habitacionais.

###### Art. 3º {#art3}
Tags: #definicao #documentacao #eia-rima #empreendimento-imobiliario #parcelamento-solo #proibicao #residuo-solido

**Art. 3º, caput** {#art3_cpt} #definicao Para fins desta Resolução consideram-se as seguintes definições:
- **Art. 3º, caput, inciso I** {#art3_cpt_inc1} #proibicao Condomínios: empreendimento imobiliário em que os condôminos têm propriedade exclusiva sobre as partes denominadas de "unidades autônomas" e têm propriedade partilhada nas áreas comuns que lhes pertencem na proporção de suas respectivas frações ideais, sendo admitida a abertura de vias de domínio privado e vedada a de logradouros públicos internamente ao perímetro do condomínio. São edificações ou conjuntos de edificações, de um ou mais pavimentos (horizontal ou vertical), construídos sob a forma de unidades isoladas entre si, destinadas a fins residenciais ou não residenciais, e constituindo-se, cada unidade, por propriedade autônoma nos termos da [[lei-federal-4591-1964|Lei Federal nº 4.591, de 16 de dezembro de 1964]].
- **Art. 3º, caput, inciso II** {#art3_cpt_inc2} Condomínio de lotes: é o empreendimento caracterizado pelos terrenos em que partes são propriedades de uso exclusivo e partes que são propriedade comum dos condôminos.
- **Art. 3º, caput, inciso III** {#art3_cpt_inc3} Conjuntos habitacionais: são aglomerados de residências ou habitações de um ou mais pavimentos (horizontal ou vertical), implantadas como condomínios ou loteamento.
- **Art. 3º, caput, inciso IV** {#art3_cpt_inc4} Desmembramento: subdivisão de gleba urbana em lotes destinados à ocupação/edificação, com aproveitamento do sistema viário existente, desde que não implique na abertura de novas vias e logradouros públicos, nem no prolongamento, modificação ou ampliação dos já existentes, salvo determinação do Plano Diretor do Município ou Lei Municipal de Uso e Ocupação do Solo Urbano.
- **Art. 3º, caput, inciso V** {#art3_cpt_inc5} #eia-rima #residuo-solido Estudos, laudos, planos e projetos ambientais específicos: todos e quaisquer estudos relativos aos aspectos ambientais relacionados à localização, instalação, operação e ampliação de uma atividade ou empreendimento apresentado como subsídio para a análise da licença requerida, tais como: Estudo de Impacto Ambiental/Relatório de Impacto Ambiental - EIA/RIMA, Relatório Ambiental Preliminar - RAP, Relatório Ambiental Simplificado -RAS, Relatório de Detalhamento dos Programas Ambientais - RDPA, Projeto Básico Ambiental - PBA, Plano de Controle Ambiental-PCA, Plano de Recuperação de Área Degradada - PRAD, Plano de Gerenciamento de Resíduos Sólidos - PGRS, Análise de Risco- AR, Projeto de Controle de Poluição Ambiental – PCPA, Avaliação Ambiental Integrada ou Estratégica - AAI ou AAE, entre outros.
- **Art. 3º, caput, inciso VI** {#art3_cpt_inc6} Infraestrutura básica: equipamentos urbanos de escoamento das águas pluviais, iluminação pública, esgotamento sanitário e abastecimento de água potável, de energia elétrica pública e domiciliar e as vias de circulação.
- **Art. 3º, caput, inciso VII** {#art3_cpt_inc7} #definicao Lote: terreno servido de infraestrutura básica cujas dimensões atendam aos índices urbanísticos definidos pelo Plano Diretor Municipal ou Lei Municipal de Uso e Ocupação do Solo Urbano para a zona em que se localize.
- **Art. 3º, caput, inciso VIII** {#art3_cpt_inc8} Loteamento: subdivisão de gleba em lotes destinados à edificação, com abertura de novas vias de circulação de logradouros públicos ou prolongamentos, modificação ou ampliação das vias existentes.
- **Art. 3º, caput, inciso IX** {#art3_cpt_inc9} Parcelamento: divisão de gleba em unidades com vistas à ocupação/edificação, podendo ser realizado na forma de loteamento, condomínio de lotes ou desmembramento.
- **Art. 3º, caput, inciso X** {#art3_cpt_inc10} Relatório Ambiental Preliminar (RAP): estudos relativos aos aspectos ambientais relacionados à localização, instalação e operação de novos empreendimentos habitacionais, incluindo as atividades de infraestrutura, de saneamento básico, viária e energia, apresentados como subsídio para a concessão da licença requerida, que conterá, dentre outras, as informações relativas ao diagnóstico ambiental da região de inserção do empreendimento, sua caracterização, a identificação dos impactos ambientais e das medidas de controle, de mitigação e de compensação, devendo ser elaborado por equipe técnica multidisciplinar.
- **Art. 3º, caput, inciso XI** {#art3_cpt_inc11} #documentacao Relatório de Detalhamento dos Programas Ambientais (RDPA): documento que apresenta, detalhadamente, todas as medidas mitigadoras e compensatórias e os programas ambientais propostos no RAP.

### CAPÍTULO II – DO LICENCIAMENTO AMBIENTAL

#### Seção I – Dos Atos Administrativos

###### Art. 4º {#art4}
Tags: #autorizacao-florestal #documentacao #eia-rima #empreendimento-imobiliario #enquadramento #las #li #licenciamento-ambiental #lo #lp #parcelamento-solo

**Art. 4º, caput** {#art4_cpt} O órgão licenciador, no exercício de sua competência ambiental, expedirá os seguintes atos administrativos, em acordo com o estabelecido na [[resolucao-cema-107-2022|Resolução CEMA 107 de 09 de setembro de 2022]]:
- **Art. 4º, caput, inciso I** {#art4_cpt_inc1} #licenciamento-ambiental Declaração de Inexigibilidade de Licença Ambiental (DILA): concedida para as atividades e empreendimentos dotados de impactos ambiental e socioambiental insignificantes para os quais é inexigível o licenciamento ambiental, respeitadas as legislações municipais;
- **Art. 4º, caput, inciso II** {#art4_cpt_inc2} Autorização Ambiental para Desmembramento: concedida para desmembramentos de imóveis localizados em áreas urbanas, com aproveitamento do sistema viário existente, desde que não implique na abertura de novas vias e logradouros públicos, nem no prolongamento, modificação ou ampliação dos já existentes.
- **Art. 4º, caput, inciso III** {#art4_cpt_inc3} #autorizacao-florestal Autorização Florestal (AF): autoriza a execução de corte ou supressão de vegetação nativa.
- **Art. 4º, caput, inciso IV** {#art4_cpt_inc4} #eia-rima Licença Ambiental por Adesão e Compromisso (LAC): autoriza a instalação e a operação de atividade ou empreendimento, de pequeno potencial de impacto ambiental, mediante declaração de adesão e compromisso do empreendedor aos critérios, pré-condições, requisitos e condicionantes ambientais estabelecidos pela autoridade licenciadora, desde que se conheçam previamente os impactos ambientais da atividade ou empreendimento, as características ambientais da área de implantação e as condições de sua instalação e operação.
- **Art. 4º, caput, inciso V** {#art4_cpt_inc5} #documentacao #enquadramento #las Licença Ambiental Simplificada (LAS): aprova a localização e a concepção do empreendimento, atividade ou obra de pequeno porte e/ou que possuam baixo potencial poluidor/degradador, atestando a viabilidade ambiental, estabelecendo os requisitos básicos e condicionantes a serem atendidos, bem como autoriza sua instalação e operação de acordo com as especificações constantes dos requerimentos, planos, programas e/ou projetos aprovados, incluindo as medidas de controle ambiental e demais condicionantes determinadas pelo órgão licenciador.
- **Art. 4º, caput, inciso VI** {#art4_cpt_inc6} #lp Licença Prévia (LP): concedida na fase preliminar do planejamento do empreendimento ou atividade aprovando sua localização e concepção, atestando a viabilidade ambiental e estabelecendo os requisitos básicos e condicionantes a serem atendidos nas próximas fases de sua implementação.
- **Art. 4º, caput, inciso VII** {#art4_cpt_inc7} #li Licença de Instalação (LI): autoriza a instalação do empreendimento ou atividade de acordo com as especificações constantes dos planos, programas e projetos aprovados, incluindo as medidas de controle ambientais e demais condicionantes, da qual constituem motivos determinantes.
- **Art. 4º, caput, inciso VIII** {#art4_cpt_inc8} #lo Licença de Operação (LO): autoriza a operação da atividade ou empreendimento, após a verificação do efetivo cumprimento do que consta das licenças anteriores, com as medidas de controle ambientais e condicionantes determinados para a operação.
- **Art. 4º, caput, inciso IX** {#art4_cpt_inc9} #licenciamento-ambiental Licenciamento Ambiental de Regularização: licenciamento para empreendimentos ou atividades já implantadas, passíveis de regularização, não eximindo a responsabilidade do empreendedor pelos danos causados.

**Art. 4º, parágrafo único** {#art4_par1u} Os atos administrativos expedidos pelo órgão licenciador são intransferíveis e deverão ser mantidos obrigatoriamente no local do empreendimento, atividade ou obra.

#### Seção II – Da Definição da Modalidade de Licenciamento Ambiental

###### Art. 5º {#art5}
Tags: #empreendimento-imobiliario #parcelamento-solo

**Art. 5º, caput** {#art5_cpt} Para os efeitos desta Resolução, os empreendimentos imobiliários serão licenciados de acordo com a sua finalidade, características da obra, localização do imóvel e outros aspectos de relevância socioambiental, conforme tabela abaixo:

> **Pendência de transcrição — Art. 5, quadro/tabela** {#art5_tab1}. Conteúdo preservado na extração textual que acompanha o lote; falta conferência visual das colunas. Não é texto normativo transcrito.


#### Seção III – Da DocumentaÇão para o Licenciamento Ambiental

##### Subseção I – Da Declaração de Inexigibilidade de Licença Ambiental – DILA

###### Art. 6º {#art6}
Tags: #empreendimento-imobiliario #parcelamento-solo

**Art. 6º, caput** {#art6_cpt} A Declaração de Inexigibilidade de Licença Ambiental – DILA, se necessário, deverá ser requerida através do SGA.

###### Art. 7º {#art7}
Tags: #empreendimento-imobiliario #licenciamento-ambiental #parcelamento-solo

**Art. 7º, caput** {#art7_cpt} #licenciamento-ambiental A inexigibilidade do licenciamento ambiental estadual não exime o interessado das exigências legais quanto à preservação do meio ambiente, bem como obtenção de alvarás e atendimento a outras exigências federais e/ou municipais.

##### Subseção II – Da Licença Ambiental por Adesão e Compromisso - LAC

###### Art. 8º {#art8}
Tags: #documentacao #efluente #empreendimento-imobiliario #enquadramento #licenciamento-ambiental #parcelamento-solo #responsavel-tecnico

**Art. 8º, caput** {#art8_cpt} #documentacao Os requerimentos para Licença Ambiental por Adesão e Compromisso - LAC, deverão ser realizados através do SGA, instruídos na forma prevista abaixo:
- **Art. 8º, caput, inciso I** {#art8_cpt_inc1} #documentacao Certidão do Município, declarando expressamente que o local e o tipo de empreendimento ou atividade estão em conformidade com o Plano Diretor Municipal e legislação urbanística básica, ambiental, bem como que atendam as demais exigências legais e administrativas perante o município (Anexo I);
- **Art. 8º, caput, inciso II** {#art8_cpt_inc2} #documentacao #responsavel-tecnico Certidão atualizada da Matrícula ou Transcrição Imobiliária emitida pelo Cartório de Registro de Imóveis ou documento de justa posse em nome do requerente, ou conforme exigências constantes da Seção V, art. 45 a 54 da [[resolucao-cema-107-2020|Resolução CEMA 107/2020]];
- **Art. 8º, caput, inciso III** {#art8_cpt_inc3} Fotocópia da Carteira de Identidade (RG) e do Cadastro de Pessoa Física (CPF), se pessoa física ou Contrato Social ou Ato Constitutivo, se pessoa jurídica, dispensado somente para COHAPAR e Companhias Habitacionais Municipais;
- **Art. 8º, caput, inciso IV** {#art8_cpt_inc4} Prova de publicação de súmula do pedido de Licença Ambiental por Adesão e Compromisso - LAC no Diário Oficial do Estado;
- **Art. 8º, caput, inciso V** {#art8_cpt_inc5} Comprovante de recolhimento da Taxa Ambiental e da taxa de publicação da súmula da expedição de Licença Ambiental por Adesão e Compromisso - LAC no Diário Oficial do Estado.
- **Art. 8º, caput, inciso VI** {#art8_cpt_inc6} Memorial Descritivo do empreendimento, acompanhado de plantas, fotos, imagens de satélite, mapas;
- **Art. 8º, caput, inciso VII** {#art8_cpt_inc7} #documentacao #efluente #enquadramento Carta de viabilidade ou documento equivalente da concessionária de água e esgoto, atestando ou não a existência do sistema e sua viabilidade técnica de suporte ao novo empreendimento;
- **Art. 8º, caput, inciso VIII** {#art8_cpt_inc8} #efluente Em local não dotado de rede de esgoto, o empreendedor deverá apresentar projeto de extensão da rede de coleta interligando à rede pública, sendo obrigatória a apresentação da anuência da concessionária quanto a viabilidade do mesmo;
- **Art. 8º, caput, inciso IX** {#art8_cpt_inc9} #efluente Projeto do sistema de tratamento de esgoto sanitário conforme disposto no Capítulo III, Seção III da presente Resolução, com base nas informações apresentadas no Laudo Geológico Geotécnico, conforme Termo de Referência (Anexo IV), quando o empreendimento não for atendido por rede de esgoto da concessionária;
- **Art. 8º, caput, inciso X** {#art8_cpt_inc10} Anotação de Responsabilidade Técnica dos profissionais elaboradores dos estudos/projetos/laudos/relatórios apresentados e dos responsáveis pela execução do empreendimento, junto aos respectivos conselhos de classe;
- **Art. 8º, caput, inciso XI** {#art8_cpt_inc11} Declaração de verdade das informações prestadas, conforme modelo do Anexo XI;
- **Art. 8º, caput, inciso XII** {#art8_cpt_inc12} #licenciamento-ambiental Declaração do empreendedor pelo Licenciamento por Adesão e Compromisso conforme modelo do Anexo XII;
- **Art. 8º, caput, inciso XIII** {#art8_cpt_inc13} #licenciamento-ambiental #responsavel-tecnico Declaração do Responsável Técnico pelo Licenciamento Por Adesão e Compromisso conforme modelo do Anexo XIII, acompanhada da respectiva Anotação de Responsabilidade Técnica.

**Art. 8º, parágrafo único** {#art8_par1u} A Licença Ambiental por Adesão e Compromisso - LAC contemplada na presente Resolução somente poderá ser emitida após análise técnica do órgão licenciador.

##### Subseção III – Da Licença Ambiental Simplificada – LAS

###### Art. 9º {#art9}
Tags: #app #definicao #documentacao #efluente #eia-rima #empreendimento-imobiliario #enquadramento #las #licenciamento-ambiental #outorga #parcelamento-solo #prazo #residuo-solido #responsavel-tecnico

**Art. 9º, caput** {#art9_cpt} #documentacao #las Os requerimentos para Licença Ambiental Simplificada - LAS, deverão ser realizados através do SGA, instruído na forma prevista abaixo:
- **Art. 9º, caput, inciso I** {#art9_cpt_inc1} Fotocópia da Carteira de Identidade (RG) e do Cadastro de Pessoa Física (CPF), se pessoa física ou Contrato Social ou Ato Constitutivo, se pessoa jurídica, dispensado somente para COHAPAR e Companhias Habitacionais Municipais;
- **Art. 9º, caput, inciso II** {#art9_cpt_inc2} #documentacao #prazo #responsavel-tecnico Certidão atualizada, máximo de 90 dias, da Matrícula ou Transcrição de inteiro teor do imóvel, devidamente averbado como urbano ou de expansão urbana, emitida pelo Cartório de Registro de Imóveis ou documento de justa posse em nome do requerente, ou conforme exigências constantes da Seção V, art.45 a 54 da [[resolucao-cema-107-2020|Resolução CEMA 107/2020]];
- **Art. 9º, caput, inciso III** {#art9_cpt_inc3} #las Prova de publicação de súmula do pedido de Licença Ambiental Simplificada - LAS no Diário Oficial do Estado;
- **Art. 9º, caput, inciso IV** {#art9_cpt_inc4} #las Comprovante de recolhimento da Taxa Ambiental e da taxa de publicação da súmula da expedição de Licença Ambiental Simplificada - LAS no Diário Oficial do Estado;
- **Art. 9º, caput, inciso V** {#art9_cpt_inc5} #documentacao Certidão Negativa de débitos ambientais emitida pelo órgão licenciador;
- **Art. 9º, caput, inciso VI** {#art9_cpt_inc6} #documentacao Certidão do município ou documento equivalente, declarando expressamente que o local e o tipo de empreendimento estão em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano, com a legislação municipal do meio ambiente, inclusive com relação ao entorno de unidades de conservação municipais, e que atende as demais exigências legais e administrativas perante o município (Anexo I);
- **Art. 9º, caput, inciso VII** {#art9_cpt_inc7} Consulta prévia da Coordenação da Região Metropolitana de Curitiba - COMEC, com os parâmetros de ocupação do solo, localização da área e zoneamento dos imóveis inseridos na Região Metropolitana de Curitiba.
- **Art. 9º, caput, inciso VIII** {#art9_cpt_inc8} Nas demais regiões metropolitanas, a Consulta Prévia somente deverá ser exigida quando as Coordenações estiverem em funcionamento e com procedimentos regulamentados;
- **Art. 9º, caput, inciso IX** {#art9_cpt_inc9} #documentacao Carta de viabilidade ou documento equivalente da concessionária de energia elétrica;
- **Art. 9º, caput, inciso X** {#art9_cpt_inc10} #documentacao #efluente Carta de viabilidade ou documento equivalente da concessionária de água e esgoto;
- **Art. 9º, caput, inciso XI** {#art9_cpt_inc11} Relatório Técnico contendo os seguintes itens:
  - **Art. 9º, caput, inciso XI, alínea "a"** {#art9_cpt_inc11_alia} Relatório fotográfico contendo no mínimo 10 fotografias, com vários ângulos do terreno;
  - **Art. 9º, caput, inciso XI, alínea "b"** {#art9_cpt_inc11_alib} #app Projeto de Implantação Urbanística do empreendimento, com estatística, contendo situação e localização, contemplando altimetria, coordenadas geográficas UTM, áreas de preservação permanente e área verde urbana, aprovado pelo município;
  - **Art. 9º, caput, inciso XI, alínea "c"** {#art9_cpt_inc11_alic} #app Projeto Planialtimétrico, com coordenadas geográficas UTM contendo curvas de nível, formato e medidas dos lotes, áreas de vegetação, áreas de preservação permanente;
  - **Art. 9º, caput, inciso XI, alínea "d"** {#art9_cpt_inc11_alid} Projeto Básico de Terraplanagem conforme Termo de Referência (Anexo III);
  - **Art. 9º, caput, inciso XI, alínea "e"** {#art9_cpt_inc11_alie} Laudo Geológico-Geotécnico conforme Termo de Referência (Anexo IV);
  - **Art. 9º, caput, inciso XI, alínea "f"** {#art9_cpt_inc11_alif} #residuo-solido Projeto de Gerenciamento de Resíduos da Construção Civil - PGRCC, quando o empreendimento possuir mais de 3.000 m² de área construída e/ou 600 m² de demolição, conforme Termo de Referência (Anexo IX), observada a [[resolucao-conama-307-2002|Resolução CONAMA 307/2002]];
  - **Art. 9º, caput, inciso XI, alínea "g"** {#art9_cpt_inc11_alig} Projeto de Drenagem Superficial, conforme Termo de Referência (Anexo VI).
  - **Art. 9º, caput, inciso XI, alínea "h"** {#art9_cpt_inc11_alih} #eia-rima Para empreendimentos com área acima de 3.000 m² de impermeabilização, o projeto de drenagem superficial deve contemplar caixas/bacias de contenção, visando evitar cheias a jusante do local, não se aplicando para loteamentos com finalidade habitacional.
  - **Art. 9º, caput, inciso XI, alínea "i"** {#art9_cpt_inc11_alii} Os condomínios horizontais/verticais e os conjuntos habitacionais deverão prever sistema de captação para aproveitamento de água da chuva de acordo com requisitos estabelecidos pela Norma NBR 15.527, bem como o projeto de concepção estabelecido pelas Normas: NBR 5626 e NBR 10.844.
- **Art. 9º, caput, inciso XII** {#art9_cpt_inc12} Anotação de Responsabilidade Técnica dos profissionais elaboradores dos estudos/projetos/laudos/relatórios apresentados e dos responsáveis pela execução do empreendimento, junto aos respectivos conselhos de classe;
- **Art. 9º, caput, inciso XIII** {#art9_cpt_inc13} #documentacao Quando aplicável, apresentar os seguintes documentos:
  - **Art. 9º, caput, inciso XIII, alínea "a"** {#art9_cpt_inc13_alia} #outorga Outorga prévia de uso/lançamento de recursos hídricos, emitida pelo órgão competente, quando for o caso de: poços artesianos e/ou canalização de corpo hídrico;
  - **Art. 9º, caput, inciso XIII, alínea "b"** {#art9_cpt_inc13_alib} #outorga Para lançamento de águas pluviais em galerias ou corpos hídricos, está dispensada a outorga conforme Portaria 46/2015, do Instituto das Águas do Paraná;
  - **Art. 9º, caput, inciso XIII, alínea "c"** {#art9_cpt_inc13_alic} #outorga A Outorga de Direito deverá ser apresentada ao órgão licenciador antes do início da ocupação do empreendimento, devendo esta condicionante constar no corpo da LAS;
  - **Art. 9º, caput, inciso XIII, alínea "d"** {#art9_cpt_inc13_alid} Projeto de extensão da rede de coleta interligando à rede pública, sendo obrigatória a apresentação da anuência da concessionária quanto a viabilidade do mesmo;
  - **Art. 9º, caput, inciso XIII, alínea "e"** {#art9_cpt_inc13_alie} Manifestação da Diretoria de Saneamento Ambiental e Recursos Hídricos (IAT) informando a cota de inundação e o período de recorrência, para empreendimentos localizados em áreas sujeitas a possíveis inundações/alagamentos.
  - **Art. 9º, caput, inciso XIII, alínea "f"** {#art9_cpt_inc13_alif} Anuência Prévia da Curadoria do Patrimônio Histórico e Artístico da Secretaria de Estado da Cultura em se tratando de empreendimentos localizados em áreas tombadas;
  - **Art. 9º, caput, inciso XIII, alínea "g"** {#art9_cpt_inc13_alig} #definicao Manifestação do Instituto do Patrimônio Histórico e Artístico Nacional-IPHAN, conforme estabelecido na Instrução Normativa IPHAN nº 001, de 25 de março de 2015, observando as definições estabelecidas nos Anexos I e II da mesma;
  - **Art. 9º, caput, inciso XIII, alínea "h"** {#art9_cpt_inc13_alih} Anuência Prévia do ICMBio quando o empreendimento se situar no interior ou na zona de amortecimento de Unidade de Conservação Federal, de acordo com o estabelecido na [[resolucao-conama-428-2010|Resolução CONAMA nº 428, de 17 de dezembro de 2010]], e alterações posteriores, devendo essa anuência ser solicitada pelo órgão licenciador;
  - **Art. 9º, caput, inciso XIII, alínea "i"** {#art9_cpt_inc13_alii} #licenciamento-ambiental Quando o empreendimento se situar no interior ou na zona de amortecimento de Unidade de Conservação Estadual, o procedimento de licenciamento deverá ser remetido ao setor competente do órgão estadual licenciador para manifestação;
  - **Art. 9º, caput, inciso XIII, alínea "j"** {#art9_cpt_inc13_alij} #documentacao Documento de aprovação do Estudo de Impacto de Vizinhança - EIV, emitido pelo município, somente para os casos em que seja uma exigência municipal para aprovação do empreendimento;
  - **Art. 9º, caput, inciso XIII, alínea "k"** {#art9_cpt_inc13_alik} #enquadramento Manifestação/anuência do Departamento de Estradas de Rodagem - DER ou Departamento Nacional de Infraestrutura de Transportes - DNIT ou concessionária de rodovias, para empreendimentos marginais às rodovias ou situados a menos de cem metros do eixo de rodovia estadual, tendo em vista questões de acesso e vias marginais.
- **Art. 9º, caput, inciso XIV** {#art9_cpt_inc14} #licenciamento-ambiental Quando da emissão da LAS, deverá o órgão licenciador carimbar e vistar a planta final de implantação urbanística com estatística aprovada no procedimento de licenciamento, constando o número da LAS e do protocolo do procedimento de licenciamento.

##### Subseção IV – Das Licenças Prévia - LP, de Instalação - LI e de Operação - LO

###### Art. 10 {#art10}
Tags: #definicao #documentacao #efluente #eia-rima #empreendimento-imobiliario #enquadramento #licenciamento-ambiental #lp #outorga #parcelamento-solo #prazo #responsavel-tecnico

**Art. 10, caput** {#art10_cpt} #documentacao #lp Os requerimentos para Licença Prévia - LP, deverão ser realizados através do SGA, instruídos na forma prevista abaixo:
- **Art. 10, caput, inciso I** {#art10_cpt_inc1} Fotocópia da Carteira de Identidade (RG) e do Cadastro de Pessoa Física (CPF), se pessoa física ou Contrato Social ou Ato Constitutivo, se pessoa jurídica, dispensado somente para COHAPAR e Companhias Habitacionais Municipais;
- **Art. 10, caput, inciso II** {#art10_cpt_inc2} #documentacao #prazo #responsavel-tecnico Certidão atualizada, máximo de 90 dias, da Matrícula ou Transcrição Imobiliária emitida pelo Cartório de Registro de Imóveis ou documento de justa posse, ou conforme exigências constantes da Seção V, art.45 a 54 da [[resolucao-cema-107-2020|Resolução CEMA 107/2020]]. Caso o imóvel seja locado, apresentar o contrato de locação;
- **Art. 10, caput, inciso III** {#art10_cpt_inc3} #documentacao Documentação complementar do imóvel, se situação imobiliária estiver irregular ou comprometida, conforme exigências para casos imobiliários excepcionais. No caso de requerimento em nome de terceiros, apresentar procuração (conforme Instrução Normativa IAT/ATJ nº 10/2020);
- **Art. 10, caput, inciso IV** {#art10_cpt_inc4} #lp Prova de publicação de súmula do pedido de Licença Prévia - LP no Diário Oficial do Estado;
- **Art. 10, caput, inciso V** {#art10_cpt_inc5} #lp Comprovante de recolhimento da Taxa Ambiental e da taxa de publicação da súmula da expedição de Licença Prévia – LP no Diário Oficial do Estado;
- **Art. 10, caput, inciso VI** {#art10_cpt_inc6} #documentacao Certidão Negativa de débitos ambientais emitida pelo órgão licenciador;
- **Art. 10, caput, inciso VII** {#art10_cpt_inc7} #documentacao Certidão do município, declarando expressamente que o local e o tipo de empreendimento está em conformidade com a legislação do Plano Diretor Municipal ou Lei Municipal de Uso e Ocupação do Solo Urbano, com a legislação municipal do meio ambiente, inclusive com relação ao entorno de Unidades de Conservação Municipais, e que atendem as demais exigências legais e administrativas perante o município (Anexo I);
- **Art. 10, caput, inciso VIII** {#art10_cpt_inc8} Consulta prévia da Coordenação da Região Metropolitana de Curitiba - COMEC, com os parâmetros de ocupação do solo, localização da área e zoneamento dos imóveis inseridos na Região Metropolitana de Curitiba;
- **Art. 10, caput, inciso IX** {#art10_cpt_inc9} Nas demais regiões metropolitanas, a Consulta Prévia deverá ser emitida conforme parâmetros de uso e ocupação do solo legalmente estabelecidos;
- **Art. 10, caput, inciso X** {#art10_cpt_inc10} #eia-rima #enquadramento Relatório Ambiental Preliminar - RAP, conforme Termo de Referência (Anexo VII), ou Estudo Prévio de Impacto Ambiental e o respectivo Relatório de Impacto Ambiental-EIA/RIMA, dependendo do porte do empreendimento;
- **Art. 10, caput, inciso XI** {#art10_cpt_inc11} Laudo Geológico-Geotécnico conforme Termo de Referência (Anexo IV);
- **Art. 10, caput, inciso XII** {#art10_cpt_inc12} #documentacao Carta de viabilidade ou documento equivalente da concessionária de energia elétrica;
- **Art. 10, caput, inciso XIII** {#art10_cpt_inc13} #documentacao #efluente #enquadramento Carta de viabilidade ou documento equivalente da concessionária de água e esgoto, atestando ou não a existência do sistema e sua viabilidade técnica de suporte ao novo empreendimento;
- **Art. 10, caput, inciso XIV** {#art10_cpt_inc14} #efluente Em local não dotado de rede de esgoto, o empreendedor deverá apresentar projeto de extensão da rede de coleta interligando à rede pública, sendo obrigatória a apresentação da anuência da concessionária quanto a viabilidade do mesmo;
- **Art. 10, caput, inciso XV** {#art10_cpt_inc15} #efluente Quando não existir viabilidade para atendimento do empreendimento através de rede coletora de esgoto da concessionária, deverão ser implantadas tecnologias viáveis e seguras de tratamento, sejam individuais ou coletivas, com base nas informações apresentadas no Laudo Geológico Geotécnico, conforme Termo de Referência (Anexo IV) e de acordo com o disposto nas NBR 7.229/1993 e 13.969/1997;
- **Art. 10, caput, inciso XVI** {#art10_cpt_inc16} Anotação de Responsabilidade Técnica dos profissionais elaboradores dos estudos/projetos/laudos/relatórios apresentados e dos responsáveis pela execução do empreendimento, junto aos respectivos conselhos de classe.
- **Art. 10, caput, inciso XVII** {#art10_cpt_inc17} #documentacao Quando aplicável, apresentar os seguintes documentos:
  - **Art. 10, caput, inciso XVII, alínea "a"** {#art10_cpt_inc17_alia} Anuência Prévia emitida pelo órgão competente para captação de água em poços;
  - **Art. 10, caput, inciso XVII, alínea "b"** {#art10_cpt_inc17_alib} #efluente #outorga Outorga Prévia para captação de água em corpos hídricos superficiais/lançamento de recursos hídricos, emitida pelo órgão competente nas seguintes situações: canalização de corpo hídrico e lançamento de efluentes líquidos tratados em corpo hídrico ou galeria de águas pluviais;
  - **Art. 10, caput, inciso XVII, alínea "c"** {#art10_cpt_inc17_alic} #efluente Para lançamento de efluentes líquidos tratados na galeria de águas pluviais apresentar também anuência do município;
  - **Art. 10, caput, inciso XVII, alínea "d"** {#art10_cpt_inc17_alid} #outorga Para lançamento de águas pluviais em galerias ou corpos hídricos, poderá ser dispensada a outorga conforme normativos do órgão competente;
  - **Art. 10, caput, inciso XVII, alínea "e"** {#art10_cpt_inc17_alie} Manifestação da Diretoria de Saneamento Ambiental e Recursos Hídricos (IAT) informando a cota de inundação e o período de recorrência, para empreendimentos localizados em áreas sujeitas a possíveis inundações/alagamentos.
  - **Art. 10, caput, inciso XVII, alínea "f"** {#art10_cpt_inc17_alif} Anuência Prévia ou manifestação da Curadoria do Patrimônio Histórico e Artístico da Secretaria de Estado da Cultura em se tratando de empreendimentos localizados em áreas tombadas;
  - **Art. 10, caput, inciso XVII, alínea "g"** {#art10_cpt_inc17_alig} #definicao Manifestação do Instituto do Patrimônio Histórico e Artístico Nacional-IPHAN, conforme estabelecido na Instrução Normativa IPHAN nº 001, de 25 de março de 2015, observando as definições estabelecidas nos Anexos da mesma.
  - **Art. 10, caput, inciso XVII, alínea "h"** {#art10_cpt_inc17_alih} Anuência Prévia ou manifestação do ICMBio quando o empreendimento se situar no interior ou na Zona de Amortecimento de Unidade de Conservação Federal, de acordo com o estabelecido na [[resolucao-conama-428-2010|Resolução CONAMA nº 428, de 17 de dezembro de 2010]];
  - **Art. 10, caput, inciso XVII, alínea "i"** {#art10_cpt_inc17_alii} #licenciamento-ambiental Quando o empreendimento se situar na zona de amortecimento de Unidade de Conservação Estadual, o procedimento de licenciamento deverá ser remetido à diretoria competente do órgão estadual gestor da unidade, para manifestação;
  - **Art. 10, caput, inciso XVII, alínea "j"** {#art10_cpt_inc17_alij} Anuência Prévia ou manifestação do Departamento de Estradas de Rodagem-DER ou concessionária de rodovias, para empreendimentos marginais às rodovias ou situados a menos de cem metros do eixo de rodovia estadual, tendo em vista questões de acesso e vias marginais.

###### Art. 11 {#art11}
Tags: #empreendimento-imobiliario #licenciamento-ambiental #lp #parcelamento-solo

**Art. 11, caput** {#art11_cpt} #licenciamento-ambiental #lp Nos procedimentos de Licença Prévia - LP, quando necessária a supressão de vegetação, deverá obrigatoriamente ser solicitada a avaliação da tipologia florestal, visando análise integrada do licenciamento.

**Art. 11, § 1º** {#art11_par1} Na hipótese prevista no caput, deverá ser apresentado o Relatório de Caracterização da vegetação, de acordo com a [[resolucao-conama-2-1994|Resolução CONAMA 02/1994]], no próprio procedimento administrativo.

**Art. 11, § 2º** {#art11_par2} A LP somente poderá ser emitida após manifestação expressa sobre a tipologia florestal e sua viabilidade de supressão.

###### Art. 12 {#art12}
Tags: #autorizacao-florestal #empreendimento-imobiliario #parcelamento-solo

**Art. 12, caput** {#art12_cpt} #autorizacao-florestal Quando aplicável, para o pedido de Autorização Florestal em procedimento próprio, deverá ser apresentado o Laudo Florestal, conforme Termo de Referência (Anexo V).

###### Art. 13 {#art13}
Tags: #app #documentacao #efluente #eia-rima #empreendimento-imobiliario #li #licenciamento-ambiental #lp #outorga #parcelamento-solo #prazo #residuo-solido

**Art. 13, caput** {#art13_cpt} #documentacao #li Os requerimentos para LICENÇA DE INSTALAÇÃO - LI, deverão ser realizados através do SGA, instruído na forma prevista abaixo:
- **Art. 13, caput, inciso I** {#art13_cpt_inc1} #documentacao #lp Fotocópia da Carteira de Identidade (RG) e do Cadastro de Pessoa Física (CPF), se pessoa física ou Contrato Social ou Ato Constitutivo, se pessoa jurídica, dispensado para COHAPAR e Companhias Habitacionais Municipais, caso haja alteração das informações da documentação apresentada na Licença Prévia;
- **Art. 13, caput, inciso II** {#art13_cpt_inc2} #documentacao #prazo Matrícula ou transcrição de inteiro teor do imóvel, devidamente averbado como urbano ou de expansão urbana; emitida pelo Cartório de Registro de Imóveis atualizada, máximo de 90 dias, em nome do requerente;
- **Art. 13, caput, inciso III** {#art13_cpt_inc3} #lp Cópia da Licença Prévia;
- **Art. 13, caput, inciso IV** {#art13_cpt_inc4} #li Prova de publicação de súmula do pedido de Licença de Instalação - LI no Diário Oficial do Estado;
- **Art. 13, caput, inciso V** {#art13_cpt_inc5} #li Comprovante de recolhimento da Taxa Ambiental e da taxa de publicação da súmula da expedição de Licença de Instalação - LI no Diário Oficial do Estado;
- **Art. 13, caput, inciso VI** {#art13_cpt_inc6} #efluente #outorga Outorga prévia de uso/lançamento de recursos hídricos, emitida pelo órgão competente nas seguintes situações: poços artesianos, canalização de corpo hídrico e lançamento de efluentes líquidos tratados em corpo hídrico ou galeria de águas pluviais;
- **Art. 13, caput, inciso VII** {#art13_cpt_inc7} Relatório de Detalhamento dos Programas Ambientais (RDPA) conforme Termo de Referência (Anexo VIII);
- **Art. 13, caput, inciso VIII** {#art13_cpt_inc8} #residuo-solido Projeto de Gerenciamento de Resíduos da Construção Civil - PGRCC, quando o empreendimento possuir mais de 3.000 m² de área construída e/ou 600 m² de demolição, conforme Termo de Referência (Anexo IX) e [[resolucao-conama-307-2002|Resolução CONAMA 307/2002]];
- **Art. 13, caput, inciso IX** {#art13_cpt_inc9} #app Projeto de Implantação Urbanística do empreendimento, com estatística, contendo situação e localização, contemplando altimetria, coordenadas geográficas UTM, áreas de preservação permanente e área verde urbana, aprovado pelo município.
- **Art. 13, caput, inciso X** {#art13_cpt_inc10} Projeto de Drenagem Superficial, conforme Termo de Referência (Anexo VI).
- **Art. 13, caput, inciso XI** {#art13_cpt_inc11} #eia-rima Para empreendimentos com área acima de 3.000 m² de impermeabilização, o projeto de drenagem superficial deve contemplar caixas/bacias de contenção, visando evitar cheias a jusante do local, não se aplicando para loteamentos com finalidade habitacional.
- **Art. 13, caput, inciso XII** {#art13_cpt_inc12} Os condomínios horizontais/verticais e os conjuntos habitacionais deverão prever sistema de captação para aproveitamento e de água da chuva de acordo com requisitos estabelecidos pela Norma NBR 15.527, bem como o projeto de concepção estabelecido pelas Normas: NBR 5626 e NBR 10.844.
- **Art. 13, caput, inciso XIII** {#art13_cpt_inc13} Projeto Básico de Terraplanagem conforme Termo de Referência (Anexo III);
- **Art. 13, caput, inciso XIV** {#art13_cpt_inc14} Anotação de Responsabilidade Técnica dos profissionais elaboradores dos estudos/projetos/laudos/relatórios apresentados e dos responsáveis pela execução do empreendimento, junto aos respectivos conselhos de classe;
- **Art. 13, caput, inciso XV** {#art13_cpt_inc15} #li #licenciamento-ambiental Quando da emissão da Licença de Instalação deverá o órgão licenciador carimbar e vistar a planta final de implantação urbanística com estatística, aprovada no procedimento de licenciamento, constando o número da Licença de Instalação e do protocolo do procedimento de licenciamento.

###### Art. 14 {#art14}
Tags: #empreendimento-imobiliario #enquadramento #lo #parcelamento-solo

**Art. 14, caput** {#art14_cpt} #enquadramento #lo Em função das características, porte e/ou localização do empreendimento imobiliário, será exigida pelo órgão ambiental licenciador a LICENÇA DE OPERAÇÃO.

###### Art. 15 {#art15}
Tags: #documentacao #efluente #empreendimento-imobiliario #li #lo #outorga #parcelamento-solo #residuo-solido

**Art. 15, caput** {#art15_cpt} #documentacao #lo Os requerimentos para LICENÇA DE OPERAÇÃO - LO, deverão ser realizados através do SGA, instruído na forma prevista abaixo:
- **Art. 15, caput, inciso I** {#art15_cpt_inc1} #li Cópia da Licença de Instalação;
- **Art. 15, caput, inciso II** {#art15_cpt_inc2} #lo Prova de publicação de súmula do pedido de Licença de Operação - LO no Diário Oficial do Estado;
- **Art. 15, caput, inciso III** {#art15_cpt_inc3} #lo Comprovante de recolhimento da Taxa Ambiental e da taxa de publicação da súmula da expedição de Licença de Operação - LO no Diário Oficial do Estado.
- **Art. 15, caput, inciso IV** {#art15_cpt_inc4} #documentacao #efluente Laudo de vistoria de ligação de esgoto ou documento equivalente, emitido pela concessionária, atestando a efetiva interligação da rede interna de esgotamento sanitário do empreendimento à rede de esgoto externa;
- **Art. 15, caput, inciso V** {#art15_cpt_inc5} #li Relatório sobre a implantação de medidas de controle previstas nos estudos ambientais apresentados e nos condicionantes da Licença de Instalação;
- **Art. 15, caput, inciso VI** {#art15_cpt_inc6} #efluente #outorga Portaria de Outorga de Direito, emitida pelo órgão competente, para lançamento de efluentes líquidos tratados em corpo hídrico ou galeria de águas pluviais, quando não servido por rede de esgoto da concessionária;
- **Art. 15, caput, inciso VII** {#art15_cpt_inc7} #residuo-solido Relatório de Gerenciamento de Resíduos da Construção Civil conforme Termo de Referência (Anexo XI);
- **Art. 15, caput, inciso VIII** {#art15_cpt_inc8} Anotação de Responsabilidade Técnica dos profissionais elaboradores dos estudos/projetos/laudos/relatórios apresentados e dos responsáveis pela execução do empreendimento, junto aos respectivos conselhos de classe.

##### Subseção V – Autorização Ambiental para Desmembramento em Área Urbana

###### Art. 16 {#art16}
Tags: #app #documentacao #efluente #empreendimento-imobiliario #enquadramento #licenciamento-ambiental #parcelamento-solo #prazo

**Art. 16, caput** {#art16_cpt} #documentacao Os requerimentos para Autorização Ambiental para Desmembramento deverão ser realizados através do sistema informatizado do IAT, instruído na forma prevista abaixo:
- **Art. 16, caput, inciso I** {#art16_cpt_inc1} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental-RLA;
- **Art. 16, caput, inciso II** {#art16_cpt_inc2} Cadastro de Empreendimento Imobiliário-CIM;
- **Art. 16, caput, inciso III** {#art16_cpt_inc3} Fotocópia da Carteira de Identidade (RG) e do Cadastro de Pessoa Física (CPF), se pessoa física ou Contrato Social ou Ato Constitutivo, se pessoa jurídica, dispensado somente para COHAPAR e Companhias Habitacionais Municipais;
- **Art. 16, caput, inciso IV** {#art16_cpt_inc4} Comprovante de recolhimento da Taxa Ambiental e da taxa de publicação da súmula da expedição de Autorização Ambiental - AA no Diário Oficial do Estado;
- **Art. 16, caput, inciso V** {#art16_cpt_inc5} #documentacao Certidão do município ou documento equivalente, declarando expressamente que o desmembramento pretendido está em área urbana devidamente parcelada e em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano (Anexo I);
- **Art. 16, caput, inciso VI** {#art16_cpt_inc6} Consulta prévia da Coordenação da Região Metropolitana de Curitiba - COMEC, com os parâmetros de ocupação do solo, localização da área e zoneamento dos imóveis inseridos na Região Metropolitana de Curitiba;
- **Art. 16, caput, inciso VII** {#art16_cpt_inc7} #documentacao #prazo Matrícula ou transcrição de inteiro teor do imóvel devidamente averbado como urbano ou de expansão urbana, emitida pelo Cartório de Registro de Imóveis atualizada, máximo de 90 dias, em nome do requerente, ou caso a matrícula ou transcrição esteja em nome de terceiros, anexar escritura pública de compra e venda;
- **Art. 16, caput, inciso VIII** {#art16_cpt_inc8} #documentacao Documentação complementar do imóvel se a situação imobiliária estiver irregular ou comprometida, conforme exigências para casos imobiliários excepcionais, conforme [[resolucao-cema-107-2020|Resolução CEMA 107/2020]] ou outra que vier a substituí-la;
- **Art. 16, caput, inciso IX** {#art16_cpt_inc9} #documentacao #efluente #enquadramento Carta de viabilidade ou documento equivalente da concessionária de água e esgoto, atestando ou não a existência do sistema e sua viabilidade técnica de suporte aos imóveis;
- **Art. 16, caput, inciso X** {#art16_cpt_inc10} #efluente Projeto do sistema de tratamento de esgoto sanitário conforme disposto no Capítulo III, Seção III da presente Resolução, com base nas informações apresentadas no Laudo Geológico Geotécnico, conforme Termo de Referência (Anexo IV), quando o empreendimento não for atendido por rede de esgoto da concessionária;
- **Art. 16, caput, inciso XI** {#art16_cpt_inc11} Relatório fotográfico contendo no mínimo 10 fotografias, com vários ângulos do terreno;
- **Art. 16, caput, inciso XII** {#art16_cpt_inc12} Planta planialtimétrica contendo as seguintes demarcações:
  - **Art. 16, caput, inciso XII, alínea "a"** {#art16_cpt_inc12_alia} Curvas de nível;
  - **Art. 16, caput, inciso XII, alínea "b"** {#art16_cpt_inc12_alib} Áreas de vegetação nativa (se houver), averbada/registrada ou não, devendo a tipologia florestal existente ser avaliada para fins de futura ocupação;
  - **Art. 16, caput, inciso XII, alínea "c"** {#art16_cpt_inc12_alic} #app Corpos hídricos (se houver) e área de preservação permanente, devendo este fato ser avaliado para fins de futura ocupação;
  - **Art. 16, caput, inciso XII, alínea "d"** {#art16_cpt_inc12_alid} Indicação do sistema viário que faz divisa com o imóvel a ser desmembrado, envolvendo todo seu entorno e indicação das ocupações próximas;
  - **Art. 16, caput, inciso XII, alínea "e"** {#art16_cpt_inc12_alie} Situação atual do imóvel e indicação da situação pretendida após o desmembramento, com legenda/estatística;
  - **Art. 16, caput, inciso XII, alínea "f"** {#art16_cpt_inc12_alif} Coordenadas geográficas ou UTM e indicação do DATUM horizontal de todo o polígono;
  - **Art. 16, caput, inciso XII, alínea "g"** {#art16_cpt_inc12_alig} A planta deverá ser assinada pelo proprietário do imóvel e pelo técnico responsável devidamente habilitado pelo conselho de classe.
- **Art. 16, caput, inciso XIII** {#art16_cpt_inc13} Anotação de Responsabilidade Técnica dos profissionais elaboradores dos estudos/projetos/laudos/relatórios apresentados, junto aos respectivos conselhos de classe.

**Art. 16, parágrafo único** {#art16_par1u} Após aprovação do município, autorização do órgão licenciador e anuência da COMEC (quando o empreendimento se localizar na Região Metropolitana de Curitiba), a planta com a situação final do desmembramento, devidamente carimbada e vistada pelo órgão licenciador, poderá ser submetida ao Registro de Imóveis.

##### Subseção VI – Da Regularização do Licenciamento Ambiental

###### Art. 17 {#art17}
Tags: #empreendimento-imobiliario #licenciamento-ambiental #parcelamento-solo #responsavel-tecnico

**Art. 17, caput** {#art17_cpt} #licenciamento-ambiental #responsavel-tecnico Os empreendimentos sem licenciamento ambiental, antes da edição desta resolução, poderão se regularizar, por meio de solicitação da respectiva licença de acordo com o enquadramento do Art.5º da presente Resolução.

#### Seção IV – Dos Estudos Ambientais

###### Art. 18 {#art18}
Tags: #eia-rima #empreendimento-imobiliario #li #licenciamento-ambiental #lp #parcelamento-solo

**Art. 18, caput** {#art18_cpt} #licenciamento-ambiental Os estudos ambientais serão exigidos no licenciamento ambiental de empreendimentos imobiliários cujas características não os enquadre em LAC e LAS de acordo com o seguinte:
- **Art. 18, caput, inciso I** {#art18_cpt_inc1} Para empreendimentos imobiliários com área até 100,0 ha:
  - **Art. 18, caput, inciso I, alínea "a"** {#art18_cpt_inc1_alia} #lp para a Licença Prévia: Relatório Ambiental Preliminar - RAP, conforme Termo de Referência (Anexo VII);
  - **Art. 18, caput, inciso I, alínea "b"** {#art18_cpt_inc1_alib} #li para a Licença de Instalação o Relatório de Detalhamento dos Programas Ambientais - RDPA, conforme Termo de Referência (Anexo VIII).
- **Art. 18, caput, inciso II** {#art18_cpt_inc2} #eia-rima #lp Para empreendimentos imobiliários com área acima de 100,0 ha, de acordo com o previsto na [[resolucao-conama-1-1986|Resolução CONAMA 001/1986]] e [[resolucao-cema-107-2020|Resolução CEMA 107/2020]] artigo [[#art9|9]], incisos XXIIIV e XXIV, ou outra a que vier a substituí-la, será exigida antes da emissão da Licença Prévia a apresentação de Estudo de Impacto Ambiental - EIA e respectivo Relatório de Impacto Ambiental - RIMA, conforme Termo de Referência a ser fornecido pelo órgão licenciador.

###### Art. 19 {#art19}
Tags: #empreendimento-imobiliario #licenciamento-ambiental #outorga #parcelamento-solo

**Art. 19, caput** {#art19_cpt} #licenciamento-ambiental #outorga No caso de imóveis com área entre 50 e 100 ha, a análise deverá ser executada por equipe multidisciplinar instituída pela Diretoria de Licenciamento e Outorga, com no mínimo 03 (três) participantes. Constituída por profissionais com habilitação técnica compatível com o empreendimento.

#### Seção V – Dos prazos de Validade das Licenças

###### Art. 20 {#art20}
Tags: #documentacao #empreendimento-imobiliario #las #li #licenciamento-ambiental #lo #lp #parcelamento-solo #prazo #renovacao

**Art. 20, caput** {#art20_cpt} #documentacao #prazo O órgão ambiental competente estabelecerá os prazos de validade para cada tipo de licença e autorização ambiental, especificando-os no respectivo documento, levando em consideração os seguintes aspectos:
- **Art. 20, caput, inciso I** {#art20_cpt_inc1} #licenciamento-ambiental #prazo A Declaração de Inexigibilidade de Licenciamento Ambiental – DILA não tem prazo de validade;
- **Art. 20, caput, inciso II** {#art20_cpt_inc2} #prazo O prazo de validade da Licença por Adesão e Compromisso - LAC:
- **Art. 20, caput, inciso III** {#art20_cpt_inc3} #prazo 02 (dois) anos para a primeira licença. Renovável;
- **Art. 20, caput, inciso IV** {#art20_cpt_inc4} #prazo #renovacao 05 (cinco) anos a partir da primeira renovação.
- **Art. 20, caput, inciso V** {#art20_cpt_inc5} #las #prazo #renovacao O prazo de validade da Licença Ambiental Simplificada - LAS será de até 10 (dez) anos, podendo ser renovada a critério técnico do órgão ambiental competente;
- **Art. 20, caput, inciso VI** {#art20_cpt_inc6} #lp #prazo O prazo de validade da Licença Prévia - LP será de 05 (cinco) anos, não prorrogável se concedido o prazo máximo;
- **Art. 20, caput, inciso VII** {#art20_cpt_inc7} #li #prazo O prazo de validade da Licença de Instalação - LI será de até 06 (seis) anos, não prorrogável se concedido o prazo máximo;
- **Art. 20, caput, inciso VIII** {#art20_cpt_inc8} #lo #prazo O prazo de validade da Licença de Operação - LO será de no mínimo 4 anos e no máximo 10 (dez) anos, renovável a critério do Órgão Licenciador.

**Art. 20, parágrafo único** {#art20_par1u} #renovacao As renovações e prorrogações se aplicam aos empreendimentos que não estejam vinculados aos outros empreendimentos.

### CAPÍTULO III – ASPECTOS GERAIS DE LICENCIAMENTO AMBIENTAL

#### Seção I – Aspectos Técnicos e Legais

###### Art. 21 {#art21}
Tags: #empreendimento-imobiliario #licenciamento-ambiental #parcelamento-solo

**Art. 21, caput** {#art21_cpt} Todas as informações referentes a engenharia e arquitetura deverão ser prestadas por profissional devidamente habilitado, mediante a emissão de Anotação de Responsabilidade Técnica junto ao respectivo conselho de classe, atestando as condicionantes acima especificadas.

**Art. 21, parágrafo único** {#art21_par1u} #licenciamento-ambiental No caso de alteração da razão social ou dos estatutos da empresa, a regularização do licenciamento ambiental deverá ser atendida conforme previsto na [[resolucao-cema-107-2020|Resolução CEMA 107/2020]], ou outra a que vier a substituí-la.

###### Art. 22 {#art22}
Tags: #definicao #empreendimento-imobiliario #parcelamento-solo

**Art. 22, caput** {#art22_cpt} #definicao Somente será admitido o parcelamento do solo para fins urbanos em zonas urbanas, de expansão urbana ou de urbanização específica, assim definidas pelo Plano Diretor Municipal, ou aprovadas por Lei Municipal de Uso e Ocupação do Solo Urbano, não sendo permitido o parcelamento do solo:
- **Art. 22, caput, inciso I** {#art22_cpt_inc1} Em terrenos alagadiços e sujeitos às inundações, antes de tomadas às providências para assegurar o escoamento das águas;
- **Art. 22, caput, inciso II** {#art22_cpt_inc2} Em terrenos que tenham sido aterrados com material nocivo à saúde pública, sem que sejam saneados;
- **Art. 22, caput, inciso III** {#art22_cpt_inc3} Em terrenos com declividade igual ou superior a 30% (trinta por cento), salvo se atendidas exigências específicas das autoridades competentes;
- **Art. 22, caput, inciso IV** {#art22_cpt_inc4} Em terrenos onde as condições geológicas não aconselham a edificação;
- **Art. 22, caput, inciso V** {#art22_cpt_inc5} Em áreas de preservação ecológica ou naquelas onde a poluição impeça condições sanitárias suportáveis, até a sua correção.

###### Art. 23 {#art23}
Tags: #definicao #empreendimento-imobiliario #las #li #licenciamento-ambiental #lp #parcelamento-solo

**Art. 23, caput** {#art23_cpt} #licenciamento-ambiental Para o licenciamento ambiental de novos empreendimentos destinados à construção de habitações de Interesse Social, deverá ser seguido o procedimento estabelecido na [[resolucao-conama-412-2009|Resolução CONAMA nº 412, de 13 de maio de 2009]] e alterações posteriores.

**Art. 23, § 1º** {#art23_par1} #licenciamento-ambiental Dependendo das características do empreendimento e da área, mediante motivação técnica, poderá o órgão ambiental solicitar o licenciamento trifásico.

**Art. 23, § 2º** {#art23_par2} #definicao #las #li #licenciamento-ambiental #lp Os critérios específicos para o Licenciamento Ambiental de empreendimentos habitacionais considerados de interesse social em área urbana, destinados ao atendimento da população definida como de baixa renda, nas modalidades Licença Prévia - LP, Licença de Instalação - LI e Licença Ambiental Simplificada - LAS, estão estabelecidos na [[portaria-iap-216-2018|Portaria IAP n°216/2018]] ou outra que vier a substituí-la.

###### Art. 24 {#art24}
Tags: #empreendimento-imobiliario #parcelamento-solo #prazo

**Art. 24, caput** {#art24_cpt} Nos casos de necessidade de realização de audiências públicas, deverão ser observadas as disposições contidas nas Resoluções do CONAMA nº 09, de 03 de dezembro de 1987 e na [[resolucao-cema-107-2020|Resolução CEMA n.º 107 de 09 de setembro de 2020]].

**Art. 24, parágrafo único** {#art24_par1u} #prazo As reuniões técnicas informativas poderão ocorrer, sempre que o órgão licenciador julgar necessário ou quando solicitado por qualquer interessado, às expensas do empreendedor, com prazos a serem estabelecidos pelo órgão ambiental.

###### Art. 25 {#art25}
Tags: #definicao #documentacao #empreendimento-imobiliario #parcelamento-solo #responsavel-tecnico

**Art. 25, caput** {#art25_cpt} #definicao #responsavel-tecnico A inserção do imóvel rural em perímetro urbano definido mediante lei municipal não desobriga o proprietário ou posseiro da manutenção da área de Reserva Legal, que só será extinta concomitantemente ao registro do parcelamento do solo para fins urbanos aprovado segundo a legislação específica e consoante as diretrizes do plano diretor de que trata o § 1º do Art. 182 da Constituição Federal.

**Art. 25, § 1º** {#art25_par1} O poder público municipal poderá utilizar como instrumento para estabelecer Áreas Verdes Urbanas, a transformação das Reservas Legais de imóveis inseridos nas expansões urbanas, em conformidade com o Plano Diretor e Leis de Zoneamento Urbano e Uso do Solo do Município;

**Art. 25, § 2º** {#art25_par2} #documentacao Para os imóveis tratados no caput deste artigo, deverão constar na matrícula os gravames constando o registro de baixa junto ao INCRA, bem como o ato do poder executivo municipal que inseriu o imóvel em área urbana ou perímetro urbano;

**Art. 25, § 3º** {#art25_par3} Para os imóveis com área inferior a 04 (quatro) módulos fiscais, com ou sem remanescente de vegetação nativa, a Reserva Legal será constituída em conformidade com o estabelecido pelo Plano Diretor do Município ou Lei de Uso e Ocupação do Solo Urbano.

###### Art. 26 {#art26}
Tags: #definicao #empreendimento-imobiliario #licenciamento-ambiental #parcelamento-solo #responsavel-tecnico

**Art. 26, caput** {#art26_cpt} #licenciamento-ambiental #responsavel-tecnico Caso seja constatada e comprovada alguma irregularidade intencional do responsável técnico pela elaboração de um ou mais estudos técnicos previstos nesta Resolução, ou apresentar no procedimento de licenciamento, estudo, laudo ou relatório ambiental, total ou parcialmente falso ou enganoso, inclusive por omissão, denúncia será encaminhada ao respectivo Conselho de Classe para as devidas providências, sendo automaticamente suspenso o trâmite do procedimento de licenciamento ambiental até os devidos esclarecimentos, sem prejuízo das apurações de responsabilidade civil e criminal.

**Art. 26, § 1º** {#art26_par1} #definicao #licenciamento-ambiental Considera-se irregularidade intencional a omissão e/ou distorção de dados relevantes ao licenciamento, inclusive mapas e croquis, que venham a ser verificados pelos técnicos do órgão ambiental licenciador, após análise e vistoria.

**Art. 26, § 2º** {#art26_par2} As situações contempladas acima são passíveis de autuação e demais sanções, conforme Artigo 69-A da [[lei-federal-9605-1998|Lei Federal 9.605, de 12 de fevereiro de 1998]].

###### Art. 27 {#art27}
Tags: #efluente #empreendimento-imobiliario #monitoramento #parcelamento-solo

**Art. 27, caput** {#art27_cpt} #efluente #monitoramento A fiscalização e o monitoramento dos sistemas individuais de tratamento de esgoto serão de responsabilidade do poder público municipal, conforme legislação vigente, podendo ocorrer em parceria com o órgão ambiental licenciador.

#### Seção II – Aspectos Locacionais

###### Art. 28 {#art28}
Tags: #empreendimento-imobiliario #licenciamento-ambiental #parcelamento-solo

**Art. 28, caput** {#art28_cpt} #licenciamento-ambiental Caso o empreendimento se localize em Área de Proteção Ambiental - APA legalmente instituída, o órgão licenciador deverá submeter o procedimento de licenciamento a Câmara de Apoio Técnico - CAT ou similar, da APA, para avaliação e manifestação.

###### Art. 29 {#art29}
Tags: #empreendimento-imobiliario #parcelamento-solo

**Art. 29, caput** {#art29_cpt} A implantação de loteamentos e condomínios em um raio de 500 metros de fontes geradoras de emissões atmosféricas, já licenciadas pelo órgão ambiental, tais como ETE, beneficiamento de grãos, graxarias, entre outras, poderá estar sujeita à condições adicionais para sua execução.

**Art. 29, parágrafo único** {#art29_par1u} #redacao-alterada São exemplos a adoção de medidas mitigatórias quando da instalação do empreendimento em relação às fontes de emissões para diminuição do incômodo gerado aos futuros moradores pelo odor e/ou pela poluição sonora, a promoção de informação ao comprador quanto à presença do empreendimento poluidor nas proximidades do empreendimento, a execução de projeto de implantação urbanística visando maior conforto e bem-estar à população, entre outros”. (NR) *(Redação dada pela Resolução 9 de 27/03/2024)*

#### Seção III – Da Destinação do Esgoto Sanitário

###### Art. 30 {#art30}
Tags: #efluente #empreendimento-imobiliario #parcelamento-solo

**Art. 30, caput** {#art30_cpt} #efluente Quando o local do empreendimento não for atendido por rede de esgoto, o empreendedor deverá buscar alternativas visando a extensão da rede de coleta e sua interligação à rede da concessionária.

###### Art. 31 {#art31}
Tags: #efluente #empreendimento-imobiliario #parcelamento-solo

**Art. 31, caput** {#art31_cpt} #efluente Quando não existir viabilidade para atendimento do empreendimento através de rede coletora de esgoto da concessionária, deverão ser implantadas tecnologias viáveis e seguras de tratamento, sejam individuais ou coletivas, com base nas informações apresentadas no Laudo Geológico Geotécnico, conforme Termo de Referência (Anexo IV).

###### Art. 32 {#art32}
Tags: #agua-subterranea #efluente #empreendimento-imobiliario #parcelamento-solo #proibicao

**Art. 32, caput** {#art32_cpt} #agua-subterranea #efluente #proibicao Não serão permitidos sistemas de infiltração de esgoto sanitário no solo em empreendimentos localizados na área de abrangência do Aquífero Karst (Anexo II).

###### Art. 33 {#art33}
Tags: #agua-subterranea #efluente #empreendimento-imobiliario #parcelamento-solo

**Art. 33, caput** {#art33_cpt} #agua-subterranea #efluente A viabilidade e o dimensionamento dos sistemas individuais de tratamento de esgoto sanitário deverão estar fundamentados nas informações apresentadas no laudo geológico-geotécnico, conforme termo de referência ANEXO IV, com ênfase nos aspectos hidrogeológicos do local, na direção do fluxo da água subterrânea, no nível freático e na taxa de percolação (ensaios de infiltração), observadas as disposições das NBR 7.229/1993 e 13.969/1997.

### CAPÍTULO IV – DAS DISPOSIÇÕES FINAIS E TRANSITÓRIAS

###### Art. 34 {#art34}
Tags: #empreendimento-imobiliario #licenciamento-ambiental #parcelamento-solo

**Art. 34, caput** {#art34_cpt} #licenciamento-ambiental Esta Resolução se aplica aos procedimentos de licenciamento ambientais protocolados junto ao órgão licenciador a partir da data de sua publicação.

###### Art. 35 {#art35}
Tags: #empreendimento-imobiliario #parcelamento-solo

**Art. 35, caput** {#art35_cpt} Esta Resolução entra em vigor na data de sua publicação, ficando revogada a [[resolucao-sedest-68-2019|Resolução SEDEST nº 068/2019]] e [[resolucao-sedest-30-2022|Resolução SEDEST n. º030/2022]]. Everton Luiz da Costa Souza Secretário de Estado do Desenvolvimento Sustentável e do Turismo Este texto não substitui o publicado no Diário Oficial do Estado ANEXOS: Arquivo                            Observações anexo271349_64071.SEDEST_EMPREENDIMENTOS_IMOBILIARIOS_E_ANEXOS- 9[1] anexo271349_64072.SEDEST_EMPREENDIMENTOS_IMOBILIARIOS_E_ANEXOS- 10[1] anexo271349_64073.SEDEST_EMPREENDIMENTOS_IMOBILIARIOS_E_ANEXOS- 19[1] anexo271349_64074.SEDEST_EMPREENDIMENTOS_IMOBILIARIOS_E_ANEXOS- 11[1] anexo271349_64075.SEDEST_EMPREENDIMENTOS_IMOBILIARIOS_E_ANEXOS- 17[1] anexo271349_64076.SEDEST_EMPREENDIMENTOS_IMOBILIARIOS_E_ANEXOS- 14[1] anexo271349_64077.SEDEST_EMPREENDIMENTOS_IMOBILIARIOS_E_ANEXOS- 21[1] anexo271349_64078.SEDEST_EMPREENDIMENTOS_IMOBILIARIOS_E_ANEXOS- 16[1] anexo271349_64079.SEDEST_EMPREENDIMENTOS_IMOBILIARIOS_E_ANEXOS- 13[1] anexo271349_64080.SEDEST_EMPREENDIMENTOS_IMOBILIARIOS_E_ANEXOS- 12[1] anexo271349_64081.SEDEST_EMPREENDIMENTOS_IMOBILIARIOS_E_ANEXOS- 20[1] anexo271349_64082.SEDEST_EMPREENDIMENTOS_IMOBILIARIOS_E_ANEXOS- 18[1] anexo271349_64083.SEDEST_EMPREENDIMENTOS_IMOBILIARIOS_E_ANEXOS- 15[1] anexo271349_64084.SEDEST_EMPREENDIMENTOS_IMOBILIARIOS_E_ANEXOS- 22[1]

### Certidão municipal {#anexo1}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Área de abrangência do Aquífero Karst {#anexo2}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência — Projeto Básico de Terraplanagem {#anexo3}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência — Laudo Geológico-Geotécnico {#anexo4}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência — Laudo Florestal {#anexo5}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência — Projeto de Drenagem Superficial {#anexo6}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência — Relatório Ambiental Preliminar - RAP {#anexo7}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência — Relatório de Detalhamento dos Programas Ambientais - RDPA {#anexo8}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência — Projeto de Gerenciamento de Resíduos da Construção Civil - PGRCC {#anexo9}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Anexo XI — citado para declaração de verdade e relatório de resíduos da construção civil {#anexo11}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Declaração do empreendedor pelo Licenciamento por Adesão e Compromisso {#anexo12}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Declaração do Responsável Técnico pelo Licenciamento por Adesão e Compromisso {#anexo13}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|
| [[resolucao-sedest-9-2024]] | Ver anotações no corpo | Alteração indicada no PDF; conferência pendente. |

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (sedest 50 2022(1).pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- Redações anteriores de artigos repetidos foram excluídas desta versão compilada, conforme o padrão do acervo; estão preservadas na extração da fonte que acompanha o lote.
- Anexo próprio citado ou vinculado em arquivo separado, sem o respectivo conteúdo no PDF do lote. Não foi importado material externo ou presumida sua redação.
- Art. 15, VII remete ao Anexo XI para relatório de resíduos; art. 10, XI remete ao mesmo Anexo XI para declaração de verdade. Mantida a literalidade; revisão humana necessária. A correspondência dos números X e XIV não foi inferida a partir dos nomes dos arquivos listados.
- Quadros no corpo devem ser conferidos visualmente; números, colunas e células mescladas ainda não estão certificados. Não utilizar este rascunho para enquadramento antes da revisão.
