---
norma: "Resolução SEDEST nº 8/2021"
arquivo: resolucao-sedest-8-2021
tipo: resolucao
esfera: estadual
uf: PR
numero: 8
ano: 2021
data_assinatura: 2021-02-23
ementa: "Estabelece definições, critérios, diretrizes e procedimentos para o licenciamento ambiental de BIODIGESTORES COM APROVEITAMENTO ENERGÉTICO DE BIOGÁS no âmbito do Estado do Paraná."
situacao: revogada
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: []
revoga: []
revogado_por: ["[[decreto-estadual-9541-2025]]"]
cita: ["[[decreto-estadual-1440-2019]]", "[[decreto-estadual-3813-2020]]", "[[lei-estadual-10066-1992]]", "[[lei-estadual-19500-2018]]", "[[lei-estadual-19848-2019]]", "[[lei-estadual-20070-2019]]", "[[portaria-iap-212-2019]]", "[[portaria-iap-256-2013]]", "[[resolucao-cema-107-2020]]", "[[resolucao-conama-1-1986]]", "[[resolucao-conama-2-1994]]", "[[resolucao-conama-6-1986]]", "[[resolucao-sedest-15-2020]]", "[[resolucao-sema-16-2014]]", "[[resolucao-sema-21-2009]]", "[[resolucao-sema-51-2009]]"]
tags: ["app", "autorizacao-florestal", "biodigestor", "biogas", "definicao", "documentacao", "efluente", "eia-rima", "enquadramento", "las", "li", "licenciamento-ambiental", "lo", "lp", "outorga", "prazo", "proibicao", "renovacao", "residuo-solido", "responsavel-tecnico"]
fonte: "PDF fornecido: sedest 08 2021(1).pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
---

# Resolução SEDEST nº 8/2021

> Estabelece definições, critérios, diretrizes e procedimentos para o licenciamento ambiental de BIODIGESTORES COM APROVEITAMENTO ENERGÉTICO DE BIOGÁS no âmbito do Estado do Paraná.

## Preâmbulo

Resolução SEDEST 08 - 23 de Fevereiro de 2021 Publicado no Diário Oficial nº. 10889 de 9 de Março de 2021 Súmula: Estabelece definições, critérios, diretrizes e procedimentos para o licenciamento ambiental de BIODIGESTORES COM APROVEITAMENTO ENERGÉTICO DE BIOGÁS no âmbito do Estado do Paraná. O Secretário de Estado do Desenvolvimento Sustentável e do Turismo do Estado do Paraná, no uso das atribuições que lhe são conferidas pela [[lei-estadual-19848-2019|Lei Estadual nº. 19.848, de 03 de maio de 2019]], [[lei-estadual-10066-1992|Lei Estadual nº 10.066 de 27 de julho de 1992]] e alterações posteriores, [[lei-estadual-20070-2019|Lei Estadual nº 20.070, de 18 de dezembro de 2019]], [[decreto-estadual-3813-2020|Decreto nº 3813, de 09 de janeiro de 2020]] e [[decreto-estadual-1440-2019|Decreto 1440 de 23 de maio de 2019]]; CONSIDERANDO: - que o Licenciamento Ambiental é o procedimento administrativo pelo qual o órgão ambiental competente, verificando a satisfação das condições legais e técnicas, delibera quanto à localização, instalação, ampliação, operação e encerramento de empreendimentos e atividades utilizadoras de recursos ambientais consideradas efetivas ou potencialmente poluidoras ou daquelas que, sob qualquer forma, possam vir a causar degradação e/ou modificação ambiental, considerando as disposições legais e regulamentares e as normas técnicas aplicáveis ao caso; - que a Licença Ambiental é o ato administrativo pelo qual o órgão ambiental competente estabelece as condições, restrições e medidas de controle ambiental que deverão ser obedecidas pelo empreendedor, pessoa física ou jurídica, para localizar, instalar, ampliar e operar empreendimentos ou atividades utilizadoras dos recursos ambientais consideradas efetiva ou potencialmente poluidoras ou aquelas que, sob qualquer forma, possam causar degradação e/ou modificação ambiental; - a necessidade de padronizar os procedimentos para os licenciamentos de geração de energia elétrica a partir do biogás no âmbito do Estado do Paraná; - o licenciamento deve estabelecer os parâmetros mínimos para garantir os remanescentes florestais, faunísticos, socioeconômicos, culturais e outros atributos naturais, bem como definir critérios para compensação ou mitigação de impactos negativos ocasionados pela instalação do empreendimento; - o disposto no Inciso Xl, da Resolução do Conselho Nacional do Meio Ambiente - CONAMA n° 001, de 23 de janeiro de 1986, que estabelece a dependência de elaboração de estudo de impacto ambiental e respectivo relatório de impacto ambiental - RIMA para o licenciamento ambiental de Usinas de geração de eletricidade, qualquer que seja a fonte de energia primária, acima de 10MW; - as determinações estabelecidas pela Resolução do Conselho Nacional do Meio Ambiente – CONAMA nº 237, de 19 de dezembro de 1997 e pela Resolução do Conselho Estadual do Meio Ambiente – CEMA nº 107, de 09 de setembro de 2.020, sobre critérios e procedimentos a serem adotados para as atividades poluidoras, degradadoras e/ou modificadoras do meio ambiente. - a [[lei-estadual-19500-2018|Lei Estadual n° 19.500/2018]], que dispõe sobre a Política Estadual do Biogás e Biometano e adota outras providências. RESOLVE:

###### Art. 1º {#art1}
Tags: #biodigestor #biogas #definicao #efluente #licenciamento-ambiental #residuo-solido

**Art. 1º, caput** {#art1_cpt} #definicao #efluente #licenciamento-ambiental #residuo-solido Estabelecer definições, critérios, diretrizes e procedimentos para o licenciamento ambiental de biodigestores, para fins de uso de culturas energéticas, tratamento de efluentes e resíduos orgânicos de origem industrial, urbana ou rural, com aproveitamento energético de biogás no Estado do Paraná.

**Art. 1º, parágrafo único** {#art1_par1u} A presente Resolução se aplica também ao aproveitamento energético de biogás gerado em aterros sanitários já implantados.

### CAPÍTULO I – DAS DEFINIÇÕES

###### Art. 2º {#art2}
Tags: #biodigestor #biogas #definicao #efluente #eia-rima #enquadramento #licenciamento-ambiental #residuo-solido

**Art. 2º, caput** {#art2_cpt} #definicao Para os efeitos desta Resolução, consideram-se as seguintes definições:
- **Art. 2º, caput, inciso I** {#art2_cpt_inc1} Aproveitamento energético de biogás: aproveitamento do biogás e/ou biometano para geração de energia elétrica, térmica e veicular, bem como injeção em linha de gás natural;
- **Art. 2º, caput, inciso II** {#art2_cpt_inc2} Biodigestão ou digestão anaeróbia: é o processo de decomposição de matéria orgânica na ausência de oxigênio, por meio da sua transformação em novos produtos o qual promove alteração das propriedades físicas, químicas e biológicas;
- **Art. 2º, caput, inciso III** {#art2_cpt_inc3} #eia-rima Biogás: gás bruto obtido da decomposição anaeróbia (ausência de oxigênio gasoso) da matéria orgânica, composta primariamente de metano e dióxido de carbono, com pequenas quantidades de ácido sulfídrico e amônia;
- **Art. 2º, caput, inciso IV** {#art2_cpt_inc4} Biodigestor: estrutura física que facilita a digestão anaeróbia de biomassa, fornecendo em seu interior um ambiente propicio para os microrganismos responsáveis pela digestão, contemplando entre outros, biodigestor de lagoa coberta (BLC), biodigestor tipo UASB, biodigestor CSTR, biodigestor em fase solida (DRY DIGESTION);
- **Art. 2º, caput, inciso V** {#art2_cpt_inc5} Biomassa: série de substâncias provenientes da matéria viva (animal ou vegetal) que têm a propriedade de se decomporem (por efeito biológico) sob ação de diferentes tipos de microrganismos;
- **Art. 2º, caput, inciso VI** {#art2_cpt_inc6} Biometano: biocombustível gasoso constituído essencialmente de metano, derivado da purificação do biogás;
- **Art. 2º, caput, inciso VII** {#art2_cpt_inc7} #efluente Digestato: efluente de biodigestores resultante da decomposição da biomassa pelo processo de biodigestão anaeróbia;
- **Art. 2º, caput, inciso VIII** {#art2_cpt_inc8} #efluente Efluentes: despejos líquidos provenientes de estabelecimentos industriais (efluente industrial), das atividades humanas (efluente ou esgoto doméstico), das atividades agropecuárias e das redes pluviais;
- **Art. 2º, caput, inciso IX** {#art2_cpt_inc9} #residuo-solido Fontes de energia primária: são as fontes oriundas da natureza, em sua forma direta, como o petróleo, o gás natural, o xisto, o carvão mineral, os resíduos vegetais e animais, a energia solar, geotérmica e a eólica e os produtos da cana-de-açúcar, como o caldo de cana, o melaço e o bagaço;
- **Art. 2º, caput, inciso X** {#art2_cpt_inc10} #efluente #residuo-solido Gerador de resíduos e efluentes: pessoas físicas ou jurídicas que geram resíduos e efluentes em suas atividades;
- **Art. 2º, caput, inciso XI** {#art2_cpt_inc11} #licenciamento-ambiental Licenciamento ambiental: ato administrativo pelo qual o órgão ambiental competente estabelece as condições, restrições e medidas de controle ambiental que deverão ser obedecidas pelo empreendedor, pessoa física ou jurídica, para localizar, instalar, ampliar e operar empreendimentos ou atividades utilizadoras dos recursos ambientais consideradas efetiva ou potencialmente poluidoras ou aquelas que, sob qualquer forma, possam causar degradação e/ou modificação ambiental;
- **Art. 2º, caput, inciso XII** {#art2_cpt_inc12} Licença ambiental: ato administrativo pelo qual o órgão ambiental competente estabelece as condições, restrições e medidas de controle ambiental que deverão ser obedecidas pelo empreendedor, pessoa física ou jurídica, para localizar, instalar, ampliar e operar empreendimentos ou atividades utilizadoras dos recursos ambientais consideradas efetivas ou potencialmente poluidoras ou aquelas que, sob qualquer forma, possam causar degradação e/ou modificação ambiental;
- **Art. 2º, caput, inciso XIII** {#art2_cpt_inc13} #residuo-solido Lodo de biodigestor: resíduo sólido formado pela sedimentação de partículas de maior granulometria e baixa biodegradabilidade que se acumula no fundo de biodigestores de lagoa coberta ou modelos sem agitação da biomassa e que apresenta teores consideráveis de nutrientes que possibilitam o seu uso para adubação do solo e nutrição de plantas;
- **Art. 2º, caput, inciso XIV** {#art2_cpt_inc14} Produtor de biogás: pessoa física ou jurídica que produz biogás a partir da decomposição de matéria orgânica e utiliza diretamente ou comercializa;
- **Art. 2º, caput, inciso XV** {#art2_cpt_inc15} Produtor de biometano: pessoa física ou jurídica, devidamente autorizada pela autoridade competente, que purifica o biogás de modo a obter o biometano;
- **Art. 2º, caput, inciso XVI** {#art2_cpt_inc16} #efluente #enquadramento #residuo-solido Resíduos sólidos: material, substância, objeto ou bem descartado resultante de atividades humanas agrícolas, pecuárias, de fruticultura, industriais, comerciais, habitacionais, urbanas, de transporte, de compostagem e de prestação de serviços, dentre outras, nos estados sólido ou semissólido, bem como gases contidos em recipientes e líquidos cujas particularidades tornem inviável o seu lançamento na rede pública de esgotos ou em corpos d’água, ou exijam para isso soluções técnicas ou economicamente inviáveis em face da melhor tecnologia disponível;
- **Art. 2º, caput, inciso XVII** {#art2_cpt_inc17} #residuo-solido Unidade de Triagem: local de recebimento de resíduos, que serão separados de acordo com suas características materiais, para posterior destinação final.

### CAPÍTULO II – DO LICENCIAMENTO AMBIENTAL

#### Seção I – Dos Atos Administrativos

###### Art. 3º {#art3}
Tags: #biodigestor #biogas #documentacao #enquadramento #las #li #licenciamento-ambiental #lo #lp

**Art. 3º, caput** {#art3_cpt} #licenciamento-ambiental O Órgão Ambiental Competente, no exercício de sua competência de controle ambiental, expedirá os seguintes atos administrativos licenciador, no âmbito do licenciamento de biodigestores com aproveitamento energético de biogás e no exercício de suas atribuições, expedirá os seguintes atos administrativos:
- **Art. 3º, caput, inciso I** {#art3_cpt_inc1} #licenciamento-ambiental Declaração de Dispensa de Licenciamento Ambiental Estadual (DLAE): concedida para os empreendimentos cujo licenciamento ambiental não compete ao órgão ambiental estadual, conforme estabelecido na [[resolucao-sema-51-2009|Resolução SEMA 051/2009]] e alterações posteriores;
- **Art. 3º, caput, inciso II** {#art3_cpt_inc2} Licença Ambiental por Adesão e Compromisso – LAC: Licença que autoriza a instalação e a operação de atividade ou empreendimento, mediante declaração de adesão e compromisso do empreendedor aos critérios, pré-condições, requisitos e condicionantes ambientais estabelecidos pela autoridade licenciadora, desde que se conheçam previamente os impactos ambientais da atividade ou empreendimento, as características ambientais da área de implantação e as condições de sua instalação e operação;
- **Art. 3º, caput, inciso III** {#art3_cpt_inc3} #documentacao #enquadramento #las Licença Ambiental Simplificada (LAS): aprova a localização e a concepção do empreendimento, atividade ou obra de pequeno porte e/ou que possuam baixo potencial poluidor/degradador, atestando a viabilidade ambiental, estabelecendo os requisitos básicos e condicionantes a serem atendidos, bem como autoriza sua instalação e operação de acordo com as especificações constantes dos requerimentos, planos, programas e/ou projetos aprovados, incluindo as medidas de controle ambiental e demais condicionantes determinadas pelo órgão licenciador;
- **Art. 3º, caput, inciso IV** {#art3_cpt_inc4} #lp Licença Prévia (LP): concedida na fase preliminar do planejamento do empreendimento ou atividade aprovando sua localização e concepção, atestando a viabilidade ambiental e estabelecendo os requisitos básicos e condicionantes a serem atendidos nas próximas fases de sua implementação;
- **Art. 3º, caput, inciso V** {#art3_cpt_inc5} #li Licença de Instalação (LI): autoriza a instalação do empreendimento ou atividade de acordo com as especificações constantes dos planos, programas e projetos aprovados, incluindo as medidas de controle ambientais e demais condicionantes, da qual constituem motivos determinantes;
- **Art. 3º, caput, inciso VI** {#art3_cpt_inc6} #lo Licença de Operação (LO): autoriza a operação da atividade ou empreendimento, após a verificação do efetivo cumprimento do que consta das licenças anteriores, com as medidas de controle ambientais e condicionantes determinados para a operação.

###### Art. 4º {#art4}
Tags: #biodigestor #biogas #documentacao #responsavel-tecnico

**Art. 4º, caput** {#art4_cpt} #documentacao #responsavel-tecnico Os atos administrativos listados no Art. 3º serão expedidos por meio do sistema SGA, mediante cadastramento do requerente como usuário ambiental, prestação das informações referente ao empreendimento e a apresentação da documentação solicitada.

#### Seção II – Da Definição do Porte, Tipo de Licenciamento e de Estudo Ambiental

###### Art. 5º {#art5}
Tags: #biodigestor #biogas #definicao #efluente #enquadramento #residuo-solido

**Art. 5º, caput** {#art5_cpt} #enquadramento Para os efeitos desta Resolução, os empreendimentos que contemplem biodigestores serão licenciados de acordo com sua classificação e porte.
- **Art. 5º, caput, inciso I** {#art5_cpt_inc1} Classificação do empreendimento, considerando a finalidade de uso do biodigestor: (Quadro/Planilha em anexo)
- **Art. 5º, caput, inciso II** {#art5_cpt_inc2} #definicao #enquadramento Porte do empreendimento definido de acordo com a capacidade de utilização de biogás ou com a potência a ser instalada para aproveitamento energético do biogás, aplicado para biodigestores do tipo II: (Quadro/Planilha em anexo)
- **Art. 5º, caput, inciso III** {#art5_cpt_inc3} #definicao #enquadramento Porte do empreendimento definido de acordo com a capacidade do biodigestor para tratamento de matéria orgânica:
  - **Art. 5º, caput, inciso III, alínea "a"** {#art5_cpt_inc3_alia} #efluente #residuo-solido para o tratamento de efluentes líquidos e resíduos sólidos, de origem industrial, agropecuária, saneamento e comerciais e serviços, aplicado para biodigestores dos tipos III e IV: (Quadro/Planilha em anexo)
  - **Art. 5º, caput, inciso III, alínea "b"** {#art5_cpt_inc3_alib} #residuo-solido para o tratamento de resíduos sólidos urbanos, aplicado para biodigestores dos tipos IV: (Quadro/Planilha em anexo)

###### Art. 6º {#art6}
Tags: #biodigestor #biogas #licenciamento-ambiental

**Art. 6º, caput** {#art6_cpt} #licenciamento-ambiental Para a concessão do licenciamento ambiental de biodigestores, considerar os critérios de licenciamento da tabela abaixo: (Quadro/Planilha em anexo)

###### Art. 7º {#art7}
Tags: #biodigestor #biogas #licenciamento-ambiental

**Art. 7º, caput** {#art7_cpt} #licenciamento-ambiental O licenciamento ambiental de biodigestores TIPO I estarão incorporados no licenciamento ambiental do empreendimento principal, não necessitando de licenciamento específico.

###### Art. 8º {#art8}
Tags: #biodigestor #biogas #eia-rima #responsavel-tecnico

**Art. 8º, caput** {#art8_cpt} #eia-rima #responsavel-tecnico Os empreendimentos com geração de eletricidade acima de 10 MW, estarão sujeitos à apresentação de EIA/RIMA, conforme estabelecido na [[resolucao-conama-1-1986|Resolução CONAMA 01/86]], independente dos critérios estabelecidos no Art. 6º desta Resolução.

###### Art. 9º {#art9}
Tags: #biodigestor #biogas #enquadramento #licenciamento-ambiental

**Art. 9º, caput** {#art9_cpt} #enquadramento #licenciamento-ambiental No licenciamento do empreendimento deverão ser contempladas todas as unidades e elementos a serem instalados, desde a unidade de geração do biogás, estruturas de transporte necessárias até seu aproveitamento energético.

#### Seção III – Documentação para o Licenciamento Ambiental

##### Subseção I – Da Declaração de Dispensa de Licenciamento Ambiental - DLAE

###### Art. 10 {#art10}
Tags: #biodigestor #biogas #documentacao #licenciamento-ambiental #responsavel-tecnico

**Art. 10, caput** {#art10_cpt} #licenciamento-ambiental #responsavel-tecnico A Declaração de Dispensa de Licenciamento Ambiental - DLAE é obrigatória para os biodigestores elegíveis conforme Art. 6º e deverá ser requerida através do SGA, instruídos na forma prevista abaixo:
- **Art. 10, caput, inciso I** {#art10_cpt_inc1} #documentacao #responsavel-tecnico Certidão atualizada da Matrícula ou Transcrição Imobiliária emitida pelo Cartório de Registro de Imóveis ou documento de justa posse em nome do requerente, ou conforme exigências constantes da Seção V, art.45 a 54 da [[resolucao-cema-107-2020|Resolução CEMA 107/2020]]. Caso o imóvel seja locado, apresentar o contrato de locação;
- **Art. 10, caput, inciso II** {#art10_cpt_inc2} #responsavel-tecnico Memorial de caracterização do empreendimento - MCE, apresentado de acordo com o Termo de Referência do ANEXO II, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART.

###### Art. 11 {#art11}
Tags: #biodigestor #biogas #enquadramento

**Art. 11, caput** {#art11_cpt} #enquadramento Deverá ser solicitada à respectiva Licença Ambiental para qualquer alteração nas características do porte dos biodigestores.

###### Art. 12 {#art12}
Tags: #biodigestor #biogas #licenciamento-ambiental

**Art. 12, caput** {#art12_cpt} #licenciamento-ambiental A Dispensa do Licenciamento Ambiental Estadual - DLAE não exime das exigências legais quanto à preservação do meio ambiente.

##### Subseção II – Da Licença Ambiental por Adesão e Compromisso - LAC

###### Art. 13 {#art13}
Tags: #biodigestor #biogas #documentacao #efluente #licenciamento-ambiental #outorga #responsavel-tecnico

**Art. 13, caput** {#art13_cpt} #responsavel-tecnico A Licença Ambiental por Adesão e Compromisso - LAC, para os biodigestores elegíveis conforme Art. 6º, deverá ser requerida através do SGA, instruídos na forma prevista abaixo:
- **Art. 13, caput, inciso I** {#art13_cpt_inc1} #documentacao Certidão do Município, declarando expressamente que o local e o tipo de empreendimento ou atividade estão em conformidade com o Plano Diretor Municipal e legislação urbanística básica, ambiental, bem como que atendam as demais exigências legais e administrativas perante o município (ANEXO I);
- **Art. 13, caput, inciso II** {#art13_cpt_inc2} #documentacao #responsavel-tecnico Certidão atualizada da Matrícula ou Transcrição Imobiliária emitida pelo Cartório de Registro de Imóveis ou documento de justa posse em nome do requerente, ou conforme exigências constantes da Seção V, art.45 a 54 da [[resolucao-cema-107-2020|Resolução CEMA 107/2020]]. Caso o imóvel seja locado, apresentar o contrato de locação;
- **Art. 13, caput, inciso III** {#art13_cpt_inc3} Cópia do Ato Constitutivo ou do Contrato Social (com última alteração), quando pessoa jurídica;
- **Art. 13, caput, inciso IV** {#art13_cpt_inc4} #responsavel-tecnico Memorial de caracterização do empreendimento - MCE, apresentado de acordo com o Termo de Referência do ANEXO II, elaborado por profissional(is) habilitado(s) e acompanhado da(s) respectivas ART(s) - Anotação(s) de Responsabilidade Técnica dos profissionais habilitados;
- **Art. 13, caput, inciso V** {#art13_cpt_inc5} #responsavel-tecnico Quando for o caso, Projeto de Utilização Agrícola do digestato, apresentado de acordo com o Termo de Referência do ANEXO X, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART.
- **Art. 13, caput, inciso VI** {#art13_cpt_inc6} #efluente #outorga Outorga de direito de uso de recursos hídricos para utilização de recursos hídricos, inclusive para o lançamento de efluentes líquidos em corpos hídricos, se for o caso;
- **Art. 13, caput, inciso VII** {#art13_cpt_inc7} Apresentação da anuência do proprietário, conforme modelo do ANEXO XI, no caso de Utilização Agrícola do digestato, em áreas em que o interessado não é o proprietário;
- **Art. 13, caput, inciso VIII** {#art13_cpt_inc8} Declaração de verdade das informações prestadas, conforme modelo do ANEXO VII;
- **Art. 13, caput, inciso IX** {#art13_cpt_inc9} #licenciamento-ambiental Declaração do empreendedor pelo Licenciamento por Adesão e Compromisso conforme modelo do ANEXO VIII;
- **Art. 13, caput, inciso X** {#art13_cpt_inc10} #licenciamento-ambiental #responsavel-tecnico Declaração do responsável técnico pelo licenciamento por Adesão e Compromisso conforme modelo do ANEXO IX, acompanhada da respectiva Anotação de Responsabilidade Técnica;
- **Art. 13, caput, inciso XI** {#art13_cpt_inc11} Prova de publicação de súmula do pedido de Licença Ambiental por Adesão e Compromisso - LAC em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente mediante pagamentos das custas, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 13, caput, inciso XII** {#art13_cpt_inc12} Comprovante de recolhimento da Taxa Ambiental.

##### Subseção III – Da Licença Ambiental Simplificada – LAS

###### Art. 14 {#art14}
Tags: #autorizacao-florestal #biodigestor #biogas #definicao #documentacao #efluente #las #outorga #responsavel-tecnico

**Art. 14, caput** {#art14_cpt} #documentacao #las #responsavel-tecnico Os requerimentos de Licença Ambiental Simplificada – LAS, para os biodigestores elegíveis conforme Art. 6º e deverá ser requerida através do SGA, instruídos na forma prevista abaixo:
- **Art. 14, caput, inciso I** {#art14_cpt_inc1} #documentacao Certidão do Município, declarando expressamente que o local e o tipo de empreendimento ou atividade estão em conformidade com o Plano Diretor Municipal e legislação urbanística básica, ambiental, bem como que atendam as demais exigências legais e administrativas perante o município (ANEXO I);
- **Art. 14, caput, inciso II** {#art14_cpt_inc2} #documentacao #responsavel-tecnico Certidão atualizada da Matrícula ou Transcrição Imobiliária emitida pelo Cartório de Registro de Imóveis ou documento de justa posse em nome do requerente, ou conforme exigências constantes da Seção V, art.45 a 54 da [[resolucao-cema-107-2020|Resolução CEMA 107/2020]]. Caso o imóvel seja locado, apresentar o contrato de locação;
- **Art. 14, caput, inciso III** {#art14_cpt_inc3} #efluente #outorga Outorga de direito de uso de recursos hídricos do Instituto das Águas para utilização de recursos hídricos, inclusive para o lançamento de efluentes líquidos em corpos hídricos, se for o caso;
- **Art. 14, caput, inciso IV** {#art14_cpt_inc4} Cópia do Ato Constitutivo ou do Contrato Social (com última alteração), quando pessoa jurídica;
- **Art. 14, caput, inciso V** {#art14_cpt_inc5} #responsavel-tecnico Memorial de caracterização do empreendimento - MCE, apresentado de acordo com o Termo de Referência do ANEXO II, elaborado por profissional(is) habilitado(s) e acompanhado da(s) respectivas ART(s) - Anotação(s) de Responsabilidade Técnica dos profissionais habilitados;
- **Art. 14, caput, inciso VI** {#art14_cpt_inc6} #definicao #responsavel-tecnico Estudo ambiental definido na tabela do Art. 6.ºda presente Resolução; Comprovante da entrega da Ficha de Caracterização de Atividade do Instituto do Patrimônio Histórico e Artístico Nacional – IPHAN, quando aplicável;
- **Art. 14, caput, inciso VII** {#art14_cpt_inc7} #responsavel-tecnico Quando for o caso, Projeto de Utilização Agrícola do digestato, apresentado de acordo com o Termo de Referência do ANEXO X, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
- **Art. 14, caput, inciso VIII** {#art14_cpt_inc8} Apresentação da anuência do proprietário, conforme modelo do ANEXO XI no caso de Utilização Agrícola do digestato, em áreas em que o interessado não é o proprietário;
- **Art. 14, caput, inciso IX** {#art14_cpt_inc9} #autorizacao-florestal #documentacao Apresentação do requerimento (protocolo) de Autorização Florestal, no caso de necessidade de supressão de vegetação;
- **Art. 14, caput, inciso X** {#art14_cpt_inc10} #las Publicação de súmula do pedido de Licença Ambiental Simplificada - LAS em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/1986]];
- **Art. 14, caput, inciso XI** {#art14_cpt_inc11} Recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

###### Art. 15 {#art15}
Tags: #autorizacao-florestal #biodigestor #biogas #las

**Art. 15, caput** {#art15_cpt} #autorizacao-florestal #las Quando necessário o corte ou supressão de vegetação nativa, a Licença Ambiental Simplificada – LAS somente poderá ser emitida acompanhada da respectiva Autorização Florestal.

###### Art. 16 {#art16}
Tags: #biodigestor #biogas #documentacao #las #renovacao #residuo-solido #responsavel-tecnico

**Art. 16, caput** {#art16_cpt} #documentacao #las #renovacao Os requerimentos para renovação da Licença Ambiental Simplificada – LAS, deverão ser protocolados no SGA, instruídos na forma prevista abaixo:
- **Art. 16, caput, inciso I** {#art16_cpt_inc1} Relatório de atendimento das condicionantes da Licença anterior;
- **Art. 16, caput, inciso II** {#art16_cpt_inc2} #residuo-solido #responsavel-tecnico Plano de gerenciamento de resíduos sólidos – PGRS atualizado e apresentado de acordo com o Termo de Referência do ANEXO VI, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
- **Art. 16, caput, inciso III** {#art16_cpt_inc3} #las Publicação de súmula de concessão de Licença Ambiental Simplificada em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 16, caput, inciso IV** {#art16_cpt_inc4} #las #renovacao Publicação de súmula do pedido de Renovação de Licença Ambiental Simplificada em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 16, caput, inciso V** {#art16_cpt_inc5} Recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

##### Subseção IV – Das Licenças Prévia - LP, de Instalação - LI e de Operação - LO

###### Art. 17 {#art17}
Tags: #biodigestor #biogas #definicao #enquadramento

**Art. 17, caput** {#art17_cpt} Os empreendimentos que necessitam de Licenças Prévia, de Instalação e de Operação, deverão requerê-las sucessivamente.

**Art. 17, parágrafo único** {#art17_par1u} #definicao #enquadramento Este procedimento se aplica a novos empreendimentos e aqueles em operação que venham a sofrer ampliações acima do porte, alterações definitivas no processo e incorporação de novas atividades, com alteração das características do empreendimento já implantado.

###### Art. 18 {#art18}
Tags: #biodigestor #biogas #definicao #documentacao #licenciamento-ambiental #lp #outorga #responsavel-tecnico

**Art. 18, caput** {#art18_cpt} #documentacao #lp Os requerimentos para LICENÇA PRÉVIA – LP, deverão ser realizados através do SGA, instruído na forma prevista abaixo:
- **Art. 18, caput, inciso I** {#art18_cpt_inc1} #responsavel-tecnico Memorial de caracterização do empreendimento - MCE, apresentado de acordo com o Termo de Referência do ANEXO II, elaborado por profissional(is) habilitado(s) e acompanhado da(s) respectivas ART(s) - Anotação(s) de Responsabilidade Técnica dos profissionais habilitados;
- **Art. 18, caput, inciso II** {#art18_cpt_inc2} #documentacao Certidão do Município, declarando expressamente que o local e o tipo de empreendimento ou atividade estão em conformidade com o Plano Diretor Municipal e legislação urbanística básica, ambiental, bem como que atendam as demais exigências legais e administrativas perante o município (ANEXO I);
- **Art. 18, caput, inciso III** {#art18_cpt_inc3} #documentacao #responsavel-tecnico Certidão atualizada da Matrícula ou Transcrição Imobiliária emitida pelo Cartório de Registro de Imóveis ou documento de justa posse em nome do requerente, ou conforme exigências constantes da Seção V, art.45 a 54 da [[resolucao-cema-107-2020|Resolução CEMA 107/2020]]. Caso o imóvel seja locado, apresentar o contrato de locação;
- **Art. 18, caput, inciso IV** {#art18_cpt_inc4} Cópia do Ato Constitutivo ou do Contrato Social (com última alteração), quando pessoa jurídica;
- **Art. 18, caput, inciso V** {#art18_cpt_inc5} #outorga Número da Outorga Prévia ou Dispensa de Outorga de Uso de Recursos Hídricos, se for o caso;
- **Art. 18, caput, inciso VI** {#art18_cpt_inc6} #definicao #responsavel-tecnico Apresentação do Estudo ambiental definido na tabela do Art. 6º da presente Resolução;
- **Art. 18, caput, inciso VII** {#art18_cpt_inc7} #licenciamento-ambiental Em caso de necessidade de supressão florestal, deve haver uma análise integrada do licenciamento e o requerente deverá apresentar o Relatório de Caracterização da Flora, de acordo com a [[resolucao-conama-2-1994|Resolução CONAMA 02/94]];
- **Art. 18, caput, inciso VIII** {#art18_cpt_inc8} #lp Publicação de súmula do pedido de Licença Prévia em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 18, caput, inciso IX** {#art18_cpt_inc9} Recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

###### Art. 19 {#art19}
Tags: #autorizacao-florestal #biodigestor #biogas #definicao #documentacao #li #lp #responsavel-tecnico

**Art. 19, caput** {#art19_cpt} #documentacao #li Os requerimentos para LICENÇA DE INSTALAÇÃO – LI, deverão ser realizados através do SGA, instruído na forma prevista abaixo:
- **Art. 19, caput, inciso I** {#art19_cpt_inc1} #lp Cópia da Licença Prévia;
- **Art. 19, caput, inciso II** {#art19_cpt_inc2} Relatório de atendimento das condicionantes da licença anterior;
- **Art. 19, caput, inciso III** {#art19_cpt_inc3} #definicao #responsavel-tecnico Apresentação do Estudo ambiental definido na tabela do Art. 6º da presente Resolução;
- **Art. 19, caput, inciso IV** {#art19_cpt_inc4} #responsavel-tecnico Quando for o caso, Projeto de Utilização Agrícola do digestato, apresentado de acordo com o Termo de Referência do ANEXO X, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
- **Art. 19, caput, inciso V** {#art19_cpt_inc5} Apresentação da anuência do proprietário, conforme modelo do ANEXO XI, no caso de Utilização Agrícola do digestato, em áreas em que o interessado não é o proprietário;
- **Art. 19, caput, inciso VI** {#art19_cpt_inc6} #autorizacao-florestal #documentacao Apresentação do requerimento (protocolo) de Autorização Florestal, no caso de necessidade de supressão de vegetação;
- **Art. 19, caput, inciso VII** {#art19_cpt_inc7} #li Publicação de súmula do pedido de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 19, caput, inciso VIII** {#art19_cpt_inc8} Recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

###### Art. 20 {#art20}
Tags: #autorizacao-florestal #biodigestor #biogas #li

**Art. 20, caput** {#art20_cpt} #autorizacao-florestal #li Quando necessário o corte ou supressão de vegetação nativa, a Licença de Instalação somente poderá ser emitida acompanhada da respectiva Autorização Florestal.

###### Art. 21 {#art21}
Tags: #biodigestor #biogas #documentacao #li #lo #outorga #residuo-solido #responsavel-tecnico

**Art. 21, caput** {#art21_cpt} #documentacao #lo Os requerimentos para LICENÇA DE OPERAÇÃO - LO, deverão ser realizados através do SGA, instruído na forma prevista abaixo:
- **Art. 21, caput, inciso I** {#art21_cpt_inc1} #li Cópia da Licença de Instalação;
- **Art. 21, caput, inciso II** {#art21_cpt_inc2} Relatório de atendimento das condicionantes da licença anterior;
- **Art. 21, caput, inciso III** {#art21_cpt_inc3} #outorga Número da Outorga de Direito ou Dispensa de Outorga de Uso de Recursos Hídricos para utilização de recursos hídricos, se for o caso;
- **Art. 21, caput, inciso IV** {#art21_cpt_inc4} #residuo-solido #responsavel-tecnico Plano de gerenciamento de resíduos sólidos – PGRS, apresentado de acordo com Termo de Referência do ANEXO VI, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
- **Art. 21, caput, inciso V** {#art21_cpt_inc5} #responsavel-tecnico Laudo de conclusão de obra, acompanhado de material fotográfico, elaborado por profissional com a devida anotação de responsabilidade técnica - ART;
- **Art. 21, caput, inciso VI** {#art21_cpt_inc6} #li Publicação de súmula de concessão de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 21, caput, inciso VII** {#art21_cpt_inc7} #lo Publicação de súmula do pedido de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 21, caput, inciso VIII** {#art21_cpt_inc8} Recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

###### Art. 22 {#art22}
Tags: #biodigestor #biogas #documentacao #lo #renovacao #residuo-solido #responsavel-tecnico

**Art. 22, caput** {#art22_cpt} #documentacao #lo #renovacao Os requerimentos para RENOVAÇÃO DE LICENÇA DE OPERAÇÃO - RLO, deverão ser realizados através do SGA, instruído na forma prevista abaixo:
- **Art. 22, caput, inciso I** {#art22_cpt_inc1} Cópia da Licença anterior;
- **Art. 22, caput, inciso II** {#art22_cpt_inc2} Relatório de atendimento das condicionantes da licença anterior;
- **Art. 22, caput, inciso III** {#art22_cpt_inc3} #residuo-solido #responsavel-tecnico Plano de Gerenciamento de Resíduos Sólidos – PGRS atualizado, apresentado de acordo com Termo de Referência do ANEXO VI, acompanhado da Autorização Ambiental de destinação dos resíduos e, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
- **Art. 22, caput, inciso IV** {#art22_cpt_inc4} Declaração de Carga Poluidora, de acordo com o previsto na [[portaria-iap-256-2013|Portaria IAP Nº 256/2013]], de 16 de Setembro de 2013, se for o caso;
- **Art. 22, caput, inciso V** {#art22_cpt_inc5} #lo Publicação de súmula de concessão de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 22, caput, inciso VI** {#art22_cpt_inc6} #lo #renovacao Publicação de súmula do pedido de Renovação de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 22, caput, inciso VII** {#art22_cpt_inc7} Recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

###### Art. 23 {#art23}
Tags: #biodigestor #biogas #prazo #renovacao

**Art. 23, caput** {#art23_cpt} #prazo #renovacao A RLO e a LO de ampliação poderão ser solicitadas de forma unificada quando o prazo de vencimento da LO em renovação for inferior a 01 (um) ano.

#### Seção V – Dos prazos de Validade das Licenças

###### Art. 24 {#art24}
Tags: #biodigestor #biogas #documentacao #las #li #licenciamento-ambiental #lo #lp #prazo #renovacao

**Art. 24, caput** {#art24_cpt} #documentacao #prazo O órgão ambiental competente estabelecerá os prazos de validade para cada tipo de licença e autorização ambiental, especificandoos no respectivo documento, levando em consideração os seguintes aspectos:
- **Art. 24, caput, inciso I** {#art24_cpt_inc1} #licenciamento-ambiental #prazo #renovacao O prazo de validade da Dispensa de Licenciamento Ambiental Estadual - DLAE será de até 10 (dez) anos, podendo ser renovada a critério técnico do órgão ambiental competente;
- **Art. 24, caput, inciso II** {#art24_cpt_inc2} #prazo #renovacao O prazo de validade da Licença por Adesão e Compromisso - LAC: - 02 (dois) anos para a primeira licença. Renovável; - 05 (cinco) anos a partir da primeira renovação.
- **Art. 24, caput, inciso III** {#art24_cpt_inc3} #las #prazo #renovacao O prazo de validade da Licença Ambiental Simplificada - LAS será de até 10 (dez) anos, podendo ser renovada a critério técnico do órgão ambiental competente;
- **Art. 24, caput, inciso IV** {#art24_cpt_inc4} #lp #prazo O prazo de validade da Licença Prévia - LP será de 05 (cinco) anos, não prorrogável se concedido o prazo máximo;
- **Art. 24, caput, inciso V** {#art24_cpt_inc5} #li #prazo O prazo de validade da Licença de Instalação - LI será de até 06 (seis) anos, não prorrogável se concedido o prazo máximo;
- **Art. 24, caput, inciso VI** {#art24_cpt_inc6} #lo #prazo O prazo de validade da Licença de Operação - LO será de no mínimo 4 anos e no máximo 10 (dez) anos, renovável a critério do Órgão Licenciador.

**Art. 24, parágrafo único** {#art24_par1u} #renovacao As renovações e prorrogações se aplicam aos empreendimentos que não estejam vinculados aos outros empreendimentos.

### CAPÍTULO III – ASPECTOS TÉCNICOS

#### Seção I – Quanto aos Efluentes Líquidos

###### Art. 25 {#art25}
Tags: #biodigestor #biogas #efluente #residuo-solido

**Art. 25, caput** {#art25_cpt} #efluente Os efluentes líquidos gerados em unidades de biodigestão, deverão se submeter a medidas de controle e/ou ser tratados para o lançamento, direto ou indireto, no corpo receptor e basicamente são constituídos de:
- **Art. 25, caput, inciso I** {#art25_cpt_inc1} Digestato;
- **Art. 25, caput, inciso II** {#art25_cpt_inc2} #residuo-solido Lixiviado das áreas de estocagem e pré- tratamento dos resíduos orgânicos e da área de armazenamento do material digerido;
- **Art. 25, caput, inciso III** {#art25_cpt_inc3} Águas de lavagem das áreas de armazenamento e serviços;
- **Art. 25, caput, inciso IV** {#art25_cpt_inc4} Lixiviado dos biofiltros ou outros sistemas de tratamento de gases (odor);
- **Art. 25, caput, inciso V** {#art25_cpt_inc5} Condensado proveniente da purificação do biogás;
- **Art. 25, caput, inciso VI** {#art25_cpt_inc6} #efluente Esgoto sanitário;
- **Art. 25, caput, inciso VII** {#art25_cpt_inc7} Entre outros.

###### Art. 26 {#art26}
Tags: #biodigestor #biogas

**Art. 26, caput** {#art26_cpt} O digestato deverá obrigatoriamente sofrer armazenamento para utilização agrícola.

###### Art. 27 {#art27}
Tags: #biodigestor #biogas #efluente #outorga #proibicao

**Art. 27, caput** {#art27_cpt} #efluente Os efluentes líquidos gerados poderão ser lançados, direta ou indiretamente no corpo receptor desde que obedeçam às condições e padrões estabelecidos na sequência, resguardadas outras exigências cabíveis:
- **Art. 27, caput, inciso I** {#art27_cpt_inc1} pH entre 5 e 9;
- **Art. 27, caput, inciso II** {#art27_cpt_inc2} Temperatura inferior à 40ºC, sendo que a elevação máxima de temperatura do corpo receptor não poderá ultrapassar 3ºC;
- **Art. 27, caput, inciso III** {#art27_cpt_inc3} Materiais sedimentáveis até 1mL/L em teste de 1 hora em Cone Imhoff;
- **Art. 27, caput, inciso IV** {#art27_cpt_inc4} Óleos e graxas: óleos minerais até 20 mg/L e óleos vegetais e gorduras animais até 50 mg/L;
- **Art. 27, caput, inciso V** {#art27_cpt_inc5} Ausência de materiais flutuantes;
- **Art. 27, caput, inciso VI** {#art27_cpt_inc6} #outorga DBO (Demanda Bioquímica de Oxigênio) até 50 mg/ l ou valor estabelecido na outorga;
- **Art. 27, caput, inciso VII** {#art27_cpt_inc7} #outorga DQO (Demanda Química de Oxigênio) até 150 mg/ l ou valor estabelecido na outorga.

**Art. 27, parágrafo único** {#art27_par1u} #efluente #proibicao Fica proibido o lançamento de efluentes líquidos, direta ou indiretamente, em corpos hídricos superficiais utilizados ou potencialmente identificados como mananciais de abastecimento público.

###### Art. 28 {#art28}
Tags: #biodigestor #biogas #efluente

**Art. 28, caput** {#art28_cpt} #efluente No caso de lançamento de efluentes na galeria de águas pluviais, o interessado deverá apresentar a anuência da prefeitura.

###### Art. 29 {#art29}
Tags: #biodigestor #biogas #licenciamento-ambiental

**Art. 29, caput** {#art29_cpt} #licenciamento-ambiental A utilização agrícola do digestato gerado em unidades de biodigestão, deverá ser contemplada no processo de licenciamento dos biodogestores.

###### Art. 30 {#art30}
Tags: #biodigestor #biogas #responsavel-tecnico

**Art. 30, caput** {#art30_cpt} #responsavel-tecnico Para utilização agrícola do digestato, deverá ser elaborado Projeto de Utilização Agrícola com a respectiva ART – Anotação de Responsabilidade Técnica, segundo as diretrizes do IAT, apresentadas no ANEXO X.

###### Art. 31 {#art31}
Tags: #biodigestor #biogas #enquadramento #residuo-solido

**Art. 31, caput** {#art31_cpt} #enquadramento #residuo-solido Para transporte e utilização agrícola do digestato proveniente de Unidade de biodigestão que receber resíduos de empreendimentos de saneamento, deverá atender aos critérios estabelecidos pela [[resolucao-sema-21-2009|Resolução SEMA 021/2009]] ou outra que vier a substituí-la.

###### Art. 32 {#art32}
Tags: #biodigestor #biogas #residuo-solido

**Art. 32, caput** {#art32_cpt} #residuo-solido Para utilização agrícola do digestato proveniente de Unidade de biodigestão que receber resíduos de empreendimentos de Bovinocultura e Suinocultura, deverá atender aos critérios estabelecidos pela Resolução SEDEST Nº 55 de 05/03/2019 e Resolução SEDEST Nº 17 de 05/03/2020, para empreendimentos de Bovinocultura e, [[resolucao-sedest-15-2020|Resolução SEDEST 15 de 05 de Março de 2020]] para empreendimentos de Suinocultura ou outras que vier a substituí-las.

#### Seção II – Quanto aos Resíduos Sólidos e Rejeitos

###### Art. 33 {#art33}
Tags: #biodigestor #biogas #residuo-solido

**Art. 33, caput** {#art33_cpt} #residuo-solido Os resíduos sólidos e rejeitos gerados em unidades de biodigestão, deverão ser acondicionados, armazenados, tratados e destinados de forma técnica e ambientalmente adequadas e basicamente são geradas nos seguintes pontos:
- **Art. 33, caput, inciso I** {#art33_cpt_inc1} #residuo-solido Resíduos da triagem;
- **Art. 33, caput, inciso II** {#art33_cpt_inc2} #residuo-solido Resíduos do pré- tratamento;
- **Art. 33, caput, inciso III** {#art33_cpt_inc3} Lodo do biodigestor;
- **Art. 33, caput, inciso IV** {#art33_cpt_inc4} #residuo-solido Resíduos sanitários e de escritórios de estruturas auxiliares (ex: vestiário, laboratório, refeitório, prédio administrativo);
- **Art. 33, caput, inciso V** {#art33_cpt_inc5} #residuo-solido Resíduos da manutenção de equipamentos.

#### Seção III – Quanto às Emissões Atmosféricas

###### Art. 34 {#art34}
Tags: #biodigestor #biogas

**Art. 34, caput** {#art34_cpt} As emissões atmosféricas deverão atender os critérios e padrões de emissões atmosféricas estabelecidos na [[resolucao-sema-16-2014|Resolução SEMA Nº 016/2014]] ou outra que venha substituí-la.

#### Seção IV – Quanto ao Gerenciamento de Riscos e Segurança

###### Art. 35 {#art35}
Tags: #biodigestor #biogas

**Art. 35, caput** {#art35_cpt} Devem ser previstas e implementadas medidas de segurança na operação dos biodigestores e manuseio do biogás.

**Art. 35, parágrafo único** {#art35_par1u} Recomenda-se, ainda, que medidas adicionais de segurança sejam adotadas, conforme preconiza a Instrução Técnica IAT/SEDEST "Guia de Segurança para Implantação e Operação de Biodigestores".

#### Seção V – Quanto ao transporte de efluentes líquidos e/ou resíduos sólidos

###### Art. 36 {#art36}
Tags: #biodigestor #biogas #enquadramento #residuo-solido

**Art. 36, caput** {#art36_cpt} #enquadramento Para transporte da materia orgânica provenientes de cada unidade geradora, para tratamento em uma unidade de biodigestão - (Biodigestor Tipo IV), deverá ser solicitada Autorização Ambiental ao IAT, em conformidade com a [[portaria-iap-212-2019|Portaria IAP 212/2019]] ou outra que vier substituí-la.

**Art. 36, parágrafo único** {#art36_par1u} #enquadramento #residuo-solido Fica isento de Autorização Ambiental o transporte de resíduos gerados em atividades agropecuárias para tratamento em Biodigestores Tipo IV.

###### Art. 37 {#art37}
Tags: #biodigestor #biogas #enquadramento #residuo-solido

**Art. 37, caput** {#art37_cpt} #enquadramento #residuo-solido O transporte e utilização agrícola dos resíduos sólidos proveniente de unidade de biodigestão que receber resíduos de empreendimentos de saneamento, deverá atender aos critérios estabelecidos pela [[resolucao-sema-21-2009|Resolução SEMA 021/2009]] ou outra que vier a substituí-la, bem como deverá ser solicitada Autorização Ambiental ao IAT, em conformidade com a [[portaria-iap-212-2019|Portaria IAP 212/2019]] ou outra que vier a substituí-la.

###### Art. 38 {#art38}
Tags: #biodigestor #biogas #efluente #enquadramento #residuo-solido

**Art. 38, caput** {#art38_cpt} #efluente #enquadramento #residuo-solido O transportador responsável pelo transporte de efluentes líquidos e/ou resíduos sólidos entre o gerador e a unidade de tratamento/destinação final, deverá estar devidamente licenciado pelo órgão ambiental competente.

### CAPÍTULO III – ASPECTOS LOCACIONAIS

###### Art. 39 {#art39}
Tags: #app #biodigestor #biogas

**Art. 39, caput** {#art39_cpt} A implantação de Biodigestores quanto à localização, deverá atender, no mínimo, os seguintes critérios:
- **Art. 39, caput, inciso I** {#art39_cpt_inc1} #app A área do empreendimento, deve situar-se a uma distância mínima de corpos hídricos, de modo a não atingir áreas de preservação permanente, conforme estabelecido no Código Florestal;
- **Art. 39, caput, inciso II** {#art39_cpt_inc2} A área do empreendimento, incluindo armazenagem, tratamento e destinação final de dejetos, deve situar-se a uma distância mínima conforme estabelecido no Código Sanitário do Estado;
- **Art. 39, caput, inciso III** {#art39_cpt_inc3} Para a localização das construções de biodigestores devem ser consideradas as condições ambientais da área e do seu entorno, bem como, a direção predominante dos ventos na região, de forma a impedir a propagação de odores para cidades, núcleos populacionais e habitações mais próximas.

### CAPÍTULO IV – DISPOSIÇÕES GERAIS

###### Art. 40 {#art40}
Tags: #biodigestor #biogas #licenciamento-ambiental

**Art. 40, caput** {#art40_cpt} #licenciamento-ambiental A presente Resolução também se aplica ao licenciamento de biodigestores Tipo III e IV sem aproveitamento energético do biogás.

###### Art. 41 {#art41}
Tags: #biodigestor #biogas #responsavel-tecnico

**Art. 41, caput** {#art41_cpt} #responsavel-tecnico Quando da necessidade da manifestação de órgãos intervenientes externos ao órgão licenciador, tais como FUNAI, INCRA, IPHAN, ICMBio, CEPHA, DNIT, DER, entre outros, será seguido o procedimento conforme estabelece os Art. 11, 12 e 13 da [[resolucao-cema-107-2020|Resolução CEMA nº107/2020]].

###### Art. 42 {#art42}
Tags: #biodigestor #biogas #licenciamento-ambiental #prazo

**Art. 42, caput** {#art42_cpt} #licenciamento-ambiental #prazo Constatada a existência de pendência judicial envolvendo o empreendedor, o empreendimento ou o imóvel, a decisão administrativa sobre a eventual suspensão do licenciamento será precedida de manifestação jurídica do órgão ambiental competente no prazo máximo de 30 (trinta) dias.

###### Art. 43 {#art43}
Tags: #biodigestor #biogas #prazo

**Art. 43, caput** {#art43_cpt} #prazo Esta Resolução deverá ser reavaliada a cada 04 (quatro) anos ou a qualquer tempo, quando o órgão ambiental considerar necessário.

###### Art. 44 {#art44}
Tags: #biodigestor #biogas

**Art. 44, caput** {#art44_cpt} O não cumprimento do disposto nesta Resolução sujeitará os infratores às sanções previstas nas Leis Federais nº 6.938 de 31 de agosto de 1981, nº 9.605 de 12 de fevereiro de 1998 e seus decretos regulamentadores.

###### Art. 45 {#art45}
Tags: #biodigestor #biogas

**Art. 45, caput** {#art45_cpt} Esta Resolução entra em vigor na data de sua publicação. Curitiba, 23 de fevereiro de 2021. Márcio Nunes Secretário de Estado do Turismo Este texto não substitui o publicado no Diário Oficial do Estado ANEXOS: Arquivo                                                     Observações anexo245464_57704.pdf anexo245464_57705.pdf


### Certidão municipal {#anexo1}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência — Memorial de caracterização do empreendimento - MCE {#anexo2}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência — Plano de gerenciamento de resíduos sólidos - PGRS {#anexo6}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Declaração de verdade das informações prestadas {#anexo7}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Declaração do empreendedor pelo Licenciamento por Adesão e Compromisso {#anexo8}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Declaração do responsável técnico pelo licenciamento por Adesão e Compromisso {#anexo9}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência — Projeto de Utilização Agrícola do digestato {#anexo10}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Anuência do proprietário para utilização agrícola do digestato {#anexo11}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|
| [[decreto-estadual-9541-2025]] | Norma inteira | Revogação expressa registrada no acervo. |

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (sedest 08 2021(1).pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- Anexo próprio citado ou vinculado em arquivo separado, sem o respectivo conteúdo no PDF do lote. Não foi importado material externo ou presumida sua redação.
- Os Anexos III, IV e V não tiveram conteúdo ou título identificável no texto lido; não foram inventados a partir da sequência de numeração.
- Quadros no corpo devem ser conferidos visualmente; números, colunas e células mescladas ainda não estão certificados. Não utilizar este rascunho para enquadramento antes da revisão.
- Situação revogada conforme relação expressa já cadastrada no acervo: [[decreto-estadual-9541-2025]]. Regras de transição e processos antigos devem ser avaliados separadamente.
