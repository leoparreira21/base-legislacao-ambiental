---
norma: "Resolução CONAMA nº 335/2003"
arquivo: resolucao-conama-335-2003
tipo: resolucao
esfera: federal
uf: BR
numero: 335
ano: 2003
data_assinatura: 2003-04-03
ementa: "Dispõe sobre o licenciamento ambiental de cemitérios."
situacao: vigente
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: ["[[resolucao-conama-368-2006]]", "[[resolucao-conama-402-2008]]"]
revoga: []
revogado_por: []
cita: ["[[decreto-federal-99274-1990]]", "[[lei-federal-6938-1981]]", "[[lei-federal-9605-1998]]", "[[portaria-mma-168-2005]]", "[[portaria-mma-499-2002]]", "[[resolucao-conama-368-2006]]", "[[resolucao-conama-402-2008]]"]
tags: ["agua-subterranea", "app", "cemiterio", "definicao", "documentacao", "efluente", "eia-rima", "incluido", "li", "licenciamento-ambiental", "lp", "proibicao", "redacao-alterada", "residuo-solido", "responsavel-tecnico"]
fonte: "PDF fornecido: conama 335 2005.pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
texto: "compilado segundo as alterações explícitas no PDF fornecido; conferência visual pendente"
---

# Resolução CONAMA nº 335/2003

> Dispõe sobre o licenciamento ambiental de cemitérios.

## Preâmbulo

RESOLUÇÃO CONAMA nº 335, de 3 de abril de 2003 Publicada no DOU no 101, de 28 de maio de 2003, Seção 1, páginas 98-99 Correlações: · Alterada pela [[resolucao-conama-368-2006|Resolução CONAMA no 368/06]] (alterados os arts. 3o e 5o, revogado o inciso III, do § 3o, do art. 3o) · Alterada pela [[resolucao-conama-402-2008|Resolução nº 402/08]] (alterados os arts 11 e 12) Dispõe sobre o licenciamento ambiental de cemitérios. O CONSELHO NACIONAL DO MEIO AMBIENTE-CONAMA, no uso das atribuições que lhe são conferidas pela [[lei-federal-6938-1981|Lei no 6.938, de 31 de agosto de 1981]], regulamentada pelo [[decreto-federal-99274-1990|Decreto no 99.274, de 6 de junho de 1990]], e tendo em vista o disposto em seu Regimento Interno, anexo à [[portaria-mma-499-2002|Portaria no 499, de 18 de dezembro de 2002]]200, e Considerando a necessidade de regulamentação dos aspectos essenciais relativos ao processo de licenciamento ambiental de cemitérios; Considerando o respeito às práticas e valores religiosos e culturais da população; e Considerando que as Resoluções CONAMA nos 1, de 23 de janeiro de 1986 e 237, de 19 de dezembro de 1997, indicam as atividades ou empreendimentos sujeitos ao licencia-mento ambiental e remetem ao órgão ambiental competente a incumbência de definir os critérios de exigibilidade, o detalhamento, observadas as especificidades, os riscos ambientais e outras características da atividade ou empreendimento, visando a obtenção de licença ambiental; Considerando que o art. 12, da Resolução CONAMA no 237, de 1997, permite a criação de critérios para agilizar e simplificar os procedimentos de licenciamento ambiental das atividades e empreendimentos similares, visando a melhoria contínua e o aprimoramento da gestão ambiental, resolve:

###### Art. 1º {#art1}
Tags: #cemiterio #licenciamento-ambiental

**Art. 1º, caput** {#art1_cpt} #licenciamento-ambiental Os cemitérios horizontais e os cemitérios verticais, doravante denominados cemitérios, deverão ser submetidos ao processo de licenciamento ambiental, nos termos desta Resolução, sem prejuízo de outras normas aplicáveis à espécie.

###### Art. 2º {#art2}
Tags: #cemiterio #definicao #licenciamento-ambiental

**Art. 2º, caput** {#art2_cpt} #definicao Para efeito desta Resolução serão adotadas as seguintes definições:
- **Art. 2º, caput, inciso I** {#art2_cpt_inc1} cemitério: área destinada a sepultamentos;
  - **Art. 2º, caput, inciso I, alínea "a"** {#art2_cpt_inc1_alia} cemitério horizontal: é aquele localizado em área descoberta compreendendo os tradicionais e o do tipo parque ou jardim;
  - **Art. 2º, caput, inciso I, alínea "b"** {#art2_cpt_inc1_alib} cemitério parque ou jardim: é aquele predominantemente recoberto por jardins, isento de construções tumulares, e no qual as sepulturas são identificadas por uma lápide, ao nível do chão, e de pequenas dimensões;
  - **Art. 2º, caput, inciso I, alínea "c"** {#art2_cpt_inc1_alic} cemitério vertical: é um edifício de um ou mais pavimentos dotados de comparti-mentos destinados a sepultamentos; e
  - **Art. 2º, caput, inciso I, alínea "d"** {#art2_cpt_inc1_alid} cemitérios de animais: cemitérios destinados a sepultamentos de animais.
- **Art. 2º, caput, inciso II** {#art2_cpt_inc2} sepultar ou inumar: é o ato de colocar pessoa falecida, membros amputados e restos mortais em local adequado;
- **Art. 2º, caput, inciso III** {#art2_cpt_inc3} sepultura: espaço unitário, destinado a sepultamentos;
- **Art. 2º, caput, inciso IV** {#art2_cpt_inc4} construção tumular: é uma construção erigida em uma sepultura, dotada ou não de compartimentos para sepultamento, compreendendo-se:
  - **Art. 2º, caput, inciso IV, alínea "a"** {#art2_cpt_inc4_alia} jazigo: é o compartimento destinado a sepultamento contido;
  - **Art. 2º, caput, inciso IV, alínea "b"** {#art2_cpt_inc4_alib} carneiro ou gaveta: é a unidade de cada um dos compartimentos para sepultamentos existentes em uma construção tumular; e
  - **Art. 2º, caput, inciso IV, alínea "c"** {#art2_cpt_inc4_alic} cripta: compartimento destinado a sepultamento no interior de edificações, templos ou suas dependências.
- **Art. 2º, caput, inciso V** {#art2_cpt_inc5} lóculo: é o compartimento destinado a sepultamento contido no cemitério ver-tical; 200 Portaria revogada pela [[portaria-mma-168-2005|Portaria MMA no 168, de 10 de junho de 2005]].
- **Art. 2º, caput, inciso VI** {#art2_cpt_inc6} produto da coliqüação: é o líquido biodegradável oriundo do processo de decom-posição dos corpos ou partes;
- **Art. 2º, caput, inciso VII** {#art2_cpt_inc7} exumar: retirar a pessoa falecida, partes ou restos mortais do local em que se acha sepultado;
- **Art. 2º, caput, inciso VIII** {#art2_cpt_inc8} reinumar: reintroduzir a pessoa falecida ou seus restos mortais, após exumação, na mesma sepultura ou em outra;
- **Art. 2º, caput, inciso IX** {#art2_cpt_inc9} urna, caixão, ataúde ou esquife: é a caixa com formato adequado para conter pessoa falecida ou partes;
- **Art. 2º, caput, inciso X** {#art2_cpt_inc10} urna ossuária: é o recipiente de tamanho adequado para conter ossos ou partes de corpos exumados;
- **Art. 2º, caput, inciso XI** {#art2_cpt_inc11} urna cinerária: é o recipiente destinado a cinzas de corpos cremados;
- **Art. 2º, caput, inciso XII** {#art2_cpt_inc12} ossuário ou ossário - é o local para acomodação de ossos, contidos ou não em urna ossuária;
- **Art. 2º, caput, inciso XIII** {#art2_cpt_inc13} cinerário: é o local para acomodação de urnas cinerárias;
- **Art. 2º, caput, inciso XIV** {#art2_cpt_inc14} columbário: é o local para guardar urnas e cinzas funerárias, dispostos horizontal e verticalmente, com acesso coberto ou não, adjacente ao fundo, com um muro ou outro conjunto de jazigos;
- **Art. 2º, caput, inciso XV** {#art2_cpt_inc15} nicho: é o local para colocar urnas com cinzas funerárias ou ossos; e
- **Art. 2º, caput, inciso XVI** {#art2_cpt_inc16} translado: ato de remover pessoa falecida ou restos mortais de um lugar para outro.

###### Art. 3º {#art3}
Tags: #agua-subterranea #app #cemiterio #documentacao #licenciamento-ambiental #lp #proibicao
Alterações: [[resolucao-conama-368-2006|resolucao-conama-368-2006]] (nova redação: § 1º)

**Art. 3º, caput** {#art3_cpt} #documentacao #licenciamento-ambiental #lp Na fase de Licença Prévia do licenciamento ambiental, deverão ser apresentados, dentre outros, os seguintes documentos:
- **Art. 3º, caput, inciso I** {#art3_cpt_inc1} caracterização da área na qual será implantado o empreendimento, compreen-dendo:
  - **Art. 3º, caput, inciso I, alínea "a"** {#art3_cpt_inc1_alia} localização tecnicamente identificada no município, com indicação de acessos, sistema viário, ocupação e benfeitorias no seu entorno;
  - **Art. 3º, caput, inciso I, alínea "b"** {#art3_cpt_inc1_alib} levantamento topográfico planialtimétrico e cadastral, compreendendo o mape-amento de restrições contidas na legislação ambiental, incluindo o mapeamento e a caracterização da cobertura vegetal;
  - **Art. 3º, caput, inciso I, alínea "c"** {#art3_cpt_inc1_alic} #agua-subterranea estudo demonstrando o nível máximo do aqüífero freático (lençol freático), ao final da estação de maior precipitação pluviométrica; e
  - **Art. 3º, caput, inciso I, alínea "d"** {#art3_cpt_inc1_alid} sondagem mecânica para caracterização do subsolo em número adequado à área e características do terreno considerado.
- **Art. 3º, caput, inciso II** {#art3_cpt_inc2} plano de implantação e operação do empreendimento.

**Art. 3º, § 1º** {#art3_par1} #redacao-alterada #app #proibicao É proibida a instalação de cemitérios em Áreas de Preservação Permanente ou em outras que exijam desmatamento de Mata Atlântica primária ou secundária, em estágio médio ou avançado de regeneração, em terrenos predominantemente cársticos, que apre-sentam cavernas, sumidouros ou rios subterrâneos, bem como naquelas que tenham seu uso restrito pela legislação vigente, ressalvadas as exceções legais previstas. *(nova redação dada pela [[resolucao-conama-368-2006|Resolução n° 368/06]])*

**Art. 3º, § 2º** {#art3_par2} #lp A critério do órgão ambiental competente, as fases de licença Prévia e de Insta-lação poderão ser conjuntas.

**Art. 3º, § 3º** {#art3_par3} Excetuam-se do previsto no parágrafo anterior deste artigo, cemitérios horizontais que:
- **Art. 3º, § 3º, inciso I** {#art3_par3_inc1} ocupem área maior que cinqüenta hectares;
- **Art. 3º, § 3º, inciso II** {#art3_par3_inc2} localizem-se em Áreas de Proteção Ambiental-APA’s, na faixa de proteção de Uni-dades de Conservação de Uso Integral, Reservas Particulares de Patrimônio Natural e Monumento Natural;
- **Art. 3º, § 3º, inciso III** {#art3_par3_inc3} localizem-se em terrenos predominantemente cársticos, que apresentam cavernas, sumidouros ou rios subterrâneos; (revogado pela [[resolucao-conama-368-2006|Resolução n° 368/06]]) e
- **Art. 3º, § 3º, inciso IV** {#art3_par3_inc4} localizem-se em áreas de manancial para abastecimento humano.

###### Art. 4º {#art4}
Tags: #cemiterio #documentacao #li #licenciamento-ambiental

**Art. 4º, caput** {#art4_cpt} #documentacao #li #licenciamento-ambiental Na fase de Licença de Instalação do licenciamento ambiental, deverão ser apresentados, entre outros, os seguintes documentos:
- **Art. 4º, caput, inciso I** {#art4_cpt_inc1} #documentacao projeto do empreendimento que deverá conter plantas, memoriais e documentos assinados por profissional habilitado; e
- **Art. 4º, caput, inciso II** {#art4_cpt_inc2} projeto executivo contemplando as medidas de mitigação e de controle ambien-tal.

###### Art. 5º {#art5}
Tags: #agua-subterranea #cemiterio #documentacao #eia-rima #licenciamento-ambiental
Alterações: [[resolucao-conama-368-2006|resolucao-conama-368-2006]] (nova redação: inciso I; incluído: § 1º, § 1º, inciso I, § 1º, inciso II, § 1º, inciso III, § 2º)

**Art. 5º, caput** {#art5_cpt} Deverão ser atendidas, entre outras, as seguintes exigências para os cemitérios horizontais:
- **Art. 5º, caput, inciso I** {#art5_cpt_inc1} #redacao-alterada #agua-subterranea #eia-rima o nível inferior das sepulturas deverá estar a uma distância de pelo menos um metro e meio acima do mais alto nível do lençol freático, medido no fim da estação das cheias. *(nova redação dada pela [[resolucao-conama-368-2006|Resolução n°368/06]])*
- **Art. 5º, caput, inciso II** {#art5_cpt_inc2} nos terrenos onde a condição prevista no inciso anterior não puder ser atendida, os sepultamentos devem ser feitos acima do nível natural do terreno;
- **Art. 5º, caput, inciso III** {#art5_cpt_inc3} adotar-se-ão técnicas e práticas que permitam a troca gasosa, proporcionando, assim, as condições adequadas à decomposição dos corpos, exceto nos casos específicos previstos na legislação;
- **Art. 5º, caput, inciso IV** {#art5_cpt_inc4} a área de sepultamento deverá manter um recuo mínimo de cinco metros em relação ao perímetro do cemitério, recuo que deverá ser ampliado, caso necessário, em função da caracterização hidrogeológica da área;
- **Art. 5º, caput, inciso V** {#art5_cpt_inc5} #documentacao documento comprobatório de averbação da Reserva Legal, prevista em Lei; e
- **Art. 5º, caput, inciso VI** {#art5_cpt_inc6} estudos de fauna e flora para empreendimentos acima de 100 (cem) hectares.

**Art. 5º, § 1º** {#art5_par1} #incluido Para os cemitérios horizontais, em áreas de manancial para abastecimento humano, devido às características especiais dessas áreas, deverão ser atendidas, além das exigências dos incisos de I a VI, as seguintes: *(paragrafo acrescentado pela [[resolucao-conama-368-2006|Resolução n° 368/06]])*
- **Art. 5º, § 1º, inciso I** {#art5_par1_inc1} #incluido a área prevista para a implantação do cemitério deverá estar a uma distância segu-ra de corpos de água, superficiais e subterrâneos, de forma a garantir sua qualidade, de acordo com estudos apresentados e a critério do órgão licenciador; *(inciso acrescentado pela [[resolucao-conama-368-2006|Resolução n° 368/06]])*
- **Art. 5º, § 1º, inciso II** {#art5_par1_inc2} #incluido o perímetro e o interior do cemitério deverão ser providos de um sistema de dre-nagem adequado e eficiente, destinado a captar, encaminhar e dispor de maneira segura o escoamento das águas pluviais e evitar erosões, alagamentos e movimentos de terra; *(inciso acrescentado pela [[resolucao-conama-368-2006|Resolução n° 368/06]])*
- **Art. 5º, § 1º, inciso III** {#art5_par1_inc3} #incluido #agua-subterranea #eia-rima o subsolo da área pretendida para o cemitério deverá ser constituído por materiais com coeficientes de permeabilidade entre 10 -5 e 10 -7 cm/s, na faixa compreendida entre o fundo das sepulturas e o nível do lençol freático, medido no fim da estação das cheias. Para permeabilidades maiores, é necessário que o nível inferior dos jazigos esteja dez metros acima do nível do lençol freático. *(inciso acrescentado pela [[resolucao-conama-368-2006|Resolução n° 368/06]])*

**Art. 5º, § 2º** {#art5_par2} #incluido #documentacao A critério do órgão ambiental competente, poderão ser solicitadas informações e documentos complementares em consonância com exigências legais específicas de caráter local. *(paragrafo acrescentado pela [[resolucao-conama-368-2006|Resolução n°368/06]])*

###### Art. 6º {#art6}
Tags: #cemiterio #efluente #licenciamento-ambiental

**Art. 6º, caput** {#art6_cpt} Deverão ser atendidas as seguintes exigências para os cemitérios verticais:
- **Art. 6º, caput, inciso I** {#art6_cpt_inc1} os lóculos devem ser constituídos de:
  - **Art. 6º, caput, inciso I, alínea "a"** {#art6_cpt_inc1_alia} materiais que impeçam a passagem de gases para os locais de circulação dos visi-tantes e trabalhadores;
  - **Art. 6º, caput, inciso I, alínea "b"** {#art6_cpt_inc1_alib} acessórios ou características construtivas que impeçam o vazamento dos líquidos oriundos da coliqüação;
  - **Art. 6º, caput, inciso I, alínea "c"** {#art6_cpt_inc1_alic} dispositivo que permita a troca gasosa, em todos os lóculos, proporcionando as condições adequadas para a decomposição dos corpos, exceto nos casos específicos previstos na legislação; e
  - **Art. 6º, caput, inciso I, alínea "d"** {#art6_cpt_inc1_alid} #efluente tratamento ambientalmente adequado para os eventuais efluentes gasosos.

###### Art. 7º {#art7}
Tags: #cemiterio #licenciamento-ambiental

**Art. 7º, caput** {#art7_cpt} Os columbários destinados ao sepultamento de corpos deverão atender ao disposto nos arts. [[#art4|4o]] e [[#art5|5o]] , no que couber.

###### Art. 8º {#art8}
Tags: #cemiterio #licenciamento-ambiental #proibicao

**Art. 8º, caput** {#art8_cpt} Os corpos sepultados poderão estar envoltos por mantas ou urnas constituídas de materiais biodegradáveis, não sendo recomendado o emprego de plásticos, tintas, vernizes, metais pesados ou qualquer material nocivo ao meio ambiente.

**Art. 8º, parágrafo único** {#art8_par1u} #proibicao Fica vedado o emprego de material impermeável que impeça a tro-ca gasosa do corpo sepultado com o meio que o envolve, exceto nos casos específicos previstos na legislação.

###### Art. 9º {#art9}
Tags: #cemiterio #licenciamento-ambiental #residuo-solido

**Art. 9º, caput** {#art9_cpt} #residuo-solido Os resíduos sólidos, não humanos, resultantes da exumação dos corpos deverão ter destinação ambiental e sanitariamente adequada.

###### Art. 10 {#art10}
Tags: #cemiterio #licenciamento-ambiental

**Art. 10, caput** {#art10_cpt} O procedimento desta Resolução poderá ser simplificado, a critério do órgão ambiental competente, após aprovação dos respectivos Conselhos de Meio Ambiente, se atendidas todas as condições abaixo:
- **Art. 10, caput, inciso I** {#art10_cpt_inc1} cemitérios localizados em municípios com população inferior a trinta mil habi-tantes;
- **Art. 10, caput, inciso II** {#art10_cpt_inc2} cemitérios localizados em municípios isolados, não integrantes de área conurbada ou região metropolitana; e
- **Art. 10, caput, inciso III** {#art10_cpt_inc3} cemitérios com capacidade máxima de quinhentos jazigos.

###### Art. 11 {#art11}
Tags: #cemiterio #licenciamento-ambiental
Alterações: [[resolucao-conama-402-2008|resolucao-conama-402-2008]] (nova redação: caput)

**Art. 11, caput** {#art11_cpt} #redacao-alterada Os órgãos estaduais e municipais de meio ambiente deverão estabelecer até dezembro de 2010 critérios para adequação dos cemitérios existentes em abril de 2003. *(nova redação dada pela [[resolucao-conama-402-2008|Resolução nº 402/08]])*

###### Art. 12 {#art12}
Tags: #cemiterio #licenciamento-ambiental
Alterações: [[resolucao-conama-402-2008|resolucao-conama-402-2008]] (nova redação: caput)

**Art. 12, caput** {#art12_cpt} #redacao-alterada O Plano de Encerramento das atividades deverá constar do processo de licencia-mento ambiental, nele incluindo medidas de recuperação da área atingida e indenização de possíveis vítimas. *(nova redação dada pela [[resolucao-conama-402-2008|Resolução nº 402/08]])*

**Art. 12, parágrafo único** {#art12_par1u} Em caso de desativação da atividade, a área deverá ser utilizada, prioritariamente, para parque público ou para empreendimentos de utilidade pública ou interesse social.

###### Art. 13 {#art13}
Tags: #cemiterio #licenciamento-ambiental

**Art. 13, caput** {#art13_cpt} Sempre que julgar necessário, ou quando for solicitado por entidade civil, pelo Ministério Público, ou por cinqüenta cidadãos, o órgão de meio ambiente competente promoverá Reunião Técnica Informativa.

**Art. 13, parágrafo único** {#art13_par1u} Na Reunião Técnica Informativa é obrigatório o comparecimento do empreendedor, da equipe responsável pela elaboração do Relatório Ambiental e de representantes do órgão ambiental competente.

###### Art. 14 {#art14}
Tags: #cemiterio #licenciamento-ambiental #responsavel-tecnico

**Art. 14, caput** {#art14_cpt} #responsavel-tecnico O descumprimento das disposições desta Resolução, dos termos das Licenças Ambientais e de eventual Termo de Ajustamento de Conduta, sujeitará o infrator às pe-nalidades previstas na [[lei-federal-9605-1998|Lei no 9.605, de 12 de fevereiro de 1998]], e em outros dispositivos normativos pertinentes, sem prejuízo do dever de recuperar os danos ambientais causados, na forma do art. 14, § 1o, da [[lei-federal-6938-1981|Lei no 6.938, de 31 de agosto de 1981]].

###### Art. 15 {#art15}
Tags: #cemiterio #licenciamento-ambiental

**Art. 15, caput** {#art15_cpt} Além das sanções penais e administrativas cabíveis, bem como da multa diária e outras obrigações previstas no Termo de Ajustamento de Conduta e na legislação vigente, o órgão ambiental competente, mediante decisão motivada, poderá exigir a imediata re-paração dos danos causados, bem como a mitigação dos riscos, desocupação, isolamento e/ou recuperação da área do empreendimento.

###### Art. 16 {#art16}
Tags: #cemiterio #documentacao #licenciamento-ambiental

**Art. 16, caput** {#art16_cpt} #documentacao #licenciamento-ambiental Os subscritores de estudos, documentos, pareceres e avaliações técnicas uti-lizados no procedimento de licenciamento e de celebração do Termo de Ajustamento de Conduta são considerados peritos, para todos os fins legais.

###### Art. 17 {#art17}
Tags: #cemiterio #licenciamento-ambiental

**Art. 17, caput** {#art17_cpt} As obrigações previstas nas licenças ambientais e no Termo de Ajustamento de Conduta são consideradas de relevante interesse ambiental.

###### Art. 18 {#art18}
Tags: #cemiterio #licenciamento-ambiental

**Art. 18, caput** {#art18_cpt} Esta Resolução entra em vigor na data de sua publicação.


## Fecho

MARINA SILVA - Presidente do Conselho Este texto não substitui o publicado no DOU, de 28 de maio de 2003.


## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|
| [[resolucao-conama-368-2006]] | Ver anotações no corpo | Alteração indicada no PDF; conferência pendente. |
| [[resolucao-conama-402-2008]] | Ver anotações no corpo | Alteração indicada no PDF; conferência pendente. |

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (conama 335 2005.pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- O arquivo recebido se chama conama 335 2005.pdf, mas seu título e data identificam a Resolução CONAMA nº 335, de 3 de abril de 2003. Adotados os dados do texto publicado. Há redações sucessivas: últimas redações explícitas mantidas, com conferência visual pendente.
- Redações anteriores de artigos repetidos foram excluídas desta versão compilada, conforme o padrão do acervo; estão preservadas na extração da fonte que acompanha o lote.
- Revisão de numeração: sequência de inciso: art5_cpt_inc1 após art5_cpt_inc1. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
