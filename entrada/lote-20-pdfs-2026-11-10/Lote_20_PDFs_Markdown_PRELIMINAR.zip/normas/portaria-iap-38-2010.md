---
norma: "Portaria IAP nº 038/2010"
arquivo: portaria-iap-38-2010
tipo: portaria
esfera: estadual
uf: PR
numero: 38
ano: 2010
data_assinatura: 2010-03-03
ementa: "Critérios para composição e qualificação de equipe técnica multidisciplinar de consultores e empresas de consultoria ambiental responsáveis por EIA/RIMA."
situacao: vigente
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: []
revoga: []
revogado_por: []
cita: ["[[decreto-estadual-1502-1992]]", "[[decreto-estadual-77-2007]]", "[[lei-estadual-10066-1992]]", "[[lei-estadual-15608-2007]]", "[[lei-federal-6938-1981]]", "[[resolucao-cema-65-2008]]", "[[resolucao-conama-1-1988]]"]
tags: ["definicao", "documentacao", "eia-rima", "licenciamento-ambiental", "prazo", "proibicao", "responsavel-tecnico"]
fonte: "PDF fornecido: portaria IAP 38 2010.pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
---

# Portaria IAP nº 038/2010

> Critérios para composição e qualificação de equipe técnica multidisciplinar de consultores e empresas de consultoria ambiental responsáveis por EIA/RIMA.

## Preâmbulo

PORTARIA IAP Nº 038, DE 03 DE MARÇO DE 2010 O Diretor Presidente do Instituto Ambiental do Paraná – IAP, nomeado pelo [[decreto-estadual-77-2007|Decreto n° 077 de 12 de fevereiro de 2007]], no uso das atribuições que lhe são conferidas pela [[lei-estadual-10066-1992|Lei Estadual n° 10.066, de 27 de julho de 1992]], com as alterações trazidas pelas Leis n° 11.352, de 13 de fevereiro de 1996 e n° 13.425, de 07 de janeiro de 2002 e de acordo com o seu Regulamento, aprovado pelo [[decreto-estadual-1502-1992|Decreto n° 1.502, de 04 de agosto de 1992]], RESOLVE:

###### Art. 1º {#art1}
Tags: #eia-rima #responsavel-tecnico

**Art. 1º, caput** {#art1_cpt} #eia-rima Estabelecer critérios para composição e qualificação de Equipe Técnica Multidisciplinar de Consultores e Empresas de Consultoria Ambiental, responsáveis pela elaboração de Estudos Prévios de Impacto Ambiental e Relatórios de Impacto sobre o Meio Ambiente, conforme segue.

### Capítulo I – Da Conceituação Geral

###### Art. 2º {#art2}
Tags: #documentacao #eia-rima #responsavel-tecnico

**Art. 2º, caput** {#art2_cpt} #documentacao #eia-rima O Estudo Prévio de Impacto Ambiental – EPIA constitui-se em documento técnico-científico, jurídico e administrativo, que tem como finalidade avaliar os impactos ambientais gerados por atividades e/ou empreendimentos potencialmente poluidores ou que possam causar degradação ambiental. Destina-se, ainda, a propor medidas mitigadoras e de controle ambiental, e garantir o uso sustentável dos recursos naturais.

###### Art. 3º {#art3}
Tags: #definicao #eia-rima #responsavel-tecnico

**Art. 3º, caput** {#art3_cpt} #definicao A avaliação de um EPIA não dever ficar restrita a mera formalidade de conferência de resposta, certa ou errada, às diretrizes definidas pelo Órgão Ambiental Estadual e repassadas ao empreendedor e equipe de consultores. Essa análise deverá responder cinco grandes questões:
- **Art. 3º, caput, inciso I** {#art3_cpt_inc1} Efetiva sustentabilidade econômica, social, cultural e ambientalmente do empreendimento;
- **Art. 3º, caput, inciso II** {#art3_cpt_inc2} Existência de alternativas para obtenção os produtos / serviços oriundos da implantação do empreendimento, sem que seja necessário provocar impactos ambientais;
- **Art. 3º, caput, inciso III** {#art3_cpt_inc3} Eliminação ou minimização dos impactos negativos;
- **Art. 3º, caput, inciso IV** {#art3_cpt_inc4} Se não evitáveis ou minimizáveis, indicação de medidas mitigatórias e/ou compensatórias que devam ser adotadas para que tais impactos sejam os menores possíveis;
- **Art. 3º, caput, inciso V** {#art3_cpt_inc5} Indicação e comentários sobre eventuais impactos ambientais irreversíveis.

### Capítulo II – Da Equipe Técnica Multidisciplinar

###### Art. 4º {#art4}
Tags: #eia-rima #responsavel-tecnico

**Art. 4º, caput** {#art4_cpt} #eia-rima Para que as respostas aos Incisos do Artigo 2o, o EPIA e o RIMA devem ser elaborados e apresentados ao Órgão Ambiental Licenciador, por uma Equipe Técnica mínima multidisciplinar composta por profissionais com formação, conhecimento e qualificação, para cada fragmento ambiental (meios físico, biótico e sócio-econômico) e a natureza do empreendimento, abrangendo todos os aspectos ambientais envolvidos no empreendimento.

###### Art. 5º {#art5}
Tags: #eia-rima #responsavel-tecnico

**Art. 5º, caput** {#art5_cpt} #eia-rima A equipe técnica multidisciplinar, com capacitação técnica compatível com as características do empreendimento / atividade, deve ter independência prevista em contrato celebrado com o empreendedor para elaboração do EPIA / RIMA.

###### Art. 6º {#art6}
Tags: #eia-rima #responsavel-tecnico

**Art. 6º, caput** {#art6_cpt} #eia-rima Devido a importância, profundidade das análises e repercussões sobre a vida humana e aos recursos ambientais, a independência de manifestação da equipe técnica encarregada da elaboração do EPIA / RIMA deve atender aos mesmos princípios aplicáveis à administração pública direta e indireta, dispostos no Artigo 37 da Constituição Federal de 1988: princípios de legalidade, impessoalidade, moralidade, publicidade e eficiência e, também, ao seguinte:
- **Art. 6º, caput, inciso I** {#art6_cpt_inc1} Vedação à participação, como integrantes e/ou orientadores e/ou consultores permanentes e temporários, em Equipes Técnicas Multidisciplinares e/ou Empresas Privadas de Consultoria Técnica Ambiental, de Servidores Públicos da Esfera Federal, Estadual e Municipal, à exceção daqueles que integram os Quadros Próprios de Professores / Pesquisadores de Universidades Públicas. A proibição de acumular estende-se, também, a empregados e qualquer pessoa física que desempenhe funções, mesmo que comissionada, em autarquias, fundações, empresas públicas, sociedades de economia mista, suas subsidiárias, e sociedades controladas, direta ou indiretamente, pelo poder público;
- **Art. 6º, caput, inciso II** {#art6_cpt_inc2} #eia-rima Não podem integrar / participar da elaboração de EPIA / RIMA, profissionais técnicos que integram o quadro de Servidores / Empregados de Órgãos Públicos integrantes do SISNAMA, mesmo que estejam em licença prêmio, férias e/ou licença especial com ou sem remuneração;
- **Art. 6º, caput, inciso III** {#art6_cpt_inc3} #eia-rima As pessoas jurídicas de direito público e as de direito privado integrante de Equipes Multidisciplinares responsáveis para elaboração de EPIA / RIMA e/ou que, a qualquer tempo prestem serviços de consultoria técnica às Empresas de Consultoria contratadas para tal finalidade, responderão pelos danos que seus agentes, nessa qualidade, causarem a terceiros, assegurado o direito de regresso contra o responsável nos casos de dolo ou culpa.

###### Art. 7º {#art7}
Tags: #eia-rima #responsavel-tecnico

**Art. 7º, caput** {#art7_cpt} Os Profissionais e/ou Equipes Técnicas Multidisciplinares (Empresas de Consultoria Ambiental), sejam pessoas físicas e/ou jurídicas, que vierem a elaborar EPIA / RIAM, devem estar previamente cadastradas junto ao Instituto Ambiental do Paraná - IAP, conforme previsto no Artigo 21 da [[resolucao-cema-65-2008|Resolução CEMA No. 065/2008]].

**Art. 7º, parágrafo único** {#art7_par1u} Os profissionais independentes e aqueles integrantes da Equipe Técnica de Consultores, deverá estar devidamente registrados junto ao respectivo Conselho Profissional e junto ao Cadastro Técnico Federal de Atividades e Instrumentos de Defesa do Meio Ambiente, conforme [[lei-federal-6938-1981|Lei Federal No. 6.938/1981]] e [[resolucao-conama-1-1988|Resolução CONAMA No. 001/88]].

###### Art. 8º {#art8}
Tags: #eia-rima #responsavel-tecnico

**Art. 8º, caput** {#art8_cpt} #eia-rima As pessoas físicas e/ou jurídicas que participem, em qualquer momento e/ou etapa do EPIA / RIMA, independentemente de sua capacitação técnica, não podem ter nenhum vínculo empregatício temporário ou permanente com o empreendedor cuja atividade seja objeto de tais estudos.

###### Art. 9º {#art9}
Tags: #eia-rima #responsavel-tecnico

**Art. 9º, caput** {#art9_cpt} #eia-rima O relacionamento / entendimento entre os Profissionais / Consultores, assim como de Empresa de Consultoria encarregada da elaboração do EPIA / RIMA, com a empresa / empreendedor responsável pelo empreendimento / atividade objeto de análise, dar-se-á em âmbito estritamente relacionado ao levantamento / obtenção de dados, informações e especificações técnicas necessárias à perfeita caracterização e compreensão.

**Art. 9º, parágrafo único** {#art9_par1u} Para tal, poderão ser realizadas visitas e reuniões técnicas entre a Equipe de Consultores e os Dirigentes / Representantes do empreendedor e/ou pessoas por estes indicadas, para:
- **Art. 9º, parágrafo único, inciso I** {#art9_par1u_inc1} Caracterização, justificativa e objetivos ambientais e sociais do empreendimento / atividade, principalmente quanto a localização pretendida, sob os aspectos técnico, econômico e ambiental;
- **Art. 9º, parágrafo único, inciso II** {#art9_par1u_inc2} Descrição do empreendimento / atividade com o máximo de detalhamento possível;
- **Art. 9º, parágrafo único, inciso III** {#art9_par1u_inc3} Obtenção de informações relacionadas ao modelo de gestão da empresa / atividade;
- **Art. 9º, parágrafo único, inciso IV** {#art9_par1u_inc4} Conhecimento detalhado das tecnologias a serem empregadas;
- **Art. 9º, parágrafo único, inciso V** {#art9_par1u_inc5} Quantificação dos custos e benefícios, e total de investimentos econômico-financeiros para a implantação do empreendimento / atividade;
- **Art. 9º, parágrafo único, inciso VI** {#art9_par1u_inc6} Colher outras informações imprescindíveis a adequada caracterização do empreendimento / atividade.

###### Art. 10 {#art10}
Tags: #eia-rima #licenciamento-ambiental #prazo #responsavel-tecnico

**Art. 10, caput** {#art10_cpt} #eia-rima #licenciamento-ambiental É de competência exclusiva do Instituto Ambiental do Paraná – IAP, enquanto integrante do Sistema Nacional de Meio Ambiente – SISNAMA e responsável pelo licenciamento ambiental de empreendimentos / atividades consideradas impactantes, o estabelecimento de Termos de Referência para elaboração e apresentação de EPIA / RIMA.

**Art. 10, § 1º** {#art10_par1} Caberá à Equipe Técnica / Empresa de Consultoria responsável por tais estudos, por seus técnicos e consultores, atender e cumprir com o contido nesse Termo de Referência.

**Art. 10, § 2º** {#art10_par2} #eia-rima #prazo Na fase de elaboração do EPIA / RIMA, mediante prévio agendamento, o IAP prestará informações técnicas e administrativas necessárias ao correto e adequado entendimento ao que é solicitado no Termo de Referência. Em tal circunstância, o Coordenador da Equipe Técnica da Equipe Multidisciplinar / Empresa de Consultoria deverá solicitar, por escrito e com antecedência mínima de quinze dias, a realização de reunião técnica, enunciando preliminarmente, todos quesitos e dúvidas que devam ser levantadas e discutidas com os Técnicos do IAP.

**Art. 10, § 3º** {#art10_par3} #eia-rima Não caberá aos Técnicos do IAP instruir / ensinar aos Técnicos / Consultores responsáveis pela elaboração do EPIA / RIMA, do como fazer e/ou atender ao que é requisitado em tais estudos. Parte-se do pressuposto que a Equipe Técnica é composta por profissionais perfeitamente habilitados e qualificado para tal tarefa.

**Art. 10, § 4º** {#art10_par4} #eia-rima #licenciamento-ambiental Antes da entrega da versão final do EPIA / RIMA ao IAP, o Coordenador da Equipe Técnica deverá agendar uma apresentação preliminar de tais estudos frente ao Grupo Técnico designado pelo IAP par avaliação do EPIA / RIMA. Com base em tal apresentação, o IAP poderá sugerir a complementação dos estudos apresentados ou, ainda, determinar a inconsistência do que vier a ser apresentado na reunião com o que é objeto de potencial licenciamento ambiental.

**Art. 10, § 5º** {#art10_par5} #prazo A manifestação do Grupo de Trabalho do IAP será realizada por escrito e em um prazo de até quinze dias após a reunião com a Equipe de Consultores.

### Capítulo III – Do Cadastramento, Qualificação e Coordenação de Equipes Técnicas Multidisciplinares / Empresas de Consultoria Ambiental

###### Art. 11 {#art11}
Tags: #eia-rima #responsavel-tecnico

**Art. 11, caput** {#art11_cpt} #eia-rima Todos os Técnicos / Profissionais que, mesmo sob a forma de Consultores temporários, vierem a integrar a Equipe Técnica / Empresa de Consultoria responsável pela elaboração e apresentação do EPIA / RIMA, deverão estar previamente cadastradas junto ao Instituto Ambiental do Paraná, conforme previsto no

###### Art. 12 {#art12}
Tags: #documentacao #eia-rima #responsavel-tecnico

**Art. 12, caput** {#art12_cpt} #documentacao #eia-rima A Equipe Técnica responsável pela elaboração do EPIA / RIMA, dever ser composta por, no mínimo, Profissionais habilitados e qualificados para cada um dos fragmentos ambientais (meios físico, biótico e sócio-econômico) a serem diagnosticados, prognosticados e avaliados, cabendo a Coordenação Técnica ao Profissional Técnico com formação inerente a natureza do empreendimento, comprovada sua habilitação junto ao Conselho de Classe respectivo e com a necessária Anotação de Responsabilidade Técnica ou documento equivalente.

**Art. 12, § 1º** {#art12_par1} Para cada um dos fragmentos a serem avaliados, a composição mínima da Equipe Técnica será a seguinte, podendo um mesmo profissional poderá realizar os estudos de mais de um fragmento.
- **Art. 12, § 1º, inciso I** {#art12_par1_inc1} Análise do meio sócio-econômico:
  - **Art. 12, § 1º, inciso I, alínea "a"** {#art12_par1_inc1_alia} Geógrafo
  - **Art. 12, § 1º, inciso I, alínea "b"** {#art12_par1_inc1_alib} Sociólogo e/ou Antropólogo
  - **Art. 12, § 1º, inciso I, alínea "c"** {#art12_par1_inc1_alic} Economista
  - **Art. 12, § 1º, inciso I, alínea "d"** {#art12_par1_inc1_alid} Advogado
  - **Art. 12, § 1º, inciso I, alínea "e"** {#art12_par1_inc1_alie} Arqueólogo
- **Art. 12, § 1º, inciso II** {#art12_par1_inc2} Análise do meio biótico:
  - **Art. 12, § 1º, inciso II, alínea "a"** {#art12_par1_inc2_alia} Biólogo
  - **Art. 12, § 1º, inciso II, alínea "b"** {#art12_par1_inc2_alib} Engenheiro Florestal
  - **Art. 12, § 1º, inciso II, alínea "c"** {#art12_par1_inc2_alic} Engenheiro Agrônomo
  - **Art. 12, § 1º, inciso II, alínea "d"** {#art12_par1_inc2_alid} Engenheiro Químico
  - **Art. 12, § 1º, inciso II, alínea "e"** {#art12_par1_inc2_alie} Engenheiro Ambiental
- **Art. 12, § 1º, inciso III** {#art12_par1_inc3} Análise do meio físico:
  - **Art. 12, § 1º, inciso III, alínea "a"** {#art12_par1_inc3_alia} Engenheiro Civil
  - **Art. 12, § 1º, inciso III, alínea "b"** {#art12_par1_inc3_alib} Arquiteto
  - **Art. 12, § 1º, inciso III, alínea "c"** {#art12_par1_inc3_alic} Advogado
  - **Art. 12, § 1º, inciso III, alínea "d"** {#art12_par1_inc3_alid} Engenheiro Ambiental
  - **Art. 12, § 1º, inciso III, alínea "e"** {#art12_par1_inc3_alie} Geógrafo
  - **Art. 12, § 1º, inciso III, alínea "f"** {#art12_par1_inc3_alif} Geólogo
  - **Art. 12, § 1º, inciso III, alínea "g"** {#art12_par1_inc3_alig} Engenheiro Agrônomo
  - **Art. 12, § 1º, inciso III, alínea "h"** {#art12_par1_inc3_alih} Engenheiro Mecânico / Engenheiro Eletricista

### Capítulo IV – Do Cadastramento, Pré-Qualificação e Classificação de Equipe Técnica / Consultores para Elaboração do EPIA / RIMA

###### Art. 13 {#art13}
Tags: #eia-rima #responsavel-tecnico

**Art. 13, caput** {#art13_cpt} #eia-rima Com a finalidade de resguardar e cumprir com os princípios constitucionais de legalidade, isonomia, impessoalidade, igualdade e imparcialidade para análise, diagnóstico e prognóstico dos empreendimentos / atividades sujeitas a EPIA / RIMA, caberá ao IAP cadastrar e pré-qualificar a Equipe Técnica / Consultoria que elaborará tais estudos.

**Art. 13, parágrafo único** {#art13_par1u} #eia-rima O IAP manterá um cadastro de Equipes Técnicas / Empresas de Consultoria pré-qualificadas para elaboração de EPIA / RIMA, obedecidos aos mesmos ritos para credenciamento previsto nos Artigos, 23, 24 e 25 da [[lei-estadual-15608-2007|Lei Estadual No. 15608/2007]].

###### Art. 14 {#art14}
Tags: #documentacao #eia-rima #licenciamento-ambiental #prazo #responsavel-tecnico

**Art. 14, caput** {#art14_cpt} #eia-rima #licenciamento-ambiental O IAP dará publicidade em Diário Oficial do Estado do Paraná e em sua página na rede mundial de computadores – Internet, que estará cadastrando Equipe Técnica Multidisciplinar / Empresas de Consultoria Ambiental para elaboração de EPIA / RIMA de empreendimento / atividade que tenha, oficialmente, demandado licenciamento ambiental e que dependa de apresentação de tais estudos para a devida anuência ambiental.

**Art. 14, parágrafo único** {#art14_par1u} #documentacao #licenciamento-ambiental #prazo A publicidade dar-se-á em até quinze dias após o protocolo de requerimento de licenciamento junto ao IAP.

###### Art. 15 {#art15}
Tags: #documentacao #eia-rima #responsavel-tecnico

**Art. 15, caput** {#art15_cpt} #eia-rima Os Profissionais que queiram candidatar-se a participar da elaboração do EPIA / RIMA, objeto da convocação, deverão constituir-se em Equipe Técnica Multidisciplinar através de contrato civil, devidamente registrado em Cartório e em Conselho de Classe Profissional.

**Art. 15, parágrafo único** {#art15_par1u} #documentacao A Coordenação da Equipe Técnica caberá ao Profissional Técnico com formação inerente a natureza do empreendimento / atividade, comprovada sua habilitação junto ao Conselho de Classe respectivo e com a necessária Anotação de Responsabilidade Técnica ou documento equivalente, obedecidas às demais exigências legais pertinentes.

###### Art. 16 {#art16}
Tags: #documentacao #eia-rima #responsavel-tecnico

**Art. 16, caput** {#art16_cpt} #eia-rima A pré-qualificação da Equipe Técnica que irá habilitar-se elaboração do EPIA / RIMA, obedecerá aos seguintes critérios:

**Art. 16, § 1º** {#art16_par1} #documentacao Quanto a Empresa de Consultoria: sede em território brasileiro; participação efetiva e devidamente comprovada em documentação hábil; comprovação de registro junto ao Cadastro Técnico Federal;   inexistência    de   co-responsabilidade   objetiva,   devidamente   transitada   em   julgado,   em procedimentos relacionados a ocorrência de infrigências ambientais constadas pelo IAP e/ou pelo IBAMA; capacitação técnico-profissional, devidamente reconhecida pela entidade competente, mediante atestado de responsabilidade técnica por execução de obra ou serviço de características semelhantes.

**Art. 16, § 2º** {#art16_par2} #documentacao Quanto ao Coordenador Técnico: formação e habilitação inerente a natureza do empreendimento / atividade a ser analisada, devidamente comprovada com o registro junto a Conselho de Classe Profissional respectivo; participação efetiva e devidamente comprovada em documentação hábil; comprovação de registro junto ao Cadastro Técnico Federal; inexistência de co-responsabilidade objetiva; comprovação de registro junto ao Cadastro Técnico Federal; inexistência de co-responsabilidade objetiva, devidamente transitada em julgado, em procedimentos relacionados a ocorrência de infrigências ambientais constadas pelo IAP e/ou pelo IBAMA;

**Art. 16, § 3º** {#art16_par3} Quanto aos integrantes da Equipe Técnica: formação e habilitação inerente aos fragmentos ambientais (meios físico, biótico e sócio-econômico) a serem diagnosticados e avaliados relativos a natureza do empreendimento / atividade a ser analisada, devidamente comprovada com o registro junto a Conselho de Classe Profissional respectivo; comprovação de registro junto ao Cadastro Técnico Federal; inexistência de co-responsabilidade objetiva, devidamente transitada em julgado, em procedimentos relacionados a ocorrência de infrigências ambientais constadas pelo IAP e/ou pelo IBAMA;

###### Art. 17 {#art17}
Tags: #eia-rima #responsavel-tecnico

**Art. 17, caput** {#art17_cpt} #eia-rima A listagem final contendo a relação das Equipes Técnica / Empresas de Consultoria pré-qualificadas pelo IAP para elaboração do EPIA / RIMA obedecerá aos mesmos ritos classificatórios estabelecidos na Lei Estadual No. LEI Nº 15.608, de 16/08/2007.

###### Art. 18 {#art18}
Tags: #eia-rima #responsavel-tecnico

**Art. 18, caput** {#art18_cpt} Em data, hora e local previamente noticiado em Diário Oficial do Estado do Paraná e na página do IAP na rede mundial de computadores – Internet, em sessão pública e na presença do empreendedor e/ou de seu representante legal, o Instituto anunciará a relação das Equipes Técnica / Empresas de Consultoria qualificadas segundo seus critérios.

###### Art. 19 {#art19}
Tags: #eia-rima #responsavel-tecnico

**Art. 19, caput** {#art19_cpt} #eia-rima No cadastro de Consultores (pessoas físicas e/ou jurídicas) não poderá constar qualquer forma ou menção de custos / honorários a serem cobrados pela elaboração do EPIA / RIMA.

###### Art. 20 {#art20}
Tags: #eia-rima #prazo #responsavel-tecnico

**Art. 20, caput** {#art20_cpt} #prazo Caberá ao IAP qualificar, em ordem decrescente por pontuação, as Equipes Técnicas / Empresas de Consultoria que melhor atenderem aos requisitos estabelecidos por este Instituto. Para tanto, terá um prazo de até trinta dias para análise e pré-qualificação das Equipes Técnicas / Empresas de Consultoria cadastradas.

**Art. 20, § 1º** {#art20_par1} #eia-rima #prazo Trinta dias contados a partir da publicidade dada pelo IAP, em Diário Oficial do Estado do Paraná e em sua página na rede mundial de computadores – Internet, do cadastrando Equipe Técnica Multidisciplinar / Empresas de Consultoria Ambiental para elaboração de EPIA / RIMA de empreendimento / atividade, será novamente publicada a relação das Equipes Multidisciplinares / Empresas de Consultoria pré-qualificadas.

**Art. 20, § 2º** {#art20_par2} #eia-rima Imediatamente, tal listagem será comunicada ao empreendedor para que, a seu exclusivo critério escolha / defina qual(is) Equipe(s) Técnica(s) / Empresa(s) de Consultoria irá contratar para elaboração do EPIA / RIMA da atividade pretendida.

###### Art. 21 {#art21}
Tags: #documentacao #eia-rima #licenciamento-ambiental #prazo #responsavel-tecnico

**Art. 21, caput** {#art21_cpt} #eia-rima Para a pré-qualificação da(s) Equipe(s) Técnica(s) / Empresa(s) de Consultoria, com melhor perfil técnico para elaboração e apresentação do EPIA / RIMA, serão adotados os seguintes critérios mínimos:
- **Art. 21, caput, inciso I** {#art21_cpt_inc1} Quanto a Empresa de Consultoria:
  - **Art. 21, caput, inciso I, alínea "a"** {#art21_cpt_inc1_alia} Sede em território paranaense;
  - **Art. 21, caput, inciso I, alínea "b"** {#art21_cpt_inc1_alib} #prazo Existência, comprovada através de registro na Junta Comercial do Estado do Paraná e em Conselho de Classe Profissional, há no mínimo, três anos;
  - **Art. 21, caput, inciso I, alínea "c"** {#art21_cpt_inc1_alic} #documentacao #eia-rima Participação efetiva e comprovada em estudos prévios de impacto ambiental ou relatórios de impacto ambiental, relativos a empreendimentos / atividades localizadas em qualquer Unidade Federativa do Brasil, mediante apresentação de Anotação de Responsabilidade Técnica ou documento similar;
  - **Art. 21, caput, inciso I, alínea "d"** {#art21_cpt_inc1_alid} Comprovação de registro junto ao Cadastro Técnico Federal;
  - **Art. 21, caput, inciso I, alínea "e"** {#art21_cpt_inc1_alie} Inexistência de co-responsabilidade objetiva, devidamente transitada em julgado, em procedimentos relacionados a ocorrência de infrigências ambientais constadas pelo IAP e/ou pelo IBAMA;
  - **Art. 21, caput, inciso I, alínea "f"** {#art21_cpt_inc1_alif} #eia-rima Disponibilidade comprovada, mediante contrato mesmo que sem vínculo empregatício ou ainda compromisso público ou particular de constituição de consórcio, subscrito pelos consorciados, de Técnicos / Consultores Técnicos com formação / habilitação e qualificação profissionais necessárias à elaboração de um EPIA / RIMA (Advogado; Arquiteto; Biólogo; Economista; Engenheiro Agrônomo; Engenheiro Ambiental; Engenheiro Civil; Engenheiro Florestal; Engenheiro Mecânico / Engenheiro Eletricista; Engenheiro Químico; Geógrafo; Geólogo; Sociólogo e/ou Antropólogo);
  - **Art. 21, caput, inciso I, alínea "g"** {#art21_cpt_inc1_alig} #licenciamento-ambiental #prazo Inexistência de projetos / estudos relativos a licenciamentos / autorizações ambientais com pendências junto ao IAP, nos últimos três anos;
  - **Art. 21, caput, inciso I, alínea "h"** {#art21_cpt_inc1_alih} #documentacao Documentação trabalhista, social e fiscal hábil e atualizada, válida para, no mínimo, doze meses a contar da data de sua apresentação junto ao IAP.
- **Art. 21, caput, inciso II** {#art21_cpt_inc2} Quanto ao Coordenador Técnico:
  - **Art. 21, caput, inciso II, alínea "a"** {#art21_cpt_inc2_alia} Formação e habilitação inerente a natureza do empreendimento / atividade a ser analisada, devidamente comprovada com o registro junto a Conselho de Classe Profissional respectivo válido para o Estado do Paraná;
  - **Art. 21, caput, inciso II, alínea "b"** {#art21_cpt_inc2_alib} #documentacao #eia-rima Participação efetiva e comprovada em estudos prévios de impacto ambiental ou relatórios de impacto ambiental, relativos a empreendimentos / atividades localizadas em qualquer Unidade Federativa do Brasil, mediante apresentação de Anotação de Responsabilidade Técnica ou documento similar;
  - **Art. 21, caput, inciso II, alínea "c"** {#art21_cpt_inc2_alic} Comprovação de registro junto ao Cadastro Técnico Federal;
  - **Art. 21, caput, inciso II, alínea "d"** {#art21_cpt_inc2_alid} Inexistência de co-responsabilidade objetiva, devidamente transitada em julgado, em procedimentos relacionados a ocorrência de infrigências ambientais constadas pelo IAP e/ou pelo IBAMA;
  - **Art. 21, caput, inciso II, alínea "e"** {#art21_cpt_inc2_alie} Disponibilidade comprovada, mediante contrato mesmo que sem vínculo empregatício, com a empresa de Consultoria Ambiental que esteja se habilitando junto ao IAP;
  - **Art. 21, caput, inciso II, alínea "f"** {#art21_cpt_inc2_alif} #eia-rima Formação, habilitação e qualificação em, no mínimo, uma das treze formações profissionais necessárias à elaboração de um EPIA / RIMA (Advogado; Arquiteto; Biólogo; Economista; Engenheiro Agrônomo; Engenheiro Ambiental; Engenheiro Civil; Engenheiro Florestal; Engenheiro Mecânico / Engenheiro Eletricista; Engenheiro Químico; Geógrafo; Geólogo; Sociólogo e/ou Antropólogo);
  - **Art. 21, caput, inciso II, alínea "g"** {#art21_cpt_inc2_alig} #licenciamento-ambiental #prazo Inexistência de projetos / estudos relativos a licenciamentos / autorizações ambientais com pendências junto ao IAP, nos últimos três anos;
  - **Art. 21, caput, inciso II, alínea "h"** {#art21_cpt_inc2_alih} #documentacao Documentação trabalhista, social e fiscal hábil e atualizada, válida para, no mínimo, doze meses a contar da data de sua apresentação junto ao IAP.
- **Art. 21, caput, inciso III** {#art21_cpt_inc3} Quanto aos integrantes da Equipe Técnica:
  - **Art. 21, caput, inciso III, alínea "a"** {#art21_cpt_inc3_alia} #eia-rima Formação, habilitação e qualificação profissional, devidamente comprovada com o registro junto a Conselho de Classe Profissional respectivo em uma áreas necessárias à elaboração de um EPIA / RIMA (Advogado; Arquiteto; Biólogo; Economista; Engenheiro Agrônomo; Engenheiro Ambiental; Engenheiro Civil; Engenheiro Florestal; Engenheiro Mecânico / Engenheiro Eletricista; Engenheiro Químico; Geógrafo; Geólogo; Sociólogo e/ou Antropólogo);
  - **Art. 21, caput, inciso III, alínea "b"** {#art21_cpt_inc3_alib} Comprovação de registro junto ao Cadastro Técnico Federal;
  - **Art. 21, caput, inciso III, alínea "c"** {#art21_cpt_inc3_alic} Inexistência de co-responsabilidade objetiva, devidamente transitada em julgado, em procedimentos relacionados a ocorrência de infrigências ambientais constadas pelo IAP e/ou pelo IBAMA;
  - **Art. 21, caput, inciso III, alínea "d"** {#art21_cpt_inc3_alid} Contrato mesmo que sem vínculo empregatício, com a empresa de Consultoria Ambiental que esteja se habilitando junto ao IAP;
  - **Art. 21, caput, inciso III, alínea "e"** {#art21_cpt_inc3_alie} #licenciamento-ambiental #prazo Inexistência de projetos / estudos relativos a licenciamentos / autorizações ambientais com pendências junto ao IAP, nos últimos três anos;
  - **Art. 21, caput, inciso III, alínea "f"** {#art21_cpt_inc3_alif} #documentacao Documentação trabalhista, social e fiscal hábil e atualizada, válida para, no mínimo, doze meses a contar da data de sua apresentação junto ao IAP.

###### Art. 22 {#art22}
Tags: #definicao #eia-rima #licenciamento-ambiental #proibicao #responsavel-tecnico

**Art. 22, caput** {#art22_cpt} Para a classificação das Equipes Técnicas / Empresas de Consultoria serão adotados parâmetros aritméticos, conforme Tabela I, II e III, que integram esta Portaria.

**Art. 22, § 1º** {#art22_par1} A listagem de classificação dar-se-á por ordem seqüencial decrescente dos pontos obtidos pela(s) Equipe(s) Técnica(s) / Empresa(s) de Consultoria, conforme constante em seu cadastro junto ao IAP.

**Art. 22, § 2º** {#art22_par2} #definicao #eia-rima #licenciamento-ambiental #proibicao Será admissível que duas ou mais Equipe(s) Técnica(s) / Empresa(s) de Consultoria alcancem a mesma pontuação classificatória. Em tal circunstância, a responsabilidade de escolha daquela que será a responsável pelo EPIA / RIMA caberá ao empreendedor. Para tal definição é vedada toda e qualquer oferta de vantagem / referência / vinculação à obtenção de licenciamento(s) / autorização(ões) ambientais junto a qualquer Órgão Público integrante do SISNAMA.

###### Art. 23 {#art23}
Tags: #eia-rima #prazo #responsavel-tecnico

**Art. 23, caput** {#art23_cpt} #eia-rima O pagamento / ressarcimento de todos e quaisquer custos relativos às de despesas efetivadas pela Equipe Técnica / Empresa de Consultoria responsável pela elaboração do EPIA / RIMA, durante toda as fases do procedimento de análise, diagnóstico e prognóstico, são de inteira responsabilidade do empreendedor, não cabendo ao IAP qualquer ônus direto e/ou indireto, responsabilidade contratual, de seguros pessoais e/ou em grupo, responsabilidades trabalhistas, sociais ou previdenciárias.

**Art. 23, § 1º** {#art23_par1} O IAP não interferirá / intercederá / emitirá opinião para nenhuma das partes quanto aos valores propostos e relativos aos honorários relativos à prestação dos serviços técnicos contratados.

**Art. 23, § 2º** {#art23_par2} #prazo A forma de pagamento, prazos, cronogramas e outros entendimentos comerciais serão realizados entre o empreendedor e a Equipe Técnica / Empresa de Consultoria a ser contratada. Sob nenhuma forma, o IAP participará, assistirá ou interferirá em tais negociações comerciais, não lhe cabendo, ainda, qualquer responsabilidade por eventual inadimplência quanto a valores devidos.

**Art. 23, § 3º** {#art23_par3} Caberá à Equipe Técnica / Empresa de Consultoria selecionada realizar as negociações de custos e honorários a serem cobrados pela Equipe Técnica / Empresa de Consultoria, bem como a discussão da proposta técnica, metodologia proposta (plano de trabalho), equipe e outras sugestões apresentadas pelos Consultores e pelo empreendedor para aprimorar o Termo de Referência.

###### Art. 24 {#art24}
Tags: #documentacao #eia-rima #licenciamento-ambiental #responsavel-tecnico

**Art. 24, caput** {#art24_cpt} #documentacao #eia-rima A entrega do documento final relativo ao EPIA e ao RIMA, elaborados pela Equipe Técnica / Empresa de Consultoria dar-se-á, primeiramente ao IAP que, mediante documento próprio atestará seu recebimento.

**Art. 24, § 1º** {#art24_par1} #eia-rima #licenciamento-ambiental Somente terá valor legal, técnico e administrativo, para efeito junto aos procedimentos que instruem o processo de licenciamento ambiental, a via do EPIA / RIMA que contiver o atestado firmado pelo IAP.

**Art. 24, § 2º** {#art24_par2} Na seqüência, a Equipe Técnica / Empresa de Consultoria, de posse de cópia autêntica da via entregue ao IAP, fará entrega de uma ou mais vias ao empreendedor que a contratou.

### Capítulo V – Dos Prazos

###### Art. 25 {#art25}
Tags: #documentacao #eia-rima #prazo #responsavel-tecnico

**Art. 25, caput** {#art25_cpt} #documentacao #eia-rima #prazo A contagem do prazo para análise do EPIA / RIMA passa a vigorar a partir da data de entrega do documento final relativo ao EPIA e ao RIMA, junto ao IAP, mediante registro no Sistema de Protocolo Geral de Documentos – AAX.

###### Art. 26 {#art26}
Tags: #documentacao #eia-rima #prazo #responsavel-tecnico

**Art. 26, caput** {#art26_cpt} #documentacao #eia-rima #prazo Segundo o Artigo 13 da [[resolucao-cema-65-2008|Resolução CEMA N° 065/2008]], o IAP terá um prazo máximo de até 6 (seis) meses para análise e deferimento ou indeferimento de cada modalidade de licença, autorização ambiental ou florestal, a contar da data do protocolo do requerimento, ressalvados os casos em que houver EPIA/RIMA e/ou Audiência Pública, quando o prazo será de até 12 (doze) meses.

###### Art. 27 {#art27}
Tags: #eia-rima #prazo #responsavel-tecnico

**Art. 27, caput** {#art27_cpt} #prazo A contagem desse prazo poderá ser suspensa durante a elaboração dos estudos ambientais complementares ou apresentação de esclarecimentos pelo empreendedor. A alteração poderá ocorrer desde que justificada e com a concordância expressa do empreendedor e do IAP.

###### Art. 28 {#art28}
Tags: #eia-rima #responsavel-tecnico

**Art. 28, caput** {#art28_cpt} Esta Portaria entra em vigor na data de sua publicação, ficando em conseqüência revogadas as disposições em contrário.


## Fecho

Curitiba, 03 de março de 2010. Vitor Hugo Ribeiro Burko Diretor Presidente do Instituto Ambiental do Paraná

### Anexo à Portaria IAP No. 038, de 03 de março de 2010 {#anexo1}

Conteúdo normativo do anexo pendente de transcrição e conferência visual. A extração textual recebida está preservada nos arquivos de fonte deste lote.

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (portaria IAP 38 2010.pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- O PDF não apresenta ementa autônoma; o frontmatter contém descrição editorial derivada do art. 1º.
- Redações anteriores de artigos repetidos foram excluídas desta versão compilada, conforme o padrão do acervo; estão preservadas na extração da fonte que acompanha o lote.
- Conferência visual não concluída: a leitura por páginas não disponibilizou imagem utilizável nesta sessão. O texto extraído foi preservado no manifesto para revisão; não foi promovido a tabela normativa validada.
- O anexo é único e não numerado no original; usado anexo1 como identificador. Possui Tabelas I, II e III e um total final. A imagem não foi disponibilizada pelo leitor de PDFs.
- Cláusula genérica de revogação: não foram atribuídas revogações tácitas por inferência; exige decisão humana.
