---
norma: "Resolução CONAMA nº 6/1987"
arquivo: resolucao-conama-6-1987
tipo: resolucao
esfera: federal
uf: BR
numero: 6
ano: 1987
data_assinatura: 1987-09-16
ementa: "Dispõe sobre o licenciamento ambiental de obras do setor de geração de energia elétrica."
situacao: vigente
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: []
revoga: []
revogado_por: []
cita: ["[[lei-federal-7735-1989]]", "[[resolucao-conama-1-1986]]"]
tags: ["definicao", "documentacao", "eia-rima", "energia-eletrica", "enquadramento", "geracao-energia", "li", "licenciamento-ambiental", "lo", "lp", "monitoramento"]
fonte: "PDF fornecido: conama 6 1987.pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
---

# Resolução CONAMA nº 6/1987

> Dispõe sobre o licenciamento ambiental de obras do setor de geração de energia elétrica.

## Preâmbulo

RESOLUÇÃO CONAMA nº 6, de 16 de setembro de 1987 Publicada no DOU, de 22 de outubro de 1987, Seção 1, página 17500 Dispõe sobre o licenciamento ambiental de obras do setor de geração de energia elétrica O CONSELHO NACIONAL DO MEIO AMBIENTE - CONAMA, no uso de suas atribui-ções legais, Considerando a necessidade de que sejam editadas regras gerais para o licenciamento ambiental de obras de grande porte, especialmente aquelas nas quais a União tenha in-teresse relevante como a geração de energia elétrica, no intuito de harmonizar conceitos e linguagem entre os diversos intervenientes no processo, resolve:

###### Art. 1º {#art1}
Tags: #definicao #energia-eletrica #geracao-energia #licenciamento-ambiental

**Art. 1º, caput** {#art1_cpt} #definicao #licenciamento-ambiental As concessionárias de exploração, geração e distribuição de energia elétrica, ao submeterem seus empreendimentos ao licenciamento ambiental perante o órgão estadual competente, deverão prestar as informações técnicas sobre o mesmo, conforme estabelecem os termos da legislação ambiental e pelos procedimentos definidos nesta Resolução.

###### Art. 2º {#art2}
Tags: #energia-eletrica #geracao-energia

**Art. 2º, caput** {#art2_cpt} Caso o empreendimento necessite ser licenciado por mais de um Estado, pela abrangência de sua área de influência, os órgãos estaduais deverão manter entendimento prévio no sentido de, na medida do possível, uniformizar as exigências.

**Art. 2º, parágrafo único** {#art2_par1u} A Secretaria Especial do Meio Ambiente - SEMA174 supervisionará os entendimentos previstos neste artigo.

###### Art. 3º {#art3}
Tags: #energia-eletrica #geracao-energia #licenciamento-ambiental

**Art. 3º, caput** {#art3_cpt} #licenciamento-ambiental Os órgãos estaduais competentes e os demais integrantes do SISNAMA envol-vidos no processo de licenciamento, estabelecerão etapas e especificações adequadas às características dos empreendimentos objeto desta Resolução.

###### Art. 4º {#art4}
Tags: #energia-eletrica #geracao-energia #li #lo #lp

**Art. 4º, caput** {#art4_cpt} #li #lo #lp Na hipótese dos empreendimentos de aproveitamento hidroelétrico, respeitadas as peculiaridades de cada caso, a Licença Prévia (LP) deverá ser requerida no início do estudo de viabilidade da Usina; a Licença de Instalação (LI) deverá ser obtida antes da realização da Licitação para construção do empreendimento e a Licença de Operação (LO) deverá ser obtida antes do fechamento da barragem.

###### Art. 5º {#art5}
Tags: #energia-eletrica #geracao-energia

**Art. 5º, caput** {#art5_cpt} No caso de usinas termoelétricas, a LP deverá ser requerida no início do estudo de viabilidade; a LI antes do início da efetiva implantação do empreendimento e a LO depois dos testes realizados e antes da efetiva colocação da usina em geração comercial de energia.

###### Art. 6º {#art6}
Tags: #definicao #energia-eletrica #geracao-energia #licenciamento-ambiental

**Art. 6º, caput** {#art6_cpt} #definicao #licenciamento-ambiental No licenciamento de subestações e linhas de transmissão, a LP deve ser reque-rida no início do planejamento do empreendimento, antes de definida sua localização, ou caminhamento definitivo, a LI, depois de concluído o projeto executivo e antes do início das obras e a LO, antes da entrada em operação comercial.

###### Art. 7º {#art7}
Tags: #documentacao #energia-eletrica #geracao-energia #licenciamento-ambiental

**Art. 7º, caput** {#art7_cpt} #documentacao #licenciamento-ambiental Os documentos necessários para o licenciamento a que se refere os artigos [[#art4|4 o]], [[#art5|5o]] e [[#art6|6o]] são aqueles discriminados no anexo.

**Art. 7º, parágrafo único** {#art7_par1u} #licenciamento-ambiental Aos órgãos estaduais de meio ambiente licenciadores, caberá solicitar informações complementares, julgadas imprescindíveis ao licenciamento. 174 A Secretaria Especial do Meio Ambiente – SEMA, vinculada ao Ministério do Interior, foi extinta pela [[lei-federal-7735-1989|Lei nº 7.735, de 22 de fevereiro de 1989]], que criou o Instituto Brasileiro do Meio Ambiente e dos Recur-sos Naturais Renováveis – IBAMA. As atribuições em matéria ambiental são atualmente do Ministério do Meio Ambiente.

###### Art. 8º {#art8}
Tags: #eia-rima #energia-eletrica #enquadramento #geracao-energia #licenciamento-ambiental

**Art. 8º, caput** {#art8_cpt} #eia-rima #enquadramento Caso o empreendimento esteja enquadrado entre as atividades exemplificadas no artigo o 2 da [[resolucao-conama-1-1986|Resolução CONAMA nº 1/86]], o estudo de impacto ambiental deverá ser encetado, de forma que, quando da solicitação da LP e concessionária tenha condições de apresentar ao(s) órgão(s) estadual(ais) competente(s) um relatório sobre o planejamento dos estudos a serem executados, inclusive cronograma tentativo, de maneira a possibilitar que sejam fixadas as instruções adicionais previstas no parágrafo único do artigo 6o da [[resolucao-conama-1-1986|Resolução CONAMA nº 1/86]].

**Art. 8º, § 1º** {#art8_par1} #licenciamento-ambiental As informações constantes de inventário, quando houver, deverão ser transmitidas ao(s) órgão(s) estadual(ais) competente(s) responsável(eis) pelo licenciamento.

**Art. 8º, § 2º** {#art8_par2} #eia-rima A emissão da LP somente será feita após a análise e aprovação do RIMA

###### Art. 9º {#art9}
Tags: #eia-rima #energia-eletrica #geracao-energia #monitoramento

**Art. 9º, caput** {#art9_cpt} #eia-rima #monitoramento O estudo de impacto ambiental, a preparação do RIMA, o detalhamento dos aspectos ambientais julgados relevantes a serem desenvolvidos nas várias fases do li-cenciamento, inclusive o programa de acompanhamento e monitoragem dos impactos, serão acompanhados por técnicos designados para este fim pelo(s) órgão(s) estadual(ais) competente(s).

###### Art. 10 {#art10}
Tags: #eia-rima #energia-eletrica #geracao-energia

**Art. 10, caput** {#art10_cpt} #eia-rima O RIMA deverá ser acessível ao público, na forma do artigo 11 da [[resolucao-conama-1-1986|Resolução CONAMA nº 1/86]].

**Art. 10, parágrafo único** {#art10_par1u} #eia-rima O RIMA destinado especificamente ao esclarecimento público das vantagens e conseqüências ambientais do empreendimento deverá ser elaborado de forma a alcançar efetivamente este objetivo, atendido o disposto no parágrafo único do artigo 9 o da [[resolucao-conama-1-1986|Resolução CONAMA nº 1/86]].

###### Art. 11 {#art11}
Tags: #eia-rima #energia-eletrica #geracao-energia

**Art. 11, caput** {#art11_cpt} #eia-rima Os demais dados técnicos do estudo de impacto ambiental deverão ser transmi-tidos ao(s) órgão(s) estadual(ais) competente(s) com a forma e o cronograma estabelecido de acordo com o artigo [[#art8|8o]] desta Resolução.

###### Art. 12 {#art12}
Tags: #eia-rima #energia-eletrica #geracao-energia #licenciamento-ambiental

**Art. 12, caput** {#art12_cpt} O disposto nesta Resolução será aplicado, considerando-se as etapas de pla-nejamento ou de execução em que se encontra o empreendimento.

**Art. 12, § 1º** {#art12_par1} Caso a etapa prevista para a obtenção da LP ou LI já esteja vencida, a mesma não será expedida.

**Art. 12, § 2º** {#art12_par2} A não expedição da LP ou LI, de acordo com o parágrafo anterior, não dispensa a transmissão aos órgãos estaduais competentes dos estudos ambientais executados por força de necessidade do planejamento e execução do empreendimento.

**Art. 12, § 3º** {#art12_par3} #eia-rima #licenciamento-ambiental Mesmo vencida a etapa da obtenção da LI, o RIMA deverá ser elaborado segundo as informações disponíveis, além das adicionais que forem requisitadas pelo(s) órgão(s) ambiental(ais) competente(s) para o licenciamento, de maneira a poder tornar públicas as características do empreendimento e suas prováveis conseqüências ambientais e só-cio-econômicas.

**Art. 12, § 4º** {#art12_par4} #eia-rima Para o empreendimento que entrou em operação a partir de 1º de fevereiro de 1986, sua regularização se dará pela obtenção da LO, para a qual será necessária a apresentação de RIMA contendo, no mínimo, as seguintes informações: descrição do empreendimento; impactos ambientais positivos e negativos provocados em sua área de influência; descri-ção das medidas de proteção ambiental e mitigadoras dos impactos ambientais negativos adotados ou em vias de adoção, além de outros estudos ambientais já realizados pela concessionária.

**Art. 12, § 5º** {#art12_par5} #eia-rima Para o empreendimento que entrou em operação anteriormente a 1º de fevereiro de 1986, sua regularização se dará pela obtenção da LO sem a necessidade de apresen-tação de RIMA, mas com a concessionária encaminhando ao(s) órgão(s) estadual(ais) a descrição geral do empreendimento; a descrição do impacto ambiental provocado e as medidas de proteção adotadas ou em vias de adoção.

###### Art. 13 {#art13}
Tags: #energia-eletrica #geracao-energia

**Art. 13, caput** {#art13_cpt} Esta Resolução entra em vigor na data de sua publicação. DENI LINEU SCHWARTZ - Presidente do Conselho


### Documentos necessários ao licenciamento {#anexo1}

Conteúdo normativo do anexo pendente de transcrição e conferência visual. A extração textual recebida está preservada nos arquivos de fonte deste lote.

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (conama 6 1987.pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- Conferência visual não concluída: a leitura por páginas não disponibilizou imagem utilizável nesta sessão. O texto extraído foi preservado no manifesto para revisão; não foi promovido a tabela normativa validada.
- O anexo único, não numerado, contém quadro com três modalidades e três tipologias. O quadro exige conferência visual antes da conversão de colunas em entradas autossuficientes.
