---
norma: "Portaria IAP nº 155/2013"
arquivo: portaria-iap-155-2013
tipo: portaria
esfera: estadual
uf: PR
numero: 155
ano: 2013
data_assinatura: 2013-05-24
ementa: "Estabelece condições e critérios e dá outras providências, para o licenciamento ambiental de Barracões para Triagem de Resíduos Sólidos Urbanos Não Perigosos."
situacao: revogada
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: []
revoga: ["[[portaria-iap-167-2012]]"]
revogado_por: ["[[instrucao-normativa-iat-31-2025]]"]
cita: ["[[decreto-estadual-114-2011]]", "[[decreto-estadual-1502-1992]]", "[[lei-estadual-10066-1992]]", "[[lei-estadual-7109-1979]]", "[[lei-federal-9605-1998]]", "[[portaria-iap-155-2013-anexo5]]", "[[portaria-iap-155-2013-anexo7]]", "[[portaria-iap-167-2012]]", "[[resolucao-cema-65-2008]]", "[[resolucao-conama-237-1997]]", "[[resolucao-conama-6-1986]]"]
tags: ["app", "definicao", "documentacao", "eia-rima", "enquadramento", "las", "li", "licenciamento-ambiental", "lo", "lp", "prazo", "renovacao", "residuo-solido", "residuo-solido-urbano", "responsavel-tecnico", "triagem"]
fonte: "PDF fornecido: portaria IAP 155 2013(1).pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
---

# Portaria IAP nº 155/2013

> Estabelece condições e critérios e dá outras providências, para o licenciamento ambiental de Barracões para Triagem de Resíduos Sólidos Urbanos Não Perigosos.

## Preâmbulo

PORTARIA IAP Nº 155 DE 24 DE MAIO DE 2013 Estabelece condições e critérios e dá outras providências, para o licenciamento ambiental de Barracões para Triagem de Resíduos Sólidos Urbanos Não Perigosos. O Diretor Presidente do Instituto Ambiental do Paraná – IAP, nomeado pelo [[decreto-estadual-114-2011|Decreto n° 114 de 06 de janeiro de 2011]], no uso das atribuições que lhe são conferidas pela [[lei-estadual-10066-1992|Lei Estadual N.°10.066, de 27 de julho de 1992]], com as alterações trazidas pelas Leis n° 11.352, de 13 de fevereiro de 1996 e n° 13.425, de 07 de janeiro de 2002 e de acordo com o seu Regulamento, aprovado pelo [[decreto-estadual-1502-1992|Decreto n° 1.502, de 04 de agosto de 1992]], com alterações posteriores e considerando o disposto na [[resolucao-conama-237-1997|Resolução CONAMA Nº 237/97]], RESOLVE:

###### Art. 1º {#art1}
Tags: #licenciamento-ambiental #residuo-solido #residuo-solido-urbano #triagem

**Art. 1º, caput** {#art1_cpt} #licenciamento-ambiental #residuo-solido Estabelecer critérios premissas para o Licenciamento Ambiental de Barracões para Triagem de Resíduos Sólidos Não Perigosos com aproveitamento econômico.

###### Art. 2º {#art2}
Tags: #definicao #eia-rima #licenciamento-ambiental #residuo-solido #residuo-solido-urbano #triagem

**Art. 2º, caput** {#art2_cpt} #definicao Para efeito desta Portaria, considera-se:
- **Art. 2º, caput, inciso I** {#art2_cpt_inc1} #eia-rima #residuo-solido Estudos Ambientais Específicos: todos e quaisquer estudos relativos aos aspectos ambientais relacionados à localização, instalação, operação e ampliação de um empreendimento, atividade ou obra, apresentado como subsídio para a análise da licença ou autorização requerida, tais como: estudo de impacto ambiental/relatório de impacto ambiental- EIA/RIMA, relatório ambiental preliminar- RAP, projeto básico ambiental- PBA, plano de controle ambiental - PCA, plano de recuperação de área degradada - PRAD, plano de gerenciamento de resíduos sólidos - PGRS, análise de risco -AR, projeto de controle de poluição ambiental - PCPA, avaliação ambiental integrada ou estratégica – AAI ou AAE e outros;
- **Art. 2º, caput, inciso II** {#art2_cpt_inc2} Fonte de Poluição: qualquer atividade, sistema, processo, operação, maquinaria, equipamentos ou dispositivos, móvel ou imóvel previstos no regulamento da [[lei-estadual-7109-1979|Lei Estadual nº 7109/79]], que alterem ou possam vir a alterar o Meio Ambiente.
- **Art. 2º, caput, inciso III** {#art2_cpt_inc3} #licenciamento-ambiental Licenciamento Ambiental: procedimento administrativo pelo qual o IAP, verificando a satisfação das condições legais e técnicas, licenciam a localização, instalação, ampliação e a operação de empreendimentos e atividades utilizadoras de recursos ambientais consideradas efetiva ou potencialmente poluidoras ou daquelas que, sob qualquer forma, possam causar degradação e/ou modificação ambiental, considerando as disposições legais e regulamentares e as normas técnicas aplicáveis ao caso.
- **Art. 2º, caput, inciso IV** {#art2_cpt_inc4} Licença Ambiental: ato administrativo pelo qual o IAP, estabelece as condições, restrições e medidas de controle ambiental que deverão ser obedecidas pelo empreendedor, pessoa física ou jurídica, para localizar, instalar, ampliar e operar empreendimentos ou atividades utilizadoras dos recursos ambientais consideradas efetiva ou potencialmente poluidoras ou aquelas que, sob qualquer forma, possam causar degradação e/ou modificação ambiental.
- **Art. 2º, caput, inciso V** {#art2_cpt_inc5} #residuo-solido Barracão de Triagem de Resíduos Sólidos Não Perigosos: local de recebimento de resíduos não perigosos, que serão separados de acordo com suas características materiais, para posterior destinação final.

###### Art. 3º {#art3}
Tags: #enquadramento #las #li #lo #lp #residuo-solido-urbano #triagem

**Art. 3º, caput** {#art3_cpt} O IAP, no exercício de sua competência de controle e operação ambiental, expedirá os seguintes atos administrativos:
- **Art. 3º, caput, inciso I** {#art3_cpt_inc1} #enquadramento #las Licença ambiental simplificada (LAS): aprova a localização e a concepção do empreendimento, atividade ou obra de pequeno porte;
- **Art. 3º, caput, inciso II** {#art3_cpt_inc2} #enquadramento #lp Licença Prévia (LP) - concedida na fase preliminar do planejamento do empreendimento ou atividade de médio ou grande porte aprovando sua localização e concepção, atestando a viabilidade ambiental e estabelecendo os requisitos básicos e condicionantes a serem atendidos nas próximas fases de sua implementação.
- **Art. 3º, caput, inciso III** {#art3_cpt_inc3} #enquadramento #li Licença de Instalação (LI) - autoriza a instalação do empreendimento ou atividade de médio e grande porte de acordo com as especificações constantes dos planos, programas e projetos aprovados, incluindo as medidas de controle ambiental e demais condicionantes da qual constituem motivo determinante.
- **Art. 3º, caput, inciso IV** {#art3_cpt_inc4} #enquadramento #lo Licença de Operação (LO) - autoriza a operação da atividade ou empreendimento de médio e grande porte, após a verificação do efetivo cumprimento do que consta das licenças anteriores, com as medidas de controle ambiental e condicionantes determinados para a operação.

###### Art. 4º {#art4}
Tags: #enquadramento #residuo-solido #residuo-solido-urbano #triagem

**Art. 4º, caput** {#art4_cpt} #enquadramento #residuo-solido Para efeito desta Portaria, os empreendimentos de Barracões de Triagem de Resíduos Sólidos Não Perigosos ,são classificados de acordo com o porte. Porte do empreendimento (m²): Pequeno: até 2000 m² Médio: 2000 a 10000 m² Grande: acima de 10000 m²

###### Art. 5º {#art5}
Tags: #app #documentacao #las #li #licenciamento-ambiental #lo #lp #prazo #renovacao #residuo-solido #residuo-solido-urbano #responsavel-tecnico #triagem

**Art. 5º, caput** {#art5_cpt} #documentacao #licenciamento-ambiental Os requerimentos de licenciamento, serão protocolados, desde que instruídos na forma prevista abaixo.
- **Art. 5º, caput, inciso I** {#art5_cpt_inc1} #app #documentacao #las #licenciamento-ambiental #prazo #residuo-solido #responsavel-tecnico LICENÇA AMBIENTAL SIMPLIFICADA – LAS Requerimento de Licenciamento Ambiental (ANEXO 1); Cadastro de Barracão de Triagem de Resíduos Sólidos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local; Certidão do Município, quanto ao uso e ocupação do solo, conforme modelo apresentado no (ANEXO 3); Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente, e em caso de imóvel locado no nome do locador junto com o contrato de locação, no máximo de 90 (noventa) dias, para imóveis rurais exige-se a averbação da Reserva Legal junto à matrícula do imóvel, ou Documento de propriedade ou justa posse rural ou conforme exigências constantes da Seção VI, art.46 a 57 da [[resolucao-cema-65-2008|Resolução CEMA 065 de 01 de julho de 2008]];
  - **Art. 5º, caput, inciso I, alínea "a"** {#art5_cpt_inc1_alia} Cópia do Ato Constitutivo ou do Contrato Social (com última alteração);
  - **Art. 5º, caput, inciso I, alínea "b"** {#art5_cpt_inc1_alib} #las Publicação de súmula do pedido de Licença Ambiental Simplificada em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 6);
  - **Art. 5º, caput, inciso I, alínea "c"** {#art5_cpt_inc1_alic} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária) no valor de 0,2 UPF/PR;
  - **Art. 5º, caput, inciso I, alínea "d"** {#art5_cpt_inc1_alid} #residuo-solido Formulário de Controle Ambiental de Barracão de Triagem de Resíduos Não Perigosos (ANEXO 4).
- **Art. 5º, caput, inciso II** {#art5_cpt_inc2} #las #renovacao RENOVAÇÃO DA LICENÇA AMBIENTAL SIMPLIFICADA – LAS
  - **Art. 5º, caput, inciso II, alínea "a"** {#art5_cpt_inc2_alia} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 5º, caput, inciso II, alínea "a"** {#art5_cpt_inc2_alia-dup2} #app #residuo-solido Cadastro de Barracão de Triagem de Resíduos Sólidos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 5º, caput, inciso II, alínea "b"** {#art5_cpt_inc2_alib} #las Publicação de súmula de recebimento de Licença Ambiental Simplificada em jornal de circulação regional e no Diário Oficial do Estado, (ANEXO 6);
  - **Art. 5º, caput, inciso II, alínea "c"** {#art5_cpt_inc2_alic} #las #renovacao Súmula do pedido de Renovação de Licença Ambiental Simplificada, publicada por ocasião da sua expedição conforme [[resolucao-conama-6-1986|Resolução CONAMA no 006/86]];
  - **Art. 5º, caput, inciso II, alínea "d"** {#art5_cpt_inc2_alid} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária) no valor de 0,2 UPF/PR.
  - **Art. 5º, caput, inciso II, alínea "e"** {#art5_cpt_inc2_alie} #residuo-solido Relatório anual de recebimento, movimentação, processamento e destinação final dos resíduos, descrevendo o gerador, classificação, quantidades e tratamento/destinação final adotados (ANEXO 5).
- **Art. 5º, caput, inciso III** {#art5_cpt_inc3} #lp LICENÇA PRÉVIA
  - **Art. 5º, caput, inciso III, alínea "a"** {#art5_cpt_inc3_alia} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 5º, caput, inciso III, alínea "b"** {#art5_cpt_inc3_alib} #residuo-solido Cadastro de Barracão de Triagem de Resíduos Sólidos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância
  - **Art. 5º, caput, inciso III, alínea "c"** {#art5_cpt_inc3_alic} #app de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 5º, caput, inciso III, alínea "d"** {#art5_cpt_inc3_alid} #documentacao Certidão do Município, quanto ao uso e ocupação do solo, conforme modelo apresentado no (ANEXO 3);
  - **Art. 5º, caput, inciso III, alínea "e"** {#art5_cpt_inc3_alie} #lp Publicação de súmula do pedido de Licença Prévia em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 6);
  - **Art. 5º, caput, inciso III, alínea "f"** {#art5_cpt_inc3_alif} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária) de acordo com Lei Estadual n. 10.233/92.
  - **Art. 5º, caput, inciso III, alínea "g"** {#art5_cpt_inc3_alig} #documentacao #prazo #responsavel-tecnico Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente, e em caso de imóvel locado no nome do locador junto com o contrato de locação, no máximo de 90 (noventa) dias, para imóveis rurais exige-se a averbação da Reserva Legal junto à matrícula do imóvel, ou Documento de propriedade ou justa posse rural ou conforme exigências constantes da Seção VI, art.46 a 57 da [[resolucao-cema-65-2008|Resolução CEMA 065 de 01 de julho de 2008]].
  - **Art. 5º, caput, inciso III, alínea "h"** {#art5_cpt_inc3_alih} #documentacao Nos casos devidamente justificados em que não seja possível a apresentação dos documentos especificados no item d, os mesmos deverão ser apresentados antes do inicio da operação da atividade ou empreendimento sob pena de cancelamento da licença Ambiental
  - **Art. 5º, caput, inciso III, alínea "i"** {#art5_cpt_inc3_alii} Cópia do Ato Constitutivo ou do Contrato Social (com última alteração)
- **Art. 5º, caput, inciso IV** {#art5_cpt_inc4} #li LICENÇA DE INSTALAÇÃO
  - **Art. 5º, caput, inciso IV, alínea "a"** {#art5_cpt_inc4_alia} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 5º, caput, inciso IV, alínea "b"** {#art5_cpt_inc4_alib} #app #residuo-solido Cadastro de Barracão de Triagem de Resíduos Sólidos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 5º, caput, inciso IV, alínea "c"** {#art5_cpt_inc4_alic} #residuo-solido Formulário de Controle Ambiental de Barracão de Triagem de Resíduos Não Perigosos (ANEXO 4);
  - **Art. 5º, caput, inciso IV, alínea "d"** {#art5_cpt_inc4_alid} #lp Publicação de súmula de recebimento de Licença Prévia em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 6);
  - **Art. 5º, caput, inciso IV, alínea "e"** {#art5_cpt_inc4_alie} #li Publicação de súmula de pedido de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 6);
  - **Art. 5º, caput, inciso IV, alínea "f"** {#art5_cpt_inc4_alif} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária) de acordo com Lei Estadual n. 10.233/92.
  - **Art. 5º, caput, inciso IV, alínea "g"** {#art5_cpt_inc4_alig} #lp Cópia da Licença Prévia.
- **Art. 5º, caput, inciso V** {#art5_cpt_inc5} #li #renovacao RENOVAÇÃO DE LICENÇA DE INSTALAÇÃO
  - **Art. 5º, caput, inciso V, alínea "a"** {#art5_cpt_inc5_alia} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 5º, caput, inciso V, alínea "b"** {#art5_cpt_inc5_alib} #app #residuo-solido Cadastro de Barracão de Triagem de Resíduos Sólidos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 5º, caput, inciso V, alínea "c"** {#art5_cpt_inc5_alic} #li Publicação de súmula de recebimento de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 6);
  - **Art. 5º, caput, inciso V, alínea "d"** {#art5_cpt_inc5_alid} #li #renovacao Publicação de súmula do pedido de Renovação de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 6);
  - **Art. 5º, caput, inciso V, alínea "e"** {#art5_cpt_inc5_alie} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária) de acordo com Lei Estadual N. 10.233/92.
  - **Art. 5º, caput, inciso V, alínea "f"** {#art5_cpt_inc5_alif} #documentacao #li Documento que declare se houveram mudanças no escopo e características do projeto apresentado quando da obtenção da Licença de Instalação. Caso existam modificações, detalhá-las.
  - **Art. 5º, caput, inciso V, alínea "g"** {#art5_cpt_inc5_alig} #li Cópia da Licença de Instalação.
- **Art. 5º, caput, inciso VI** {#art5_cpt_inc6} #lo LICENÇA DE OPERAÇÃO
  - **Art. 5º, caput, inciso VI, alínea "a"** {#art5_cpt_inc6_alia} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 5º, caput, inciso VI, alínea "b"** {#art5_cpt_inc6_alib} #app #residuo-solido Cadastro de Barracão de Triagem de Resíduos Sólidos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 5º, caput, inciso VI, alínea "c"** {#art5_cpt_inc6_alic} #li Publicação de súmula de recebimento de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 6);
  - **Art. 5º, caput, inciso VI, alínea "d"** {#art5_cpt_inc6_alid} #lo Publicação de súmula do pedido de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 6);
  - **Art. 5º, caput, inciso VI, alínea "e"** {#art5_cpt_inc6_alie} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária) de acordo com Lei Estadual n. 10.233/92.
  - **Art. 5º, caput, inciso VI, alínea "f"** {#art5_cpt_inc6_alif} #li Cópia da Licença de Instalação.
- **Art. 5º, caput, inciso VII** {#art5_cpt_inc7} #lo #renovacao RENOVAÇÃO DE LICENÇA DE OPERAÇÃO
  - **Art. 5º, caput, inciso VII, alínea "a"** {#art5_cpt_inc7_alia} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 5º, caput, inciso VII, alínea "b"** {#art5_cpt_inc7_alib} #app #residuo-solido Cadastro de Barracão de Triagem de Resíduos Sólidos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 5º, caput, inciso VII, alínea "c"** {#art5_cpt_inc7_alic} #lo Cópia da Licença de Operação;
  - **Art. 5º, caput, inciso VII, alínea "d"** {#art5_cpt_inc7_alid} #lo Publicação de recebimento de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 6);
  - **Art. 5º, caput, inciso VII, alínea "e"** {#art5_cpt_inc7_alie} #lo #renovacao Publicação de pedido de Renovação de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 6);
  - **Art. 5º, caput, inciso VII, alínea "f"** {#art5_cpt_inc7_alif} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária) de acordo com Lei Estadual n. 10.233/92.
  - **Art. 5º, caput, inciso VII, alínea "g"** {#art5_cpt_inc7_alig} #residuo-solido Relatório anual de recebimento, movimentação, processamento e destinação final dos resíduos, descrevendo o gerador, classificação, quantidades e tratamento/destinação final adotados (ANEXO 5).
- **Art. 5º, caput, inciso VIII** {#art5_cpt_inc8} #licenciamento-ambiental REGULARIZAÇÃO DO LICENCIAMENTO
  - **Art. 5º, caput, inciso VIII, alínea "a"** {#art5_cpt_inc8_alia} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental (ANEXO 1);
  - **Art. 5º, caput, inciso VIII, alínea "b"** {#art5_cpt_inc8_alib} #app #residuo-solido Cadastro de Barracão de Triagem de Resíduos Sólidos Não Perigosos (ANEXO 2) detalhando ou anexando, croqui de localização do empreendimento, contendo distância de corpos hídricos, indicando as áreas de preservação permanente, vias de acesso principais e pontos de referências para chegar ao local;
  - **Art. 5º, caput, inciso VIII, alínea "c"** {#art5_cpt_inc8_alic} #documentacao #prazo Matrícula ou Transcrição do Cartório de Registro de Imóveis, atualizada, no máximo, 90 (noventa) dias;
  - **Art. 5º, caput, inciso VIII, alínea "e"** {#art5_cpt_inc8_alie} #residuo-solido Formulário de Controle Ambiental de Barracão de Triagem de Resíduos Não Perigosos (ANEXO 4).
  - **Art. 5º, caput, inciso VIII, alínea "d"** {#art5_cpt_inc8_alid} #licenciamento-ambiental Publicação de pedido de Regularização do Licenciamento Ambiental em jornal de circulação regional e no Diário Oficial do Estado (ANEXO 6);
  - **Art. 5º, caput, inciso VIII, alínea "e"** {#art5_cpt_inc8_alie-dup2} Comprovante de recolhimento da Taxa Ambiental (Ficha de Compensação Bancária) de acordo com Lei Estadual n. 10.233/92.
  - **Art. 5º, caput, inciso VIII, alínea "f"** {#art5_cpt_inc8_alif} #residuo-solido Relatório anual de recebimento, movimentação, processamento e destinação final dos resíduos, descrevendo o gerador, classificação, quantidades e tratamento/destinação final adotados (ANEXO 5).
  - **Art. 5º, caput, inciso VIII, alínea "g"** {#art5_cpt_inc8_alig} #documentacao #prazo #responsavel-tecnico Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente, e em caso de imóvel locado no nome do locador junto com o contrato de locação, no máximo de 90 (noventa) dias, para imóveis rurais exige-se a averbação da Reserva Legal junto à matrícula do imóvel, ou Documento de propriedade ou justa posse rural ou conforme exigências constantes da Seção VI, art.46 a 57 da [[resolucao-cema-65-2008|Resolução CEMA 065 de 01 de julho de 2008]];
  - **Art. 5º, caput, inciso VIII, alínea "h"** {#art5_cpt_inc8_alih} Cópia do Ato Constitutivo ou do Contrato Social (com última alteração).

###### Art. 6º {#art6}
Tags: #enquadramento #las #licenciamento-ambiental #lo #prazo #residuo-solido #residuo-solido-urbano #triagem

**Art. 6º, caput** {#art6_cpt} #licenciamento-ambiental Os empreendimentos já implantados, que necessitam se regularizar, deverão protocolar o pedido de Regularização do Licenciamento Ambiental.
- **Art. 6º, caput, inciso I** {#art6_cpt_inc1} #prazo #residuo-solido Fica concedido o prazo 12 meses, a partir da publicação desta Portaria, para que os responsáveis por barracões de triagem de resíduos sólidos não perigosos regularizem seus empreendimentos junto ao órgão ambiental
- **Art. 6º, caput, inciso II** {#art6_cpt_inc2} #enquadramento #las #lo Para as situações que trata este artigo, conforme o porte do empreendimento, poderá ser emitida a Licença Ambiental Simplificada ou Licença de Operação.

###### Art. 7º {#art7}
Tags: #documentacao #las #li #lo #lp #prazo #renovacao #residuo-solido-urbano #triagem

**Art. 7º, caput** {#art7_cpt} #documentacao #prazo O IAP estabelecerá os prazos de validade de cada tipo de licença ambiental, especificando-os no respectivo documento, levando em consideração os seguintes aspectos:
- **Art. 7º, caput, inciso III** {#art7_cpt_inc3} #lp #prazo #renovacao O prazo de validade da Licença Prévia (LP) será de 2 (dois) anos. A Licença Prévia - LP não é passível de renovação.
- **Art. 7º, caput, inciso IV** {#art7_cpt_inc4} #li #prazo #renovacao O prazo de validade da Licença de Instalação (LI) será de 2 (dois) anos. A Licença de Instalação - LI poderá ser renovada. A renovação deve ser requerida no mínimo 120 (cento e vinte) dias antes da data de sua expiração.
- **Art. 7º, caput, inciso V** {#art7_cpt_inc5} #lo #prazo #renovacao O prazo de validade da Licença de Operação (LO) será de 04 (quatro) anos. A Licença de Operação (LO) poderá ser renovada. A renovação deve ser requerida no mínimo 120 (cento e vinte) dias antes da data de sua expiração.
- **Art. 7º, caput, inciso VI** {#art7_cpt_inc6} #las #prazo #renovacao O prazo de validade da Licença Ambiental Simplificada (LAS) será de 06 (seis) anos. A Licença Ambiental Simplificada (LAS) poderá ser renovada. A renovação deve ser requerida no mínimo 120 (cento e vinte) dias antes da data de sua expiração.

**Art. 7º, parágrafo único** {#art7_par1u} #prazo Em casos excepcionais, justificados por motivos técnicos e/ou legais, o IAP poderá reduzir o prazo de validade das Licenças. DAS DISPOSIÇÕES TRANSITÓRIAS E FINAIS

###### Art. 8º {#art8}
Tags: #documentacao #licenciamento-ambiental #residuo-solido-urbano #triagem

**Art. 8º, caput** {#art8_cpt} #documentacao #licenciamento-ambiental Caso haja necessidade, o IAP solicitará, a qualquer momento, outros documentos e informações complementares do requerente ou de outras instituições envolvidas no licenciamento ambiental em questão, inclusive o Plano de Controle Ambiental (ANEXO 7), assim como a anotação de responsabilidade técnica pelo projeto, implantação e operação do empreendimento.

###### Art. 9º {#art9}
Tags: #residuo-solido-urbano #responsavel-tecnico #triagem

**Art. 9º, caput** {#art9_cpt} #responsavel-tecnico O descumprimento das disposições desta Portaria, dos termos das Licenças Ambientais sujeitará o infrator às penalidades previstas na [[lei-federal-9605-1998|Lei nº 9.605, de 12 de fevereiro de 1998]], e em outros dispositivos normativos pertinentes, sem prejuízo do dever de recuperar os danos ambientais causados, na forma do art. 225, Parágrafo 4º, da Constituição Federal do Brasil, e do art. 14, Parágrafo 1o, da Lei n. 6.938, de 1981.

###### Art. 10 {#art10}
Tags: #residuo-solido-urbano #triagem

**Art. 10, caput** {#art10_cpt} O Instituto Ambiental do Paraná poderá reformular e/ou complementar os critérios estabelecidos na presente Portaria de acordo com o desenvolvimento científico e tecnológico e a necessidade de preservação ambiental.

###### Art. 11 {#art11}
Tags: #residuo-solido-urbano #triagem

**Art. 11, caput** {#art11_cpt} Casos não contemplados nesta Portaria serão analisados caso a caso pelo IAP.

###### Art. 12 {#art12}
Tags: #residuo-solido-urbano #triagem

**Art. 12, caput** {#art12_cpt} Fica revogada a [[portaria-iap-167-2012|Portaria IAP n° 167 de 07 de agosto de 2012]]

###### Art. 13 {#art13}
Tags: #residuo-solido-urbano #triagem

**Art. 13, caput** {#art13_cpt} Esta Portaria entra em vigor na data de sua publicação.


## Fecho

LUIZ TARCÍSIO MOSSATO PINTO Diretor Presidente do Instituto Ambiental do Paraná

REQUERIMENTO DE LICENCIAMENTO AMBIENTALDOCUMENTO DESTINADO À FORMALIZAÇÃO DO

REQUERIMENTO         PARA TODAS        AS     MODALIDADES       DE   LICENCIAMENTO        DE   ATIVIDADES POLUIDORAS, DEGRADANTES E/OU MODIFICADORAS DO MEIO AMBIENTE Secretaria de Estado do Meio Ambiente e Recursos HídricoS Diretoria de Controle de Recursos Ambientais 01 – USO DO IAP01 protocolo sid 02 – IDENTIFICAÇÃO DO REQUERENTE 02 RAZÃO SOCIAL (PESSOA JURÍDICA) OU NOME (PESSOA FÍSICA) 03 CNPJ OU CPF/MF 04 INSCRIÇÃO ESTADUAL PESSOA JURÍDICA OU RG PESSOA FÍSICA 05 ENDEREÇO COMPLETO 06 BAIRRO 07 MUNICÍPIO/UF 08 CEP 09 TELEFONE PARA CONTATO 03 – IDENTIFICAÇÃO DO OBJETO DA SOLICITAÇÃO 10 SOLICITAÇÃO DE LICENCIAMENTO AMBIENTAL PARA (TIPO DE EMPREENDIMENTO) 04 – REQUERIMENTO

AO SENHORDIRETOR PRESIDENTE DO INSTITUTO AMBIENTAL DO PARANÁCURITIBA - PARANÁO

REQUERENTE SUPRA CITADO, VEM MUI RESPEITOSAMENTE À PRESENÇA DE V.S., REQUERER EXPEDIÇÃO DE(A): 12 MODALIDADE DE LICENCIAMENTO AMBIENTAL

DISPENSA DE LICENÇA AMBIENTAL ESTADUAL - DLAE AUTORIZAÇÃO AMBIENTAL - AA

LICENÇA AMBIENTAL SIMPLIFICADA - LAS LICENÇA PRÉVIA - LP

LICENÇA DE INSTALAÇÃO - LI LICENÇA DE OPERAÇÃO - LO RENOVAÇÃO DE: DLAE LAS LI LO REGULARIZAÇÃO DO LICENCIAMENTO

CONFORME ELEMENTOS CONSTANTES DAS INFORMAÇÕES CADASTRADAS E DOCUMENTOS EM

ANEXO.DECLARA, OUTROSSIM, QUE CONHECE A LEGISLAÇÃO AMBIENTAL E DEMAIS NORMAS

PERTINENTES AO LICENCIAMENTO REQUERIDO, COMPROMETENDO-SE A RESPEITÁ-LA.NESTES

TERMOSPEDE DEFERIMENTO 13 LOCAL E DATA 14 ASSINATURA DO REQUERENTE 05 – IDENTIFICAÇÃO DO RESPONSÁVEL TÉCNICO (SE HOUVER) 15 NOME DO TÉCNICO RESPONSÁVEL 16 QUALIFICAÇÃO PROFISSIONAL 17 NO REGISTRO NO CREA 18 REGIÃO 19 POSSUI PENDÊNCIAS TÉCNICAS OU LEGAIS?

SIM NÃO TIPO 06 – RECEPÇÃO DE DOCUMENTOS 20 POSSUI DÉBITOS AMBIENTAIS? SIM NÃO 21 FORMA DE ENTREGA DA LICENÇA 22 ESCRITÓRIO REGIONAL DO IAP DE : 23 DOCUMENTOS E TAXA AMBIENTAL CONFERIDOS POR: (NOME, CARIMBO E ASSINATURA) 24 DATA

CADASTRO PARA BARRACÕES DE TRIAGEM DE RESÍDUOS NÃO PERIGOSOSDOCUMENTO

DESTINADO AO CADASTRAMENTO DE EMPREENDIMENTOS INDUSTRIAIS PARA QUALQUER

MODALIDADE DE LICENCIAMENTO AMBIENTAL CBR

SECRETARIA DE ESTADO DO MEIO AMBIENTE E RECURSOS HÍDRICOS DIRETORIA DE CONTROLE DE RECURSOS AMBIENTAIS - DIRAM 01 USO DO IAP01 PROTOCOLO SID 02 IDENTIFICAÇÃO DO REQUERENTE 02 RAZÃO SOCIAL 03 CGC 04 INSCRIÇÃO ESTADUAL 05 TELEFONE (DDD - NÚMERO) 06 FAX (DDD - NÚMERO) 07 ENDEREÇO PARA CONTATO 08 BAIRRO /DISTRITO 09 MUNICÍPIO/UF 10 CEP 11 NOME PARA CONTATO 12 CARGO 13 FONE PARA CONTATO 03 CARACTERIZAÇÃO DA ATIVIDADE GERADORA DO RESÍDUO 14 ATIVIDADE 15 CÓDIGO 16 ENDEREÇO DA ATIVIDADE 17 BAIRRO /DISTRITO 18 MUNICÍPIO/UF 19 CEP

RESÍDUOS RECEBIDOS DESTINOS SELECIONADOS 20 TIPO 21 QUANTIDADE/MÊS 22 TIPO 23 QUANTIDADE/MÊS 24 RESPONSÁVEL PELAS INFORMAÇÕES 25 NOME COMPLETO 26 CPF - CADASTRO DE PESSOA FÍSICA 27 LOCAL E DATA ASSUMO SOB AS PENAS DA LEI, QUE AS INFORMAÇÕES PRESTADAS SÃO VERDADEIRAS 28

ASSINATURA

ANEXO 3 Modelo de certidão do município, quanto ao uso e ocupação do solo Em papel timbrado do Município. CERTIDÃO MUNICÍPIO DE - (NOME DO MUNICÍPIO) Declaramos ao INSTITUTO AMBIENTAL DO PARANÁ - IAP/SEMA que o Empreendimento abaixo descrito, está localizado neste Município e que o Local, o Tipo de Empreendimento e Atividade estão em conformidade com a legislação municipal aplicável ao uso e ocupação do solo (nº do diploma legal pertinente) bem como atendem as demais exigências legais e administrativas perante o nosso Município.

EMPREENDEDOR CPF/CNPJ

NOME DO EMPREENDIMENTO

ATIVIDADE ENDEREÇO BAIRRO CEP TELEFONE Local e Data Nome, assinatura e carimbo do Prefeito Municipal e/ou Secretário Municipal

ANEXO 4 Formulário de Controle Ambiental de Barracão de Triagem de Resíduos Não Perigosos O formulário poderá ser preenchido a mão 1.Nome completo do responsável/presidente pelo barracão 2.Telefone para contato do responsável pelo estabelecimento: 3.Endereço completo do estabelecimento: 4.E-mail para contato 5.O barracão pertence a: Cooperativa Associação de catadores Prefeitura do município Outro: ___________ 6.Número de funcionários/ * 7.Turno de trabalho manhã tarde noite 8.Horário de trabalho * Horários fixos ou flexível (cada pessoa estabelece sua carga horária) Fixo Flexível 9.Quantidade de resíduos recebida kg/dia 10.Porcentagem de resíduos recicláveis 0 - 50% 50 - 100% 11.Porcentagem de resíduos orgânicos 10 - 50% 50 - 100% 12.Local de armazenamento dos resíduos orgânicos Tambores Sacos plásticos Outro: 13.Qual a Razão Social (nome da empresa) do destino do material orgânico separado? 14.Frequência em que os resíduos orgânicos são levados ao destino final vezes/mês 15.No barracão existe local para fazer compostagem do material orgânico? Sim Não 16.Quantas vezes ao dia chegam novas cargas de resíduos coletados? vezes/dia 17.Quantidade dos Plásticos separados: kg/dia 18.Quantidade dos Papéis separados: kg/dia 19.Quantidade dos Metais separados: kg/dia 20.Quantidade dos Vidros separados: kg/dia 21.Especificar em quais subgrupos são divididos os Plásticos: 22.Especificar em quais subgrupos são divididos os Papéis: 23.Especificar em quais subgrupos são divididos os Metais: 24.Especificar em quais subgrupos são divididos os Vidros: 25.Qual a Razão Social (nome da empresa) do destino dos líquidos que sobraram nas garrafas, latas, tambores, etc? 26.Qual a Razão Social (nome da empresa) do destino dos resíduos como latas de tinta, embalagens de agrotóxicos, seringas, lâmpadas e pilhas, misturados aos demais tipos de resíduos? 27.Quantidade de mesas de triagem manual 28.Quantidade de esteiras mecânicas 29.Quantidade de prensas elétricas 30.Quantidade de prensas manuais 31.Quantidade de empilhadeiras 32.Quantidade de balanças 33.Quantas vezes por mês é feita a manutenção das esteiras? 34.Quantas vezes por mês é feita a manutenção das prensas? 35.Quantas vezes por mês é feita a manutenção das empilhadeiras? 36.Quem é o responsável pela manutenção dos equipamentos? Proprietário Terceirizado 37.Quantidade de óleo lubrificante gerado na manutenção dos equipamentos (prensa e da empilhadeira) L/mês 38.Qual a Razão Social (nome da empresa) do destino desse óleo? 39.Quem é responsável pela limpeza do galpão? Trabalhadores do local Terceirizados 40.Qual a freqüência e os produtos utilizados na limpeza dos barracões? 41.Para onde é encaminhado o esgoto? Rede coletora de esgoto Galeria de águas pluviais Fossa e sumidouro Outro: __________ 42.De que maneira se evita a proliferação de vetores de doenças? 43.O ambiente do barracão é: Aberto Parcialmente fechado Totalmente fechado 44.A maior parte do piso do barracão é feito de: Concreto Cerâmica Chão batido Outro: 45.A maior parte do sistema de iluminação do barracão é: Natural Artificial 46.Construções vizinhas ao barracão * Ao lado esquerdo Residência Comércio Indústria Outro: 47.Construções vizinhas ao barracão * Ao lado direito Residência Comércio Indústria Outro: 48.Construções vizinhas ao barracão * A frente Residência Comércio Indústria Outro: 49.Construções vizinhas ao barracão * Atrás Residência Comércio Indústria Outro:

ANEXO 5 Relatório Anual de recebimento, movimentação, processamento e destinação final dos resíduos, descrevendo o gerador, classificação, quantidades e tratamento/destinação final adotados. Este relatório deverá ser entregue na ocasião da renovação de licença ambiental simplificada, na renovação da licença de operação e na ocasião da regularização do licenciamento, e deverá ser referente a cada ano de operação. Os arquivos deverão ser mantidos na administração do empreendimento. O relatório deve conter as seguintes informações: - Período de referência do documento; - Informações sobre a perspectiva de reformas e ampliações no empreendimento; - Medidas adotadas para controle de vetores; - Medidas adotadas para controle ambiental; - Identificar os resíduos recolhidos pelo empreendimento, suas quantidades, características, geradores e pontos de coleta; - Descrever o processo de manuseio e triagem dos resíduos, especificando o local de armazenamento temporário e equipamentos utilizados; - Preencher a seguinte tabela, com os dados referentes aos resíduos já separados e possíveis rejeitos do processo: Resíduo Quantidade(ton/mês) Forma de destinação final Razão social da empresa responsável pela destinação final Nº da Licença Ambiental da empresa responsável pela destinação final

ANEXO 6 FUNDAMENTO LEGAL: RESOLUÇÃO CONAMA 06/1986 Modelo para publicação de REQUERIMENTO de licença em Jornal Local e Diário Oficial (Nome da empresa ou Município) torna público que (requereu ou recebeu) do IAP, a (LAS, LP, LI, LO, RLI ou RLO) com validade de até (data de validade apenas para licença recebida) para (atividade e local).

ANEXO 7 – Termo de referência para elaboração de PCA

1. MEMORIAL TÉCNICO 1.1. Informações sobre os resíduos

a) origem dos resíduos;

b) composição dos resíduos, com indicação das frações de resíduos orgânicos e inorgânicos, recicláveis e de rejeitos;

c) quantidade diária e mensal a ser recebida na área;

d) freqüência e horário de recebimento. 1.2. Concepção e justificativa de projeto Devem ser apresentadas a concepção e a metodologia de operação, justificando face às suas finalidades. 1.3. Descrição e especificações do projeto Todos os elementos de projeto devem ser suficientemente descritos e especificados, com apresentação de desenhos, esquemas, detalhes, cálculos, etc. 1.3.1. Disposição dos resíduos Especificar o local e a forma como os resíduos serão armazenados e dispostos, antes e depois da triagem. 1.3.2. Acessos e isolamento da área Apresentar a forma de isolamento do empreendimento e os dispositivos de segurança para evitar a interferência de pessoas estranhas e animais, bem como para coibir possíveis efeitos na vizinhança. 1.3.3. Fluxograma e descrição detalhada do processo Apresentar uma descrição da atividade, bem como um fluxograma detalhado da operação, contendo todas as atividades realizadas no empreendimento. Obs.: Quando houver utilização de simbologia ou abreviatura, anexar ao fluxograma legenda explicativa. 1.3.4. Descrição do sistema de captação de água, limpeza do barracão , estruturas e drenagem Quando existirem áreas descobertas de estocagem de resíduos, contemplar sistema de prevenção para a não contaminação das águas pluviais. Detalhar sistemas de drenagem, impermeabilização e contenção. 1.3.5. Instalações de apoio Deverão ser descritas as instalações de apoio a serem instaladas na área. Detalhar o abastecimento de água e o esgotamento sanitário nas instalações. 1.3.6. Controle Ambiental Detalhar as medidas de controle ambiental a serem adotadas, bem como de controle de vetores. Especificar a possível geração de rejeitos e efluentes, e a destinação a ser dada. 1.4. Equipe de trabalho e equipamentos

a) Quantificar a equipe de trabalho;

b) Adoção de equipamentos de proteção individual - EPI

c) Especificar e quantificar os equipamentos a serem utilizados na operação do empreendimento, tais como veículos, balanças de pesagem, mesas de triagem manual, esteira mecânicas, prensas elétricas, entre outros.

2. REPRESENTAÇÃO GRÁFICA Planta da concepção geral Devem ser apresentados em um único desenho georeferenciado os seguintes elementos:

a) localização geográfica do barracão;

b) acessos principais e instalações de apoio;

c) cursos de água e poços existentes na região. Planta com indicação das áreas de deposição de resíduos sólidos

a) indicação das áreas de deposição dos resíduos sólidos;

b) limites da área total a ser utilizada;

c) apresentação do perfil original do terreno, com as devidas cotas, e identificação do nível d’água subterrânea;

d) cortes longitudinais e transversais, onde necessário, para melhor visualização dos elementos do sistema. Planta com representação da área e vegetação

a) indicação do isolamento da área;

c) indicação da área de Reserva Legal;

d) indicação das áreas de Preservação Permanente;

e) indicação de demais áreas com presença de vegetação, se aplicável. Apresentação das plantas As pranchas de desenho e demais peças deverão possuir identificação contendo:

a) Denominação e local da obra;

b) Nome da entidade executora;

c) Tipo de projeto;

d) Data;

e) Nome do responsável técnico, número de registro no CREA e sua assinatura.

### Requerimento de Licenciamento Ambiental {#anexo1}

Modelo de requerimento de Licenciamento Ambiental.

### Cadastro de Barracão de Triagem de Resíduos Sólidos Não Perigosos {#anexo2}

Modelo de cadastro de Barracão de Triagem de Resíduos Sólidos Não Perigosos.

### Certidão do município, quanto ao uso e ocupação do solo {#anexo3}

Modelo de certidão do município, quanto ao uso e ocupação do solo.

### Formulário de Controle Ambiental de Barracão de Triagem de Resíduos Não Perigosos {#anexo4}

Modelo de formulário de Controle Ambiental de Barracão de Triagem de Resíduos Não Perigosos.

### Relatório Anual de recebimento, movimentação, processamento e destinação final dos resíduos {#anexo5}

[[portaria-iap-155-2013-anexo5|Relatório Anual de recebimento, movimentação, processamento e destinação final dos resíduos]]

### Publicação de REQUERIMENTO de licença em Jornal Local e Diário Oficial {#anexo6}

Modelo de publicação de REQUERIMENTO de licença em Jornal Local e Diário Oficial.

### Termo de referência para elaboração de PCA {#anexo7}

[[portaria-iap-155-2013-anexo7|Termo de referência para elaboração de PCA]]

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|
| [[instrucao-normativa-iat-31-2025]] | Norma inteira | Revogação expressa registrada no acervo. |

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (portaria IAP 155 2013(1).pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- Fonte: portaria IAP 155 2013(1).pdf (portal Sistema de Informações Ambientais do Paraná). Foram retirados os marcadores de página da extração e reunidas as quebras de linha; mantidas as grafias do texto fornecido.
- A transcrição foi feita a partir do texto extraído disponível. A comparação palavra por palavra com a extração local do PDF e a conferência visual não foram concluídas nesta etapa.
- Anexo misto: transcritas as diretrizes textuais do relatório; a tabela vazia para preenchimento foi tratada como modelo, conforme a regra de anexos tipo 1. As instruções sobre preenchimento permanecem no texto.
- Revisão de numeração: ID duplicado: art5_cpt_inc2_alia. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Revisão de numeração: sequência de alínea: art5_cpt_inc2_alia-dup2 após art5_cpt_inc2_alia. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Revisão de numeração: sequência de alínea: art5_cpt_inc8_alie após art5_cpt_inc8_alic. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Revisão de numeração: sequência de alínea: art5_cpt_inc8_alid após art5_cpt_inc8_alie. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Revisão de numeração: ID duplicado: art5_cpt_inc8_alie. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Revisão de numeração: inciso inicial III: art7_cpt_inc3. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Situação revogada conforme relação expressa já cadastrada no acervo: [[instrucao-normativa-iat-31-2025]]. Regras de transição e processos antigos devem ser avaliados separadamente.
