---
norma: "Resolução SEDEST nº 16/2020"
arquivo: resolucao-sedest-16-2020
tipo: resolucao
esfera: estadual
uf: PR
numero: 16
ano: 2020
data_assinatura: 2020-03-05
ementa: "Estabelece condições e critérios e dá outras providências, para o licenciamento ambiental de Empreendimentos de Avicultura no Estado do Paraná e dá outras providências."
situacao: revogada
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: []
revoga: ["[[resolucao-sema-54-2019]]"]
revogado_por: ["[[decreto-estadual-9541-2025]]"]
cita: ["[[decreto-estadual-1440-2019]]", "[[decreto-estadual-2432-2019]]", "[[decreto-estadual-5503-2002]]", "[[lei-estadual-10066-1992]]", "[[lei-estadual-7109-1979]]", "[[lei-federal-11326-2006]]", "[[lei-federal-19848-2019]]", "[[lei-federal-19857-2019]]", "[[lei-federal-9605-1998]]", "[[resolucao-cema-105-2019]]", "[[resolucao-conama-6-1986]]", "[[resolucao-sema-54-2019]]"]
tags: ["app", "avicultura", "definicao", "documentacao", "efluente", "enquadramento", "las", "li", "licenciamento-ambiental", "lo", "lp", "monitoramento", "outorga", "prazo", "proibicao", "renovacao", "residuo-solido", "responsavel-tecnico"]
fonte: "PDF fornecido: sedest 16 2020(1).pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
---

# Resolução SEDEST nº 16/2020

> Estabelece condições e critérios e dá outras providências, para o licenciamento ambiental de Empreendimentos de Avicultura no Estado do Paraná e dá outras providências.

## Preâmbulo

Resolução SEDEST 16 - 05 de Março de 2020 Publicado no Diário Oficial nº. 10640 de 6 de Março de 2020 Súmula: Estabelece condições e critérios e dá outras providências, para o licenciamento ambiental de Empreendimentos de Avicultura no Estado do Paraná e dá outras providências. O SECRETÁRIO DE ESTADO DO DESENVOLVIMENTO SUSTENTÁVEL E DO TURISMO, designado pelo [[decreto-estadual-1440-2019|Decreto Estadual n. º 1440, de 23 de maio de 2019]], no uso das atribuições que lhe são conferidas pela Lei Estadual nº [[lei-federal-19848-2019|Lei nº 19.848, de 3 de maio de 2019]] e [[lei-estadual-10066-1992|Lei n° 10.066, de 27 de julho de 1992]], e Considerando que a proteção do meio ambiente é um dever do Poder Público, conforme dispõe o Art. 225, § 1º, da Constituição Federal; Considerando o disposto na Resolução do Conselho Nacional de Meio Ambiente- CONAMA nº 237, de 19 de dezembro de 1997; Considerando as Resoluções do Conselho Nacional de Meio Ambiente - CONAMA nº 357, de 17 de março de 2005 e 430, de 13 de maio de 2011, que dispõem sobre condições e padrões de lançamento de efluentes; Considerando o disposto na Resolução do Conselho Estadual do Meio Ambiente - CEMA nº 105 de 17 de dezembro de 2019, que dispõe sobre o licenciamento ambiental; Considerando o inciso XVI, art.4.º da [[lei-federal-19848-2019|Lei 19.848, de 03 de maio de 2019]] que estabelece competências para os Secretários de Estado para propor, planejar, coordenar e sugerir a adoção de medidas de desburocratização e eficiência na gestão; Considerando o §2.º do art.3.º da [[lei-federal-19857-2019|Lei 19.857 de 29 de maio de 2019]], que institui o Programa de Integridade e Compliance da Administração Pública Estadual, cujos mecanismos visam proteger o órgão e a entidade, bem como impor aos agentes públicos e políticos o compromisso com a ética, o respeito, a integridade e a eficiência na prestação do serviço público. Considerando o [[decreto-estadual-2432-2019|Decreto Estadual 2.432, de 15 de agosto de 2019]] que criou o Comitê Permanente de Desburocratização, com o objetivo de identificar os principais entraves burocráticos para a categoria empresarial no Estado do Paraná e trabalhar em função de soluções, melhorando o ambiente de negócios; Considerando o Plano de Ação “Descomplica” da SEDEST, aprovado pelo Comitê Permanente de Desburocratização, cujo objetivo é a simplificação dos procedimentos de licenciamento RESOLVE:

###### Art. 1º {#art1}
Tags: #avicultura #licenciamento-ambiental

**Art. 1º, caput** {#art1_cpt} #licenciamento-ambiental Estabelecer critérios para o Licenciamento Ambiental de Empreendimentos de Avicultura com aproveitamento econômico.

###### Art. 2º {#art2}
Tags: #avicultura #definicao #documentacao #enquadramento #licenciamento-ambiental #monitoramento #responsavel-tecnico

**Art. 2º, caput** {#art2_cpt} #definicao Para os efeitos desta Resolução, considera-se:
- **Art. 2º, caput, inciso I** {#art2_cpt_inc1} Agricultor Familiar: aquele que pratica atividades no meio rural, atendendo, aos seguintes requisitos estabelecidos no artigo [[#art3|3º]] de [[lei-federal-11326-2006|Lei Federal nº 11.326, de 24 de julho de 2006]];
- **Art. 2º, caput, inciso II** {#art2_cpt_inc2} Estudos Ambientais Específicos: todos e quaisquer estudos relativos aos aspectos ambientais relacionados à localização, instalação, operação e ampliação de uma atividade ou empreendimento, apresentado como subsídio para a análise da licença requerida, como Plano de Controle Ambiental, Projeto de Controle de Poluição Ambiental e Plano de Recuperação de Área Degradada;
- **Art. 2º, caput, inciso III** {#art2_cpt_inc3} Fonte de Poluição: qualquer atividade, sistema, processo, operação, maquinaria, equipamentos ou dispositivos, móvel ou imóvel previstos no regulamento da [[lei-estadual-7109-1979|Lei Estadual nº 7109/79]], que alterem ou possam vir a alterar o Meio Ambiente;
- **Art. 2º, caput, inciso IV** {#art2_cpt_inc4} Licença Ambiental: ato administrativo pelo qual o órgão ambiental competente, estabelece as condições, restrições e medidas de controle ambiental que deverão ser obedecidas pelo empreendedor, pessoa física ou jurídica, para localizar, instalar, ampliar e operar empreendimentos ou atividades utilizadoras dos recursos ambientais consideradas efetiva ou potencialmente poluidoras ou aquelas que, sob qualquer forma, possam causar degradação e/ou modificação ambiental;
- **Art. 2º, caput, inciso V** {#art2_cpt_inc5} #licenciamento-ambiental Licenciamento Ambiental: procedimento administrativo pelo qual o órgão ambiental competente, verificando a satisfação das condições legais e técnicas, licencia a localização, instalação, ampliação e a operação de empreendimentos e atividades utilizadoras de recursos ambientais consideradas efetiva ou potencialmente poluidoras ou daquelas que, sob qualquer forma, possam causar degradação e/ou modificação ambiental, considerando as disposições legais e regulamentares e as normas técnicas aplicáveis ao caso;
- **Art. 2º, caput, inciso VI** {#art2_cpt_inc6} #documentacao #responsavel-tecnico Responsável Técnico: profissional especializado na área de abrangência do sistema, responsável pelos projetos, orientação, documentação técnica, citados nesta Resolução; e
- **Art. 2º, caput, inciso VII** {#art2_cpt_inc7} #enquadramento #licenciamento-ambiental #monitoramento Sistema de Gestão Ambiental – SGA: Módulo Licenciamento, sistema informatizado para emissão de licenças ambientais, permitindo aos usuários a requisição de licenças pela internet, além de disponibilizar consultas e outras informações. É integrada com uma base de dados georreferenciados que serve de apoio à tomada de decisão na emissão de pareceres e laudos técnicos, bem como na decisão administrativa, além de dar suporte aos módulos de monitoramento e fiscalização.

###### Art. 3º {#art3}
Tags: #avicultura #documentacao #enquadramento #las #li #licenciamento-ambiental #lo #lp #prazo

**Art. 3º, caput** {#art3_cpt} O Órgão Ambiental Competente, no exercício de sua competência de controle ambiental, expedirá os seguintes atos administrativos:
- **Art. 3º, caput, inciso I** {#art3_cpt_inc1} #prazo Autorização Ambiental - AA: ato administrativo discricionário pelo qual o IAT estabelece condições, restrições e medidas de controle ambiental empreendimentos ou atividades específicas, com prazo de validade estabelecido de acordo com a natureza do empreendimento ou atividade;
- **Art. 3º, caput, inciso II** {#art3_cpt_inc2} #documentacao Autorização Ambiental Florestal – AAF: documento expedido pelo Órgão Ambiental Competente que permite ao proprietário de um imóvel a condição de efetuar o corte de vegetação florestal nativa, árvores isoladas em ambiente florestal ou agropecuário e aproveitamento material lenhoso seco;
- **Art. 3º, caput, inciso III** {#art3_cpt_inc3} #licenciamento-ambiental Declaração de Dispensa de Licenciamento Ambiental Estadual – DLAE: concedida para os empreendimentos cujo licenciamento ambiental não compete ao órgão ambiental estadual, conforme os critérios estabelecidos em resoluções específicas;
- **Art. 3º, caput, inciso IV** {#art3_cpt_inc4} #documentacao #enquadramento #las Licença Ambiental Simplificada – LAS: aprova a localização e a concepção do empreendimento, atividade ou obra de pequeno porte e/ou que possua baixo potencial poluidor/degradador, atestando a viabilidade ambiental e estabelecendo os requisitos básicos e condicionantes a serem atendidos, bem como autoriza sua instalação e operação de acordo com as especificações constantes dos requerimentos, planos, programas e/ou projetos aprovados, incluindo as medidas de controle ambiental e demais condicionantes determinadas pelo Órgão Ambiental Competente;
- **Art. 3º, caput, inciso V** {#art3_cpt_inc5} #lp Licença Prévia – LP: concedida na fase preliminar do planejamento do empreendimento ou atividade, aprovando sua localização e concepção, atestando a viabilidade ambiental e estabelecendo os requisitos básicos e condicionantes a serem atendidos nas próximas fases de sua implementação;
- **Art. 3º, caput, inciso VI** {#art3_cpt_inc6} #li Licença de Instalação – LI: autoriza a instalação do empreendimento ou atividade de acordo com as especificações constantes dos planos, programas e projetos aprovados, incluindo as medidas de controle ambiental e demais condicionantes; e
- **Art. 3º, caput, inciso VII** {#art3_cpt_inc7} #lo Licença de Operação – LO: autoriza o funcionamento da atividade ou empreendimento, após a verificação do efetivo cumprimento do que consta das licenças anteriores, com as medidas de controle ambientais e condicionantes determinados para a operação.

###### Art. 4º {#art4}
Tags: #avicultura #definicao #enquadramento #licenciamento-ambiental #responsavel-tecnico

**Art. 4º, caput** {#art4_cpt} Esta Resolução se aplica às atividades de avicultura comercial, como granjas, postura comercial, recria de matrizes, postura de ovos férteis e avicultura de corte.

**Art. 4º, parágrafo único** {#art4_par1u} #definicao #enquadramento #licenciamento-ambiental #responsavel-tecnico Ficam excluídos os empreendimentos de avicultura/incubatórios, que são enquadrados como atividades industriais. Art. 5º Os empreendimentos de avicultura serão classificados de acordo com a tipologia, sistema de criação e porte:

I - tipologia do empreendimento:

a) postura comercial;

b) recria de matrizes;

c) postura de ovos férteis; e

d) avicultura de corte.

II - sistema de criação: confinamento;

III - porte do empreendimento: o porte de empreendimentos de avicultura, para fins de licenciamento ambiental é definido através da área construída para o confinamento das aves, conforme os seguintes parâmetros:

###### Art. 6º {#art6}
Tags: #app #avicultura #documentacao #enquadramento #licenciamento-ambiental

**Art. 6º, caput** {#art6_cpt} #licenciamento-ambiental São passíveis de Declaração de Dispensa de Licenciamento Ambiental - DLAE os empreendimentos de avicultura com área construída de confinamento de no máximo 7.000 m2 de área construída.

**Art. 6º, § 1º** {#art6_par1} #enquadramento Para os empreendimentos enquadrados no caput deste artigo o interessado deverá ser cadastrado no SGA como Usuário Ambiental.

**Art. 6º, § 2º** {#art6_par2} #licenciamento-ambiental A Declaração de Dispensa de Licenciamento Ambiental - DLAE é obrigatória e deverá ser solicitada através do SGA, instruído na forma prevista abaixo:
- **Art. 6º, § 2º, inciso I** {#art6_par2_inc1} croqui de localização do empreendimento com imagem aérea e contendo no mínimo:
  - **Art. 6º, § 2º, inciso I, alínea "a"** {#art6_par2_inc1_alia} distância dos corpos hídricos;
  - **Art. 6º, § 2º, inciso I, alínea "b"** {#art6_par2_inc1_alib} #app áreas de preservação permanente;
  - **Art. 6º, § 2º, inciso I, alínea "c"** {#art6_par2_inc1_alic} cobertura florestal;
  - **Art. 6º, § 2º, inciso I, alínea "d"** {#art6_par2_inc1_alid} vias de acesso principais; e
  - **Art. 6º, § 2º, inciso I, alínea "e"** {#art6_par2_inc1_alie} pontos de referências.
- **Art. 6º, § 2º, inciso II** {#art6_par2_inc2} requerer a AAF em caso de necessidade de supressão florestal, antes do início das obras de instalação; e
- **Art. 6º, § 2º, inciso III** {#art6_par2_inc3} #documentacao documento de propriedade ou justa posse rural, conforme Capitulo II, Seção V da [[resolucao-cema-105-2019|Resolução CEMA nº 105 de 17 de dezembro de 2019]];

**Art. 6º, § 3º** {#art6_par3} Qualquer alteração na área construída de confinamento para os empreendimentos de Avicultura, deverá ser solicitada a respectiva Licença Ambiental.

**Art. 6º, § 4º** {#art6_par4} #licenciamento-ambiental A dispensa do Licenciamento Ambiental não exime o dispensado das exigências legais quanto à preservação do meio ambiente.

###### Art. 7º {#art7}
Tags: #app #avicultura #documentacao #enquadramento #las #licenciamento-ambiental #outorga #prazo #renovacao #responsavel-tecnico

**Art. 7º, caput** {#art7_cpt} #documentacao #enquadramento #las #renovacao O requerimento de Licença Ambiental Simplificada – LAS, bem como sua renovação, para os Empreendimentos de Avicultura classificados como de porte mínimo, deverá ser realizado através do SGA, instruído na forma prevista abaixo:
- **Art. 7º, caput, inciso I** {#art7_cpt_inc1} #las LICENÇA AMBIENTAL SIMPLIFICADA – LAS:
  - **Art. 7º, caput, inciso I, alínea "a"** {#art7_cpt_inc1_alia} croqui de localização do empreendimento com imagem aérea atualizada e contendo no mínimo:
    - **Art. 7º, caput, inciso I, alínea "a", item 1** {#art7_cpt_inc1_alia_ite1} estruturas físicas;
    - **Art. 7º, caput, inciso I, alínea "a", item 2** {#art7_cpt_inc1_alia_ite2} distância dos corpos hídricos;
    - **Art. 7º, caput, inciso I, alínea "a", item 3** {#art7_cpt_inc1_alia_ite3} #app áreas de preservação permanente;
    - **Art. 7º, caput, inciso I, alínea "a", item 4** {#art7_cpt_inc1_alia_ite4} cobertura florestal;
    - **Art. 7º, caput, inciso I, alínea "a", item 5** {#art7_cpt_inc1_alia_ite5} vias de acesso principais; e
    - **Art. 7º, caput, inciso I, alínea "a", item 6** {#art7_cpt_inc1_alia_ite6} pontos de referências.
  - **Art. 7º, caput, inciso I, alínea "b"** {#art7_cpt_inc1_alib} #documentacao a Certidão do município ou documento equivalente, quando se tratar de empreendimento em perímetro urbano, declarando expressamente que o local e o tipo de empreendimento estão em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano, bem como atendem as demais exigências legais e administrativas perante o município (Anexo I);
  - **Art. 7º, caput, inciso I, alínea "c"** {#art7_cpt_inc1_alic} #documentacao #prazo a Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente ou em nome do locador, junto com o contrato de locação, em caso de imóvel locado, atualizada em até 90 (noventa) dias contados da data de sua emissão;
  - **Art. 7º, caput, inciso I, alínea "d"** {#art7_cpt_inc1_alid} #documentacao documentação complementar do imóvel se a situação imobiliária estiver irregular conforme Capitulo II, Seção V da [[resolucao-cema-105-2019|Resolução CEMA nº 105 de 17 de dezembro de 2019]];
  - **Art. 7º, caput, inciso I, alínea "e"** {#art7_cpt_inc1_alie} cópia do Ato Constitutivo ou do Contrato Social (com última alteração), quando pessoa jurídica;
  - **Art. 7º, caput, inciso I, alínea "f"** {#art7_cpt_inc1_alif} #outorga número da Outorga de Direito ou Dispensa de Outorga de Uso de Recursos Hídricos, se for o caso;
  - **Art. 7º, caput, inciso I, alínea "g"** {#art7_cpt_inc1_alig} #responsavel-tecnico apresentar Projeto de Controle de Poluição Ambiental, apresentado de acordo com as diretrizes do Anexo II, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
  - **Art. 7º, caput, inciso I, alínea "h"** {#art7_cpt_inc1_alih} apresentar AAF em caso de necessidade de supressão florestal, antes do início das obras de instalação;
  - **Art. 7º, caput, inciso I, alínea "i"** {#art7_cpt_inc1_alii} apresentação da anuência do proprietário, conforme modelo do ANEXO III, no caso de disposição de dejetos no solo para fins agrícolas, em áreas em que o interessado não é o proprietário;
  - **Art. 7º, caput, inciso I, alínea "j"** {#art7_cpt_inc1_alij} #las publicação de súmula do pedido de Licença Ambiental Simplificada - LAS em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]]; e
  - **Art. 7º, caput, inciso I, alínea "k"** {#art7_cpt_inc1_alik} ecolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações
- **Art. 7º, caput, inciso II** {#art7_cpt_inc2} #las #renovacao RENOVAÇÃO DA LICENÇA AMBIENTAL SIMPLIFICADA – LAS:
  - **Art. 7º, caput, inciso II, alínea "a"** {#art7_cpt_inc2_alia} relatório de atendimento das condicionantes da Licença anterior, se for o caso;
  - **Art. 7º, caput, inciso II, alínea "b"** {#art7_cpt_inc2_alib} #las publicação de súmula de concessão de Licença Ambiental Simplificada em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
  - **Art. 7º, caput, inciso II, alínea "c"** {#art7_cpt_inc2_alic} #las #renovacao publicação de súmula do pedido de Renovação de Licença Ambiental Simplificada em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
  - **Art. 7º, caput, inciso II, alínea "d"** {#art7_cpt_inc2_alid} recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações

**Art. 7º, § 1º** {#art7_par1} #documentacao #las #renovacao O requerente terá, automaticamente, sua Licença Ambiental Simplificada, bem como a sua renovação, com a apresentação de toda documentação solicitada neste artigo e após a compensação do pagamento das taxas devidas.

**Art. 7º, § 2º** {#art7_par2} #licenciamento-ambiental O órgão ambiental realizará avaliação posterior das informações constantes no procedimento, podendo solicitar complementações ou até a suspensão do licenciamento.

###### Art. 8º {#art8}
Tags: #app #avicultura #definicao #documentacao #enquadramento #licenciamento-ambiental #lp #outorga #prazo

**Art. 8º, caput** {#art8_cpt} #enquadramento Os Empreendimentos de Avicultura classificados como de porte pequeno, médio, grande e excepcional, deverão requerer sucessivamente as Licenças Prévia, de Instalação e de Operação.

**Art. 8º, § 1º** {#art8_par1} #definicao #enquadramento Este procedimento se aplica a novos empreendimentos, empreendimentos em operação que venham a sofrer ampliações acima do porte, alterações definitivas no processo e incorporação de novas atividades, com alteração das características do empreendimento já implantado.

**Art. 8º, § 2º** {#art8_par2} Em caso de aumento do número de animais sem alteração da área construída de confinamento e, desde que não sejam alteradas as características do empreendimento já implantado, não se aplica o caput deste artigo, devendo o empreendedor comunicar o órgão ambiental competente declarando essa situação.

**Art. 8º, § 3º** {#art8_par3} #documentacao #licenciamento-ambiental Os requerimentos para esses licenciamentos, deverão ser realizados através do SGA, instruído na forma prevista abaixo:
- **Art. 8º, § 3º, inciso I** {#art8_par3_inc1} #lp LICENÇA PRÉVIA:
  - **Art. 8º, § 3º, inciso I, alínea "a"** {#art8_par3_inc1_alia} croqui de localização do empreendimento com imagem aérea atualizada e contendo no mínimo:
    - **Art. 8º, § 3º, inciso I, alínea "a", item 1** {#art8_par3_inc1_alia_ite1} estruturas físicas;
    - **Art. 8º, § 3º, inciso I, alínea "a", item 2** {#art8_par3_inc1_alia_ite2} distância dos corpos hídricos;
    - **Art. 8º, § 3º, inciso I, alínea "a", item 3** {#art8_par3_inc1_alia_ite3} #app áreas de preservação permanente;
    - **Art. 8º, § 3º, inciso I, alínea "a", item 4** {#art8_par3_inc1_alia_ite4} cobertura florestal;
    - **Art. 8º, § 3º, inciso I, alínea "a", item 5** {#art8_par3_inc1_alia_ite5} vias de acesso principais; e
    - **Art. 8º, § 3º, inciso I, alínea "a", item 6** {#art8_par3_inc1_alia_ite6} pontos de referências.
  - **Art. 8º, § 3º, inciso I, alínea "b"** {#art8_par3_inc1_alib} apresentar AAF em caso de necessidade de supressão florestal, antes do início das obras de instalação;
  - **Art. 8º, § 3º, inciso I, alínea "c"** {#art8_par3_inc1_alic} #outorga número da Outorga Prévia para utilização de recursos hídricos, se for o caso;
  - **Art. 8º, § 3º, inciso I, alínea "d"** {#art8_par3_inc1_alid} #documentacao a Certidão do município ou documento equivalente, quando se tratar de empreendimento em perímetro urbano, declarando expressamente que o local e o tipo de empreendimento estão em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano, bem como atendem as demais exigências legais e administrativas perante o município (Anexo I);
  - **Art. 8º, § 3º, inciso I, alínea "e"** {#art8_par3_inc1_alie} #documentacao #prazo a Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente ou em nome do locador, junto com o contrato de locação, em caso de imóvel locado, atualizada em até 90 (noventa) dias contados da data de sua emissão;
  - **Art. 8º, § 3º, inciso I, alínea "f"** {#art8_par3_inc1_alif} #documentacao documentação complementar do imóvel, se a situação imobiliária estiver irregular ou comprometida, conforme Capitulo II,

#### Seção V – da Resolução CEMA nº 105 de 17 de dezembro de 2019; g) cópia do Ato Constitutivo ou do Contrato Social (com última alteração), quando pessoa jurídica; h) publicação de súmula do pedido de Licença Prévia em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela Resolução CONAMA nº 006/86; e II - LICENÇA DE INSTALAÇÃO: a) cópia do Ato Constitutivo ou do Contrato Social (com última alteração), quando pessoa jurídica; b) documento de propriedade ou justa posse rural, conforme Capitulo II, Seção V da Resolução CEMA nº 105 de 17 de dezembro de 2019; c) apresentar AAF em caso de necessidade de supressão florestal, antes do início das obras de instalação; d) Projeto de Controle de Poluição Ambiental, elaborado por profissional(is) habilitado(s) e apresentado de acordo com as diretrizes do Anexo II; e) publicação de súmula da concessão da Licença Prévia em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela Resolução CONAMA nº 006/86; f) publicação de súmula do pedido de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela Resolução CONAMA nº 006/86; e g) recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações. III - LICENÇA DE OPERAÇÃO: a) número da Outorga de Direito ou Dispensa de Outorga de Uso de Recursos Hídricos para utilização de recursos hídricos, se for o caso; b) publicação de súmula de concessão de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela Resolução CONAMA nº 006/86; c) publicação de súmula do pedido de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela Resolução CONAMA nº 006/86; e d) recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações IV - RENOVAÇÃO DE LICENÇA DE OPERAÇÃO: a) croqui de localização do empreendimento com imagem aérea atualizada e contendo no mínimo: 1. estruturas físicas; 2. distância dos corpos hídricos; 3. áreas de preservação permanente; 4. cobertura florestal; 5. vias de acesso principais; e 6. pontos de referências. b) cópia da Licença de Operação; c) relatório de atendimento das condicionantes da licença anterior; d) publicação de súmula de concessão de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela Resolução CONAMA nº 006/86; e) publicação de súmula do pedido de Renovação de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela Resolução CONAMA nº 006/86; e f) recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental , demais valores cabíveis referentes às publicações.

###### Art. 9º {#art9}
Tags: #avicultura #licenciamento-ambiental #prazo #renovacao

**Art. 9º, caput** {#art9_cpt} #prazo #renovacao A RLO e LO de ampliação poderão ser solicitadas de forma unificada quando o prazo de vencimento da LO em renovação for inferior a 01 (um) ano.

###### Art. 10 {#art10}
Tags: #app #avicultura #documentacao #enquadramento #las #licenciamento-ambiental #lo #prazo

**Art. 10, caput** {#art10_cpt} #las #licenciamento-ambiental #lo Para regularização do licenciamento ambiental de empreendimentos já existentes e em operação, que não tenham se submetido ao licenciamento simplificado (LAS) ou ao licenciamento completo (LP, LI, LO), de acordo com Artigo 3° da presente Resolução, deverá solicitar a Licença Ambiental Simplificada de Regularização (LASR) ou a Licença de Operação de Regularização (LOR).

**Art. 10, § 1º** {#art10_par1} #enquadramento Os empreendimentos enquadrados no caput deste artigo, com início de funcionamento posterior à publicação da presente Resolução, ficam sujeitos à aplicação das penalidades legais.

**Art. 10, § 2º** {#art10_par2} #documentacao #enquadramento #licenciamento-ambiental Os requerimentos de licenciamento ambiental para os empreendimentos enquadrados no caput deste artigo deverão ser realizados através do SGA, instruído na forma prevista abaixo:
- **Art. 10, § 2º, inciso I** {#art10_par2_inc1} #las LICENÇA AMBIENTAL SIMPLIFICADA DE REGULARIZAÇÃO – LASR:
  - **Art. 10, § 2º, inciso I, alínea "a"** {#art10_par2_inc1_alia} croqui de localização do empreendimento com imagem aérea atualizada e contendo no mínimo:
    - **Art. 10, § 2º, inciso I, alínea "a", item 1** {#art10_par2_inc1_alia_ite1} estruturas físicas;
    - **Art. 10, § 2º, inciso I, alínea "a", item 2** {#art10_par2_inc1_alia_ite2} distância dos corpos hídricos;
    - **Art. 10, § 2º, inciso I, alínea "a", item 3** {#art10_par2_inc1_alia_ite3} #app áreas de preservação permanente;
    - **Art. 10, § 2º, inciso I, alínea "a", item 4** {#art10_par2_inc1_alia_ite4} cobertura florestal;
    - **Art. 10, § 2º, inciso I, alínea "a", item 5** {#art10_par2_inc1_alia_ite5} vias de acesso principais; e
    - **Art. 10, § 2º, inciso I, alínea "a", item 6** {#art10_par2_inc1_alia_ite6} pontos de referências.
  - **Art. 10, § 2º, inciso I, alínea "b"** {#art10_par2_inc1_alib} #documentacao documento de propriedade ou justa posse rural, conforme [[resolucao-cema-105-2019|Resolução CEMA nº 105 de 17 de dezembro de 2019]];
  - **Art. 10, § 2º, inciso I, alínea "c"** {#art10_par2_inc1_alic} #documentacao a Certidão do município ou documento equivalente, quando se tratar de empreendimento em perímetro urbano, declarando expressamente que o local e o tipo de empreendimento estão em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano, bem como atendem as demais exigências legais e administrativas perante o município (Anexo I);
  - **Art. 10, § 2º, inciso I, alínea "d"** {#art10_par2_inc1_alid} #documentacao #prazo a Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente ou em nome do locador, junto com o contrato de locação, em caso de imóvel locado, atualizada em até 90 (noventa) dias contados da data de sua emissão;
  - **Art. 10, § 2º, inciso I, alínea "e"** {#art10_par2_inc1_alie} #documentacao documentação complementar do imóvel, se a situação imobiliária estiver irregular ou comprometida, conforme Capitulo II,

#### Seção V – da Resolução CEMA nº 105 de 17 de dezembro de 2019; f) cópia do Ato Constitutivo ou do Contrato Social (com última alteração), quando pessoa jurídica; g) número da Outorga de Direito ou Dispensa de Outorga de Uso de Recursos Hídricos, se for o caso; h) apresentar Projeto de Controle de Poluição Ambiental, apresentado de acordo com as diretrizes do Anexo II, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART; i) publicação de súmula do pedido de regularização da Licença Ambiental Simplificada de Regularização – LARS em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela Resolução CONAMA nº 006/86; e j) recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental , demais valores cabíveis referentes às publicações II - LICENÇA DE OPERAÇÃO DE REGULARIZAÇÃO – LOR: §1º O requerente terá, automaticamente, sua Licença Ambiental Simplificada, bem como a sua renovação, com a apresentação de toda documentação solicitada neste artigo e após a compensação do pagamento das taxas devidas. §2º O órgão ambiental realizará avaliação posterior das informações constantes no procedimento, podendo solicitar complementações ou até a suspensão do licenciamento. a) croqui de localização do empreendimento com imagem aérea atualizada e contendo no mínimo: 1. estruturas físicas; 2. distância dos corpos hídricos; 3. indicando as áreas de preservação permanente; 4. cobertura florestal; 5. vias de acesso principais; e 6. pontos de referências. b) documento de propriedade ou justa posse rural, conforme Resolução CEMA nº 105 de 17 de dezembro de 2019; c) a Certidão do município ou documento equivalente, quando se tratar de empreendimento em perímetro urbano, declarando expressamente que o local e o tipo de empreendimento estão em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano, bem como atendem as demais exigências legais e administrativas perante o município. (Anexo I); d) a Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente ou em nome do locador, junto com o contrato de locação, em caso de imóvel locado, atualizada em até 90 (noventa) dias contados da data de sua emissão; e) documentação complementar do imóvel, se a situação imobiliária estiver irregular ou comprometida, conforme Capitulo II,

#### Seção V – da Resolução CEMA nº 105 de 17 de dezembro de 2019; f) cópia do Ato Constitutivo ou do Contrato Social (com última alteração), quando pessoa jurídica; g) número da Outorga de Direito ou Dispensa de Outorga de Uso de Recursos Hídricos utilização de recursos hídricos, se for o caso; h) Projeto de Controle de Poluição Ambiental, conforme diretrizes do Anexo II; i) publicação de súmula do pedido de Licença de Operação de Regularização LOR em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela Resolução CONAMA nº 006/86; e j) recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental , demais valores cabíveis referentes às publicações

###### Art. 11 {#art11}
Tags: #avicultura #licenciamento-ambiental

**Art. 11, caput** {#art11_cpt} #licenciamento-ambiental Para fins de isenção da taxa ambiental, em todas as modalidades de licenciamento ambiental, deverá ser apresentada declaração emitida pela EMATER, Sindicatos Rurais ou ainda o DAP - Declaração de Aptidão do PRONAF.

###### Art. 12 {#art12}
Tags: #avicultura #documentacao #las #li #licenciamento-ambiental #lo #lp #prazo #renovacao

**Art. 12, caput** {#art12_cpt} #documentacao #prazo O órgão ambiental competente estabelecerá os prazos de validade para cada tipo de licença e autorização ambiental, especificando-os no respectivo documento, levando em consideração os seguintes aspectos:
- **Art. 12, caput, inciso I** {#art12_cpt_inc1} #las #prazo #renovacao o prazo de validade da Licença Ambiental Simplificada - LAS será de até 06 (seis) anos, podendo ser renovada a critério técnico do órgão ambiental competente;
- **Art. 12, caput, inciso II** {#art12_cpt_inc2} #lp #prazo o prazo de validade da Licença Prévia - LP será de até 02 (dois) anos passível de prorrogação por mais 02(dois) anos;
- **Art. 12, caput, inciso III** {#art12_cpt_inc3} #li #prazo #renovacao o prazo de validade da Licença de Instalação - LI será de até 06 (seis) anos não sendo passível de renovação;
- **Art. 12, caput, inciso IV** {#art12_cpt_inc4} #lo #prazo #renovacao o prazo de validade da Licença de Operação - LO será de até 06 (seis) anos e poderá ser renovada; e
- **Art. 12, caput, inciso V** {#art12_cpt_inc5} #prazo o prazo de validade da autorização ambiental AA será de 1 (um) ano, não sendo passível de prorrogação.

**Art. 12, parágrafo único** {#art12_par1u} #las #lo #prazo Em casos excepcionais, justificados por motivos técnicos e/ou legais, o órgão ambiental competente poderá reduzir o prazo de validade da Licença Ambiental Simplificada - LAS e da Licença de Operação - LO.

###### Art. 13 {#art13}
Tags: #avicultura #documentacao #licenciamento-ambiental

**Art. 13, caput** {#art13_cpt} #documentacao A implantação de dois ou mais empreendimentos de Avicultura na mesma matricula do imóvel deverá ser licenciado como um único empreendimento, devendo os interessados constituir condomínio.

###### Art. 14 {#art14}
Tags: #app #avicultura #licenciamento-ambiental

**Art. 14, caput** {#art14_cpt} A implantação de empreendimentos de Avicultura, quanto à localização, deverá atender, no mínimo, aos seguintes critérios:
- **Art. 14, caput, inciso I** {#art14_cpt_inc1} as áreas devem ser de uso rural e estar em conformidade com as diretrizes de zoneamento do município;
- **Art. 14, caput, inciso II** {#art14_cpt_inc2} #app a área do empreendimento, incluindo armazenagem, tratamento e disposição final de estercos, deve situar-se a uma distância mínima de corpos hídricos, de modo a não atingir áreas de preservação permanente, conforme estabelecido no Código Florestal;
- **Art. 14, caput, inciso III** {#art14_cpt_inc3} a(s) área(s) de criação, bem como de armazenagem, tratamento e disposição final de dejetos, deve(m) estar localizada(s), de acordo com o [[decreto-estadual-5503-2002|Decreto Estadual no 5.503, de 21 de março de 2002]], no mínimo, nas distâncias e condições abaixo especificadas:
  - **Art. 14, caput, inciso III, alínea "a"** {#art14_cpt_inc3_alia} 50 (cinquenta) metros das divisas de terrenos vizinhos, podendo esta distância ser inferior quando da anuência legal dos respectivos confrontantes, exceto em unidades residenciais;
  - **Art. 14, caput, inciso III, alínea "b"** {#art14_cpt_inc3_alib} 12 (doze) metros de estradas municipais;
  - **Art. 14, caput, inciso III, alínea "c"** {#art14_cpt_inc3_alic} 15 (quinze) metros de estradas estaduais;
  - **Art. 14, caput, inciso III, alínea "d"** {#art14_cpt_inc3_alid} 55 (cinquenta e cinco) metros de estradas federais;
  - **Art. 14, caput, inciso III, alínea "e"** {#art14_cpt_inc3_alie} 50 (cinquenta) metros de distância mínima, em relação a frentes de estradas – exigida apenas em relação às áreas de disposição final dos dejetos.
- **Art. 14, caput, inciso IV** {#art14_cpt_inc4} na localização das construções para criação dos animais, armazenagem, tratamento e disposição final de dejetos – devem ser consideradas as condições ambientais da área e do seu entorno, bem como, a direção predominante dos ventos na região, de forma a impedir a propagação de odores para cidades, núcleos populacionais e habitações mais próximas.

###### Art. 15 {#art15}
Tags: #avicultura #licenciamento-ambiental

**Art. 15, caput** {#art15_cpt} As propriedades avícolas deverão obrigatoriamente implantar medidas para controle do consumo de água, como instalação de hidrômetros, redução do consumo de água de limpeza, reuso de água e evitar a entrada de água da chuva nas instalações.

###### Art. 16 {#art16}
Tags: #avicultura #efluente #licenciamento-ambiental #proibicao

**Art. 16, caput** {#art16_cpt} #efluente #proibicao É vedado o lançamento de efluentes líquidos de empreendimentos de avicultura em corpos hídricos.

###### Art. 17 {#art17}
Tags: #avicultura #licenciamento-ambiental #prazo #proibicao #residuo-solido

**Art. 17, caput** {#art17_cpt} #residuo-solido Para uso agrícola dos resíduos, devem ser considerados os seguintes aspectos:
- **Art. 17, caput, inciso I** {#art17_cpt_inc1} #prazo a cama de aviário deverá sofrer processo de fermentação por no mínimo 10 (dez) dias, e seu armazenamento deve ser realizada em local adequado, com adoção de medidas que evitem a proliferação de vetores;
- **Art. 17, caput, inciso II** {#art17_cpt_inc2} #residuo-solido a taxa de aplicação no solo (quantidade/área) deve ser calculada com base nas características físico-químicas do resíduo, da interpretação da análise química do solo e da necessidade da cultura, conforme recomendação agronômica;
- **Art. 17, caput, inciso III** {#art17_cpt_inc3} #proibicao #residuo-solido fica vedada a utilização de material para substrato de cama de aviário com presença de resíduos de produtos químicos para tratamento de madeira.

###### Art. 18 {#art18}
Tags: #avicultura #documentacao #las #licenciamento-ambiental #lo #residuo-solido

**Art. 18, caput** {#art18_cpt} #residuo-solido Para melhorias em sistemas de tratamento e/ou de destinação final de resíduos deverá ser solicitada Autorização Ambiental específica, cujo processo a ser protocolado deverá conter:
- **Art. 18, caput, inciso I** {#art18_cpt_inc1} #documentacao #licenciamento-ambiental requerimento de Licenciamento Ambiental;
- **Art. 18, caput, inciso II** {#art18_cpt_inc2} #las #lo cópia da Licença de Operação/Licença Ambiental simplificada ou do Termo de Ajustamento de Conduta Ambiental (TAC);
- **Art. 18, caput, inciso III** {#art18_cpt_inc3} estudo ambiental apresentado de acordo com as diretrizes do Anexo II;
- **Art. 18, caput, inciso IV** {#art18_cpt_inc4} em se tratando de readequação de sistemas de controle ambiental já implantados, encaminhar o estudo anterior e um relatório com a situação atual do sistema justificando o motivo da readequação; e
- **Art. 18, caput, inciso V** {#art18_cpt_inc5} recolhimento da taxa ambiental.

###### Art. 19 {#art19}
Tags: #avicultura #licenciamento-ambiental

**Art. 19, caput** {#art19_cpt} Os animais mortos deverão ser dispostos adequadamente, utilizando tecnologias de disposição específicas estabelecidas pelos órgãos competentes e atendendo a Portaria IAP/GP nº 106, de 30 de maio de 2018.

###### Art. 20 {#art20}
Tags: #avicultura #documentacao #licenciamento-ambiental

**Art. 20, caput** {#art20_cpt} #documentacao #licenciamento-ambiental Caso haja necessidade, o órgão ambiental competente solicitará, a qualquer momento, outros documentos e/ou informações complementares do requerente ou de outras instituições envolvidas no licenciamento ambiental em questão, assim como, anotação ou registro de responsabilidade técnica pela implantação e conclusão de eventuais estudos ambientais.

###### Art. 21 {#art21}
Tags: #avicultura #licenciamento-ambiental #responsavel-tecnico

**Art. 21, caput** {#art21_cpt} #responsavel-tecnico O descumprimento das disposições desta Resolução, dos termos das Licenças Ambientais sujeitará o infrator às penalidades previstas na [[lei-federal-9605-1998|Lei nº 9.605, de 12 de fevereiro de 1998]], e em outros dispositivos normativos pertinentes, sem prejuízo do dever de recuperar os danos ambientais causados, na forma do Art. 225, §3º, da Constituição Federal, e do Art. 14, § 1°, da Lei Federal n. 6.938, de 1981.

###### Art. 22 {#art22}
Tags: #avicultura #licenciamento-ambiental

**Art. 22, caput** {#art22_cpt} O órgão ambiental competente poderá complementar os critérios estabelecidos na presente Resolução de acordo com o desenvolvimento científico e tecnológico e a necessidade de preservação ambiental.

###### Art. 23 {#art23}
Tags: #avicultura #licenciamento-ambiental

**Art. 23, caput** {#art23_cpt} Caberá ao órgão ambiental competente deliberar sobre casos omissos não previstos nesta Resolução.

###### Art. 24 {#art24}
Tags: #avicultura #licenciamento-ambiental

**Art. 24, caput** {#art24_cpt} Esta Resolução entra em vigor na data de sua publicação, ficando revogada a [[resolucao-sema-54-2019|Resolução SEMA nº 054 de 19 de novembro de 2019]]. Curitiba, 05 de março de 2020. Márcio Nunes Secretário de Estado do Turismo Este texto não substitui o publicado no Diário Oficial do Estado ANEXOS: Arquivo          Observações anexo232900_53557.03

### Certidão municipal {#anexo1}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Diretrizes — Projeto de Controle de Poluição Ambiental {#anexo2}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Anuência do proprietário para disposição de dejetos no solo {#anexo3}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|
| [[decreto-estadual-9541-2025]] | Norma inteira | Revogação expressa registrada no acervo. |

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (sedest 16 2020(1).pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- A extração do SIA apresenta artigos sem a palavra Art.; os números sequenciais foram tratados como artigos. Na SEDEST 16/2020 o marcador 6º aparece repetido e foi reduzido a um único rótulo, sem alteração do conteúdo do dispositivo.
- Anexo próprio citado ou vinculado em arquivo separado, sem o respectivo conteúdo no PDF do lote. Não foi importado material externo ou presumida sua redação.
- Quadros no corpo devem ser conferidos visualmente; números, colunas e células mescladas ainda não estão certificados. Não utilizar este rascunho para enquadramento antes da revisão.
- Situação revogada conforme relação expressa já cadastrada no acervo: [[decreto-estadual-9541-2025]]. Regras de transição e processos antigos devem ser avaliados separadamente.
