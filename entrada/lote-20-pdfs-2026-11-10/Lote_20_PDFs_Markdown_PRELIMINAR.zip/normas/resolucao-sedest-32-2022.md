---
norma: "Resolução SEDEST nº 32/2022"
arquivo: resolucao-sedest-32-2022
tipo: resolucao
esfera: estadual
uf: PR
numero: 32
ano: 2022
data_assinatura: 2022-06-03
ementa: "Estabelece procedimentos para a integração entre procedimentos de licenciamento ambiental e de Outorga para uso de recursos hídricos no território paranaense."
situacao: revogada
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: []
revoga: ["[[resolucao-sema-3-2004]]"]
revogado_por: ["[[decreto-estadual-9541-2025]]"]
cita: ["[[decreto-estadual-3813-2020]]", "[[decreto-estadual-9957-2014]]", "[[lei-estadual-10066-1992]]", "[[lei-estadual-12726-1999]]", "[[lei-estadual-20070-2019]]", "[[lei-federal-19848-2019]]", "[[portaria-iat-130-2020]]", "[[resolucao-sema-3-2004]]"]
tags: ["agua-subterranea", "definicao", "documentacao", "efluente", "eia-rima", "enquadramento", "las", "li", "licenciamento-ambiental", "lo", "lp", "outorga", "recurso-hidrico", "renovacao", "residuo-solido"]
fonte: "PDF fornecido: sedest 32 2022.pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
---

# Resolução SEDEST nº 32/2022

> Estabelece procedimentos para a integração entre procedimentos de licenciamento ambiental e de Outorga para uso de recursos hídricos no território paranaense.

## Preâmbulo

Resolução SEDEST 32 - 03 de Junho de 2022 Publicado no Diário Oficial nº. 11192 de 7 de Junho de 2022 Súmula: Estabelece procedimentos para a integração entre procedimentos de licenciamento ambiental e de Outorga para uso de recursos hídricos no território paranaense. O Secretário de Estado do Desenvolvimento Sustentável e do Turismo-SEDEST, designado pelo Decreto Estadual n. º 10613 - 30 de março de 2022, no uso das atribuições que lhes são conferidas pela [[lei-federal-19848-2019|Lei nº 19.848, de 3 de maio de 2019]] e alterações posteriores, e; Considerando as finalidades básicas do Instituto Água e Terra - IAT conferidas pela [[lei-estadual-10066-1992|Lei Estadual nº 10.066, de 27 de julho de 1992]], [[lei-estadual-20070-2019|Lei Estadual nº 20.070, de 18 de dezembro de 2019]], [[decreto-estadual-3813-2020|Decreto Estadual nº 3.813, de 09 de janeiro de 2020]], e Considerando o disposto na Resolução do Conselho Nacional de Meio Ambiente- CONAMA nº 237, de 19 de dezembro de 1997; Considerando o disposto na Resolução do Conselho Estadual do Meio Ambiente - CEMA n° 107 de 09 de setembro de 2020, ou outra que vier a substituí-la, que dispõe sobre o licenciamento ambiental, estabelece critérios e procedimentos a serem adotados para as atividades poluidoras, degradadoras e/ou modificadoras do meio ambiente; Considerando a [[lei-estadual-12726-1999|Lei Estadual n.º 12.726, de 26 de novembro de 1999]], que instituiu a Política Estadual de Recursos Hídricos e criou o Sistema Estadual de Gerenciamento de Recursos Hídricos; Considerando o [[decreto-estadual-9957-2014|Decreto Estadual n.º 9.957, de 23 de janeiro de 2014]], que dispõe sobre o regime de Outorga de Direitos de uso de recursos hídricos e adota outras providências; Considerando a [[portaria-iat-130-2020|Portaria IAT nº 130 de 05 de maio de 2020]], que dispensa de Outorga, considerando-se como de uso insignificante, acumulações, derivações, captações e lançamentos; Considerando a necessidade de integração de procedimentos dos instrumentos da Política Estadual de Recursos Hídricos e da Política Estadual de Meio Ambiente; Considerando a necessidade de estabelecer os procedimentos de integração entre o Licenciamento Ambiental e a Outorga para Uso de Recursos Hídricos. RESOLVE:

###### Art. 1º {#art1}
Tags: #licenciamento-ambiental #outorga #recurso-hidrico

**Art. 1º, caput** {#art1_cpt} #licenciamento-ambiental #outorga Estabelecer a integração dos procedimentos entre a Outorga para uso de recursos hídricos e o licenciamento ambiental no âmbito do Instituto Água e Terra.

###### Art. 2º {#art2}
Tags: #agua-subterranea #efluente #eia-rima #enquadramento #outorga #recurso-hidrico #residuo-solido

**Art. 2º, caput** {#art2_cpt} #outorga A Outorga para uso de recursos hídricos é obrigatória para os empreendimentos, atividades ou obras que necessitem de:
- **Art. 2º, caput, inciso I** {#art2_cpt_inc1} derivação ou captação de parcela da água existente em um corpo de água para consumo final, inclusive abastecimento público ou insumo de processo produtivo;
- **Art. 2º, caput, inciso II** {#art2_cpt_inc2} #agua-subterranea extração de água de aquífero subterrâneo para consumo final, inclusive abastecimento público, ou insumo de processo produtivo;
- **Art. 2º, caput, inciso III** {#art2_cpt_inc3} #efluente #enquadramento #residuo-solido lançamento em copo de água de esgoto e demais resíduos líquidos ou gasosos, tratados ou não, com o fim de sua diluição, transporte ou disposição final;
- **Art. 2º, caput, inciso IV** {#art2_cpt_inc4} usos de recursos hídricos para aproveitamento de potenciais hidrelétricos;
- **Art. 2º, caput, inciso V** {#art2_cpt_inc5} #eia-rima intervenções de macrodrenagem urbana para retificação, canalização barramento e obras similares que visem ao controle de cheias;
- **Art. 2º, caput, inciso VI** {#art2_cpt_inc6} outros usos e ações e execução de obras ou serviços necessários à implantação de qualquer intenção ou empreendimento, que demandem a utilização de recursos hídricos, ou que impliquem, mesmo que temporária, do regime, da quantidade ou da qualidade da água, superficial ou subterrânea, ou, ainda, que modifiquem o leito e margens dos corpos de água.

###### Art. 3º {#art3}
Tags: #licenciamento-ambiental #outorga #recurso-hidrico

**Art. 3º, caput** {#art3_cpt} #licenciamento-ambiental #outorga Nos procedimentos de licenciamento ambiental para atividades, empreendimentos, obras e intervenções utilizadoras de recursos hídricos, deverá constar, obrigatoriamente, a Outorga Prévia ou Outorga de Direito de Uso dos Recursos Hídricos, emitidas pelo Instituto Água e Terra, sem prejuízo de outras licenças, autorizações e concessões pertinentes.

### CAPÍTULO I – DO LICENCIAMENTO AMBIENTAL E OUTORGA DE RECURSOS HÍDRICOS

#### Seção I – Dos Atos Administrativos

###### Art. 4º {#art4}
Tags: #documentacao #efluente #eia-rima #enquadramento #las #li #licenciamento-ambiental #lo #lp #outorga #recurso-hidrico

**Art. 4º, caput** {#art4_cpt} #licenciamento-ambiental #outorga O órgão ambiental competente, no exercício do controle ambiental, expedirá os seguintes atos administrativos, referentes ao licenciamento ambiental e à Outorga de recursos hídricos.
- **Art. 4º, caput, inciso I** {#art4_cpt_inc1} #licenciamento-ambiental Declaração de Inexigibilidade de Licença Ambiental (DILA): concedida para as atividades e empreendimentos dotados de impactos ambiental e socioambiental insignificantes para os quais é inexigível o licenciamento ambiental, respeitadas as legislações municipais;
- **Art. 4º, caput, inciso II** {#art4_cpt_inc2} #licenciamento-ambiental Declaração de Dispensa de Licenciamento Ambiental Estadual-DLAE: concedida para os empreendimentos que são dispensados do licenciamento por parte do órgão ambiental estadual conforme os critérios estabelecidos em Resoluções específicas;
- **Art. 4º, caput, inciso III** {#art4_cpt_inc3} #eia-rima Licença Ambiental por Adesão e Compromisso - LAC: autoriza a instalação e a operação de atividade ou empreendimento, de pequeno potencial de impacto ambiental, mediante declaração de adesão e compromisso do empreendedor aos critérios, pré-condições, requisitos e condicionantes ambientais estabelecidos pela autoridade licenciadora, desde que se conheçam previamente os impactos ambientais da atividade ou empreendimento, as características ambientais da área de implantação e as condições de sua instalação e operação;
- **Art. 4º, caput, inciso IV** {#art4_cpt_inc4} #documentacao #enquadramento #las Licença Ambiental Simplificada-LAS: aprova a localização e a concepção do empreendimento, atividade ou obra de pequeno porte e/ou que possua baixo potencial poluidor/degradador, atestando a viabilidade ambiental e estabelecendo os requisitos básicos e condicionantes a serem atendidos, bem como autoriza sua instalação e operação de acordo com as especificações constantes dos requerimentos, planos, programas e/ou projetos aprovados, incluindo as medidas de controle ambiental e demais condicionantes determinadas pelo órgão ambiental competente;
- **Art. 4º, caput, inciso V** {#art4_cpt_inc5} #lp Licença Prévia-LP: concedida na fase preliminar do planejamento do empreendimento ou atividade aprovando sua localização e concepção, atestando a viabilidade ambiental e estabelecendo os requisitos básicos e condicionantes a serem atendidos nas próximas fases de sua implementação;
- **Art. 4º, caput, inciso VI** {#art4_cpt_inc6} #li Licença de Instalação-LI: autoriza a instalação do empreendimento ou atividade de acordo com as especificações constantes dos planos, programas e projetos aprovados, incluindo as medidas de controle ambientais e demais condicionantes, da qual constituem motivos determinantes;
- **Art. 4º, caput, inciso VII** {#art4_cpt_inc7} #lo Licença de Operação-LO: autoriza a operação da atividade ou empreendimento, após a verificação do efetivo cumprimento do que consta das licenças anteriores, com as medidas de controle ambientais e condicionantes determinados para a operação;
- **Art. 4º, caput, inciso VIII** {#art4_cpt_inc8} #documentacao Autorização Ambiental-AA: autoriza a execução de obras, atividades, pesquisas e serviços de caráter temporário ou obras emergenciais, de acordo com as especificações constantes dos requerimentos, cadastros, planos, programas e/ou projetos aprovados, incluindo as medidas de controle ambiental e demais condicionantes determinadas pelo órgão ambiental competente;
- **Art. 4º, caput, inciso IX** {#art4_cpt_inc9} Anuência Prévia – AP: ato administrativo que autoriza a perfuração de um poço;
- **Art. 4º, caput, inciso XI** {#art4_cpt_inc11} #outorga Outorga Prévia - OP: ato administrativo com finalidade de declarar a disponibilidade de água para os usos requeridos, que não confere direto de uso de recursos hídricos e se destina a reservar a razão passível de Outorga, possibilitando, aos investidores, o planejamento de empreendimentos que necessitem desses recursos;
- **Art. 4º, caput, inciso XII** {#art4_cpt_inc12} #efluente #outorga Declaração de Uso Independente de Outorga – DUIO: concedida para usuários ou empreendimentos que possuem acumulações, derivações, captações e lançamentos de efluentes considerados como usos insignificantes, conforme critérios estabelecidos na [[portaria-iat-130-2020|Portaria IAT nº 130/2020]].

#### Seção II – Das Modalidades de Licenciamento Ambiental

###### Art. 5º {#art5}
Tags: #li #licenciamento-ambiental #lo #lp #outorga #recurso-hidrico

**Art. 5º, caput** {#art5_cpt} #licenciamento-ambiental Constituem modalidades de licenciamento ambiental:
- **Art. 5º, caput, inciso I** {#art5_cpt_inc1} #li #licenciamento-ambiental #lo #lp Licenciamento Ambiental Trifásico: licenciamento no qual a Licença Prévia - LP, a Licença de Instalação - LI e a Licença de Operação - LO da atividade ou do empreendimento são concedidas em etapas sucessivas;
- **Art. 5º, caput, inciso II** {#art5_cpt_inc2} #licenciamento-ambiental Licenciamento Ambiental Bifásico: licenciamento no qual o empreendimento ou atividade não está sujeita a todas as etapas, podendo ser:
  - **Art. 5º, caput, inciso II, alínea "a"** {#art5_cpt_inc2_alia} #li #licenciamento-ambiental #lo #lp licenciamento de ampliações da atividade ou do empreendimento que não impliquem no aumento do seu potencial poluidor e/ou degradador, no qual a Licença Prévia-LP e a Licença de Operação-LO são concedidas em etapas sucessivas, sempre que não houver necessidade da Licença de Instalação-LI, devidamente justificada;
  - **Art. 5º, caput, inciso II, alínea "b"** {#art5_cpt_inc2_alib} #li #licenciamento-ambiental #lo #lp licenciamento no qual a Licença Prévia - LP e a Licença de Instalação-LI da atividade ou do empreendimento são concedidas em etapas sucessivas, sempre que não houver necessidade de Licença de Operação-LO, devidamente justificada;
- **Art. 5º, caput, inciso III** {#art5_cpt_inc3} #licenciamento-ambiental Licenciamento Ambiental em uma única fase:
  - **Art. 5º, caput, inciso III, alínea "a"** {#art5_cpt_inc3_alia} #licenciamento-ambiental Licenciamento Ambiental por Adesão e Compromisso - LAC;
  - **Art. 5º, caput, inciso III, alínea "b"** {#art5_cpt_inc3_alib} #licenciamento-ambiental Licenciamento Ambiental Simplificado - LAS.
- **Art. 5º, caput, inciso IV** {#art5_cpt_inc4} #licenciamento-ambiental Licenciamento Ambiental de Regularização: licenciamento para empreendimentos ou atividades já implantadas, passíveis de regularização, não eximindo a responsabilidade do empreendedor pelos danos causados;
- **Art. 5º, caput, inciso V** {#art5_cpt_inc5} Autorizações Ambientais: ato administrativo discricionário a ser emitido para obras, atividades, pesquisas e serviços, de caráter temporário, ou obras emergenciais.

#### Seção III – Das Etapas entre Licenciamento Ambiental e Outorga Para Uso De Recursos Hídricos

###### Art. 6º {#art6}
Tags: #licenciamento-ambiental #outorga #recurso-hidrico

**Art. 6º, caput** {#art6_cpt} #licenciamento-ambiental #outorga Nos procedimentos de licenciamento ambiental para atividades, empreendimentos, obras e intervenções utilizadoras de recursos hídricos capazes, deverá constar, obrigatoriamente, a Outorga Prévia, a Outorga de Direito de Uso dos Recursos Hídricos e/ou Declaração de Uso Independente de Outorga, emitidas pelo Instituto Água e Terra, sem prejuízo de outras licenças, autorizações e concessões pertinentes.

###### Art. 7º {#art7}
Tags: #licenciamento-ambiental #outorga #recurso-hidrico

**Art. 7º, caput** {#art7_cpt} #licenciamento-ambiental #outorga Os procedimentos de integração de Licenciamento Ambiental e Outorga para novos empreendimentos se dará de acordo com os critérios abaixo:

> **Pendência de transcrição — Art. 7, quadro/tabela** {#art7_tab1}. Conteúdo preservado na extração textual que acompanha o lote; falta conferência visual das colunas. Não é texto normativo transcrito.


###### Art. 8º {#art8}
Tags: #licenciamento-ambiental #outorga #recurso-hidrico

**Art. 8º, caput** {#art8_cpt} #licenciamento-ambiental #outorga Os procedimentos de integração de Licenciamento Ambiental e Outorga para empreendimentos em operação se dará de acordo as etapas dos quadros abaixo:

> **Pendência de transcrição — Art. 8, quadro/tabela** {#art8_tab1}. Conteúdo preservado na extração textual que acompanha o lote; falta conferência visual das colunas. Não é texto normativo transcrito.


###### Art. 9º {#art9}
Tags: #outorga #recurso-hidrico

**Art. 9º, caput** {#art9_cpt} #outorga Para captações subterrâneas deverá ser solicitada a Anuência Prévia para perfuração do poço, anteriormente à Outorga Prévia ou Declaração de uso independente de Outorga.

###### Art. 10 {#art10}
Tags: #efluente #lo #outorga #recurso-hidrico #renovacao

**Art. 10, caput** {#art10_cpt} #efluente #lo #outorga #renovacao Nos casos de renovação de licença de Operação, em que seja necessário exigir do usuário qualquer alteração no empreendimento que afete os usos múltiplos a altere as características de regime, de quantidade ou de qualidade da captação da água ou de lançamento de efluentes, a deverá ser consultada a Gerência de Outorga previamente e o requerente deverá solicitar a alteração de sua Outorga.

###### Art. 11 {#art11}
Tags: #definicao #licenciamento-ambiental #outorga #recurso-hidrico #renovacao

**Art. 11, caput** {#art11_cpt} #definicao #licenciamento-ambiental #outorga #renovacao Quando da análise da renovação da Outorga, a Gerência de Licenciamento deverá ser informada sobre as conclusões alcançadas e as possíveis alterações nas condições de Outorga, para definição das providências necessárias.

###### Art. 12 {#art12}
Tags: #outorga #recurso-hidrico

**Art. 12, caput** {#art12_cpt} Qualquer alteração nos dados técnicos ou operacionais do empreendimento quando houver a utilização dos recursos hídricos e as suas possíveis interferências em outros usos, deverá ser submetida à análise do IAT.

###### Art. 13 {#art13}
Tags: #licenciamento-ambiental #outorga #recurso-hidrico

**Art. 13, caput** {#art13_cpt} #licenciamento-ambiental #outorga Nos procedimentos de integração de Licenciamento Ambiental e Outorga, os estudos a serem apresentados pelo empreendedor deverão ser elaborados de forma a atender as exigências do IAT.

### CAPÍTULO III – DAS DISPOSIÇÕES FINAIS E TRANSITÓRIAS

###### Art. 14 {#art14}
Tags: #outorga #recurso-hidrico

**Art. 14, caput** {#art14_cpt} Esta Resolução entra em vigor na data de sua publicação, ficando revogada a [[resolucao-sema-3-2004|Resolução Nº 003/04-SEMA]].

## Fecho

Curitiba, 30 de maio de 2022. Everton Luiz da Costa Souza Secretário de Estado do Desenvolvimento Sustentável e do Turismo Este texto não substitui o publicado no Diário Oficial do Estado


## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|
| [[decreto-estadual-9541-2025]] | Norma inteira | Revogação expressa registrada no acervo. |

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (sedest 32 2022.pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- Divergência no próprio documento: cabeçalho de 03/06/2022 e fecho em Curitiba, 30 de maio de 2022. Mantida a data do cabeçalho nos metadados; revisão humana necessária.
- Revisão de numeração: sequência de inciso: art4_cpt_inc11 após art4_cpt_inc9. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Situação revogada conforme relação expressa já cadastrada no acervo: [[decreto-estadual-9541-2025]]. Regras de transição e processos antigos devem ser avaliados separadamente.
