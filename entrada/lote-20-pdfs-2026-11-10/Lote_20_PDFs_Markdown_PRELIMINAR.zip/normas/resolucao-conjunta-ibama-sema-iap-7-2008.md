---
norma: "Resolução Conjunta IBAMA/SEMA/IAP nº 007/2008"
arquivo: resolucao-conjunta-ibama-sema-iap-7-2008
tipo: resolucao
esfera: estadual
uf: PR
numero: 7
ano: 2008
data_assinatura: 2008-04-18
ementa: "Regulamenta a exploração eventual de espécies arbóreas nativas em remanescentes de vegetação nativa do Bioma Mata Atlântica, em ambientes agropastoril e em áreas urbanas."
situacao: vigente
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: []
revoga: ["[[portaria-conjunta-ibama-iap-2-2007]]", "[[portaria-iap-193-2007]]", "[[resolucao-conjunta-ibama-sema-iap-54-2007]]"]
revogado_por: []
cita: ["[[decreto-estadual-1502-1992]]", "[[decreto-estadual-77-2007]]", "[[decreto-federal-3179-1999]]", "[[decreto-federal-6040-2007]]", "[[decreto-federal-6358-2006]]", "[[lei-estadual-10066-1992]]", "[[lei-federal-11428-2006]]", "[[lei-federal-4771-1965]]", "[[lei-federal-6905-1998]]", "[[portaria-iap-193-2007]]", "[[resolucao-conjunta-ibama-sema-iap-54-2007]]"]
tags: ["app", "autorizacao-florestal", "definicao", "documentacao", "eia-rima", "enquadramento", "licenciamento-ambiental", "mata-atlantica", "prazo", "proibicao", "responsavel-tecnico", "supressao-vegetacao"]
fonte: "PDF fornecido: Resolução Conjunta IBAMA SEMA IAP 007 2008.pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
---

# Resolução Conjunta IBAMA/SEMA/IAP nº 007/2008

> Regulamenta a exploração eventual de espécies arbóreas nativas em remanescentes de vegetação nativa do Bioma Mata Atlântica, em ambientes agropastoril e em áreas urbanas.

## Preâmbulo

Resolução Conjunta IBAMA/SEMA/IAP nº 007 - 18 de Abril de 2008 Publicado no Diário Oficial nº. 7710 de 29 de Abril de 2008 Súmula: Regulamenta a exploração eventual de espécies arbóreas nativas em remanescentes de vegetação nativa do Bioma Mata Atlântica, em ambientes agropastoril e em áreas urbanas.

O SUPERINTENDENTE SUBSTITUTO DO INSTITUTO BRASILEIRO DO MEIO AMBIENTE E DOS RECURSOS NATURAIS RENOVÁVEIS – IBAMA, designado pela Portaria nº 2 de 22 de fevereiro de 2006, publicado no DOU de 24 de fevereiro de 2006, no uso das atribuições que lhe são conferidas pela Portaria n° 1.045, de 06 de julho de 2001, publicado no DOU de 09 de julho de 2001, em conformidade com o art. 1º, alínea “o” e; O SECRETÁRIO DE ESTADO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS – SEMA, designado pelo [[decreto-federal-6358-2006|Decreto n° 6358 de 30 de março de 2006]], publicado no DOE de 30 de março de 2006, no uso das atribuições que lhe são conferidas pela [[lei-estadual-10066-1992|Lei Estadual nº 10.066, de 27 de julho de 1992]] e alterações posteriores que cria a Secretaria de Estado do Meio Ambiente e dos Recursos Hídricos – SEMA, e; O DIRETOR PRESIDENTE DO INSTITUTO AMBIENTAL DO PARANÁ – IAP, designado pelo [[decreto-estadual-77-2007|Decreto n° 077 de 12 de fevereiro de 2007]], no uso das atribuições que lhe são conferidas pela [[lei-estadual-10066-1992|Lei Estadual n° 10.066, de 27 de julho de 1992]], com as alterações trazidas pelas Leis n° 11.352, de 13 de fevereiro de 1996 e n° 13.425, de 07 de janeiro de 2002 e de acordo com o seu Regulamento, aprovado pelo [[decreto-estadual-1502-1992|Decreto n° 1.502, de 04 de agosto de 1992]], e CONSIDERANDO; .      As definições, objetivos e princípios do regime jurídico do Bioma Mata Atlântica, [[lei-federal-11428-2006|Lei n° 11.428 de 22 de dezembro de 2006]]; .      As normas e as especificações do controle da cadeia produtiva de base florestal; .      O [[decreto-federal-6040-2007|Decreto n° 6.040, de 7 de fevereiro de 2007]] que Institui a Política Nacional de Desenvolvimento Sustentável dos Povos e Comunidades Tradicionais; .      A necessidade de estabelecer critérios técnicos que auxiliem o Instituto Ambiental do Paraná – IAP e demais órgãos componentes do SISNAMA no Estado do Paraná, na tomada de decisões para deliberação de procedimentos administrativos; RESOLVEM:

CAPITULO I – DAS DEFINIÇÕES

###### Art. 1º {#art1}
Tags: #app #definicao #documentacao #eia-rima #enquadramento #mata-atlantica #prazo #responsavel-tecnico #supressao-vegetacao

**Art. 1º, caput** {#art1_cpt} #definicao Para os fins previstos nesta Resolução, entende-se por:
- **Art. 1º, caput, inciso I** {#art1_cpt_inc1} #responsavel-tecnico Exploração sustentável: exploração do meio ambiente de maneira a garantir a perenidade dos recursos ambientais renováveis e dos processos ecológicos, mantendo a biodiversidade e os demais atributos ecológicos, de forma socialmente justa e economicamente viável. [[lei-federal-11428-2006|Lei 11428/06]], Art. 3º, item V.
- **Art. 1º, caput, inciso II** {#art1_cpt_inc2} Exploração eventual de espécies arbóreas nativas em remanescentes de vegetação nativa do Bioma Mata Atlântica:
  - **Art. 1º, caput, inciso II, alínea "a"** {#art1_cpt_inc2_alia} #app Exploração ou corte ou supressão de exemplares sem propósito comercial direto ou indireto, para consumo nas propriedades ou posses das populações tradicionais ou de pequenos produtores rurais, respeitadas as demais normais federais e estaduais, em especial as exigências da [[lei-federal-4771-1965|Lei nº 4771/65]], no que diz respeito às Áreas de Preservação Permanente e à Reserva Legal.
  - **Art. 1º, caput, inciso II, alínea "b"** {#art1_cpt_inc2_alib} Corte eventual de exemplares necessários para a realização de práticas preservacionistas e de pesquisas científicas, conforme regulamentado pelo CONAMA;
  - **Art. 1º, caput, inciso II, alínea "c"** {#art1_cpt_inc2_alic} Casos de obras, atividades ou projetos de utilidade pública, quando em remanescentes de vegetação primária e nos estágios secundários, que foram devidamente aprovados em procedimentos administrativos próprios.
  - **Art. 1º, caput, inciso II, alínea "d"** {#art1_cpt_inc2_alid} Casos de obras, atividades ou projetos de interesse social, quando em remanescentes de vegetação nos estágios secundário médio e inicial, que foram devidamente aprovados em procedimentos administrativos próprios.
- **Art. 1º, caput, inciso III** {#art1_cpt_inc3} Função ecológica relevante, nidificação, pousio, habitat de fauna: vegetação que tenha como função proteger espécies ameaçadas de extinção; vegetação que forme corredores entre remanescentes de vegetação primária ou em estágio médio ou avançado de regeneração; vegetação que protege o entorno de Unidade de Conservação e possuir excepcional valor paisagístico, reconhecido pelos órgãos executivos competentes do sistema Nacional do Meio Ambiente – SISNAMA.
- **Art. 1º, caput, inciso IV** {#art1_cpt_inc4} #app #responsavel-tecnico Áreas de Preservação Permanente: áreas especialmente protegidas nos termos dos art. 2º e 3º da [[lei-federal-4771-1965|Lei 4.771/65]] – Código Florestal – incluindo manguezais, restingas e áreas indígenas;
- **Art. 1º, caput, inciso V** {#art1_cpt_inc5} #definicao Remanescentes da vegetação nativa – Remanescentes da vegetação nativa do Estado do Paraná são as formações florestais nativas caracterizadas como florestas primárias, florestas de estágio avançado, médio e inicial de regeneração natural identificados nos parâmetros definidas nas Resoluções 10/93 e 02/94 do CONAMA.
- **Art. 1º, caput, inciso VI** {#art1_cpt_inc6} #definicao #enquadramento As áreas de agricultura, pecuária e silvicultura, até a data da aprovação da Lei 11.428 de 22/12/2006, não serão classificadas como remanescentes na área de abrangência definida no artigo [[#art2|2º]] desta Lei Federal.
- **Art. 1º, caput, inciso VII** {#art1_cpt_inc7} A vegetação primária ou a vegetação secundária em qualquer estágio de regeneração do Bioma Mata Atlântica não perderão esta classificação nos casos de incêndio, desmatamento ou qualquer outro tipo de intervenção não autorizada ou não licenciada.
- **Art. 1º, caput, inciso VIII** {#art1_cpt_inc8} #prazo Ambiente Agropastoril: aquelas áreas legalmente instituídas que já tiveram a sua cobertura arbórea retirada em anos anteriores, sendo as mesmas transformadas em áreas de pastagem e/ou lavouras, mantendo-se algumas espécies arbóreas.
- **Art. 1º, caput, inciso IX** {#art1_cpt_inc9} Pequeno Produtor Rural: é aquele que, residindo na zona rural, detenha a posse de gleba rural não superior a 50 (cinquenta) hectares, explorando-a mediante o trabalho pessoal e de sua família, admitida a ajuda eventual de terceiros, bem como as posses coletivas de terra considerando-se a fração individual não superior a 50 (cinquenta) hectares, cuja renda bruta seja proveniente de atividades ou usos agrícolas, pecuários ou silviculturais ou do extrativismo rural em 80% (oitenta por cento) no mínimo, (Lei Federal n° 11.428 de 22.12.2006). No caso de um Proprietário possuir mais de um imóvel contíguos ou não, a soma dos mesmos não poderá ultrapassar a 50 ha sob pena de perder a condição de Pequeno Produtor Rural.
- **Art. 1º, caput, inciso X** {#art1_cpt_inc10} Pequenas propriedades ou posses de glebas rurais familiares: são aquelas de propriedade ou posse de pequeno produtor rural.
- **Art. 1º, caput, inciso XI** {#art1_cpt_inc11} #eia-rima População tradicional: são os povos e comunidades tradicionais como indígenas, quilombolas, faxinais, ribeirinhos, caiçaras e grupos culturalmente diferenciados e que se reconhecem como tais, conforme estabelece o [[decreto-federal-6040-2007|Decreto n° 6.040/07]]. População vivendo em estreita relação com o ambiente natural, dependendo de seus recursos naturais para a sua reprodução sociocultural, por meio de atividades de baixo impacto ambiental, devidamente declarada pelo Poder Público Federal ou Estadual. Estas áreas deverão estar devidamente identificadas através do decreto Federal e/ou Estadual que delimetem o perímetro das respectivas populações tradicional.
- **Art. 1º, caput, inciso XII** {#art1_cpt_inc12} Territórios tradicionais: são aqueles de posse ou propriedade de população ou povos ou comunidades tradicionais, com perímetros devidamente identificados através de declaração do poder Público Federal ou Estadual.
  - **Art. 1º, caput, inciso XII, alínea "a"** {#art1_cpt_inc12_alia} #definicao A atividade de exploração ou corte ou supressão eventual de indivíduos da vegetação secundária em estágio inicial e médio de regeneração, praticada na pequena propriedade ou posse rural familiar, por pequeno produtor rural e nos territórios tradicionais por população tradicional, será definida como de interesse social, quando esta atividade for considerada imprescindível à suas subsistências e de suas famílias.
- **Art. 1º, caput, inciso XIII** {#art1_cpt_inc13} Corte: O termo corte se aplica à remoção de toda e qualquer árvore, independente de seu estágio de desenvolvimento.
- **Art. 1º, caput, inciso XIV** {#art1_cpt_inc14} Corte raso: retirada total da vegetação de uma determinada área, independente de seu estágio de desenvolvimento.
- **Art. 1º, caput, inciso XV** {#art1_cpt_inc15} Exploração: Termo geral aplicado quando da remoção de árvores fisiológica e ou financeiramente maduras. Distingue-se de corte, pois neste caso inclui-se também a remoção de árvores imaturas, geralmente sem valor econômico;
- **Art. 1º, caput, inciso XVI** {#art1_cpt_inc16} #documentacao Imóvel – área compreendida por uma matricula onde se exerça a propriedade ou a posse.
- **Art. 1º, caput, inciso XVII** {#art1_cpt_inc17} Propriedade – composta por um imóvel ou o conjunto de imóveis de um mesmo proprietário ou mesmo possuidor.

### CAPITULO II – DOS OBJETIVOS

###### Art. 2º {#art2}
Tags: #mata-atlantica #supressao-vegetacao

**Art. 2º, caput** {#art2_cpt} A exploração, o corte e a supressão eventual de espécies arbóreas nativas em remanescentes de vegetação nativa do Bioma Mata Atlântica, em ambientes, agropastoris e em áreas urbanas, são regulamentados pela presente Resolução.

### CAPITULO III – DA EXPLORAÇÃO NA PEQUENA PROPRIEDADE RURAL

###### Art. 3º {#art3}
Tags: #app #documentacao #enquadramento #mata-atlantica #prazo #supressao-vegetacao

**Art. 3º, caput** {#art3_cpt} Para a exploração e corte de espécies arbóreas e o aproveitamento de material lenhoso em remanescentes de vegetação nativa do Bioma Mata Atlântica, sem propósito comercial direto ou indireto, para consumo nas propriedades ou posses de pequenos produtores rurais e nos territórios das populações tradicionais, deverá ser observado o seguinte regramento:
- **Art. 3º, caput, inciso I** {#art3_cpt_inc1} #documentacao Efetuar, junto ao IAP, o cadastro de caracterização de pequeno produtor rural ou de populações tradicionais, mediante apresentação de declaração expressa de seu Sindicato, EMATER ou outro órgão oficial, na primeira ocasião em que efetuar o seu pedido, obtendo do IAP o documento declaratório.
- **Art. 3º, caput, inciso II** {#art3_cpt_inc2} A quantidade máxima de exemplares arbóreos, verdes ou secos, admitidos para o corte ou retirada de material lenhoso, isentos de autorização dos órgãos competentes é de até 05 (cinco) exemplares, não ultrapassando o volume de 15 (quinze) m³ no total, por propriedade a cada ano.
- **Art. 3º, caput, inciso III** {#art3_cpt_inc3} #app Tais exemplares não poderão estar localizados em Área de Preservação Permanente – APP, também entendido como tal, as áreas indígenas .
- **Art. 3º, caput, inciso IV** {#art3_cpt_inc4} #app Após a primeira intervenção o proprietário, deverá regularizar sua situação da reserva legal e preservação permanente junto ao IAP bem como demonstrar o efetivo plantio de reposição na razão de 10 árvores para cada árvore cortada;
- **Art. 3º, caput, inciso V** {#art3_cpt_inc5} Os exemplares não poderão estar constando na Lista Vermelha de Plantas Ameaçadas de Extinção no Estado do Paraná editada em 1995 e Portaria nº 37-N/92 do IBAMA.
- **Art. 3º, caput, inciso VI** {#art3_cpt_inc6} Serão priorizados para aproveitamento os exemplares de árvores mortas em pé ou caídas ou árvores caídas por causas naturais.

**Art. 3º, § 1º** {#art3_par1} #prazo Após a primeira exploração de que trata este artigo, o cadastrado deverá informar previamente as retiradas a serem efetuadas nos anos subsequentes, respeitando os limites e prazos acima estipulados.

**Art. 3º, § 2º** {#art3_par2} #documentacao #enquadramento #prazo O transporte da madeira explorada para fins de beneficiamento será efetuado mediante documento de informação, expedida pelo IAP, com validade máxima de 10 (dez) dias, para corte, beneficiamento e retorno à propriedade, prorrogável uma única vez, em caso fortuito ou de força maior em no máximo 5 [cinco] dias.

**Art. 3º, § 3º** {#art3_par3} #documentacao O documento de informação não poderá ser utilizado para contabilização de estoque da madeira no pateo da serraria.

###### Art. 4º {#art4}
Tags: #app #autorizacao-florestal #documentacao #enquadramento #mata-atlantica #supressao-vegetacao

**Art. 4º, caput** {#art4_cpt} #app #documentacao O corte de vegetação secundária em estágio médio de regeneração do Bioma Mata Atlântica, quando necessário ao pequeno produtor rural e populações tradicionais devidamente cadastrados no IAP, para o exercício de atividades ou usos agrícolas, pecuários ou silviculturais imprescindíveis à sua subsistência e de sua família, somente será autorizado mediante requerimento que comprove tal necessidade, ressalvadas as áreas de preservação permanente e, quando for o caso, após averbação da reserva legal, nos termos da [[lei-federal-4771-1965|Lei nº 4.771, de 15 de setembro de 1965]].

**Art. 4º, § 1º** {#art4_par1} #app #autorizacao-florestal A autorização florestal deverá ser priorizada para o corte de vegetação em estagio inicial, mantendo-se as áreas de reserva legal e preservação permanente.

**Art. 4º, § 2º** {#art4_par2} Consideram-se, para efeito deste artigo, atividades ou usos agrícolas imprescindíveis à sua subsistência e de sua família os seguintes casos: a – Tratamento de saúde do titular e seus dependentes; b – Constituição de nova célula familiar na mesma propriedade.

**Art. 4º, § 3º** {#art4_par3} Para efeito deste artigo a autorização de corte não poderá exceder o limite de 20% do remanescente do estágio médio de regeneração natural existente na propriedade.

**Art. 4º, § 4º** {#art4_par4} Nas propriedades inseridas em Unidades de Conservação de Uso Sustentável ou nas Zonas de amortecimento das Unidades de Conservação de Proteção Integral, as autorizações serão emitidas após a anuência do Órgão responsável pela Unidade.

**Art. 4º, § 5º** {#art4_par5} #documentacao #enquadramento O proprietário de que trata o caput deste artigo poderá efetuar a comercialização dos produtos objeto do corte, cujo transporte será realizado mediante DOF – Documento de Origem Florestal.

### CAPITULO IV – DA EXPLORAÇÃO DE NATIVAS EM AMBIENTE AGROPASTORIL

###### Art. 5º {#art5}
Tags: #app #mata-atlantica #supressao-vegetacao

**Art. 5º, caput** {#art5_cpt} Poderá ser permitido o corte de árvores nativas isoladas em Ambiente Agropastoril até o limite máximo de 40 (quarenta) m³ por propriedade (tora e lenha), desde que devidamente autorizado pelo órgão competente.

**Art. 5º, § 1º** {#art5_par1} Fica subentendido de que no volume total de corte em Ambiente Agropastoril de 40,00 m³ [quarenta metros cúbicos] está incluído, caso seja objeto de extração, o volume das espécies ameaçadas de extinção, o qual não poderá exceder a 15, 00 m³ [quinze metros cúbicos].

**Art. 5º, § 2º** {#art5_par2} Para a autorização deste corte será efetuada a vistoria e deliberação pelo Escritório Regional do IAP.

**Art. 5º, § 3º** {#art5_par3} #app Será exigida a averbação da reserva legal e preservação permanente bem como a lavratura do Termo de Compromisso para o plantio de 10 [dez] árvores para cada árvore cortada.

**Art. 5º, § 4º** {#art5_par4} Os exemplares que constarem da Lista de Vermelha de Plantas Ameaçadas de Extinção no Estado do Paraná editada em 1995 e Portaria nº 37-N/92 do IBAMA, deverão observar a legislação específica que regula a matéria.

###### Art. 6º {#art6}
Tags: #documentacao #mata-atlantica #supressao-vegetacao

**Art. 6º, caput** {#art6_cpt} #documentacao Para o requerimento de exploração de nativas em ambiente agropastoril, deverá o proprietário dirigir-se ao Escritório Regional do IAP mediante apresentação dos documentos relacionados no Capitulo VII da presente Resolução.

### CAPITULO V – DO APROVEITAMENTO DO MATERIAL LENHOSO

###### Art. 7º {#art7}
Tags: #documentacao #mata-atlantica #supressao-vegetacao

**Art. 7º, caput** {#art7_cpt} O aproveitamento do material lenhoso poderá ser autorizado, para exemplares secos, em pé e/ou caídos naturalmente, áreas de ocorrência de acidente natural (vendaval, desmoronamento, enchentes) na propriedade rural, após vistoria técnica realizada por Câmara Técnica Florestal composta por técnicos habilitados, servidores de nível superior do IAP, cujo laudo deverá:
- **Art. 7º, caput, inciso I** {#art7_cpt_inc1} Determinar o percentual de material lenhoso seco em pé ou caído, a permanecer no local para servir de nicho ecológico ou por representarem risco à não regeneração natural do sitio em que se encontram;
- **Art. 7º, caput, inciso II** {#art7_cpt_inc2} Exigir a assinatura de Termo de Compromisso de Restauração de Florestas de plantio e condução de árvores, para os casos específicos de árvores derrubadas por acidentes naturais e vendavais.

**Art. 7º, § 1º** {#art7_par1} #documentacao Para volumes de lenha acima de 100 m³ e toras acima de 50 m³ será exigida a averbação do Termo de Compromisso com mapa georreferenciado registrado às margens da matricula do imóvel ou registrado em Cartório de Títulos e Documentos em caso de posse, na razão de 10 (dez) árvores para cada m³ de toras e 5 (cinco) para cada m³ de lenha de material lenhoso aproveitado.

###### Art. 8º {#art8}
Tags: #mata-atlantica #supressao-vegetacao

**Art. 8º, caput** {#art8_cpt} O procedimento administrativo visando o aproveitamento de material lenhoso deverá ser conduzido pelos Escritórios Regionais do IAP conforme orientação dos seguintes itens:
- **Art. 8º, caput, inciso I** {#art8_cpt_inc1} Para espécies florestais constantes da lista ameaçada de extinção:
  - **Art. 8º, caput, inciso I, alínea "a"** {#art8_cpt_inc1_alia} Para o volume igual ou inferior a 15 m³: O Regional do IAP efetua a vistoria e faz a deliberação final.
- **Art. 8º, caput, inciso II** {#art8_cpt_inc2} Para as demais espécies florestais:
  - **Art. 8º, caput, inciso II, alínea "a"** {#art8_cpt_inc2_alia} Para o volume igual ou inferior a 100 m³: O Regional do IAP efetua a vistoria e faz a deliberação final;
  - **Art. 8º, caput, inciso II, alínea "b"** {#art8_cpt_inc2_alib} Para volumes superiores a 100 m³: Deverá o Regional encaminhar os procedimentos de vistoria a ser executada pela Câmara Técnica Florestal e a sua respectiva deliberação.

**Art. 8º, parágrafo único** {#art8_par1u} As espécies florestais constantes na Lista de Vermelha de Plantas Ameaçadas de Extinção no Estado do Paraná editada em 1995 e Portaria nº 37-N/92 do IBAMA, são especialmente o pinheiro (Araucaria angustifolia), canela sassafrás (Ocotea pretiosa), pau amarelo (Euxilophora paraensis), imbuia (Ocotea porosa), canela preta (Ocotea catharinensis), xaxim (Dicksonia sp), bem como as espécies que venham a compor estas listas.

###### Art. 9º {#art9}
Tags: #autorizacao-florestal #enquadramento #mata-atlantica #proibicao #supressao-vegetacao

**Art. 9º, caput** {#art9_cpt} #autorizacao-florestal #enquadramento #proibicao As operações de retirada das árvores autorizadas para corte seletivo em remanescentes florestais e também para aproveitamento de material lenhoso deverão ser executadas preferencialmente com tração animal, ficando proibido o uso de equipamentos pesados e/ou de grande porte, tais como tratores de esteira e similares. Estas restrições deverão constar no corpo da Autorização Florestal, no caso de exploração autorizável.

### CAPITULO VI – DO CORTE DE NATIVAS EM ÁREAS URBANAS

###### Art. 10 {#art10}
Tags: #documentacao #mata-atlantica #proibicao #responsavel-tecnico #supressao-vegetacao

**Art. 10, caput** {#art10_cpt} Em áreas urbanas consolidadas e loteamentos devidamente licenciados em perímetros urbanos aprovados até a edição da Lei 11.428 de 22.12.2006, o corte eventual de espécies nativas será autorizado pelo IAP ou órgão municipal competente, nos seguintes casos:
- **Art. 10, caput, inciso I** {#art10_cpt_inc1} Para fins de edificações;
- **Art. 10, caput, inciso II** {#art10_cpt_inc2} Árvores que ponham em risco a vida e ao patrimônio público ou privado.

**Art. 10, § 1º** {#art10_par1} #responsavel-tecnico Nas regiões metropolitanas e áreas urbanas, assim consideradas em lei, o parcelamento do solo para fins de loteamento ou qualquer edificação em área de vegetação secundária, em estágio médio de regeneração, do Bioma Mata Atlântica, devem obedecer ao disposto no Plano Diretor do Município e demais normas aplicáveis, e dependerão de prévia autorização do órgão estadual competente, ressalvado o disposto nos art. 11 da [[lei-federal-11428-2006|Lei 11.428/06]].

**Art. 10, § 2º** {#art10_par2} Nos perímetros urbanos aprovados até a data de início de vigência da [[lei-federal-11428-2006|Lei 11.428/06]], a supressão de vegetação secundária em estágio médio de regeneração somente será admitida, para fins de loteamento ou edificação, no caso de empreendimentos que garantam a preservação de vegetação nativa em estágio médio de regeneração em no mínimo 30% (trinta por cento) da área total coberta por esta vegetação.

**Art. 10, § 3º** {#art10_par3} #proibicao Nos perímetros urbanos aprovados após a data de início de vigência da [[lei-federal-11428-2006|Lei 11.428/2006]], é vedada a supressão de vegetação secundária em estágio avançado de regeneração do Bioma Mata Atlântica para fins de loteamento ou edificação.

**Art. 10, § 4º** {#art10_par4} Nos perímetros urbanos delimitados após a data de início de vigência da [[lei-federal-11428-2006|Lei 11.428/06]], a supressão de vegetação secundária em estágio médio de regeneração fica condicionada à manutenção de vegetação em estágio médio de regeneração em no mínimo 50% (cinquenta por cento) da área total coberta por esta vegetação.

**Art. 10, § 5º** {#art10_par5} Os novos empreendimentos que impliquem no corte ou na supressão de vegetação do Bioma Mata Atlântica deverão ser implantados preferencialmente em áreas já substancialmente alteradas ou degradadas.

**Art. 10, § 6º** {#art10_par6} O corte ou a supressão de vegetação primária ou secundária nos estágios médio ou avançado de regeneração do Bioma Mata Atlântica, autorizados pela [[lei-federal-11428-2006|Lei 11.428/06]], ficam condicionados à compensação ambiental, na forma da destinação de área equivalente à extensão da área desmatada, com as mesmas características ecológicas, na mesma bacia hidrográfica, sempre que possível na mesma microbacia hidrográfica, e, nos casos previstos nos parágrafos primeiro e segundo deste artigo, em áreas localizadas no mesmo Município ou região metropolitana.

**Art. 10, § 7º** {#art10_par7} #documentacao O interessado deverá se dirigir ao Escritório Regional do IAP e requerer o corte mediante apresentação dos documentos relacionados no Capitulo VII, artigo [[#art11|11]], itens I, II, III, VII, VIII e IX.

### CAPITULO VII – DO PROCEDIMENTO ADMINISTRATIVO

###### Art. 11 {#art11}
Tags: #app #documentacao #licenciamento-ambiental #mata-atlantica #prazo #responsavel-tecnico #supressao-vegetacao

**Art. 11, caput** {#art11_cpt} #documentacao O requerimento para o corte seletivo e aproveitamento de material lenhoso em tipologias florestais nativas previstas em legislações específicas, deverá ser encaminhado ao órgão ambiental competente, de acordo com a legislação vigente e demais documentos, conforme relacionado abaixo:
- **Art. 11, caput, inciso I** {#art11_cpt_inc1} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental - RAF devidamente preenchido;
- **Art. 11, caput, inciso II** {#art11_cpt_inc2} #documentacao Fotocópia da Carteira de Identidade (RG) e do Cadastro de Pessoa Física (CPF), se pessoa física; ou Contrato Social ou Ato Constitutivo, se pessoa jurídica. Para pessoas com cadastro já existente no IAP, ficam dispensadas as fotocópias, diante da apresentação dos documentos originais no ato de cadastro/protocolo.
- **Art. 11, caput, inciso III** {#art11_cpt_inc3} #documentacao #prazo Transcrição ou matricula do cartório de registro de imóveis atualizada, no máximo 90 dias; ou prova de justa posse, com anuência dos confrontantes, no caso do requerente não possuir documentação legal do imóvel;
- **Art. 11, caput, inciso IV** {#art11_cpt_inc4} Apresentação de declaração de caracterização de Pequeno Produtor Rural fornecido pela EMATER, Sindicato de sua categoria ou outro órgão oficial.
- **Art. 11, caput, inciso V** {#art11_cpt_inc5} #app Averbação da Reserva Legal e Áreas de Preservação Permanente, conforme exigências previstas no SISLEG.
- **Art. 11, caput, inciso VI** {#art11_cpt_inc6} #documentacao Documentação complementar do imóvel – se a situação imobiliária estiver irregular ou comprometida, conforme exigências para casos imobiliários excepcionais;
- **Art. 11, caput, inciso VII** {#art11_cpt_inc7} Comprovante de pagamento da taxa ambiental, de acordo com as tabelas e normas estabelecidas;
- **Art. 11, caput, inciso VIII** {#art11_cpt_inc8} #app Mapa de uso atual do solo georreferenciado, assinalando os remanescentes florestais, áreas de preservação permanente, reserva legal, reflorestamentos, hidrografia, estradas, e o local objeto da solicitação (também georreferenciado) devidamente identificado no mapa;
- **Art. 11, caput, inciso IX** {#art11_cpt_inc9} #responsavel-tecnico Anotação de Responsabilidade Técnica – ART de profissional habilitado, pela elaboração do mapa de uso atual do solo georreferenciado e/ou inventário florestal ou censo, quando for o caso;
- **Art. 11, caput, inciso X** {#art11_cpt_inc10} #documentacao Poderá o órgão ambiental competente solicitar, quando julgado necessário, documentação complementar, conforme estabelecido em normativas específicas;

**Art. 11, § 1º** {#art11_par1} #documentacao Para o caso de Pequeno Produtor Rural somente deverá apresentar os documentos relativos aos itens I, II, III, IV, V e VI.

###### Art. 12 {#art12}
Tags: #documentacao #enquadramento #mata-atlantica #supressao-vegetacao

**Art. 12, caput** {#art12_cpt} #documentacao #enquadramento O transporte do material lenhoso do local de corte ou da área do aproveitamento deverá ser acompanhado do DOF – Documento de Origem Florestal, no caso dos autorizáveis.

**Art. 12, parágrafo único** {#art12_par1u} #enquadramento No caso do explorador eventual o transporte dependerá de autorização específica, desde que o destino não ultrapasse a fronteira do Estado do Paraná.

###### Art. 13 {#art13}
Tags: #definicao #mata-atlantica #supressao-vegetacao

**Art. 13, caput** {#art13_cpt} #definicao São consideradas exceções às proibições contidas nesta Resolução, os casos reconhecidamente de: utilidade pública, interesse social e as espécies arbóreas que ponham em risco a vida e o patrimônio comprovado por meio de laudo técnico emitido pelo órgão ambiental competente, de acordo com as definições da [[lei-federal-4771-1965|Lei Federal n°4771/65]].

### CAPITULO VIII – DAS PENALIZAÇÕES

###### Art. 14 {#art14}
Tags: #mata-atlantica #supressao-vegetacao

**Art. 14, caput** {#art14_cpt} As infringências de quaisquer das disposições desta Resolução sujeitarão os infratores às sanções estipuladas a [[lei-federal-6905-1998|Lei nº 6.905/98]] e no [[decreto-federal-3179-1999|Decreto 3.179/99]] sem prejuízo da obrigação de reparar o dano.

###### Art. 15 {#art15}
Tags: #mata-atlantica #supressao-vegetacao

**Art. 15, caput** {#art15_cpt} Esta Resolução entra em vigor na data de sua publicação, ficando em consequência revogada a [[portaria-iap-193-2007|Portaria IAP nº 193 de 27 de outubro de 2007]], a [[resolucao-conjunta-ibama-sema-iap-54-2007|Resolução Conjunta IBAMA/SEMA/IAP nº 54 de 10 de dezembro de 2007]] e Portaria Conjunta IBAMA/IAP nº 002 de 10 de dezembro de 2007 e as demais disposições em contrário.


## Fecho

Curitiba, 18 de abril de 2008. Hélio Sydol Superintendente Substituto Estadual do IBAMA/PR Lindsley da Silva Rasca Rodrigues Secretário de Estado do Meio Ambiente e Recursos Hídricos Vitor Hugo Ribeiro Burko Diretor Presidente do Instituto Ambiental do Paraná Este texto não substitui o publicado no Diário Oficial do Estado


## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (Resolução Conjunta IBAMA SEMA IAP 007 2008.pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
