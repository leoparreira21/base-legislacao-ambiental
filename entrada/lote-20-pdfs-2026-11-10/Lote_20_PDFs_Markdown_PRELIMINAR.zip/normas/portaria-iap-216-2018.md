---
norma: "Portaria IAP nº 216/2018"
arquivo: portaria-iap-216-2018
tipo: portaria
esfera: estadual
uf: PR
numero: 216
ano: 2018
data_assinatura: 2018-08-22
ementa: "Critérios para licenciamento ambiental de empreendimentos habitacionais de interesse social em área urbana."
situacao: revogada
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: []
revoga: ["[[portaria-iap-165-2015]]"]
revogado_por: ["[[instrucao-normativa-iat-17-2025]]"]
cita: ["[[decreto-estadual-4696-2016]]", "[[decreto-federal-9302-2018]]", "[[lei-estadual-10066-1992]]", "[[lei-estadual-10671-1993]]", "[[portaria-iap-165-2015]]", "[[portaria-iap-216-2018-anexo1]]", "[[resolucao-cema-65-2008]]", "[[resolucao-conama-237-1997]]", "[[resolucao-conama-412-2009]]", "[[resolucao-conama-6-1986]]"]
tags: ["agua-subterranea", "app", "autorizacao-florestal", "definicao", "documentacao", "efluente", "empreendimento-imobiliario", "interesse-social", "las", "li", "licenciamento-ambiental", "lp", "prazo", "renovacao", "responsavel-tecnico"]
fonte: "PDF fornecido: portaria IAP 216 2018.pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
---

# Portaria IAP nº 216/2018

> Critérios para licenciamento ambiental de empreendimentos habitacionais de interesse social em área urbana.

## Preâmbulo

PORTARIA IAP Nº 216, DE 22 DE AGOSTO DE 2018 O Diretor Presidente do Instituto Ambiental do Paraná – IAP, nomeado pelo [[decreto-federal-9302-2018|Decreto nº 9302, de 10 de abril de 2018]], no uso das atribuições que lhe são conferidas pela [[lei-estadual-10066-1992|Lei Estadual n° 10.066, de 27 de julho de 1992]], com as alterações trazidas pelas Leis n° 11.352, de 13 de fevereiro de 1996 e n° 13.425, de 07 de janeiro de 2002 e de acordo com o seu Regulamento, aprovado pelo [[decreto-estadual-4696-2016|Decreto n° 4696 de 27 de julho de 2016]], e: • Considerando o disposto na [[resolucao-conama-237-1997|Resolução CONAMA nº 237/1997]]; • Considerando o disposto na [[resolucao-cema-65-2008|Resolução CEMA nº 065/2008]]; • Considerando o disposto na [[resolucao-conama-412-2009|Resolução CONAMA n° 412/2009]] e • Considerando o disposto na [[lei-estadual-10671-1993|Lei Estadual 10.671, de 17 de dezembro de 1993]], RESOLVE:

###### Art. 1º {#art1}
Tags: #definicao #empreendimento-imobiliario #interesse-social #las #li #licenciamento-ambiental #lp

**Art. 1º, caput** {#art1_cpt} #definicao #las #li #licenciamento-ambiental #lp Estabelecer critérios para o Licenciamento Ambiental para implantação de empreendimentos habitacionais considerados de interesse social em área urbana, destinados ao atendimento da população definida como de baixa renda, nas modalidades Licença Prévia-LP, Licença de Instalação-LI e Licença Ambiental Simplificada-LAS;

###### Art. 2º {#art2}
Tags: #empreendimento-imobiliario #interesse-social

**Art. 2º, caput** {#art2_cpt} Aplica-se a LP e LI para implantação de novos empreendimentos habitacionais;

###### Art. 3º {#art3}
Tags: #empreendimento-imobiliario #interesse-social

**Art. 3º, caput** {#art3_cpt} Aplica-se a LAS para implantação de unidades habitacionais em áreas consolidadas, com infraestrutura urbana implantada, em complementação a empreendimentos já instalados, onde exista remanescente de terreno e haja viabilidade técnica e ambiental de implantação de novas unidades habitacionais;

#### SEÇÃO I – Da Licença Prévia – LP

###### Art. 4º {#art4}
Tags: #agua-subterranea #app #documentacao #efluente #empreendimento-imobiliario #interesse-social #licenciamento-ambiental #lp #prazo #responsavel-tecnico

**Art. 4º, caput** {#art4_cpt} #lp Para solicitação da Licença Prévia o requerente deverá apresentar:
- **Art. 4º, caput, inciso I** {#art4_cpt_inc1} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental - RLA;
- **Art. 4º, caput, inciso II** {#art4_cpt_inc2} Cadastro de Empreendimentos Imobiliários- CIM
- **Art. 4º, caput, inciso III** {#art4_cpt_inc3} #lp Prova de publicação da súmula do pedido de Licença Prévia em jornal de circulação regional e no Diário Oficial do Estado, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 4º, caput, inciso IV** {#art4_cpt_inc4} #documentacao Certidão do município ou documento equivalente, declarando expressamente que o local e o tipo de empreendimento estão em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano;
- **Art. 4º, caput, inciso V** {#art4_cpt_inc5} #documentacao #prazo Matrícula ou Transcrição emitida pelo Cartório de Registro de Imóveis, atualizada, máximo de 90 dias, ou caso a matrícula ou transcrição esteja em nome de terceiros, anexar escritura pública de compra e venda ou lei municipal de doação;
- **Art. 4º, caput, inciso VI** {#art4_cpt_inc6} #documentacao Documentação complementar do imóvel se a situação imobiliária estiver irregular ou comprometida, conforme exigências para casos imobiliários excepcionais, conforme Artigo 46 da [[resolucao-cema-65-2008|Resolução CEMA 065/2008]];
- **Art. 4º, caput, inciso VII** {#art4_cpt_inc7} Apresentação de relatório fotográfico, contendo no mínimo 10 fotografias, visando a caracterização do imóvel, bem como imagem de satélite com localização do imóvel, sendo aceitas imagens obtidas nos sites de consulta pública, tais como Google Maps ou Google Earth;
- **Art. 4º, caput, inciso VIII** {#art4_cpt_inc8} #agua-subterranea Teste de sondagem à trado contendo no mínimo a seguinte caracterização do solo: textura (arenosa/argilosa), horizontes (espessuras), profundidade (topo rochoso) e profundidade de lençol freático. (ABNT/NBR 9603/1986);
  - **Art. 4º, caput, inciso VIII, alínea "a"** {#art4_cpt_inc8_alia} Deverá ser executado no mínimo 01 (uma) sondagem para cada 3.000,00 m2 de terreno;
  - **Art. 4º, caput, inciso VIII, alínea "b"** {#art4_cpt_inc8_alib} Para terrenos com área inferior a 9.000,00 m2, deverão ser executadas 03 (três) sondagens.
  - **Art. 4º, caput, inciso VIII, alínea "c"** {#art4_cpt_inc8_alic} Os furos deverão ser executados com trado de 0,20 m de diâmetro até uma profundidade mínima de 3,00 m e deverão abranger uniformemente o terreno;
  - **Art. 4º, caput, inciso VIII, alínea "d"** {#art4_cpt_inc8_alid} Deverá ser apresentado o perfil geológico dos furos de sondagem ;
  - **Art. 4º, caput, inciso VIII, alínea "e"** {#art4_cpt_inc8_alie} #agua-subterranea Deverá ser apresentado um relatório de sondagem descrevendo suscintamente a área do empreendimento, relevo, vegetação e tipo de solo encontrado, bem como informando a profundidade do lençol freático encontrada.
  - **Art. 4º, caput, inciso VIII, alínea "f"** {#art4_cpt_inc8_alif} Deverá ser apresentado um croqui com a localização dos furos de sondagem.
  - **Art. 4º, caput, inciso VIII, alínea "g"** {#art4_cpt_inc8_alig} Quanto aos aspectos geológicos deverá ser verificada a presença de erosão (sulcos e ravinas), zonas úmidas, abatimentos, cascalho e blocos de rocha não alterados e coeficiente de permeabilidade do solo (ABNT/NBR 7229/1993 e 13969/1997);
- **Art. 4º, caput, inciso IX** {#art4_cpt_inc9} #documentacao Carta de viabilidade do empreendimento ou documento equivalente da COPEL ou concessionária de energia elétrica;
- **Art. 4º, caput, inciso X** {#art4_cpt_inc10} #documentacao #efluente Carta de viabilidade do empreendimento ou documento equivalente da SANEPAR ou concessionária de água e esgoto;
- **Art. 4º, caput, inciso XI** {#art4_cpt_inc11} #efluente Quando não existir viabilidade para atendimento do empreendimento através de rede coletora de esgoto (SANEPAR ou concessionária), deverá ser apresentado o Teste de Percolação conforme NBR 13.969/1997, cujos requisitos para sua elaboração devem contemplar, no mínimo:
  - **Art. 4º, caput, inciso XI, alínea "a"** {#art4_cpt_inc11_alia} 01(um) teste de percolação para cada 6.000,00 m2 de terreno, com profundidade mínima de 3,00 m, conforme método de ensaio anexo.
  - **Art. 4º, caput, inciso XI, alínea "b"** {#art4_cpt_inc11_alib} Para terrenos com área inferior a 18.000,00 m2, deverão ser executados no mínimo 03 (três) testes.
  - **Art. 4º, caput, inciso XI, alínea "c"** {#art4_cpt_inc11_alic} Para cada teste deverá ser apresentado o resultado gráfico do ensaio de capacidade de absorção do solo, e o respectivo coeficiente de infiltração.
  - **Art. 4º, caput, inciso XI, alínea "d"** {#art4_cpt_inc11_alid} #responsavel-tecnico Deverá ser apresentado um relatório de percolação, no qual o responsável técnico informará: área do empreendimento, relevo, vegetação, tipo de solo encontrado e a conclusão técnica sobre a possibilidade/impossibilidade da utilização do sistema composto por fossa séptica e sumidouro.
  - **Art. 4º, caput, inciso XI, alínea "e"** {#art4_cpt_inc11_alie} Deverá ser apresentado um croqui com a localização das valas de percolação.
- **Art. 4º, caput, inciso XII** {#art4_cpt_inc12} #app Levantamento planialtimétrico cadastral e planta de implantação urbanística preliminar com estatística, contendo situação e localização, áreas de preservação permanente e áreas de interesse a manter, com coordenadas geográficas UTM;
- **Art. 4º, caput, inciso XIII** {#art4_cpt_inc13} O IAP deverá solicitar o Relatório Ambiental Simplificado-RAS, conforme Termo de Referência (Anexo I) quando o imóvel pretendido para implantação do empreendimento estiver localizado em:
  - **Art. 4º, caput, inciso XIII, alínea "a"** {#art4_cpt_inc13_alia} Área de manancial de abastecimento público;
  - **Art. 4º, caput, inciso XIII, alínea "b"** {#art4_cpt_inc13_alib} #agua-subterranea Área localizada no Aquifero Karst;
  - **Art. 4º, caput, inciso XIII, alínea "c"** {#art4_cpt_inc13_alic} Área de Proteção Ambiental - APA
  - **Art. 4º, caput, inciso XIII, alínea "d"** {#art4_cpt_inc13_alid} Área de risco e/ou suscetíveis a erosões;
  - **Art. 4º, caput, inciso XIII, alínea "e"** {#art4_cpt_inc13_alie} Área alagadiça ou sujeita a inundações;
  - **Art. 4º, caput, inciso XIII, alínea "f"** {#art4_cpt_inc13_alif} Área de aterro com material nocivo à saúde e área com suspeita de contaminação;
  - **Art. 4º, caput, inciso XIII, alínea "g"** {#art4_cpt_inc13_alig} Área com declividade igual ou superior a 30%, salvo se atendidas exigências específicas das autoridades competentes;
  - **Art. 4º, caput, inciso XIII, alínea "h"** {#art4_cpt_inc13_alih} Áreas com cobertura florestal significativa;
  - **Art. 4º, caput, inciso XIII, alínea "i"** {#art4_cpt_inc13_alii} Área localizada em corredor ecológico e/ou corredor de fauna;

###### Art. 5º {#art5}
Tags: #empreendimento-imobiliario #interesse-social #lp #prazo #renovacao

**Art. 5º, caput** {#art5_cpt} #lp #prazo #renovacao O prazo de validade da Licença Prévia será de 03 (três) anos, não sendo possível sua renovação.

#### SEÇÃO II – Da Licença de Instalação - LI

###### Art. 6º {#art6}
Tags: #agua-subterranea #app #definicao #documentacao #efluente #empreendimento-imobiliario #interesse-social #li #licenciamento-ambiental #lp #prazo

**Art. 6º, caput** {#art6_cpt} #li Para solicitação da Licença de Instalação o requerente deverá apresentar:
- **Art. 6º, caput, inciso I** {#art6_cpt_inc1} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental - RLA;
- **Art. 6º, caput, inciso II** {#art6_cpt_inc2} Cadastro de Empreendimentos Imobiliários- CIM;
- **Art. 6º, caput, inciso III** {#art6_cpt_inc3} #lp Cópia da Licença Prévia;
- **Art. 6º, caput, inciso IV** {#art6_cpt_inc4} #lp Prova de publicação da súmula de recebimento da Licença Prévia, em jornal de circulação regional e no Diário Oficial do Estado, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA no 006/86]];
- **Art. 6º, caput, inciso V** {#art6_cpt_inc5} #li Prova de publicação da súmula do pedido de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 6º, caput, inciso VI** {#art6_cpt_inc6} #documentacao #prazo Matrícula ou Transcrição emitida pelo Cartório de Registro de Imóveis, em nome do requerente, atualizada, máximo de 90 dias, com a devida averbação como imóvel urbano;
- **Art. 6º, caput, inciso VII** {#art6_cpt_inc7} #app #definicao Planta definitiva de implantação do empreendimento, com estatística, contendo altimetria, situação e localização, coordenadas geográficas UTM, áreas de preservação permanente e áreas de interesse a manter, aprovadas pelo município;
- **Art. 6º, caput, inciso VIII** {#art6_cpt_inc8} Demais plantas e detalhamentos técnicos julgados pertinentes para análise da instalação do empreendimento;
- **Art. 6º, caput, inciso IX** {#art6_cpt_inc9} #documentacao #lp Documentos elencados nas condicionantes da Licença Prévia.
- **Art. 6º, caput, inciso X** {#art6_cpt_inc10} #agua-subterranea #efluente Quando não existir viabilidade para atendimento do empreendimento através de rede coletora de esgoto (SANEPAR ou concessionária), apresentar projeto hidrossanitário individual de acordo com as normas da ABNT, com base nas características do solo obtidas no teste de sondagem e percolação (tipo de solo, textura, coeficiente de infiltração, nível do lençol freático, entre outros) e densidade de ocupação;
- **Art. 6º, caput, inciso XI** {#art6_cpt_inc11} #li #licenciamento-ambiental Quando da emissão da Licença de Instalação deverá o órgão licenciador carimbar as plantas finais de implantação urbanística com estatística, de terraplenagem, de drenagem e do projeto hidrossanitário individual, aprovados no procedimento de licenciamento, constando o número da L.I. e do protocolo do procedimento de licenciamento;

###### Art. 7º {#art7}
Tags: #empreendimento-imobiliario #interesse-social #li #prazo #renovacao

**Art. 7º, caput** {#art7_cpt} #li #prazo #renovacao O prazo de validade da Licença de Instalação será de 06 (seis) anos, sendo possível sua renovação, devendo ser requerida no mínimo 120 (cento e vinte) dias antes da data de vencimento;

###### Art. 8º {#art8}
Tags: #documentacao #empreendimento-imobiliario #interesse-social #li #licenciamento-ambiental #renovacao

**Art. 8º, caput** {#art8_cpt} #li #renovacao Para solicitação da Renovação da Licença de Instalação o requerente deverá apresentar:
- **Art. 8º, caput, inciso I** {#art8_cpt_inc1} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental - RLA;
- **Art. 8º, caput, inciso II** {#art8_cpt_inc2} #li Cópia da Licença de Instalação;
- **Art. 8º, caput, inciso III** {#art8_cpt_inc3} #li Prova de publicação da súmula de recebimento da Licença de Instalação e de sua respectiva publicação em jornal de circulação regional e no Diário Oficial do Estado, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 8º, caput, inciso IV** {#art8_cpt_inc4} #li #renovacao Prova de publicação da súmula do pedido de Renovação da Licença de Instalação, em jornal de circulação regional e no Diário Oficial do Estado, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA no 006/86]];
- **Art. 8º, caput, inciso V** {#art8_cpt_inc5} #renovacao Justificativa para o pedido de renovação e relatório fotográfico com no mínimo 10 fotos das obras já executadas (quando aplicável);

#### SEÇÃO III – Da Licença Ambiental Simplificada – LAS

###### Art. 9º {#art9}
Tags: #agua-subterranea #app #definicao #documentacao #efluente #empreendimento-imobiliario #interesse-social #las #licenciamento-ambiental #prazo #renovacao #responsavel-tecnico

**Art. 9º, caput** {#art9_cpt} Para solicitação da LAS o requerente deverá apresentar:
- **Art. 9º, caput, inciso I** {#art9_cpt_inc1} #documentacao #licenciamento-ambiental Requerimento de Licenciamento Ambiental - RLA;
- **Art. 9º, caput, inciso II** {#art9_cpt_inc2} Cadastro de Empreendimentos Imobiliários- CIM
- **Art. 9º, caput, inciso III** {#art9_cpt_inc3} #las Prova de publicação da súmula do pedido de Licença Ambiental Simplificada em jornal de circulação regional e no Diário Oficial do Estado, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 9º, caput, inciso IV** {#art9_cpt_inc4} #documentacao Certidão do município ou documento equivalente, declarando expressamente que o local e o tipo de empreendimento estão em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano;
- **Art. 9º, caput, inciso V** {#art9_cpt_inc5} #documentacao #prazo Matrícula ou Transcrição emitida pelo Cartório de Registro de Imóveis, registrado como imóvel urbano, em nome do requerente e atualizada, máximo de 90 dias, ou caso a matrícula ou transcrição esteja em nome de terceiros, anexar escritura pública de compra e venda ou lei municipal de doação;
- **Art. 9º, caput, inciso VI** {#art9_cpt_inc6} #documentacao Documentação complementar do imóvel se a situação imobiliária estiver irregular ou comprometida, conforme exigências para casos imobiliários excepcionais, conforme Artigo 46 da [[resolucao-cema-65-2008|Resolução CEMA 065/2008]];
- **Art. 9º, caput, inciso VII** {#art9_cpt_inc7} Apresentação de relatório fotográfico, contendo no mínimo 10 fotografias, visando a caracterização do imóvel, bem como imagem de satélite com localização do imóvel, sendo aceitas imagens obtidas nos sites de consulta pública, tais como Google Maps ou Google Earth;
- **Art. 9º, caput, inciso VIII** {#art9_cpt_inc8} #agua-subterranea Teste de sondagem à trado contendo no mínimo a seguinte caracterização do solo: textura (arenosa/argilosa), horizontes (espessuras), profundidade (topo rochoso) e profundidade de lençol freático, (ABNT/NBR 9603/1986), conforme especificado abaixo:
  - **Art. 9º, caput, inciso VIII, alínea "a"** {#art9_cpt_inc8_alia} Deverá ser executado no mínimo 01 (uma) sondagem para cada 3.000,00 m2 de terreno;
  - **Art. 9º, caput, inciso VIII, alínea "b"** {#art9_cpt_inc8_alib} Para terrenos com área inferior a 9.000,00 m2, deverão ser executadas 03 (três) sondagens.
  - **Art. 9º, caput, inciso VIII, alínea "c"** {#art9_cpt_inc8_alic} Os furos deverão ser executados com trado de 0,20 m de diâmetro até uma profundidade mínima de 3,00 m e deverão abranger uniformemente o terreno;
  - **Art. 9º, caput, inciso VIII, alínea "d"** {#art9_cpt_inc8_alid} Deverá ser apresentado o perfil geológico dos furos de sondagem;
  - **Art. 9º, caput, inciso VIII, alínea "e"** {#art9_cpt_inc8_alie} #agua-subterranea Deverá ser apresentado um relatório de sondagem descrevendo suscintamente a área do empreendimento, relevo, vegetação e tipo de solo encontrado, bem como informando a profundidade do lençol freático encontrada.
  - **Art. 9º, caput, inciso VIII, alínea "f"** {#art9_cpt_inc8_alif} Deverá ser apresentado um croqui com a localização dos furos de sondagem.
  - **Art. 9º, caput, inciso VIII, alínea "g"** {#art9_cpt_inc8_alig} Quanto aos aspectos geológicos deverá ser verificada a presença de erosão (sulcos e ravinas), zonas úmidas, abatimentos, cascalho e blocos de rocha não alterados e coeficiente de permeabilidade do solo (ABNT/NBR 7229/1993 e 13969/1997);
- **Art. 9º, caput, inciso IX** {#art9_cpt_inc9} #documentacao Carta de viabilidade do empreendimento ou documento equivalente da COPEL ou concessionária de energia elétrica;
- **Art. 9º, caput, inciso X** {#art9_cpt_inc10} #documentacao #efluente Carta de viabilidade do empreendimento ou documento equivalente da SANEPAR ou concessionária de água e esgoto;
- **Art. 9º, caput, inciso XI** {#art9_cpt_inc11} #efluente Quando não existir viabilidade para atendimento do empreendimento através de rede coletora de esgoto, deverá ser apresentado o projeto hidrossanitário individual, com base no Teste de Percolação a ser apresentado conjuntamente (ABNT NBR 7.229/1993, NBR 13.969/1997), cujos requisitos para sua elaboração devem contemplar, no mínimo:
  - **Art. 9º, caput, inciso XI, alínea "a"** {#art9_cpt_inc11_alia} 01(um) teste de percolação para cada 6.000,00 m2 de terreno, com profundidade mínima de 3,00 m, conforme método de ensaio anexo.
  - **Art. 9º, caput, inciso XI, alínea "b"** {#art9_cpt_inc11_alib} Para terrenos com área inferior a 18.000,00 m2, deverão ser executados no mínimo 03 (três) testes.
  - **Art. 9º, caput, inciso XI, alínea "c"** {#art9_cpt_inc11_alic} Para cada teste deverá ser apresentado o resultado gráfico do ensaio de capacidade de absorção do solo, e o respectivo coeficiente de infiltração.
  - **Art. 9º, caput, inciso XI, alínea "d"** {#art9_cpt_inc11_alid} #responsavel-tecnico Deverá ser apresentado um relatório de percolação, no qual o responsável técnico informará: área do empreendimento, relevo, vegetação, tipo de solo encontrado e a conclusão técnica sobre a possibilidade/impossibilidade da utilização do sistema composto por fossa séptica e sumidouro.
  - **Art. 9º, caput, inciso XI, alínea "e"** {#art9_cpt_inc11_alie} Deverá ser apresentado um croqui com a localização das valas de percolação.
- **Art. 9º, caput, inciso XII** {#art9_cpt_inc12} #app #definicao Planta definitiva de implantação do empreendimento, com estatística, contendo altimetria, situação e localização, coordenadas geográficas UTM, áreas de preservação permanente e áreas de interesse a manter, aprovadas pelo município;
- **Art. 9º, caput, inciso XIII-O** {#art9_cpt_inc13-o} #las #prazo #renovacao prazo de validade da Licença Ambiental Simplificada (LAS) será de 06 (seis) anos, podendo ser renovada se necessário, devendo ser requerida no mínimo 120 (cento e vinte) dias antes da data de vencimento;

#### SEÇÃO IV – Das Disposições Gerais

###### Art. 10 {#art10}
Tags: #documentacao #empreendimento-imobiliario #interesse-social #responsavel-tecnico

**Art. 10, caput** {#art10_cpt} #documentacao #responsavel-tecnico Todos os documentos (laudos, testes, plantas, levantamentos, relatórios, informações, etc.) devem ser encaminhados com assinatura do técnico responsável habilitado, constando o nome, qualificação, registro profissional, endereço e telefone para contato, com emissão de ART/RRT devidamente registrada no Conselho de Classe correspondente;

###### Art. 11 {#art11}
Tags: #documentacao #empreendimento-imobiliario #interesse-social #licenciamento-ambiental

**Art. 11, caput** {#art11_cpt} #documentacao #licenciamento-ambiental Caso haja necessidade o IAP poderá solicitar outros documentos e informações complementares, de acordo com as particularidades do imóvel e/ou do empreendimento objeto do licenciamento, mediante parecer técnico devidamente fundamentado;

###### Art. 12 {#art12}
Tags: #empreendimento-imobiliario #interesse-social

**Art. 12, caput** {#art12_cpt} O descumprimento das disposições desta Portaria e dos termos das condicionantes das licenças ambientais emitidas, bem como da legislação ambiental, sujeitará o infrator às penalidades previstas nos dispositivos normativos pertinentes, sem prejuízo do dever de recuperar os danos ambientais eventualmente causados;

###### Art. 13 {#art13}
Tags: #autorizacao-florestal #empreendimento-imobiliario #interesse-social #licenciamento-ambiental

**Art. 13, caput** {#art13_cpt} #autorizacao-florestal #licenciamento-ambiental Nos procedimentos de licenciamento em que haja necessidade de supressão de vegetação, o pedido de Autorização Florestal deverá ser protocolado em procedimento próprio, devendo obrigatoriamente ser analisado em conjunto com o licenciamento do empreendimento, visando avaliação integrada;

###### Art. 14 {#art14}
Tags: #empreendimento-imobiliario #interesse-social

**Art. 14, caput** {#art14_cpt} Em caso de terrenos provenientes de áreas rurais com reserva legal averbada e legalmente incorporados ao perímetro urbano, a mesma deverá ser mantida como área verde urbana;

###### Art. 15 {#art15}
Tags: #empreendimento-imobiliario #interesse-social #licenciamento-ambiental

**Art. 15, caput** {#art15_cpt} #licenciamento-ambiental Nos procedimentos de licenciamento abordados na presente Portaria, deverão ser contemplados a destinação de áreas para circulação, implantação de equipamentos urbanos e comunitários, áreas verdes e espaços livres de uso público, que garantam a qualidade e segurança ambiental do empreendimento, compatível com Plano Diretor Municipal ou Lei Municipal de Uso e Ocupação do Solo Urbano;

###### Art. 16 {#art16}
Tags: #empreendimento-imobiliario #interesse-social #licenciamento-ambiental

**Art. 16, caput** {#art16_cpt} #licenciamento-ambiental Caberá aos escritórios regionais do IAP atender as demandas de licenciamento ambiental desses empreendimentos e criar as condições operacionais para o cumprimento dos objetivos da presente Portaria;

###### Art. 17 {#art17}
Tags: #empreendimento-imobiliario #interesse-social #licenciamento-ambiental

**Art. 17, caput** {#art17_cpt} #licenciamento-ambiental Não está sujeita ao licenciamento ambiental a construção de uma unidade habitacional quando se tratar de lote isolado;

###### Art. 18 {#art18}
Tags: #empreendimento-imobiliario #interesse-social #licenciamento-ambiental

**Art. 18, caput** {#art18_cpt} #licenciamento-ambiental Esta norma se aplica aos procedimentos de licenciamento ambiental protocolados junto ao IAP a partir da data de sua publicação;

###### Art. 19 {#art19}
Tags: #empreendimento-imobiliario #interesse-social

**Art. 19, caput** {#art19_cpt} Esta Portaria entra em vigor na data de sua publicação, sendo revogada a [[portaria-iap-165-2015|Portaria IAP 165/2015]].


## Fecho

PAULINO HEITOR MEXIA Diretor Presidente do Instituto Ambiental do Paraná

### Termo de referência — Relatório Ambiental Simplificado - RAS {#anexo1}

[[portaria-iap-216-2018-anexo1|Termo de referência — Relatório Ambiental Simplificado - RAS]]

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|
| [[instrucao-normativa-iat-17-2025]] | Norma inteira | Revogação expressa registrada no acervo. |

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (portaria IAP 216 2018.pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- O PDF não apresenta ementa autônoma; o frontmatter contém descrição editorial derivada do art. 1º.
- Fonte: portaria IAP 216 2018.pdf (portal Sistema de Informações Ambientais do Paraná). Foram retirados os marcadores de página da extração e reunidas as quebras de linha; mantidas as grafias do texto fornecido.
- A transcrição foi feita a partir do texto extraído disponível. A comparação palavra por palavra com a extração local do PDF e a conferência visual não foram concluídas nesta etapa.
- Situação revogada conforme relação expressa já cadastrada no acervo: [[instrucao-normativa-iat-17-2025]]. Regras de transição e processos antigos devem ser avaliados separadamente.
