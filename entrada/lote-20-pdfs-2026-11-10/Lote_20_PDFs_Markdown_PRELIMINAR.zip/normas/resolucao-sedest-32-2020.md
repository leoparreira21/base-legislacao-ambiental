---
norma: "Resolução SEDEST nº 32/2020"
arquivo: resolucao-sedest-32-2020
tipo: resolucao
esfera: estadual
uf: PR
numero: 32
ano: 2020
data_assinatura: 2020-05-11
ementa: "Estabelece condições e critérios e dá outras providências, para o licenciamento ambiental de Pátio/Estacionamento de Caminhões – Protocolo 16.546.771-0."
situacao: revogada
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: []
revoga: []
revogado_por: ["[[resolucao-sedest-39-2024]]"]
cita: ["[[decreto-estadual-1440-2019]]", "[[decreto-estadual-6390-2006]]", "[[lei-estadual-10066-1992]]", "[[lei-estadual-12248-1998]]", "[[lei-federal-19848-2019]]", "[[lei-federal-6938-1981]]", "[[lei-federal-9605-1998]]", "[[portaria-iap-256-2013]]", "[[resolucao-cema-105-2019]]", "[[resolucao-conama-428-2010]]", "[[resolucao-conama-6-1986]]"]
tags: ["app", "definicao", "documentacao", "efluente", "eia-rima", "enquadramento", "las", "li", "licenciamento-ambiental", "lo", "lp", "outorga", "patio-caminhao", "prazo", "proibicao", "renovacao", "residuo-solido", "responsavel-tecnico"]
fonte: "PDF fornecido: sedest 32 2020(1).pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
---

# Resolução SEDEST nº 32/2020

> Estabelece condições e critérios e dá outras providências, para o licenciamento ambiental de Pátio/Estacionamento de Caminhões – Protocolo 16.546.771-0.

## Preâmbulo

Resolução SEDEST 32 - 11 de Maio de 2020 Publicado no Diário Oficial nº. 10684 de 12 de Maio de 2020 Súmula: Estabelece condições e critérios e dá outras providências, para o licenciamento ambiental de Pátio/Estacionamento de Caminhões – Protocolo 16.546.771-0 O SECRETÁRIO DE ESTADO DO DESENVOLVIMENTO SUSTENTÁVEL E DO TURISMO, designado pelo [[decreto-estadual-1440-2019|Decreto Estadual n. º 1440, de 23 de maio de 2019]], no uso das atribuições que lhe são conferidas pela Lei Estadual nº [[lei-federal-19848-2019|Lei nº 19.848, de 3 de maio de 2019]] e [[lei-estadual-10066-1992|Lei n° 10.066, de 27 de julho de 1992]], e Considerando o disposto na Resolução do Conselho Nacional do Meio Ambiente – CONAMA, sob n° 237, de 19 de dezembro de 1997 e na Resolução do Conselho Estadual do Meio Ambiente – CEMA nº 105/2019, que dispõe sobre licenciamento ambiental, estabelece critérios e procedimentos a serem adotados para as atividades poluidoras, degradadoras e/ou modificadoras do meio ambiente e adota outras providências; Considerando a necessidade de dar efetividade ao "princípio da prevenção" consagrado na Política Nacional do Meio Ambiente (artigo 2º, incisos I, IV e IX da [[lei-federal-6938-1981|Lei Federal n.º 6.938, de 31 de agosto de 1.981]]) e na Declaração do Rio de Janeiro de 1992 (Princípio n.º 15); RESOLVE:

###### Art. 1º {#art1}
Tags: #licenciamento-ambiental #patio-caminhao

**Art. 1º, caput** {#art1_cpt} #licenciamento-ambiental Estabelecer critérios para o Licenciamento Ambiental Pátio/Estacionamento de Caminhões, vinculados ou não à uma outra atividade, tais como: posto de combustível, industria, terminal de cargas.

###### Art. 2º {#art2}
Tags: #definicao #documentacao #licenciamento-ambiental #patio-caminhao #responsavel-tecnico

**Art. 2º, caput** {#art2_cpt} #definicao Para os efeitos desta Resolução, considera-se:
- **Art. 2º, caput, inciso I** {#art2_cpt_inc1} Estudos Ambientais Específicos: todos e quaisquer estudos relativos aos aspectos ambientais relacionados à localização, instalação, operação e ampliação de uma atividade ou empreendimento, apresentado como subsídio para a análise da licença requerida, tais como: Plano de Controle Ambiental, Projeto de Controle de Poluição Ambiental e Plano de Recuperação de Área Degradada;
- **Art. 2º, caput, inciso II** {#art2_cpt_inc2} Licença Ambiental: ato administrativo pelo qual o órgão ambiental competente, estabelece as condições, restrições e medidas de controle ambiental que deverão ser obedecidas pelo empreendedor, pessoa física ou jurídica, para localizar, instalar, ampliar e operar empreendimentos ou atividades utilizadoras dos recursos ambientais consideradas efetiva ou potencialmente poluidoras ou aquelas que, sob qualquer forma, possam causar degradação e/ou modificação ambiental;
- **Art. 2º, caput, inciso III** {#art2_cpt_inc3} #licenciamento-ambiental Licenciamento Ambiental: procedimento administrativo pelo qual o órgão ambiental competente, verificando a satisfação das condições legais e técnicas, licencia a localização, instalação, ampliação e a operação de empreendimentos e atividades utilizadoras de recursos ambientais consideradas efetiva ou potencialmente poluidoras ou daquelas que, sob qualquer forma, possam causar degradação e/ou modificação ambiental, considerando as disposições legais e regulamentares e as normas técnicas aplicáveis ao caso;
- **Art. 2º, caput, inciso IV** {#art2_cpt_inc4} #documentacao #responsavel-tecnico Responsável Técnico: profissional especializado na área de abrangência do sistema, responsável pelos projetos, orientação, documentação técnica, citados nesta Resolução;
- **Art. 2º, caput, inciso V** {#art2_cpt_inc5} Pátio/Estacionamento de Caminhões: espaço coberto e/ou descoberto, destinado ao estacionamento, movimentação e/ou manobra de veículos pesados, infraestruturas para manutenção, serviços, descanso, higiene e alimentação.

###### Art. 3º {#art3}
Tags: #documentacao #enquadramento #las #li #licenciamento-ambiental #lo #lp #patio-caminhao #prazo

**Art. 3º, caput** {#art3_cpt} O órgão ambiental competente, no exercício de sua competência de controle ambiental, expedirá os seguintes atos administrativos:
- **Art. 3º, caput, inciso I** {#art3_cpt_inc1} #prazo Autorização Ambiental - AA: ato administrativo discricionário pelo qual o órgão ambiental competente estabelece condições, restrições e medidas de controle ambiental empreendimentos ou atividades específicas, com prazo de validade estabelecido de acordo com a natureza do empreendimento ou atividade;
- **Art. 3º, caput, inciso II** {#art3_cpt_inc2} #documentacao Autorização Ambiental Florestal – AAF: documento expedido pelo órgão ambiental competente que permite ao proprietário de um imóvel a condição de efetuar o corte de vegetação florestal nativa, árvores isoladas em ambiente florestal ou agropecuário e aproveitamento material lenhoso seco;
- **Art. 3º, caput, inciso III** {#art3_cpt_inc3} #documentacao #enquadramento #las Licença Ambiental Simplificada - LAS - Aprova a localização e a concepção do empreendimento, atividade ou obra de pequeno porte e/ou que possua baixo potencial poluidor/degradador, atestando a viabilidade ambiental e estabelecendo os requisitos básicos e condicionantes a serem atendidos, bem como autoriza sua instalação e operação de acordo com as especificações constantes dos requerimentos, planos, programas e/ou projetos aprovados, incluindo as medidas de controle ambiental e demais condicionantes determinadas pelo órgão ambiental competente;
- **Art. 3º, caput, inciso IV** {#art3_cpt_inc4} #lp Licença Prévia - LP - Concedida na fase preliminar do planejamento do empreendimento ou atividade, aprovando sua localização e concepção, atestando a viabilidade ambiental e estabelecendo os requisitos básicos e condicionantes a serem atendidos nas próximas fases de sua implementação;
- **Art. 3º, caput, inciso V** {#art3_cpt_inc5} #li Licença de Instalação - LI - Autoriza a instalação do empreendimento ou atividade de acordo com as especificações constantes dos planos, programas e projetos aprovados, incluindo as medidas de controle ambiental e demais condicionantes;
- **Art. 3º, caput, inciso VI** {#art3_cpt_inc6} #lo Licença de Operação - LO - Autoriza o funcionamento da atividade ou empreendimento, após a verificação do efetivo cumprimento do que consta das licenças anteriores, com as medidas de controle ambientais e condicionantes determinados para a operação.

###### Art. 4º {#art4}
Tags: #enquadramento #licenciamento-ambiental #patio-caminhao

**Art. 4º, caput** {#art4_cpt} #enquadramento Para os efeitos desta Resolução, os empreendimentos denominados Pátio/Estacionamento de Caminhões serão licenciados de acordo com o porte, considerando a área destinada à estacionamento, movimentação e/ou manobra de veículos pesados, infraestruturas para manutenção, serviços, descanso, higiene e alimentação.

> **Pendência de transcrição — Art. 4, quadro/tabela** {#art4_tab1}. Conteúdo preservado na extração textual que acompanha o lote; falta conferência visual das colunas. Não é texto normativo transcrito.


###### Art. 5º {#art5}
Tags: #enquadramento #licenciamento-ambiental #patio-caminhao

**Art. 5º, caput** {#art5_cpt} #licenciamento-ambiental No caso do Pátio/Estacionamento de Caminhões estar vinculado à uma outra atividade, tais como: posto de combustível, industria, terminal de cargas, entre outros, o licenciamento ambiental da atividade principal deverá contemplar o pátio para estacionamento de caminhões no escopo da licença.

**Art. 5º, § 1º** {#art5_par1} #licenciamento-ambiental Para empreendimentos já licenciados e que venham a implantar pátio/ estacionamento de caminhões, deverá ser requerido licenciamento ambiental de ampliação.

**Art. 5º, § 2º** {#art5_par2} #enquadramento Nos casos previstos no §1.º que venham a implantar Pátio/Estacionamento de Caminhões, os estudos ambientais a serem apresentados são de acordo com o porte previstos na tabela constante do artigo [[#art4|4]].º.

###### Art. 6º {#art6}
Tags: #documentacao #enquadramento #las #licenciamento-ambiental #outorga #patio-caminhao #prazo #responsavel-tecnico

**Art. 6º, caput** {#art6_cpt} #documentacao #enquadramento #las Os requerimentos para LICENÇA AMBIENTAL SIMPLIFICADA – LAS, de empreendimentos de porte pequeno, deverão ser protocolados no SGA, instruídos na forma prevista abaixo:
- **Art. 6º, caput, inciso I** {#art6_cpt_inc1} #documentacao certidão do município ou documento equivalente, quando se tratar de empreendimento em perímetro urbano, declarando expressamente que o local e o tipo de empreendimento estão em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano, bem como atendem as demais exigências legais e administrativas perante o município (Anexo I);
- **Art. 6º, caput, inciso II** {#art6_cpt_inc2} #documentacao #prazo a Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente ou em nome do locador, junto com o contrato de locação, em caso de imóvel locado, atualizada em até 90 (noventa) dias contados da data de sua emissão e, em caso da matricula estar constando a área como rural, deve ser apresentado o CAR;
- **Art. 6º, caput, inciso III** {#art6_cpt_inc3} #documentacao documentação complementar do imóvel se a situação imobiliária estiver irregular conforme capitulo II, Seção V da [[resolucao-cema-105-2019|Resolução CEMA nº 105 de 17 de dezembro de 2019]] ou outras alterações que vierem;
- **Art. 6º, caput, inciso IV** {#art6_cpt_inc4} cópia do Ato Constitutivo ou do Contrato Social (com última alteração), quando pessoa jurídica;
- **Art. 6º, caput, inciso V** {#art6_cpt_inc5} #outorga número da Outorga de Direito ou Dispensa de Outorga de Uso de Recursos Hídricos, se for o caso;
- **Art. 6º, caput, inciso VI** {#art6_cpt_inc6} #responsavel-tecnico o Plano Básico de Controle Ambiental - PBCA, apresentado de acordo com o Termo de Referência do Anexo II, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
- **Art. 6º, caput, inciso VII** {#art6_cpt_inc7} #licenciamento-ambiental em caso de necessidade de supressão florestal, deve haver uma análise integrada do licenciamento e o requerente deverá:
  - **Art. 6º, caput, inciso VII, item 1** {#art6_cpt_inc7_ite1} Requerer a autorização de supressão de vegetação em paralelo a LAS, e;
  - **Art. 6º, caput, inciso VII, item 2** {#art6_cpt_inc7_ite2} Apresentar no SGA a AAF quando então será emitida a LAS, se for o caso;
- **Art. 6º, caput, inciso VIII** {#art6_cpt_inc8} #las publicação de súmula do pedido de Licença Ambiental Simplificada - LAS em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]]; e
- **Art. 6º, caput, inciso IX** {#art6_cpt_inc9} recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

###### Art. 7º {#art7}
Tags: #documentacao #las #licenciamento-ambiental #patio-caminhao #renovacao #residuo-solido #responsavel-tecnico

**Art. 7º, caput** {#art7_cpt} #documentacao #las #renovacao Os requerimentos para RENOVAÇÃO DA LICENÇA AMBIENTAL SIMPLIFICADA – LAS, deverão ser protocolados no SGA, instruídos na forma prevista abaixo:
- **Art. 7º, caput, inciso I** {#art7_cpt_inc1} relatório de atendimento das condicionantes da Licença anterior, se for o caso;
- **Art. 7º, caput, inciso II** {#art7_cpt_inc2} #residuo-solido #responsavel-tecnico o Plano de Gerenciamento de Resíduos Sólidos – PGRS atualizado e apresentado de acordo com o Termo de Referência do ANEXO V, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
- **Art. 7º, caput, inciso III** {#art7_cpt_inc3} #las publicação de súmula de concessão de Licença Ambiental Simplificada em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 7º, caput, inciso IV** {#art7_cpt_inc4} #las #renovacao publicação de súmula do pedido de Renovação de Licença Ambiental Simplificada em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 7º, caput, inciso V** {#art7_cpt_inc5} rrecolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

###### Art. 8º {#art8}
Tags: #definicao #enquadramento #licenciamento-ambiental #patio-caminhao

**Art. 8º, caput** {#art8_cpt} #enquadramento Os Pátios/Estacionamentos de Caminhões classificados como de porte médio, grande e excepcional, deverão requerer sucessivamente as Licenças Prévia, de Instalação e de Operação.

**Art. 8º, parágrafo único** {#art8_par1u} #definicao #enquadramento Este procedimento se aplica a novos empreendimentos e aqueles em operação que venham a sofrer ampliações acima do porte, alterações definitivas no processo e incorporação de novas atividades, com alteração das características do empreendimento já implantado.

###### Art. 9º {#art9}
Tags: #app #documentacao #eia-rima #enquadramento #licenciamento-ambiental #lp #outorga #patio-caminhao #prazo #responsavel-tecnico

**Art. 9º, caput** {#art9_cpt} #documentacao #lp Os requerimentos para LICENÇA PRÉVIA – LP, deverão ser realizados através do SGA, instruído na forma prevista abaixo:
- **Art. 9º, caput, inciso I** {#art9_cpt_inc1} #documentacao certidão do município ou documento equivalente, quando se tratar de empreendimento em perímetro urbano, declarando expressamente que o local e o tipo de empreendimento estão em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano, bem como atendem as demais exigências legais e administrativas perante o município (Anexo I);
- **Art. 9º, caput, inciso II** {#art9_cpt_inc2} #documentacao #prazo a Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente ou em nome do locador, junto com o contrato de locação, em caso de imóvel locado, atualizada em até 90 (noventa) dias contados da data de sua emissão e, em caso da matricula estar constando a área como rural, deve ser apresentado o CAR;
- **Art. 9º, caput, inciso III** {#art9_cpt_inc3} #documentacao documentação complementar do imóvel se a situação imobiliária estiver irregular conforme Capitulo II, Seção V da [[resolucao-cema-105-2019|Resolução CEMA nº 105 de 17 de dezembro de 2019]] ou outras alterações que vierem;
- **Art. 9º, caput, inciso IV** {#art9_cpt_inc4} cópia do Ato Constitutivo ou do Contrato Social (com última alteração), quando pessoa jurídica;
- **Art. 9º, caput, inciso V** {#art9_cpt_inc5} #outorga número da Outorga de Direito ou Dispensa de Outorga de Uso de Recursos Hídricos, se for o caso;
- **Art. 9º, caput, inciso VI** {#art9_cpt_inc6} croqui de localização do empreendimento com imagem aérea atualizada e contendo no mínimo:
  - **Art. 9º, caput, inciso VI, item 1** {#art9_cpt_inc6_ite1} Estruturas físicas existentes;
  - **Art. 9º, caput, inciso VI, item 2** {#art9_cpt_inc6_ite2} Distância dos corpos hídricos;
  - **Art. 9º, caput, inciso VI, item 3** {#art9_cpt_inc6_ite3} #app Áreas de preservação permanente;
  - **Art. 9º, caput, inciso VI, item 4** {#art9_cpt_inc6_ite4} Cobertura florestal;
  - **Art. 9º, caput, inciso VI, item 5** {#art9_cpt_inc6_ite5} Vias de acesso principais; e
  - **Art. 9º, caput, inciso VI, item 6** {#art9_cpt_inc6_ite6} Pontos de referências
- **Art. 9º, caput, inciso VII** {#art9_cpt_inc7} apresentação de:
  - **Art. 9º, caput, inciso VII, item 1** {#art9_cpt_inc7_ite1} #enquadramento #responsavel-tecnico RAP para empreendimento de grande porte, apresentado de acordo com Termo de Referência do Anexo IV, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
  - **Art. 9º, caput, inciso VII, item 2** {#art9_cpt_inc7_ite2} #documentacao #eia-rima #enquadramento #lp EIA para empreendimento de porte Excepcional, apresentado de acordo com Termo de Referência a ser fornecido pelo órgão ambiental quando do requerimento da Licença Prévia.
- **Art. 9º, caput, inciso VIII** {#art9_cpt_inc8} #licenciamento-ambiental em caso de necessidade de supressão florestal, deve haver uma análise integra do licenciamento e o requerente deverá:
  - **Art. 9º, caput, inciso VIII, item 1** {#art9_cpt_inc8_ite1} Requerer a autorização de supressão de vegetação em paralelo a LP, e;
  - **Art. 9º, caput, inciso VIII, item 2** {#art9_cpt_inc8_ite2} Apresentar no SGA a AAF quando então será emitida a LP, se for o caso;
- **Art. 9º, caput, inciso IX** {#art9_cpt_inc9} #lp publicação de súmula do pedido de Licença Prévia em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]]; e
- **Art. 9º, caput, inciso X** {#art9_cpt_inc10} recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

###### Art. 10 {#art10}
Tags: #documentacao #enquadramento #li #licenciamento-ambiental #lp #patio-caminhao #responsavel-tecnico

**Art. 10, caput** {#art10_cpt} #documentacao #li Os requerimentos para LICENÇA DE INSTALAÇÃO – LI, deverão ser realizados através do SGA, instruído na forma prevista abaixo:
- **Art. 10, caput, inciso I** {#art10_cpt_inc1} #lp cópia da Licença Prévia;
- **Art. 10, caput, inciso II** {#art10_cpt_inc2} relatório de atendimento das condicionantes da licença anterior;
- **Art. 10, caput, inciso III** {#art10_cpt_inc3} #enquadramento #responsavel-tecnico plano de Controle Ambiental - PCA, apresentado de acordo com Termo de Referência do Anexo III e, no caso de empreendimentos de porte grande e excepcional também o Plano Básico Ambiental - PBA, ambos elaborados por profissional (is) habilitado (s) acompanhado da respectiva ART;
- **Art. 10, caput, inciso IV** {#art10_cpt_inc4} #li publicação de súmula do pedido de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 10, caput, inciso V** {#art10_cpt_inc5} recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

###### Art. 11 {#art11}
Tags: #documentacao #li #licenciamento-ambiental #lo #outorga #patio-caminhao #residuo-solido #responsavel-tecnico

**Art. 11, caput** {#art11_cpt} #documentacao #lo Os requerimentos para LICENÇA DE OPERAÇÃO - LO, deverão ser realizados através do SGA, instruído na forma prevista abaixo:
- **Art. 11, caput, inciso I** {#art11_cpt_inc1} #li cópia da Licença de Instalação;
- **Art. 11, caput, inciso II** {#art11_cpt_inc2} relatório de atendimento das condicionantes da licença anterior;
- **Art. 11, caput, inciso III** {#art11_cpt_inc3} #outorga número da Outorga de Direito ou Dispensa de Outorga de Uso de Recursos Hídricos para utilização de recursos hídricos, se for o caso;
- **Art. 11, caput, inciso IV** {#art11_cpt_inc4} #residuo-solido #responsavel-tecnico o Plano de Gerenciamento de Resíduos Sólidos – PGRS, apresentado de acordo com Termo de Referência do Anexo V, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
- **Art. 11, caput, inciso V** {#art11_cpt_inc5} #responsavel-tecnico o Laudo de conclusão de obra, acompanhado de material fotográfico, elaborado por profissional com a devida anotação de responsabilidade técnica - ART;
- **Art. 11, caput, inciso VI** {#art11_cpt_inc6} #li publicação de súmula de concessão de Licença de Instalação em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 11, caput, inciso VII** {#art11_cpt_inc7} #lo publicação de súmula do pedido de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 11, caput, inciso VIII** {#art11_cpt_inc8} recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

###### Art. 12 {#art12}
Tags: #documentacao #licenciamento-ambiental #lo #patio-caminhao #renovacao #residuo-solido #responsavel-tecnico

**Art. 12, caput** {#art12_cpt} #documentacao #lo #renovacao Os requerimentos para RENOVAÇÃO DE LICENÇA DE OPERAÇÃO - RLO, deverão ser realizados através do SGA, instruído na forma prevista abaixo:
- **Art. 12, caput, inciso I** {#art12_cpt_inc1} cópia da Licença anterior;
- **Art. 12, caput, inciso II** {#art12_cpt_inc2} #responsavel-tecnico relatório de atendimento das condicionantes da licença anterior, elaborado por profissional com a devida anotação de responsabilidade técnica – ART;
- **Art. 12, caput, inciso III** {#art12_cpt_inc3} #residuo-solido #responsavel-tecnico o Plano de Gerenciamento de Resíduos Sólidos – PGRS atualizado, apresentado de acordo com Termo de Referência do Anexo V, acompanhado da Autorização Ambiental de destinação dos resíduos e, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
- **Art. 12, caput, inciso IV** {#art12_cpt_inc4} a Declaração de Carga Poluidora, de acordo com o previsto na [[portaria-iap-256-2013|Portaria IAP Nº 256/2013]], de 16 de Setembro de 2013, se for o caso;
- **Art. 12, caput, inciso V** {#art12_cpt_inc5} #lo publicação de súmula de concessão de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 12, caput, inciso VI** {#art12_cpt_inc6} #lo #renovacao publicação de súmula do pedido de Renovação de Licença de Operação em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]]; e
- **Art. 12, caput, inciso VII** {#art12_cpt_inc7} recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

###### Art. 13 {#art13}
Tags: #licenciamento-ambiental #patio-caminhao #prazo #renovacao

**Art. 13, caput** {#art13_cpt} #prazo #renovacao A RLO e a LO de ampliação poderão ser solicitadas de forma unificada quando o prazo de vencimento da LO em renovação for inferior a 01 (um) ano.

###### Art. 14 {#art14}
Tags: #enquadramento #las #licenciamento-ambiental #lo #patio-caminhao #prazo

**Art. 14, caput** {#art14_cpt} #las #licenciamento-ambiental #lo A regularização do licenciamento ambiental de empreendimentos já existentes e em operação, que não tenham se submetido ao licenciamento simplificado (LAS) ou ao licenciamento completo na modalidade (LP, LI e LO), deverão solicitar a Licença Ambiental Simplificada de Regularização (LASR) ou a Licença de Operação de Regularização (LOR).

**Art. 14, parágrafo único** {#art14_par1u} #enquadramento #prazo Os empreendimentos enquadrados no caput deste artigo terão um prazo de até 24 meses a contar da data de publicação da mesma, para requerer a regularização junto ao órgão ambiental.

###### Art. 15 {#art15}
Tags: #app #documentacao #las #licenciamento-ambiental #outorga #patio-caminhao #prazo #residuo-solido #responsavel-tecnico

**Art. 15, caput** {#art15_cpt} #documentacao #las Os requerimentos para LICENÇA AMBIENTAL SIMPLIFICADA DE REGULARIZAÇÃO – LASR, deverão ser realizados através do SGA, instruído na forma prevista abaixo:
- **Art. 15, caput, inciso I** {#art15_cpt_inc1} #documentacao certidão do município ou documento equivalente, quando se tratar de empreendimento em perímetro urbano, declarando expressamente que o local e o tipo de empreendimento estão em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano, bem como atendem as demais exigências legais e administrativas perante o município (Anexo I);
- **Art. 15, caput, inciso II** {#art15_cpt_inc2} #documentacao #prazo a Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente ou em nome do locador, junto com o contrato de locação, em caso de imóvel locado, atualizada em até 90 (noventa) dias contados da data de sua emissão e, em caso da matricula estar constando a área como rural, deve ser apresentado o CAR;
- **Art. 15, caput, inciso III** {#art15_cpt_inc3} #documentacao documentação complementar do imóvel se a situação imobiliária estiver irregular conforme Capitulo II, Seção V da [[resolucao-cema-105-2019|Resolução CEMA nº 105 de 17 de dezembro de 2019]] ou outras alterações que vierem;
- **Art. 15, caput, inciso IV** {#art15_cpt_inc4} cópia do Ato Constitutivo ou do Contrato Social (com última alteração), quando pessoa jurídica;
- **Art. 15, caput, inciso V** {#art15_cpt_inc5} #outorga número da Outorga de Direito ou Dispensa de Outorga de Uso de Recursos Hídricos, se for o caso;
- **Art. 15, caput, inciso VI** {#art15_cpt_inc6} croqui de localização do empreendimento com imagem aérea atualizada e contendo no mínimo:
  - **Art. 15, caput, inciso VI, item 1** {#art15_cpt_inc6_ite1} estruturas físicas existentes;
  - **Art. 15, caput, inciso VI, item 2** {#art15_cpt_inc6_ite2} distância dos corpos hídricos;
  - **Art. 15, caput, inciso VI, item 3** {#art15_cpt_inc6_ite3} #app áreas de preservação permanente;
  - **Art. 15, caput, inciso VI, item 4** {#art15_cpt_inc6_ite4} cobertura florestal;
  - **Art. 15, caput, inciso VI, item 5** {#art15_cpt_inc6_ite5} vias de acesso principais; e
  - **Art. 15, caput, inciso VI, item 6** {#art15_cpt_inc6_ite6} pontos de referências.
- **Art. 15, caput, inciso VII** {#art15_cpt_inc7} #responsavel-tecnico o Plano Básico de Controle Ambiental, apresentado de acordo com o Termo de Referência do Anexo II, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
- **Art. 15, caput, inciso VIII** {#art15_cpt_inc8} #residuo-solido #responsavel-tecnico o Plano de Gerenciamento de Resíduos Sólidos – PGRS, apresentado de acordo com Termo de Referência do Anexo V, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
- **Art. 15, caput, inciso IX** {#art15_cpt_inc9} #las publicação de súmula do pedido de Licença Ambiental Simplificada de Regularização – LARS, em jornal de circulação regional e no Diário Oficial do Estado, ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]];
- **Art. 15, caput, inciso X** {#art15_cpt_inc10} e recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

###### Art. 16 {#art16}
Tags: #app #documentacao #licenciamento-ambiental #lo #outorga #patio-caminhao #prazo #residuo-solido #responsavel-tecnico

**Art. 16, caput** {#art16_cpt} #documentacao #lo Os requerimentos para LICENÇA DE OPERAÇÃO DE REGULARIZAÇÃO - LOR, deverão ser protocolados no SGA, instruídos na forma prevista abaixo.
- **Art. 16, caput, inciso I** {#art16_cpt_inc1} #documentacao certidão do município ou documento equivalente, quando se tratar de empreendimento em perímetro urbano, declarando expressamente que o local e o tipo de empreendimento estão em conformidade com a legislação do Plano Diretor Municipal e/ou Lei de Uso e Ocupação do Solo Urbano, bem como atendem as demais exigências legais e administrativas perante o município (Anexo I);
- **Art. 16, caput, inciso II** {#art16_cpt_inc2} #documentacao #prazo a Matrícula ou Transcrição do Cartório de Registro de Imóveis em nome do requerente ou em nome do locador, junto com o contrato de locação, em caso de imóvel locado, atualizada em até 90 (noventa) dias contados da data de sua emissão e, em caso da matricula estar constando a área como rural, deve ser apresentado o CAR;
- **Art. 16, caput, inciso III** {#art16_cpt_inc3} #documentacao documentação complementar do imóvel se a situação imobiliária estiver irregular conforme Capitulo II, Seção V da [[resolucao-cema-105-2019|Resolução CEMA nº 105 de 17 de dezembro de 2019]] ou outras alterações que vierem;
- **Art. 16, caput, inciso IV** {#art16_cpt_inc4} cópia do Ato Constitutivo ou do Contrato Social (com última alteração), quando pessoa jurídica;
- **Art. 16, caput, inciso V** {#art16_cpt_inc5} #outorga número da Outorga de Direito ou Dispensa de Outorga de Uso de Recursos Hídricos, se for o caso;
- **Art. 16, caput, inciso VI** {#art16_cpt_inc6} croqui de localização do empreendimento com imagem aérea atualizada e contendo no mínimo:
  - **Art. 16, caput, inciso VI, item 1** {#art16_cpt_inc6_ite1} estruturas físicas existentes;
  - **Art. 16, caput, inciso VI, item 2** {#art16_cpt_inc6_ite2} distância dos corpos hídricos;
  - **Art. 16, caput, inciso VI, item 3** {#art16_cpt_inc6_ite3} #app áreas de preservação permanente;
  - **Art. 16, caput, inciso VI, item 4** {#art16_cpt_inc6_ite4} cobertura florestal;
  - **Art. 16, caput, inciso VI, item 5** {#art16_cpt_inc6_ite5} vias de acesso principais; e
  - **Art. 16, caput, inciso VI, item 6** {#art16_cpt_inc6_ite6} pontos de referências.
- **Art. 16, caput, inciso VII** {#art16_cpt_inc7} #responsavel-tecnico o Plano de Controle Ambiental - PCA, apresentado de acordo com Termo de Referência do Anexo III, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
- **Art. 16, caput, inciso VIII** {#art16_cpt_inc8} #residuo-solido #responsavel-tecnico o Plano de Gerenciamento de Resíduos Sólidos – PGRS, apresentado de acordo com Termo de Referência do Anexo V, elaborado por profissional (is) habilitado (s) acompanhado da respectiva ART;
- **Art. 16, caput, inciso IX** {#art16_cpt_inc9} #lo publicação de súmula do pedido de Licença de Operação de Regularização - LOR em jornal de circulação regional e no Diário Oficial do Estado ou no site do órgão ambiental competente, conforme modelo aprovado pela [[resolucao-conama-6-1986|Resolução CONAMA nº 006/86]]; e
- **Art. 16, caput, inciso X** {#art16_cpt_inc10} recolhimento da taxa ambiental e, em caso de optar pela publicação no site do órgão ambiental, demais valores cabíveis referentes às publicações.

###### Art. 17 {#art17}
Tags: #definicao #documentacao #enquadramento #licenciamento-ambiental #patio-caminhao #prazo

**Art. 17, caput** {#art17_cpt} #licenciamento-ambiental Na análise dos procedimentos de licenciamento ambiental contemplados na presente Resolução, o órgão ambiental competente solicitará manifestação aos seguintes órgãos, quando aplicável:
- **Art. 17, caput, inciso I** {#art17_cpt_inc1} a Curadoria do Patrimônio Histórico e Artístico da Secretaria de Estado da Comunicação Social e da Cultura, e do Instituto do Patrimônio Histórico e Artístico Nacional, no caso de atividades e empreendimentos em área tombada ou em processo de tombamento, conforme normativas especificas destes;
- **Art. 17, caput, inciso II** {#art17_cpt_inc2} #definicao manifestação do Instituto do Patrimônio Histórico e Artístico Nacional - IPHAN, conforme estabelecido na Instrução Normativa IPHAN nº 001, de 25 de março de 2015, observando as definições estabelecidas nos Anexos I e II da mesma;
- **Art. 17, caput, inciso III** {#art17_cpt_inc3} a Coordenação da Região Metropolitana de Curitiba-COMEC, no caso de atividades e empreendimentos localizados em área de manancial na Região Metropolitana de Curitiba, conforme [[lei-estadual-12248-1998|Lei Estadual nº. 12.248/1998]] e alterações posteriores, bem como [[decreto-estadual-6390-2006|Decreto Estadual nº 6.390/2006]] e 4435/2016, e alterações posteriores;
- **Art. 17, caput, inciso IV** {#art17_cpt_inc4} nas demais regiões metropolitanas, a manifestação somente deverá ser exigida quando as Coordenações estiverem em funcionamento e com procedimentos regulamentados;
- **Art. 17, caput, inciso V** {#art17_cpt_inc5} autoridade portuária, quando localizada dentro da área do porto organizado;
- **Art. 17, caput, inciso VI** {#art17_cpt_inc6} manifestação do ICMBio quando o empreendimento se situar no interior ou na zona de amortecimento de Unidade de Conservação Federal, de acordo com o estabelecido na [[resolucao-conama-428-2010|Resolução CONAMA nº 428, de 17 de dezembro de 2010]], e alterações posteriores, bem como, a manifestação do Município quando o empreendimento se situar no interior ou na zona de amortecimento de Unidade de Conservação Municipal;
- **Art. 17, caput, inciso VII** {#art17_cpt_inc7} manifestação da FUNAI, com relação a possível impacto em comunidade indígena;
- **Art. 17, caput, inciso VIII** {#art17_cpt_inc8} #enquadramento manifestação Departamento de Estradas de Rodagem - DER ou Departamento Nacional de Infraestrutura de Transportes - DNIT ou concessionária de rodovias, para empreendimentos marginais às rodovias ou situados a menos de cem metros do eixo de rodovia estadual, tendo em vista questões de acesso e vias marginais e, se for o caso, manifestação do órgão correspondente para empreendimentos a serem implantados nas áreas de amortecimento das linhas férreas.

**Art. 17, § 1º** {#art17_par1} #documentacao #prazo ºA manifestação dos entes públicos citados neste artigo, seja através da anuência, parecer ou documento similar, deverá ser apresentada no prazo de 30 (trinta) dias da ciência do órgão correspondente, podendo ser prorrogado, desde que devidamente justificado, por mais 30 (trinta dias).

**Art. 17, § 2º** {#art17_par2} #licenciamento-ambiental #prazo Vencido o prazo estabelecido no parágrafo primeiro, o órgão ambiental dará continuidade no licenciamento, tendo em vista que a ausência de manifestação, implica em que nada obsta sobre a atividade ou empreendimento a ser licenciado.

**Art. 17, § 3º** {#art17_par3} #licenciamento-ambiental Quando o empreendimento se situar no interior ou na zona de amortecimento de Unidade de Conservação Estadual, o procedimento de licenciamento deverá ser remetido a Diretoria competente do órgão ambiental, para manifestação.

###### Art. 18 {#art18}
Tags: #licenciamento-ambiental #patio-caminhao #prazo

**Art. 18, caput** {#art18_cpt} #licenciamento-ambiental #prazo Constatada a existência de pendência judicial envolvendo o empreendedor, o empreendimento ou o imóvel, a decisão administrativa sobre a eventual suspensão do licenciamento será precedida de manifestação jurídica do órgão ambiental competente no prazo máximo de 30 (trinta) dias.

###### Art. 19 {#art19}
Tags: #documentacao #las #li #licenciamento-ambiental #lo #lp #patio-caminhao #prazo #renovacao

**Art. 19, caput** {#art19_cpt} #documentacao #prazo O órgão ambiental competente estabelecerá os prazos de validade para cada tipo de licença e autorização ambiental, especificando-os no respectivo documento, levando em consideração os seguintes aspectos:
- **Art. 19, caput, inciso I** {#art19_cpt_inc1} #las #prazo #renovacao o prazo de validade da Licença Ambiental Simplificada - LAS será de até 10 (dez) anos, podendo ser renovada a critério técnico do órgão ambiental competente;
- **Art. 19, caput, inciso II** {#art19_cpt_inc2} #lp #prazo o prazo de validade da Licença Prévia - LP será de 05 (cinco) anos, não prorrogável se concedido o prazo máximo;
- **Art. 19, caput, inciso III** {#art19_cpt_inc3} #li #prazo o prazo de validade da Licença de Instalação - LI será de até 06 (seis) anos, não prorrogável se concedido o prazo máximo;
- **Art. 19, caput, inciso IV** {#art19_cpt_inc4} #lo #prazo o prazo de validade da Licença de Operação - LO será de no mínimo 4 anos e no máximo 10 (dez) anos, renovável a critério do Órgão Licenciador.

###### Art. 20 {#art20}
Tags: #app #licenciamento-ambiental #patio-caminhao

**Art. 20, caput** {#art20_cpt} A implantação de Pátios/Estacionamentos de Caminhões quanto à localização, deverá atender, no mínimo, os seguintes critérios:
- **Art. 20, caput, inciso I** {#art20_cpt_inc1} estar em conformidade com as diretrizes de zoneamento do município;
- **Art. 20, caput, inciso II** {#art20_cpt_inc2} #app a área do empreendimento, deve situar-se a uma distância mínima de corpos hídricos, de modo a não atingir áreas de preservação permanente, conforme estabelecido no Código Florestal.

###### Art. 21 {#art21}
Tags: #efluente #licenciamento-ambiental #patio-caminhao

**Art. 21, caput** {#art21_cpt} #efluente Os Pátios/Estacionamentos de Caminhões deverão ser impermeabilizados com a finalidade de captar, conter e destinar de águas pluviais e outro efluentes incidentes na área.

###### Art. 22 {#art22}
Tags: #efluente #licenciamento-ambiental #outorga #patio-caminhao #proibicao

**Art. 22, caput** {#art22_cpt} #efluente Os efluentes líquidos gerados poderão ser lançados, direta ou indiretamente no corpo recepto desde que obedeçam às condições e padrões estabelecidos na sequência, resguardadas outras exigências cabíveis:
- **Art. 22, caput, inciso I** {#art22_cpt_inc1} pH entre 5 e 9;
- **Art. 22, caput, inciso II** {#art22_cpt_inc2} temperatura inferior à 40ºC, sendo que a elevação máxima de temperatura do corpo receptor não poderá ultrapassar 3ºC;
- **Art. 22, caput, inciso III** {#art22_cpt_inc3} materiais sedimentáveis até 1mL/L em teste de 1 hora em Cone Imhoff;
- **Art. 22, caput, inciso IV** {#art22_cpt_inc4} óleos e graxas: óleos minerais até 20 mg/L e óleos vegetais e gorduras animais até 50 mg/L;
- **Art. 22, caput, inciso V** {#art22_cpt_inc5} ausência de materiais flutuantes;
- **Art. 22, caput, inciso VI** {#art22_cpt_inc6} #outorga DBO (Demanda Bioquímica de Oxigênio) deverá ser OUTORGADA;
- **Art. 22, caput, inciso VII** {#art22_cpt_inc7} #outorga DQO (Demanda Química de Oxigênio) deverá ser OUTORGADA.

**Art. 22, § 1º** {#art22_par1} #efluente #proibicao Fica proibida a infiltração direta no solo de efluentes provenientes da área de lavagem e manutenção de veículos e do setor de abastecimento, mesmo que tratados.

**Art. 22, § 2º** {#art22_par2} #efluente #proibicao Fica proibido o lançamento de efluentes líquidos, direta ou indiretamente, em corpos hídricos superficiais utilizados ou potencialmente identificados como mananciais de abastecimento público.

###### Art. 23 {#art23}
Tags: #efluente #licenciamento-ambiental #patio-caminhao

**Art. 23, caput** {#art23_cpt} #efluente No caso de lançamento de efluentes na galeria de águas pluviais, o interessado deverá apresentar a anuência da prefeitura.

###### Art. 24 {#art24}
Tags: #definicao #enquadramento #licenciamento-ambiental #patio-caminhao

**Art. 24, caput** {#art24_cpt} #definicao #enquadramento #licenciamento-ambiental Os casos omissos quanto ao licenciamento de Pátios/Estacionamentos de Caminhões, quanto ao porte e potencial poluidor serão definidos pelo órgão ambiental.

###### Art. 25 {#art25}
Tags: #documentacao #licenciamento-ambiental #patio-caminhao

**Art. 25, caput** {#art25_cpt} #documentacao #licenciamento-ambiental Caso haja necessidade, o órgão ambiental competente solicitará, a qualquer momento, outros documentos e/ou informações complementares do requerente ou de outras instituições envolvidas no licenciamento ambiental em questão, assim como, anotação ou registro de responsabilidade técnica pela implantação e conclusão de eventuais estudos ambientais.

###### Art. 26 {#art26}
Tags: #licenciamento-ambiental #patio-caminhao #responsavel-tecnico

**Art. 26, caput** {#art26_cpt} #responsavel-tecnico O descumprimento das disposições desta Resolução, dos termos das Licenças Ambientais sujeitará o infrator às penalidades previstas na [[lei-federal-9605-1998|Lei nº 9.605, de 12 de fevereiro de 1998]], e em outros dispositivos normativos pertinentes, sem prejuízo do dever de recuperar os danos ambientais causados, na forma do Art. 225, §3º, da Constituição Federal, e do Art. 14, § 1°, da Lei Federal n. 6.938, de 1981.

###### Art. 27 {#art27}
Tags: #licenciamento-ambiental #patio-caminhao

**Art. 27, caput** {#art27_cpt} O órgão ambiental competente poderá complementar os critérios estabelecidos na presente Resolução de acordo com o desenvolvimento científico e tecnológico e a necessidade de preservação ambiental.

###### Art. 28 {#art28}
Tags: #licenciamento-ambiental #patio-caminhao #prazo

**Art. 28, caput** {#art28_cpt} #prazo A cada 4 (quatro) anos, ou sempre que necessário, será revisada a presente Resolução.

###### Art. 29 {#art29}
Tags: #licenciamento-ambiental #patio-caminhao

**Art. 29, caput** {#art29_cpt} Essa Resolução entra em vigor na data de sua publicação. Márcio Nunes Secretário de Estado do Turismo Este texto não substitui o publicado no Diário Oficial do Estado ANEXOS: Arquivo                                                    Observações anexo234356_54098.pdf

### Certidão municipal {#anexo1}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência — Plano Básico de Controle Ambiental - PBCA {#anexo2}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência — Plano de Controle Ambiental - PCA {#anexo3}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência — Relatório Ambiental Preliminar - RAP {#anexo4}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência — Plano de Gerenciamento de Resíduos Sólidos - PGRS {#anexo5}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|
| [[resolucao-sedest-39-2024]] | Norma inteira | Revogação expressa registrada no acervo. |

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (sedest 32 2020(1).pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- A extração do SIA apresenta artigos sem a palavra Art.; os números sequenciais foram tratados como artigos. Na SEDEST 16/2020 o marcador 6º aparece repetido e foi reduzido a um único rótulo, sem alteração do conteúdo do dispositivo.
- Anexo próprio citado ou vinculado em arquivo separado, sem o respectivo conteúdo no PDF do lote. Não foi importado material externo ou presumida sua redação.
- Quadros no corpo devem ser conferidos visualmente; números, colunas e células mescladas ainda não estão certificados. Não utilizar este rascunho para enquadramento antes da revisão.
- Situação revogada conforme relação expressa já cadastrada no acervo: [[resolucao-sedest-39-2024]]. Regras de transição e processos antigos devem ser avaliados separadamente.
