---
norma: "Portaria IAT nº 170/2020"
arquivo: portaria-iat-170-2020
tipo: portaria
esfera: estadual
uf: PR
numero: 170
ano: 2020
data_assinatura: 2020-06-01
ementa: "Estabelece procedimentos para elaboração, análise, aprovação e acompanhamento da execução de Projeto de Recuperação de Áreas Degradadas ou Alteradas - PRAD."
situacao: vigente
regulamenta: []
regulamentado_por: []
altera: []
alterado_por: []
revoga: []
revogado_por: []
cita: ["[[decreto-estadual-11515-2018]]", "[[decreto-estadual-3813-2020]]", "[[decreto-estadual-3820-2020]]", "[[decreto-estadual-4696-2016]]", "[[decreto-federal-8235-2014]]", "[[lei-estadual-10066-1992]]", "[[lei-estadual-18295-2014]]", "[[lei-estadual-20070-2019]]", "[[lei-federal-12651-2012]]", "[[lei-federal-18295-2014]]"]
tags: ["app", "definicao", "documentacao", "enquadramento", "licenciamento-ambiental", "monitoramento", "prad", "prazo", "recuperacao-ambiental", "responsavel-tecnico"]
fonte: "PDF fornecido: portaria IAT 170 2020.pdf"
revisao: "pendente; não incorporar ao acervo antes da revisão"
---

# Portaria IAT nº 170/2020

> Estabelece procedimentos para elaboração, análise, aprovação e acompanhamento da execução de Projeto de Recuperação de Áreas Degradadas ou Alteradas - PRAD.

## Preâmbulo

PORTARIA Nº 170, DE 01 DE JUNHO DE 2020 Estabelece procedimentos para elaboração, análise, aprovação e acompanhamento da execução de Projeto de Recuperação de Áreas Degradadas ou Alteradas - PRAD. O Diretor Presidente do Instituto Água e Terra, nomeado pelo [[decreto-estadual-3820-2020|Decreto Estadual nº 3.820, de 10 de janeiro de 2020]], no uso de suas atribuições que lhe são conferidas pela [[lei-estadual-10066-1992|Lei Estadual nº 10.066, de 27 de julho 1992]], [[lei-estadual-20070-2019|Lei Estadual nº 20.070, de 18 de dezembro de 2019]], [[decreto-estadual-3813-2020|Decreto Estadual nº 3.813, de 09 de janeiro de 2020]] e [[decreto-estadual-4696-2016|Decreto Estadual nº 4.696 de 27 de julho de 2016]] e

CONSIDERANDO -A [[lei-federal-12651-2012|Lei Federal n.º 12.651, de 25 de maio de 2012]], que dispõe sobre a proteção da vegetação nativa, instituindo o novo código florestal, e delimitações de Áreas de Preservação Permanente e Reserva Legal; -O inciso II do Art.16 [[decreto-federal-8235-2014|Decreto Federal n.º 8.235, de 05 de maio de 2014]], que estabelece normas gerais complementares aos Programas de Regularização Ambiental dos Estados; -A [[lei-estadual-18295-2014|Lei Estadual n.º 18.295, de 10 de novembro de 2014]], que institui o Programa de Regularização Ambiental no Estado do Paraná e em seu art. 1°,§ 1°, inciso III dispõe o PRAD como instrumento do Programa; -O [[decreto-estadual-11515-2018|Decreto Estadual n.º 11.515, de 29 de outubro de 2018]], que regulamenta a [[lei-federal-18295-2014|Lei nº 18.295, de 10 de novembro de 2014]], que dispõe sobre as formas, prazos e procedimentos para a regularização ambiental das propriedades rurais no Estado do Paraná; -A necessidade de padronização do Termo de Referência que norteará os Projetos de Recuperação de Áreas Degradadas ou Alteradas-PRAD e PRAD Simplificados a serem protocolados no órgão ambiental; -A importância da recuperação para a conservação e proteção ecológica dos ecossistemas naturais, especialmente nas Áreas de Preservação Permanente e Reservas Legais e demais espaços protegidos; -A necessidade de estabelecer parâmetros e proporções para a restauração florestal a serem utilizados em execução e análise dos projetos bem como a necessidade de definição de parâmetros e procedimentos para o monitoramento; -Que compete ao Instituto Água e Terra estabelecer diretrizes para promoção da restauração da vegetação nativa no estado do Paraná; -Que o Art. 3º da [[lei-federal-12651-2012|Lei Federal nº 12.651/2012]] considera de interesse social “as atividades de proteção à integridade da vegetação nativa, tais como prevenção, combate e controle do fogo, controle da erosão, erradicação de invasoras e proteção de plantios com espécies nativas”; -Que a Resolução Conjunta SEDEST/ IAP nº 10/2019 que considera que a soltura de animais silvestres, quando realizada em áreas de restauração ecológica pode ser uma importante ferramenta na recomposição e equilíbrio destas áreas, mediante as interações flora versus fauna que garantam as funções ou processos dos ecossistemas naturais; -Que a verificação de cumprimento dos compromissos de restauração deve ser realizada sobre os resultados atingidos e não sobre a execução das técnicas e metodologias planejadas. -Considerando erros formais existentes na Portaria IAT nº 170, de 01 de junho de 2020, publicada no DIOE nº 10.701, de 04 de junho de 2020, republica-se a presente Portaria Instituto Água e Terra nº 170/2020. RESOLVE:

###### Art. 1º {#art1}
Tags: #monitoramento #prad #recuperacao-ambiental

**Art. 1º, caput** {#art1_cpt} #monitoramento Estabelecer procedimentos para elaboração, análise, aprovação e acompanhamento da execução de Projeto de Recuperação de Área Degradada ou Alterada -PRAD, e seus de Termos de Referência-TR.

### CAPÍTULO I – DISPOSIÇÕES GERAIS

###### Art. 2º {#art2}
Tags: #definicao #monitoramento #prad #recuperacao-ambiental #responsavel-tecnico

**Art. 2º, caput** {#art2_cpt} #definicao Considera-se para efeitos desta Portaria:
- **Art. 2º, caput, inciso I** {#art2_cpt_inc1} Área degradada: aquela impossibilitada de retornar por uma trajetória natural a um ecossistema que se assemelhe ao estado inicial, dificilmente sendo restaurada, apenas recuperada;
- **Art. 2º, caput, inciso II** {#art2_cpt_inc2} Área perturbada/alterada: aquela que após o impacto ainda mantém capacidade de regeneração natural e pode ser restaurada;
- **Art. 2º, caput, inciso III** {#art2_cpt_inc3} Chave de tomada de decisão: processo que orienta a escolha de métodos destinados a restauração ecológica de áreas degradadas, com base no diagnóstico ambiental prévio;
- **Art. 2º, caput, inciso IV** {#art2_cpt_inc4} Condução da regeneração de espécies nativas: técnicas que auxiliam a colonização e o desenvolvimento dos indivíduos vegetais nativos presentes na área, inclusive por meio do isolamento de acesso a área, coroamento das mudas, controle de espécies exóticas e invasoras, adubação e controle sanitário;
- **Art. 2º, caput, inciso V** {#art2_cpt_inc5} Espécie ameaçada de extinção: aquela constante nas listas oficiais de espécies em perigo de extinção, sendo sua sobrevivência incerta caso os fatores que causam essa ameaça continuem atuando;
- **Art. 2º, caput, inciso VI** {#art2_cpt_inc6} Espécie exótica invasora: aquela que, uma vez introduzida a partir de outros ambientes, adapta-se e passa a se reproduzir a ponto de ocupar o espaço de espécies nativas e produzir alterações nos processos ecológicos naturais, tendendo a se tornar dominante após um período de tempo cuja introdução ou dispersão ameace ecossistema, habitat ou espécies e cause impactos negativos ambientais, econômicos, sociais ou culturais;
- **Art. 2º, caput, inciso VII** {#art2_cpt_inc7} Espécie exótica: espécie que não é nativa daquele ambiente, mas que foi introduzida pela ação humana e se adaptou ao novo ambiente;
- **Art. 2º, caput, inciso VIII** {#art2_cpt_inc8} Espécie nativa: espécie de ocorrência no território brasileiro, que apresenta suas populações naturais dentro dos limites de sua distribuição geográfica, participando de ecossistemas onde apresenta seus níveis de interação e controles demográficos;
- **Art. 2º, caput, inciso IX** {#art2_cpt_inc9} Indicadores ecológicos: parâmetros que podem servir como medida da condição ambiental de uma determinada área;
- **Art. 2º, caput, inciso X** {#art2_cpt_inc10} Isolamento da área: restrição de acesso e paralisação de quaisquer atividades antrópicas que possam impactar negativamente a qualidade e o desenvolvimento da regeneração natural em uma área degradada;
- **Art. 2º, caput, inciso XI** {#art2_cpt_inc11} #responsavel-tecnico Pequena propriedade rural ou posse rural familiar: aquela explorada mediante o trabalho pessoal do agricultor familiar e empreendedor familiar rural, incluindo os assentamentos e projetos de reforma agrária, e que atenda ao disposto no art. 3°, inciso V, da Lei Federal nº 12.651, de 25 de maio de2012;
- **Art. 2º, caput, inciso XII** {#art2_cpt_inc12} Plantio de espécies nativas: técnicas que introduzam novos indivíduos vegetais nativos na área, por meio de plantio de mudas, ramos, sementes, raízes ou quaisquer tipos de propágulos;
- **Art. 2º, caput, inciso XIII** {#art2_cpt_inc13} #monitoramento Projeto de Recuperação de Áreas Degradadas ou Alteradas-PRAD: instrumento de planejamento das ações necessárias visando à recuperação da vegetação nativa, o qual deve apresentar o diagnóstico ambiental da área degradada ou alterada, os métodos e técnicas a serem utilizados e prever cronograma de implantação e monitoramento das ações;
- **Art. 2º, caput, inciso XIV** {#art2_cpt_inc14} Recuperação de área degradada: atividade intencional, que inicia ou acelera a recuperação de um ecossistema com relação à sua saúde, integridade e sustentabilidade, que pode ou não ser diferente de sua condição original;
- **Art. 2º, caput, inciso XV** {#art2_cpt_inc15} Restauração: restituição de um ecossistema ou de uma população silvestre degradada o mais próximo possível da sua condição original;
- **Art. 2º, caput, inciso XVI** {#art2_cpt_inc16} Restauração ecológica: ação intencional em ecossistemas degradados ou alterados com a finalidade de restabelecer atributos de estrutura e função de um dado ecossistema, incrementando sua biodiversidade;
- **Art. 2º, caput, inciso XVII** {#art2_cpt_inc17} #responsavel-tecnico Restaurador: pessoa responsável pelo Projeto de Restauração Ecológica, podendo ser o proprietário ou possuidor do imóvel, seu representante legal ou terceiro autorizado pelo proprietário ou possuidor, incluindo o responsável técnico devidamente habilitado;
- **Art. 2º, caput, inciso XVIII** {#art2_cpt_inc18} Vegetação nativa: comunidade de plantas em seu ecossistema de origem, dotada de características próprias e adaptadas ao meio e às interações ecológicas ali presentes.

###### Art. 3º {#art3}
Tags: #app #licenciamento-ambiental #prad #recuperacao-ambiental

**Art. 3º, caput** {#art3_cpt} Esta Portaria aplica-se a todos os PRAD no Estado do Paraná, provenientes de demandas não voluntárias, cujo cumprimento integral será exigido para:
- **Art. 3º, caput, inciso I** {#art3_cpt_inc1} Recuperação/restauração de áreas oriundas de danos ambientais que foram objeto de autuações administrativas de desmatamentos, queimadas e outras infrações administrativas que necessitem da reparação do dano ambiental;
- **Art. 3º, caput, inciso II** {#art3_cpt_inc2} #app Recuperação/restauração de Reserva Legal, Áreas de Uso Restrito e de Áreas de Preservação Permanente do Programa de Regularização Ambiental - PRA executados por proprietários e/ou possuidores rurais previstos na [[lei-federal-12651-2012|Lei Federal nº 12.651, de 25 de maio de 2012]] e na [[lei-estadual-18295-2014|Lei Estadual nº 18.295 de 10 de novembro de 2014]];
- **Art. 3º, caput, inciso III** {#art3_cpt_inc3} #licenciamento-ambiental Cumprimento de condicionantes em processos de licenciamento ambiental e autorizações ambientais para a supressão de vegetação nativa;
- **Art. 3º, caput, inciso IV** {#art3_cpt_inc4} Atendimento de Termo de Ajustamento Conduta - TAC ou Termo de Compromisso- TC;
- **Art. 3º, caput, inciso V** {#art3_cpt_inc5} Atendimento a demandas judiciais – ação civil pública, ações criminais, entre outras que o órgão for chamado a se manifestar;
- **Art. 3º, caput, inciso VI** {#art3_cpt_inc6} #app Projetos de Substituição de Florestas Homogêneas com Espécies Exóticas por Florestas Heterogêneas com Espécies Nativas em Áreas de Preservação Permanente;
- **Art. 3º, caput, inciso VII** {#art3_cpt_inc7} Projetos financiados com recursos públicos e submetidos à aprovação do órgão ambiental estadual.

###### Art. 4º {#art4}
Tags: #monitoramento #prad #recuperacao-ambiental

**Art. 4º, caput** {#art4_cpt} São instrumentos desta Portaria:
- **Art. 4º, caput, inciso I** {#art4_cpt_inc1} Cadastro Ambiental Rural - CAR, que deverá ser feito no site oficial utilizado pela União para cadastramento de áreas rurais, onde serão fornecidas todas as informações de uso do solo do imóvel, de acordo com as normas vigentes;
- **Art. 4º, caput, inciso II** {#art4_cpt_inc2} Termo de Compromisso - TC, mecanismo de adesão ao Programa de Regularização Ambiental, título executivo que descreve as medidas a serem tomadas pelo produtor para a adequação do imóvel rural às exigências do Capítulo XIII da Lei Federal nº 12.651, de 2012, prevendo sanções em caso de descumprimento;
- **Art. 4º, caput, inciso III** {#art4_cpt_inc3} Programa de Regularização Ambiental - PRA;
- **Art. 4º, caput, inciso IV** {#art4_cpt_inc4} Sistema de Gestão Ambiental - SGA;
- **Art. 4º, caput, inciso V** {#art4_cpt_inc5} Termo de Referência - TR (Anexo I);
- **Art. 4º, caput, inciso VI** {#art4_cpt_inc6} Termo de Referência Simplificado - TRS (Anexo II);
- **Art. 4º, caput, inciso VII** {#art4_cpt_inc7} #monitoramento Indicadores de Monitoramento (Anexo III);
- **Art. 4º, caput, inciso VIII** {#art4_cpt_inc8} Chave de Tomada de Decisão (Anexo IV), a qual poderá ser utilizada para auxiliar o diagnóstico inicial da área;

### CAPÍTULO II – DA ELABORAÇÃO DO PRAD

###### Art. 5º {#art5}
Tags: #definicao #prad #recuperacao-ambiental #responsavel-tecnico

**Art. 5º, caput** {#art5_cpt} #definicao O PRAD deverá definir as medidas necessárias à recuperação ou restauração da área perturbada ou degradada, fundamentado nas características bióticas e abióticas da área e em conhecimentos secundários sobre o tipo de impacto causado, a resiliência da vegetação e a sucessão secundária.

**Art. 5º, § 1º** {#art5_par1} Em se tratando de propriedade ou posse rural menor ou igual a 4 (quatro) módulos fiscais com o objetivo de adequá-las aos termos do Capítulo XIII da [[lei-federal-12651-2012|Lei Federal nº 12.651/2012]], poderá ser apresentado PRAD Simplificado, conforme Anexo II desta Portaria.

**Art. 5º, § 2º** {#art5_par2} #responsavel-tecnico Os TR constantes nos Anexos I e II estabelecem diretrizes e orientações técnicas voltadas à apresentação de PRAD e PRAD Simplificado. A elaboração do PRAD será atribuição do responsável técnico pela recuperação/restauração.

**Art. 5º, § 3º** {#art5_par3} O disposto no parágrafo anterior também se aplica aos imóveis localizados em áreas urbanas onde a gravidade do dano e a capacidade econômica do interessado assim o justifiquem.

**Art. 5º, § 4º** {#art5_par4} O PRAD Simplificado poderá ser substituído por projeto gerado automaticamente a partir de novas ferramentas tecnológicas que possam vir a ser disponibilizadas no Sistema Nacional de Cadastro Ambiental Rural - SICAR.

###### Art. 6º {#art6}
Tags: #enquadramento #prad #recuperacao-ambiental

**Art. 6º, caput** {#art6_cpt} O Projeto deverá propor métodos e técnicas a serem empregados de acordo com as peculiaridades de cada área e do dano observado, incluindo medidas que assegurem a proteção das áreas degradadas ou perturbadas de quaisquer fatores que possam dificultar ou impedir o processo de recuperação/restauração, devendo ser utilizados, de forma isolada ou conjunta, preferencialmente aqueles de eficácia já comprovada.

**Art. 6º, § 1º** {#art6_par1} Deverá ser dada atenção especial à proteção e conservação do solo e dos recursos hídricos e, se necessário, técnicas de controle da erosão deverão ser executadas.

**Art. 6º, § 2º** {#art6_par2} O Projeto deverá apresentar embasamento teórico que contemple as variáveis ambientais e seu funcionamento similar ao dos ecossistemas da região.

**Art. 6º, § 3º** {#art6_par3} #enquadramento O Projeto deverá incluir o plantio inicial de no mínimo 5% (cinco por cento) de espécies nativas da vegetação regional, enquadradas em alguma das categorias de ameaça (vulnerável, em perigo, criticamente em perigo ou presumivelmente extinta) conforme lista de espécies da flora ameaçada de extinção do Estado do Paraná.

**Art. 6º, § 4º** {#art6_par4} O Projeto deverá incluir o plantio inicial de no mínimo 40% (quarenta por cento) de espécies zoocóricas nativas da vegetação regional para a atração da fauna, além da aplicação de técnicas que promovam/favoreçam as interações interespecíficas fauna-flora, criando assim um cenário favorável à restauração de áreas degradadas.

**Art. 6º, § 5º** {#art6_par5} Áreas em recuperação, a partir da fase intermediária de desenvolvimento da vegetação, poderão requerer cadastramento junto ao órgão ambiental, seguindo as regulamentações estaduais existentes, como áreas de soltura de animais silvestres (ASAS), a fim de potencializar a recomposição destas áreas mediante as interações fauna- flora.
- **Art. 6º, § 5º, inciso I** {#art6_par5_inc1} Ao que se referem os parágrafos 3º e 4º deste artigo, os percentuais devem ser observados na entrega final do projeto.

###### Art. 7º {#art7}
Tags: #app #monitoramento #prad #recuperacao-ambiental

**Art. 7º, caput** {#art7_cpt} São considerados métodos de restauração ecológica:
- **Art. 7º, caput, inciso I** {#art7_cpt_inc1} Condução da regeneração natural de espécies nativas;
- **Art. 7º, caput, inciso II** {#art7_cpt_inc2} Plantio de espécies nativas;
- **Art. 7º, caput, inciso III** {#art7_cpt_inc3} Plantio de espécies nativas conjugado com a condução da regeneração natural de espécies nativas;
- **Art. 7º, caput, inciso IV** {#art7_cpt_inc4} Plantio intercalado de espécies lenhosas, perenes ou de ciclo longo, exóticas com nativas de ocorrência natural, em até 50% (cinquenta por cento) da área total a ser recomposta.

**Art. 7º, § 1º** {#art7_par1} O restaurador poderá adotar um mix de metodologias visando à inovação e ganho de escala na restauração ecológica, o qual deverá ser considerado como complemento para os métodos descritos no caput do artigo, dentre as quais:
- **Art. 7º, § 1º, inciso I** {#art7_par1_inc1} Semeadura de espécies nativas;
- **Art. 7º, § 1º, inciso II** {#art7_par1_inc2} Transplante de espécies nativas;
- **Art. 7º, § 1º, inciso III** {#art7_par1_inc3} Transposição de serrapilheira;
- **Art. 7º, § 1º, inciso IV** {#art7_par1_inc4} Nucleação;
- **Art. 7º, § 1º, inciso V** {#art7_par1_inc5} Isolamento da área;
- **Art. 7º, § 1º, inciso VI** {#art7_par1_inc6} Outras técnicas, desde que comprovada sua exequibilidade e eficiência.

**Art. 7º, § 2º** {#art7_par2} #monitoramento Todas as metodologias adotadas em forma de mix estarão submetidas ao mesmo protocolo de monitoramento, devendo apresentar os mesmos resultados para seus indicadores ecológicos e avaliação para quitação dos compromissos.

**Art. 7º, § 3º** {#art7_par3} Como ferramenta de apoio para diagnóstico da metodologia adequada à situação ambiental do imóvel, poderá ser utilizada de forma auxiliar, a Chave de Tomada de Decisão, constante do Anexo IV.

**Art. 7º, § 4º** {#art7_par4} O restaurador somente poderá optar pelo método a que se refere o inciso I do caput do artigo quando constatar que há potencial efetivo de regeneração natural na área.

**Art. 7º, § 5º** {#art7_par5} #app O restaurador somente adotará o método a que se refere o inciso IV do caput deste artigo para os projetos de restauração e/ou recomposição de Área de Preservação Permanente, da Área de Uso Restrito e da Reserva Legal, ou que incidam sobre a mesma, para os casos previstos na Lei Federal nº 12.651 de 2012.

###### Art. 8º {#art8}
Tags: #prad #recuperacao-ambiental

**Art. 8º, caput** {#art8_cpt} Os indicadores específicos apresentados no Anexo III desta Portaria são finalísticos e podem ser aplicados a qualquer metodologia de restauração ecológica tratada nesta Portaria.

###### Art. 9º {#art9}
Tags: #prad #recuperacao-ambiental

**Art. 9º, caput** {#art9_cpt} A metodologia de restauração ecológica deve ser compatível com o diagnóstico ambiental da área, levando-se em conta as restrições legais incidentes sobre a mesma.

###### Art. 10 {#art10}
Tags: #prad #recuperacao-ambiental

**Art. 10, caput** {#art10_cpt} Para todos os métodos, os indivíduos provenientes de regeneração de espécies nativas que forem constatados na área deverão ser conduzidos conforme procedimentos indicados para a manutenção dos indivíduos plantados, visando ao seu estabelecimento e desenvolvimento.

**Art. 10, parágrafo único** {#art10_par1u} A manutenção das mudas plantadas ou regenerantes dar-se-á mediante técnicas que garantam o seu bom desenvolvimento, principalmente através do coroamento, adubação, controle de formigas cortadeiras, controle de espécies competidoras e controle fitossanitário.

###### Art. 11 {#art11}
Tags: #prad #prazo #recuperacao-ambiental #responsavel-tecnico

**Art. 11, caput** {#art11_cpt} #prazo #responsavel-tecnico Para os métodos a que se referem os incisos II e III do caput do Art. 7º, poderá ser realizado o cultivo intercalar temporário de espécies exóticas sem potencial de invasão, herbáceas ou arbustivas, tais como culturas agrícolas anuais ou espécies de adubação verde por até 2 (dois) anos, como estratégia de manutenção da área a fim de auxiliar o controle de gramíneas com potencial de invasão e favorecer o estabelecimento da vegetação nativa.

###### Art. 12 {#art12}
Tags: #prad #recuperacao-ambiental

**Art. 12, caput** {#art12_cpt} Nas ações de restauração ecológica não poderão ser utilizadas espécies exóticas invasoras constantes na legislação estadual vigente.

**Art. 12, § 1º** {#art12_par1} Quando houver presença de espécies vegetais exóticas com potencial de invasão sejam herbáceas, arbustivas ou arbóreas, o restaurador deverá adotar medidas de controle de modo a não comprometer o ecossistema em restauração, devendo as medidas ser informadas ao Instituto Água e Terra.

**Art. 12, § 2º** {#art12_par2} Em caso de ocorrência de espécies nativas e regenerantes nativos nas áreas de remoção de exóticas invasoras, o interessado está obrigado a informar ao Instituto Água e Terra e deverá adotar medidas de erradicação das exóticas invasoras que não comprometam a sobrevivência dos indivíduos nativos ou através do manejo de mínimo impacto.

### CAPÍTULO III – DA SUBMISSÃO DO PROJETO

###### Art. 13 {#art13}
Tags: #documentacao #prad #prazo #recuperacao-ambiental #responsavel-tecnico

**Art. 13, caput** {#art13_cpt} #documentacao O PRAD, a ser elaborado de acordo com os TR constantes do Anexo I e II, deverá ser protocolado em qualquer unidade regional ou local do Instituto Água e Terra via protocolo digital, acompanhado dos originais ou cópia dos seguintes documentos:
- **Art. 13, caput, inciso I** {#art13_cpt_inc1} Fotocópias da Carteira de Identidade e do CPF de pessoa física, e do Contrato Social, se pessoa jurídica;
- **Art. 13, caput, inciso II** {#art13_cpt_inc2} #documentacao #prazo Certidão do Cartório de Registro de Imóveis, devidamente atualizada (até 90 dias) ou documento hábil expedido pelo Poder Público, se terra pública, ou prova de justa posse;
- **Art. 13, caput, inciso III** {#art13_cpt_inc3} #responsavel-tecnico Anotação de Responsabilidade Técnica - ART, devidamente recolhida, do(s) técnico(s) responsável(is) pela elaboração e execução do PRAD, exceto nos casos previstos no § 1º do Art. 5º desta Portaria;
- **Art. 13, caput, inciso III** {#art13_cpt_inc3-dup2} #responsavel-tecnico Mapa com informações georreferenciadas de todos os vértices das áreas do imóvel e das áreas no interior do imóvel a restaurar, a fim de delimitar a (s) poligonal (ais), utilizando o DATUM SIRGAS 2000, e no caso previsto no Parágrafo 1º do Art. 5º desta Portaria podendo também ser obtidos via plataformas gratuitas e disponíveis na WEB;
- **Art. 13, caput, inciso IV** {#art13_cpt_inc4} Croqui que possibilite o acesso ao imóvel rural, contendo o endereço do interessado e, sempre que possível, as coordenadas de localização da sede do imóvel;
- **Art. 13, caput, inciso V** {#art13_cpt_inc5} Comprovante de recolhimento da taxa ambiental (Inspeção Florestal + Análise de Projeto);
- **Art. 13, caput, inciso VI** {#art13_cpt_inc6} Quando aplicável, cópia do Termo de Ajustamento de Conduta - TAC ou Termo de Compromisso - TC, devidamente assinado pelo interessado;
- **Art. 13, caput, inciso VII** {#art13_cpt_inc7} Quando aplicável, cópia do Auto de Infração Ambiental, com o termo de reparação de danos;
- **Art. 13, caput, inciso VIII** {#art13_cpt_inc8} Quando aplicável, cópia da Licença Ambiental, com a condicionante descrevendo a necessidade de recuperação ambiental;
- **Art. 13, caput, inciso IX** {#art13_cpt_inc9} Quando aplicável, cópia da Autorização Ambiental para a supressão de vegetação nativa;
- **Art. 13, caput, inciso X** {#art13_cpt_inc10} Quando aplicável, cópia do Projeto financiado com recursos públicos, aprovado pelo estabelecimento bancário;
- **Art. 13, caput, inciso XI** {#art13_cpt_inc11} Fotografias do local, antes e após a implantação do PRAD.

###### Art. 14 {#art14}
Tags: #prad #recuperacao-ambiental

**Art. 14, caput** {#art14_cpt} A existência de irregularidade da propriedade ou posse não impede a aprovação do PRAD ou do PRAD Simplificado conforme esta Portaria.

###### Art. 15 {#art15}
Tags: #prad #recuperacao-ambiental

**Art. 15, caput** {#art15_cpt} O PRAD poderá contemplar peculiaridades locais sem necessariamente atender todas as diretrizes e orientações técnicas constantes nos TR, desde que tecnicamente justificado.

### CAPÍTULO IV – DA ANÁLISE E APROVAÇÃO

###### Art. 16 {#art16}
Tags: #monitoramento #prad #recuperacao-ambiental

**Art. 16, caput** {#art16_cpt} #monitoramento A instância de análise e acompanhamento do PRAD e do PRAD Simplificado dentro do Instituto Água e Terra será a Gerência Regional de Bacia Hidrográfica, Núcleo Regional afetado ou Diretoria solicitante.

**Art. 16, parágrafo único** {#art16_par1u} O Gerente Regional de Bacia Hidrográfica ou Chefe de Núcleo Regional deverá designar um servidor ou equipe responsável pela análise do PRAD e realização de vistoria, se necessário.

###### Art. 17 {#art17}
Tags: #monitoramento #prad #recuperacao-ambiental #responsavel-tecnico

**Art. 17, caput** {#art17_cpt} #monitoramento #responsavel-tecnico A Gerência Regional de Bacia Hidrográfica ou Núcleo Regional responsável pela análise e acompanhamento do PRAD, conforme disposto no Art. 9º, caso necessário, poderá solicitar adequações ou complementações no projeto ao proponente, apontando as alterações ou complementações necessárias à adequação do projeto.

###### Art. 18 {#art18}
Tags: #app #prad #recuperacao-ambiental

**Art. 18, caput** {#art18_cpt} Depois de sanadas eventuais pendências apontadas pela análise técnica, caberá ao técnico da Gerência Regional de Bacia Hidrográfica ou Núcleo Regional designado para análise, manifestar-se conclusivamente quanto à aprovação do projeto.

**Art. 18, § 1º** {#art18_par1} A comunicação da aprovação do PRAD se dará por ofício ao interessado, enviado via postal com aviso de recebimento ou entregue em mãos com comprovação mediante ciência no próprio ofício.

**Art. 18, § 2º** {#art18_par2} #app Para os PRAD e os PRAD Simplificados que têm como finalidade a regularização da Reserva Legal, Uso Restrito e de Áreas de Preservação Permanente do Programa de Regularização Ambiental – PRA, previstos na [[lei-federal-12651-2012|Lei Federal nº 12.651 de 25 de maio de 2012]], os proprietários e possuidores de imóveis rurais deverão assinar Termo de Compromisso de Adesão ao PRA, emitido pelo Sistema Nacional de Cadastro Ambiental Rural – SICAR.

### CAPÍTULO V – DO MONITORAMENTO

###### Art. 19 {#art19}
Tags: #enquadramento #prad #prazo #recuperacao-ambiental

**Art. 19, caput** {#art19_cpt} #enquadramento Os parâmetros avaliados em cada projeto terão seus valores aferidos para cada um dos indicadores ecológicos, a partir dos dados obtidos em campo e informados pelo restaurador, e serão comparados, pelo órgão ambiental, com os valores intermediários de referência previstos no Anexo III e classificados em 3 (três) níveis de adequação:
- **Art. 19, caput, inciso I** {#art19_cpt_inc1} #prazo Adequado: quando forem atingidos os valores esperados para o prazo determinado;
- **Art. 19, caput, inciso II** {#art19_cpt_inc2} #prazo Mínimo: quando os valores estiverem dentro da margem de tolerância para o prazo determinado e cumprirem as exigências mínimas, porém os valores sejam inferiores ao esperado, o que indica a necessidade da realização de ações corretivas visando não comprometer os resultados futuros;
- **Art. 19, caput, inciso III** {#art19_cpt_inc3} #prazo Crítico: quando não forem atingidos os valores mínimos esperados no prazo determinado, caso em que será exigida a readequação do projeto por meio da realização de ações corretivas.

###### Art. 20 {#art20}
Tags: #monitoramento #prad #recuperacao-ambiental

**Art. 20, caput** {#art20_cpt} #monitoramento O Relatório de Monitoramento para fins de acompanhamento periódico deverá ser apresentado conforme Anexo V da presente Portaria.

###### Art. 21 {#art21}
Tags: #monitoramento #prad #recuperacao-ambiental

**Art. 21, caput** {#art21_cpt} #monitoramento Os parâmetros utilizados para acompanhamento periódico e quitação do cumprimento dos compromissos de restauração serão baseados no atendimento aos indicadores ecológicos dispostos no Anexo III desta Portaria.

###### Art. 22 {#art22}
Tags: #app #monitoramento #prad #prazo #recuperacao-ambiental

**Art. 22, caput** {#art22_cpt} #monitoramento O restaurador deverá monitorar periodicamente as áreas em restauração até o alcance dos indicadores ecológicos estabelecidos para a quitação no Anexo III desta Portaria.

**Art. 22, § 1º** {#art22_par1} #monitoramento #prazo O restaurador fica compromissado de encaminhar ao Órgão Ambiental o monitoramento periódico nos seguintes anos a contar da data de aprovação do PRAD:
- **Art. 22, § 1º, inciso I** {#art22_par1_inc1} #prazo 3 anos;
- **Art. 22, § 1º, inciso II** {#art22_par1_inc2} #prazo 5 anos;
- **Art. 22, § 1º, inciso III** {#art22_par1_inc3} #prazo 10 anos;
- **Art. 22, § 1º, inciso IV** {#art22_par1_inc4} #prazo 15 anos;
- **Art. 22, § 1º, inciso V** {#art22_par1_inc5} #prazo 20 anos.

**Art. 22, § 2º** {#art22_par2} #app #prazo Para Áreas de Preservação Permanente e para demais casos oriundos de demandas não voluntárias, o prazo de entrega dos relatórios será:
- **Art. 22, § 2º, inciso I** {#art22_par2_inc1} #prazo 3 anos;
- **Art. 22, § 2º, inciso II** {#art22_par2_inc2} #prazo 5 anos;
- **Art. 22, § 2º, inciso III** {#art22_par2_inc3} #prazo 10 anos.

###### Art. 23 {#art23}
Tags: #prad #recuperacao-ambiental

**Art. 23, caput** {#art23_cpt} O não atingimento do conceito estipulado no artigo anterior implica a manutenção do compromisso e na obrigação do restaurador em aplicar medidas corretivas para adequação dos projetos.

###### Art. 24 {#art24}
Tags: #monitoramento #prad #recuperacao-ambiental

**Art. 24, caput** {#art24_cpt} #monitoramento O Instituto Água e Terra deverá analisar os Relatórios de Monitoramento para fins de acompanhamento e poderá solicitar ações corretivas sempre que julgar que os projetos não estão tendo desenvolvimento adequado.

**Art. 24, parágrafo único** {#art24_par1u} O Instituto Água e Terra poderá realizar vistorias na área, sempre que julgar necessário, visando constatar em campo os dados apresentados nos relatórios.

### CAPÍTULO VI – DISPOSIÇÕES FINAIS

###### Art. 25 {#art25}
Tags: #prad #recuperacao-ambiental

**Art. 25, caput** {#art25_cpt} Mesmo após a conclusão do PRAD, fica mantida a responsabilidade do proprietário ou possuidor das áreas particulares ou públicas onde foram realizados os projetos de adotar medidas de proteção e conservação das florestas restauradas, nos termos da legislação vigente.

###### Art. 26 {#art26}
Tags: #prad #recuperacao-ambiental #responsavel-tecnico

**Art. 26, caput** {#art26_cpt} #responsavel-tecnico As exigências contidas nesta Portaria aplicam-se aos compromissos de restauração oriundos de demandas não voluntárias especificadas no Art. 3º desta Portaria ainda vigentes e aqueles firmados a partir da data da sua publicação.

###### Art. 27 {#art27}
Tags: #monitoramento #prad #recuperacao-ambiental

**Art. 27, caput** {#art27_cpt} As iniciativas de restauração ecológica provenientes de ações voluntárias poderão utilizar os parâmetros e metodologias apresentados nesta Portaria como ferramenta de apoio à sua gestão.

**Art. 27, parágrafo único** {#art27_par1u} #monitoramento O registro das ações voluntárias de restauração ecológica não implicará obrigatoriedade quanto às exigências de execução ou monitoramento previstas nesta Portaria.

###### Art. 28 {#art28}
Tags: #prad #recuperacao-ambiental

**Art. 28, caput** {#art28_cpt} Os anexos da presente Portaria serão disponibilizados no endereço eletrônico do http://www.iat.pr.gov.br.

###### Art. 29 {#art29}
Tags: #prad #recuperacao-ambiental

**Art. 29, caput** {#art29_cpt} Esta Portaria entra em vigor na data da sua publicação, ficando revogadas todas as disposições em contrário.


## Fecho

EVERTON LUIZ DA COSTA E SOUZA Diretor Presidente do Instituto Água e Terra

### Termo de Referência - TR {#anexo1}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Termo de Referência Simplificado - TRS {#anexo2}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Indicadores de Monitoramento {#anexo3}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Chave de Tomada de Decisão {#anexo4}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

### Relatório de Monitoramento {#anexo5}

Anexo citado no PDF, sem conteúdo integral incluído no documento fornecido. Transcrição pendente.

## Histórico de alterações

| Norma | Dispositivo | Alteração |
|---|---|---|

## Notas de transcrição

- Fonte: PDF fornecido pelo usuário (portaria IAT 170 2020.pdf). Texto obtido pela extração textual do documento; cabeçalhos repetidos e marcadores de página removidos. A conferência palavra por palavra contra os bytes do PDF e a verificação de tachados não puderam ser concluídas nesta sessão.
- As quebras de linha foram recompostas. Os rótulos foram normalizados para IDs LexML; erros de redação do original foram preservados. Esta conversão requer revisão antes da incorporação ao acervo.
- Anexo próprio citado ou vinculado em arquivo separado, sem o respectivo conteúdo no PDF do lote. Não foi importado material externo ou presumida sua redação.
- Revisão de numeração: ID duplicado: art13_cpt_inc3. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Revisão de numeração: sequência de inciso: art13_cpt_inc3-dup2 após art13_cpt_inc3. Numeração/texto preservados; sufixo técnico -dup identifica ocorrências repetidas sem as eliminar.
- Cláusula genérica de revogação: não foram atribuídas revogações tácitas por inferência; exige decisão humana.
