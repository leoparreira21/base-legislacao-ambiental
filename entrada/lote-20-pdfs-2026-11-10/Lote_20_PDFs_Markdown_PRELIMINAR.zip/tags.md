# Tags da base

Gerado por `python scripts/validar.py --tags`. Formato: minúsculas, sem acento, singular, hífen entre palavras.

| Tag | Normas que usam |
|---|---|
| `#agrotoxico` | 1 |
| `#agua-subterranea` | 6 |
| `#app` | 12 |
| `#armazenamento-agrotoxico` | 1 |
| `#autorizacao-ambiental` | 1 |
| `#autorizacao-florestal` | 5 |
| `#avicultura` | 1 |
| `#biodigestor` | 1 |
| `#biogas` | 1 |
| `#cemiterio` | 1 |
| `#definicao` | 20 |
| `#documentacao` | 18 |
| `#efluente` | 12 |
| `#eia-rima` | 13 |
| `#empreendimento-imobiliario` | 2 |
| `#energia-eletrica` | 1 |
| `#enquadramento` | 16 |
| `#geracao-energia` | 1 |
| `#incluido` | 1 |
| `#interesse-social` | 1 |
| `#irrigacao` | 1 |
| `#las` | 10 |
| `#li` | 12 |
| `#licenciamento-ambiental` | 18 |
| `#lo` | 12 |
| `#logistica-reversa` | 2 |
| `#lp` | 12 |
| `#mata-atlantica` | 2 |
| `#monitoramento` | 6 |
| `#outorga` | 6 |
| `#parcelamento-solo` | 1 |
| `#patio-caminhao` | 1 |
| `#pilha-bateria` | 1 |
| `#prad` | 1 |
| `#prazo` | 16 |
| `#proibicao` | 12 |
| `#recuperacao-ambiental` | 1 |
| `#recurso-hidrico` | 1 |
| `#redacao-alterada` | 5 |
| `#renovacao` | 12 |
| `#residuo-solido` | 12 |
| `#residuo-solido-urbano` | 2 |
| `#responsavel-tecnico` | 17 |
| `#revogado` | 1 |
| `#supressao-vegetacao` | 1 |
| `#transbordo` | 1 |
| `#triagem` | 1 |
| `#unidade-conservacao` | 1 |
| `#vegetacao` | 1 |
| `#zona-amortecimento` | 1 |
